package fr.gouv.justice.cpn.commun.model;


import fr.gouv.justice.cpn.commun.model.enumeration.Status;

import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;
import java.util.StringJoiner;

public class DemandeEnvoiMessageStatutDTO implements Serializable {

    private Long id;

    private Status statutCode;

    private Integer responseCode;

    private Instant dateStatut;

    private String traitementMessage;

    private String cause;

    private Long messageId;

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DemandeEnvoiMessageStatutDTO demandeEnvoiMessageStatutDTO = (DemandeEnvoiMessageStatutDTO) o;
        if (demandeEnvoiMessageStatutDTO.getId() == null || getId() == null) {
            return false;
        }

        return Objects.equals(getId(), demandeEnvoiMessageStatutDTO.getId());
    }

    public String getCause() {
        return cause;
    }

    public Instant getDateStatut() {
        return dateStatut;
    }

    public Long getId() {
        return id;
    }

    public Long getMessageId() {
        return messageId;
    }

    public Integer getResponseCode() {
        return responseCode;
    }

    public Status getStatutCode() {
        return statutCode;
    }

    public String getTraitementMessage() {
        return traitementMessage;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    public void setCause(String cause) {
        this.cause = cause;
    }

    public void setDateStatut(Instant dateStatut) {
        this.dateStatut = dateStatut;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setMessageId(Long messageId) {
        this.messageId = messageId;
    }

    public void setResponseCode(Integer responseCode) {
        this.responseCode = responseCode;
    }

    public void setStatutCode(Status statutCode) {
        this.statutCode = statutCode;
    }

    public void setTraitementMessage(String traitementMessage) {
        this.traitementMessage = traitementMessage;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", DemandeEnvoiMessageStatutDTO.class.getSimpleName() + "[", "]")
                .add("id=" + id)
                .add("statutCode=" + statutCode)
                .add("responseCode=" + responseCode)
                .add("dateStatut=" + dateStatut)
                .add("traitementMessage='" + traitementMessage + "'")
                .add("cause='" + cause + "'")
                .add("messageId=" + messageId)
                .toString();
    }
}
