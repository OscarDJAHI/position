package fr.gouv.justice.cpn.commun.model;

public class ProcedureMetadataPpnKeys {

    public static final String CODE_NIVEAU_ORGATNISATION_2 = "ppn:codeNiveauOrganisation2";
    public static final String CODE_NIVEAU_ORGATNISATION_1 = "ppn:codeNiveauOrganisation1";
    public static final String CODE_NIVEAU_ORGATNISATION_3 = "ppn:codeNiveauOrganisation3";
    public static final String CODE_NIVEAU_ORGATNISATION_4 = "ppn:codeNiveauOrganisation4";
    public static final String CODE_NIVEAU_ORGATNISATION_5 = "ppn:codeNiveauOrganisation5";
    public static final String CODE_NIVEAU_ORGATNISATION_6 = "ppn:codeNiveauOrganisation6";
    public static final String DATE_DERNIERE_MISE_A_JOUR   = "ppn:dateDerniereMiseAjour";
    public static final String ID_PARQUET                  = "ppn:idParquet";
    public static final String NOM_DPN                     = "ppn:nomDpn";
    public static final String NOM_JURIDICTION             = "ppn:nomJuridiction";
    public static final String TYPE_DOSSIER                = "ppn:typeDossier";
    public static final String TYPE_ID_DPN                 = "ppn:typeIdDpn";
    public static final String UNA_UPVA                    = "ppn:unaUpva";
    public static final String VALEUR_ID_DPN               = "ppn:valeurIdDpn";
    public static final String CHEMIN            = "ppn:chemin";
    public static final String DATE_DERNIERE_MAJ = "ppn:dateDerniereMAJ";
    public static final String ETAT_FICHIER      = "ppn:etatFichier";
    public static final String ID_NOEUD_NPP      = "ppn:idNoeudNPP";
    public static final String NOM_FICHIER       = "ppn:nomFichier";
    public static final String TYPE_FICHIER      = "ppn:typeFichier";
    private ProcedureMetadataPpnKeys() {
    }


}
