package fr.gouv.justice.cpn.commun.model;


import fr.gouv.justice.cpn.commun.beans.generic.ResponseDTO;
import fr.gouv.justice.cpn.commun.model.enumeration.Status;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.springframework.http.HttpStatus;

import java.time.Instant;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DemandeEnvoiMessageResponseDTO extends ResponseDTO {

    private Status status;

    public static DemandeEnvoiMessageResponseDTO empty(final String message) {
        final DemandeEnvoiMessageResponseDTO response = new DemandeEnvoiMessageResponseDTO();
        response.setDate(Instant.now());
        response.setStatus(Status.ECHEC);
        response.setCode(HttpStatus.NO_CONTENT.value());
        response.setMessage(message);

        return response;
    }
}
