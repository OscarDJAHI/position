package fr.gouv.justice.cpn.commun.beans.journal.reception.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.time.Instant;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class SousServiceDTO extends AbstractBaseDTO {

    private Long serviceId;

    private String serviceLibelle;

    private Instant dateCreation;

    private Boolean favori;

    private boolean deletable;
}
