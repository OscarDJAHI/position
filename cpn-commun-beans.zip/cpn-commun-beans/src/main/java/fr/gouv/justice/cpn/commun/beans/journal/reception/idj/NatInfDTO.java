package fr.gouv.justice.cpn.commun.beans.journal.reception.idj;

import lombok.Data;

import java.util.List;

@Data
public class NatInfDTO {
    private String       dateNatInf;
    private List<String> natInfsAp;
    private List<String> natInfsAv;
}
