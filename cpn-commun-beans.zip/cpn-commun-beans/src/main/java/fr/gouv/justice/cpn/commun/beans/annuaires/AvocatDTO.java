package fr.gouv.justice.cpn.commun.beans.annuaires;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.time.Instant;

@Data
public class AvocatDTO implements Serializable {

    private String codeCnbf;

    private String nom;

    private String prenom;

    private String barreauLibelle;

    private String vestiaire;

    private String formeJuridique;

    private String rs;

    private String toque;

    private boolean actif;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant dateDerniereMaj;

    private String adresse;

    private String complementAdresse;

    private String codePostal;

    private String ville;

    private String telephone;

    private String email;

    private String fax;
}
