package fr.gouv.justice.cpn.commun.beans.journal.reception.dto;

import lombok.Data;

@Data
public class OrientationPenaleDTO {

    private String deferrement;

    private String libelleCourt;

    private String libelleLong;

    private String miseEnCause;

    private String priorisationNumerique;

    private String texte;
}
