package fr.gouv.justice.cpn.commun.beans.journal.reception.dto;

import fr.gouv.justice.cpn.commun.beans.journal.reception.enumeration.StatutProcedureJournal;
import fr.gouv.justice.cpn.commun.beans.journal.reception.enumeration.TypeProcedure;
import lombok.Builder;
import lombok.Data;

import java.time.Instant;

@Data
@Builder
public class ViewProcedureApiDTO {

    private Long id;

    private StatutProcedureJournal etat;

    private String numeroProcedure;

    private String codeSrj;

    private String libelleUnite;

    private String commentaire;

    private Instant dateCreation;

    private String nomDossier;

    private Boolean multi;

    private Boolean urgence;

    private String orientation;

    private String codeOrientation;

    private String service;

    private String sousService;

    private String couleur;

    private TypeProcedure typeProcedure;

    private String idSps;

    private String idj;

    private String uri;
}
