package fr.gouv.justice.cpn.commun.beans.message;

import lombok.Data;

import java.time.Instant;

@Data
public class MessageActionHistoryDTO {

    private Long id;

    private Long messageId;

    private Instant dateAction;

    private TypeAction typeAction;

    private String actionBy;
}
