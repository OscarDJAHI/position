package fr.gouv.justice.cpn.commun.beans.storage;

import lombok.Data;

@Data
public class ProxyStorageUploadRequest extends ProxyStorageRequest {
    private String  document;
    private String  extension;
    private String  path;
    private Integer versionsToKeep;
}
