package fr.gouv.justice.cpn.commun.model;

import lombok.Data;

import java.time.ZonedDateTime;

@Data
public class IdjParamsWrapper {
    private String        idApplication;
    private String        servDemandeur;
    private String        libelleServDemandeur;
    private String        refProcAjout;
    private ZonedDateTime dateRef;
    private String        serviceActif;
    private String        libelleServActif;
}
