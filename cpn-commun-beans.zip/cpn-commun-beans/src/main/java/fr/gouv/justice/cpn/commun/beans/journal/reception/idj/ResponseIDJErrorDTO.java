package fr.gouv.justice.cpn.commun.beans.journal.reception.idj;

import lombok.Data;

@Data
public class ResponseIDJErrorDTO {
    private String codeErreur;
    private String message;
}
