package fr.gouv.justice.cpn.commun.beans.journal.reception.dto;

import fr.gouv.justice.cpn.commun.beans.journal.reception.enumeration.StatutProcedureJournal;
import fr.gouv.justice.cpn.commun.beans.journal.reception.enumeration.TypeProcedure;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.time.Instant;
import java.util.HashSet;
import java.util.Set;

@Data
public class ProcedureDTO {

    private Long id;

    private StatutProcedureJournal etat;

    private String numeroProcedure;

    private String codeSrj;

    private String version;

    private String idSps;

    private String codeUnite;

    private String libelleUnite;

    private String commentaire;

    private Instant dateCreation;

    private Integer anneeProcedure;

    private String nomDossier;

    private String numeroProcedureFormate;

    @NotNull
    private RefSourceDTO refSource;

    private Set<ProcedureIssueDTO> procedureIssues = new HashSet<>();

    private Set<ProcedureHistoEtatDTO> procedureHistoEtats = new HashSet<>();

    private Set<ProcedureFichierDTO> procedureFichiers = new HashSet<>();

    private Boolean multi;

    private Boolean urgence;

    private String nomOriginalCapsule;

    private String cepnNomCapsule;

    private Instant dateExtraction;

    private Instant dateTransmission;

    private Instant dateCloture;

    private String codeInsee;

    private String juridiction;

    private TypeProcedure typeProcedure;

    private String idAffaire;

    private String idj;

    private String uri;

    private Instant dateReservation;
}
