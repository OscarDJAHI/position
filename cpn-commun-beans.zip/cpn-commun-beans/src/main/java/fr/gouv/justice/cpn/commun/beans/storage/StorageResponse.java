package fr.gouv.justice.cpn.commun.beans.storage;

import lombok.Data;

import java.io.ByteArrayOutputStream;
import java.util.Map;

@Data
public class StorageResponse {
    private boolean               sucess;
    private String                path;
    private ByteArrayOutputStream file;
    private Map<String, String>   filesNamesAndUri;
    private String message;
}
