package fr.gouv.justice.cpn.commun.beans.demande.envoi.npp;

/**
 * The Fonction enumeration.
 */
public enum FonctionEnum {
    A,
    I,
    R,
    U
}
