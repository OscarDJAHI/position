package fr.gouv.justice.cpn.commun.beans.message;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import fr.gouv.justice.cpn.commun.beans.message.detail.AuditDTO;
import fr.gouv.justice.cpn.commun.beans.message.detail.FileDTO;
import fr.gouv.justice.cpn.commun.beans.message.detail.RecipientDTO;
import fr.gouv.justice.cpn.commun.beans.message.detail.SenderDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@ApiModel(description = "Modele servant a la visualisation lors de l'ouverture d'un message")
@Data
public class MessageDTO {

    @ApiModelProperty(example = "2", value = "L'identifiant unique du message")
    @JsonProperty("id")
    private String messageId;

    @ApiModelProperty(example = "simple", value = "Type de message")
    private String type;

    @ApiModelProperty(example = "Message important", value = "L'objet du message")
    private String subject;

    @ApiModelProperty(example = "Voici le fichier demande", value = "Corps du message / Commentaire")
    private String comment;

    @ApiModelProperty(example = "janedo@acme.ltd", value = "Adresse mail de l'emetteur")
    private SenderDTO sender;

    @ApiModelProperty(value = "Liste des destinataires, array de String (cet attribut est mutuellement exclusif avec id/type).")
    private List<RecipientDTO> recipients;

    @ApiModelProperty(example = "02/06/2020 11:51:10", value = "La date et heure de creation du message")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime date;

    @ApiModelProperty(example = "10/06/2020 11:51:10", value = "La date et heure d'expiration du message")
    @JsonProperty("expiration_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime expirationDate;

    @ApiModelProperty(example = "0", value = "Indique si le message est crypte 1 si oui et 0 si non")
    private int encrypted;

    @ApiModelProperty(example = "0", value = "Indique si le message est signe 1 si oui et 0 si non")
    private int signed;

    @ApiModelProperty(example = "0", value = "Indique si le message est supprime 1 si oui et 0 si non")
    private boolean deleted;

    @ApiModelProperty(example = "NO_PREARCHIVING", value = "Status concernant l'archivage du message")
    @JsonProperty("pre_archiving_status")
    private String preArchivingStatus;

    @ApiModelProperty(value = "Liste des pieces jointes, array de Files (cet attribut est mutuellement exclusif avec index/name).")
    private List<FileDTO> files;

    @ApiModelProperty(example = "https://telecheger-moi-ici.com/pj", value = "L'url de telechargement des pieces jointes du message")
    @JsonProperty("download_url")
    private String downloadUrl;

    @ApiModelProperty(example = "https://ouverture-message.com", value = "L'url d'ouverture du message")
    @JsonProperty("access_url")
    private String accessUrl;

    @ApiModelProperty(example = "32325", value = "Taille du message")
    private String size;

    @ApiModelProperty(example = "root@localhoste.fr", value = "Email de reference")
    private String email;

    @ApiModelProperty(value = "Ensemble d'objets permettant la visulisation du status du message (vu) et de sa/ses piece(s) jointe(s) (telechargee(s)).")
    private AuditDTO audit;

    private String idExterne;

    private String originMessage;
}
