package fr.gouv.justice.cpn.commun.beans.demande.envoi.npp;

import fr.gouv.justice.cpn.commun.beans.message.MessageOriginEnum;
import lombok.Data;

@Data
public class DemandeEnvoiDocumentNppMessageDTO {

    private Long id;

    private String idExterne;

    private MessageOriginEnum origine;

    private String email;

    private String emailBs;

    private Long demandeId;
}
