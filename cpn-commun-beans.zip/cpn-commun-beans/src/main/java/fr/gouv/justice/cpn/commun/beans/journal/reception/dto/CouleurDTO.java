package fr.gouv.justice.cpn.commun.beans.journal.reception.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.validation.constraints.NotNull;
import java.time.Instant;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class CouleurDTO extends AbstractBaseDTO {

    private String code;

    @NotNull
    private String codeSrj;

    private Instant dateCreation;

    private boolean deletable;
}
