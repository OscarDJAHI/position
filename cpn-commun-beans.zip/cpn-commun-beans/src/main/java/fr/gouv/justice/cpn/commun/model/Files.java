package fr.gouv.justice.cpn.commun.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

public class Files {

    @JsonProperty("index")
    private int index;

    @JsonProperty("name")
    private String name;

    @JsonProperty("size")
    private String size;

    @JsonProperty("download_url")
    private String downloadUrl;

    @JsonProperty("digest")
    private String digest;

    @ApiModelProperty(example = "ftyu20daef81ebbd754f11153fe0d2f1f10b67aed1bc87f3fc5b72a3065", value = "Codage de la piece jointe")
    public String getDigest() {
        return this.digest;
    }

    @ApiModelProperty(example = "https://telecharger-moi-ici.com", value = "L'url de telechargement de la piece jointe")
    public String getDownloadUrl() {
        return this.downloadUrl;
    }

    @ApiModelProperty(example = "0", value = "L'index lie a la piece jointe")
    public int getIndex() {
        return this.index;
    }

    @ApiModelProperty(example = "Objectifs du Projet", value = "Le nom de la piece jointe")
    public String getName() {
        return this.name;
    }

    @ApiModelProperty(example = "32115", value = "Taille de la piece jointe")
    public String getSize() {
        return this.size;
    }

    public void setDigest(String digest) {
        this.digest = digest;
    }

    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSize(String size) {
        this.size = size;
    }
}
