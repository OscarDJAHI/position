package fr.gouv.justice.cpn.commun.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

public class Recipients {

    @JsonProperty("index")
    private int index;

    @JsonProperty("email")
    private String email;

    @JsonProperty("uid")
    private String userId;

    @JsonProperty("domain")
    private String domain;

    @JsonProperty("type")
    private String type;

    @ApiModelProperty(example = "CPN", value = "Le domaine vers lequel est destine l'envoi")
    public String getDomain() {
        return this.domain;
    }

    @ApiModelProperty(example = "johndoe@acme.dtl", value = "Email du destinataire")
    public String getEmail() {
        return this.email;
    }

    @ApiModelProperty(example = "0", value = "L'index attribue au destinataire du message")
    public int getIndex() {
        return this.index;
    }

    @ApiModelProperty(example = "registered", value = "Type ")
    public String getType() {
        return this.type;
    }

    @ApiModelProperty(example = "johneo@acme.dtl", value = "Identite du destinataire")
    public String getUserId() {
        return this.userId;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
