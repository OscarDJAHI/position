package fr.gouv.justice.cpn.commun.model;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

@ApiModel(description = "Modele servant a la visualisation lors de l'ouverture d'un message")
public class MessageApi {

    @JsonProperty("id")
    private String messageId;

    @JsonProperty("type")
    private String type;

    @JsonProperty("subject")
    private String subject;

    @JsonProperty("comment")
    private String comment;

    @JsonProperty("sender")
    private SenderDTO sender;

    @JsonProperty("recipients")
    private List<Recipients> recipients;

    @JsonProperty("date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private LocalDateTime date;

    @JsonProperty("expiration_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private LocalDateTime expirationDate;

    @JsonProperty("encrypted")
    private int encrypted;

    @JsonProperty("signed")
    private int signed;

    @JsonProperty("pre_archiving_status")
    private String preArchivingStatus;

    @JsonProperty("files")
    private List<Files> files;

    @JsonProperty("download_url")
    private String downloadUrl;

    @JsonProperty("access_url")
    private String accessUrl;

    @JsonProperty("size")
    private String size;

    @JsonProperty("email")
    private String email;

    @JsonProperty("audit")
    private Audit audit;

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        MessageApi that = (MessageApi) o;
        return Objects.equals(messageId, that.messageId);
    }

    @ApiModelProperty(example = "https://ouverture-message.com", value = "L'url d'ouverture du message")
    public String getAccessUrl() {
        return this.accessUrl;
    }

    @ApiModelProperty(value = "Ensemble d'objets permettant la visulisation du status du message (vu) et" +
            " de sa/ses piece(s) jointe(s) (telechargee(s)).")
    public Audit getAudit() {
        return this.audit;
    }

    @ApiModelProperty(example = "Voici le fichier demande", value = "Corps du message / Commentaire")
    public String getComment() {return comment;}

    @ApiModelProperty(example = "02/06/2020 11:51:10", value = "La date et heure de creation du message")
    public LocalDateTime getDate() {
        return this.date;
    }

    @ApiModelProperty(example = "https://telecheger-moi-ici.com/pj",
                      value = "L'url de telechargement des pieces jointes du message")
    public String getDownloadUrl() {
        return this.downloadUrl;
    }

    @ApiModelProperty(example = "root@localhoste.fr", value = "Email de reference")
    public String getEmail() {
        return this.email;
    }

    @ApiModelProperty(example = "0", value = "Indique si le message est crypte 1 si oui et 0 si non")
    public int getEncrypted() {
        return this.encrypted;
    }

    @ApiModelProperty(example = "10/06/2020 11:51:10", value = "La date et heure d'expiration du message")
    public LocalDateTime getExpirationDate() {
        return this.expirationDate;
    }

    @ApiModelProperty(
            value = "Liste des pieces jointes, array de Files (cet attribut est mutuellement exclusif avec index/name).")
    public List<Files> getFiles() {
        return this.files;
    }

    @ApiModelProperty(example = "2", value = "L'identifiant unique du message")
    public String getMessageId() {
        return this.messageId;
    }

    @ApiModelProperty(example = "NO_PREARCHIVING", value = "Status concernant l'archivage du message")
    public String getPreArchivingStatus() {
        return this.preArchivingStatus;
    }

    @ApiModelProperty(
            value = "Liste des destinataires, array de String (cet attribut est mutuellement exclusif avec id/type).")
    public List<Recipients> getRecipients() {
        return this.recipients;
    }

    @ApiModelProperty(example = "janedo@acme.ltd", value = "Adresse mail de l'emetteur")
    public SenderDTO getSender() {
        return this.sender;
    }

    @ApiModelProperty(example = "0", value = "Indique si le message est signe 1 si oui et 0 si non")
    public int getSigned() {
        return this.signed;
    }

    @ApiModelProperty(example = "32325", value = "Taille du message")
    public String getSize() {
        return this.size;
    }

    @ApiModelProperty(example = "Message important", value = "L'objet du message")
    public String getSubject() {
        return this.subject;
    }

    @ApiModelProperty(example = "simple", value = "Type de message")
    public String getType() {
        return this.type;
    }

    @Override
    public int hashCode() {
        return Objects.hash(messageId, type, subject, comment, sender, recipients, date, expirationDate, encrypted,
                            signed, preArchivingStatus, files, downloadUrl, accessUrl, size, email, audit);
    }

    public void setAccessUrl(String accessUrl) {
        this.accessUrl = accessUrl;
    }

    public void setAudit(Audit audit) {
        this.audit = audit;
    }

    public void setComment(String comment) {this.comment = comment;}

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setEncrypted(int encrypted) {
        this.encrypted = encrypted;
    }

    public void setExpirationDate(LocalDateTime expirationDate) {
        this.expirationDate = expirationDate;
    }

    public void setFiles(List<Files> files) {
        this.files = files;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public void setPreArchivingStatus(String preArchivingStatus) {
        this.preArchivingStatus = preArchivingStatus;
    }

    public void setRecipients(List<Recipients> recipients) {
        this.recipients = recipients;
    }

    public void setSender(SenderDTO sender) {
        this.sender = sender;
    }

    public void setSigned(int signed) {
        this.signed = signed;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public void setType(String type) {
        this.type = type;
    }
}
