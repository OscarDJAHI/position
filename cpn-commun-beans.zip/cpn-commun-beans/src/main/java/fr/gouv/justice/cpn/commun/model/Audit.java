package fr.gouv.justice.cpn.commun.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

@ApiModel(description = "Sous ensemble du message utilise pour indiquer le status du message envoye.")
public class Audit {

    @JsonProperty("viewed")
    private List<Viewed> viewed;

    @JsonProperty("downloaded")
    private List<Downloaded> downloaded;

    @ApiModelProperty(value = "List des Dowloaded, array d'objets")
    public List<Downloaded> getDownloaded() {
        return this.downloaded;
    }

    @ApiModelProperty(value = "List des Viewed, array d'objets")
    public List<Viewed> getViewed() {
        return this.viewed;
    }

    public void setDownloaded(List<Downloaded> downloaded) {
        this.downloaded = downloaded;
    }

    public void setViewed(List<Viewed> viewed) {
        this.viewed = viewed;
    }
}
