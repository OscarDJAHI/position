package fr.gouv.justice.cpn.commun.beans.storage;

import lombok.Data;

import java.util.Map;

@Data
public class ProxyStorageRequest {
    private Map<String, Object> metadata;
    private Integer             count;
    private Integer             offset;
}
