package fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn;

import fr.gouv.justice.cpn.commun.beans.document.DocumentDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DemandeEnvoiDocumentBpnFileDTO extends DocumentDTO {

    private Long demandeId;
}
