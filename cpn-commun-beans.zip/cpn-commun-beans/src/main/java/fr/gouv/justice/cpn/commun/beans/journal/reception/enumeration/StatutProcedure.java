package fr.gouv.justice.cpn.commun.beans.journal.reception.enumeration;

public enum StatutProcedure {
    ENCOURS,
    TELECHARGE,
    CONROLEE,
    CONTROLE_FONC_ERR,
    SUCCES,
    ERREUR_SPS,
    ERREUR_NPP,
    ERREUR,
    ERREURDEFINITIVE
}
