package fr.gouv.justice.cpn.commun.beans.message.detail;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@ApiModel(description = "Sous ensemble du message utilisé pour indiquer les informations sur l'emetteur du message.")
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class SenderDTO extends AbstractContact {
}
