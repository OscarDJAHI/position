package fr.gouv.justice.cpn.commun.beans.contact;

import lombok.Data;

@Data
public class ContactsFilterDTO {

    private ContactDTO filter;

    private Integer limit;

    private Integer count;
}
