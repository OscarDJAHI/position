package fr.gouv.justice.cpn.commun.beans.message;

import lombok.Data;

import javax.validation.constraints.Size;
import java.time.Instant;

@Data
public class SignatureDTO {

    private String userUid;

    @Size(max = 255, message = "Signature trop longue. Veuillez ne pas dépasser {max} caractères.")
    private String content;

    private Instant creationDate;
}
