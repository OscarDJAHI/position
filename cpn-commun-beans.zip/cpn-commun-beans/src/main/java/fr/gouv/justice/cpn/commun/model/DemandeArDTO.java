package fr.gouv.justice.cpn.commun.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import fr.gouv.justice.cpn.commun.model.enumeration.OriginMessage;
import fr.gouv.justice.cpn.commun.model.enumeration.Status;

import java.time.Instant;
import java.util.Objects;
import java.util.Set;

public class DemandeArDTO {

    private Long id;

    private Integer idMessage;

    private Instant creationDate;

    private String idj;

    private String idExterne;

    private OriginMessage originMessage;

    private Status status;

    private Integer nbTry;

    private String emailMessage;

    private String codeSrj;

    private String affaire;

    private Set<DemandeArStatusDTO> demandeArStatuses;

    private String emailBs;

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DemandeArDTO demandeArDTO = (DemandeArDTO) o;
        if (demandeArDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), demandeArDTO.getId());
    }

    public String getAffaire() {
        return affaire;
    }

    public String getCodeSrj() {
        return codeSrj;
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy HH:mm:ss", timezone = "UTC")
    public Instant getCreationDate() {
        return creationDate;
    }

    public Set<DemandeArStatusDTO> getDemandeArStatuses() {
        return demandeArStatuses;
    }

    public String getEmailBs() {
        return emailBs;
    }

    public String getEmailMessage() {
        return emailMessage;
    }

    public Long getId() {
        return id;
    }

    public String getIdExterne() {
        return idExterne;
    }

    public Integer getIdMessage() {
        return idMessage;
    }

    public String getIdj() {
        return idj;
    }

    public Integer getNbTry() {
        return nbTry;
    }

    public OriginMessage getOriginMessage() {
        return originMessage;
    }

    public Status getStatus() {
        return status;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    public void setAffaire(String affaire) {
        this.affaire = affaire;
    }

    public void setCodeSrj(String codeSrj) {
        this.codeSrj = codeSrj;
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy HH:mm:ss", timezone = "UTC")
    public void setCreationDate(Instant creationDate) {
        this.creationDate = creationDate;
    }

    public void setDemandeArStatuses(Set<DemandeArStatusDTO> demandeArStatuses) {
        this.demandeArStatuses = demandeArStatuses;
    }

    public void setEmailBs(String emailBs) {
        this.emailBs = emailBs;
    }

    public void setEmailMessage(String emailMessage) {
        this.emailMessage = emailMessage;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setIdExterne(String idExterne) {
        this.idExterne = idExterne;
    }

    public void setIdMessage(Integer idMessage) {
        this.idMessage = idMessage;
    }

    public void setIdj(String idj) {
        this.idj = idj;
    }

    public void setNbTry(Integer nbTry) {
        this.nbTry = nbTry;
    }

    public void setOriginMessage(OriginMessage originMessage) {
        this.originMessage = originMessage;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "DemandeArDTO{" +
                "id=" + getId() +
                ", idMessage=" + getIdMessage() +
                ", creationDate='" + getCreationDate() + "'" +
                ", idj='" + getIdj() + "'" +
                ", idExterne='" + getIdExterne() + "'" +
                ", originMessage='" + getOriginMessage() + "'" +
                ", status='" + getStatus() + "'" +
                ", nbTry=" + getNbTry() +
                "}";
    }
}
