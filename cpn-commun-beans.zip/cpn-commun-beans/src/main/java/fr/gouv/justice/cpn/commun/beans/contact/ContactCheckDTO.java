package fr.gouv.justice.cpn.commun.beans.contact;

import lombok.Data;

@Data
public class ContactCheckDTO {

    private String email;

    private boolean exist;
}
