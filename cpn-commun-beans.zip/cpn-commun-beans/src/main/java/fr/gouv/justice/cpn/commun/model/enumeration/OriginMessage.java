package fr.gouv.justice.cpn.commun.model.enumeration;

public enum OriginMessage {
    PLINE,
    PLEX,
    EXCHANGE_CEP,
    BS_PLEX,
    BS_PLINE

}
