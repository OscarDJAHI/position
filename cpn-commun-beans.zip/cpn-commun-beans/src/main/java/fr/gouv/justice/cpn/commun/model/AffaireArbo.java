package fr.gouv.justice.cpn.commun.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Informations sur l'Affaire")
public class AffaireArbo {

    public static class Builder {
        private final AffaireArbo affaire;

        public Builder() {
            this.affaire = new AffaireArbo();
        }

        public AffaireArbo build() {
            return affaire;
        }

        public Builder withDateCreation(String dateCreation) {
            this.affaire.setDateCreation(dateCreation);
            return this;
        }

        public Builder withDateModification(String dateModification) {
            this.affaire.setDateModification(dateModification);
            return this;
        }

        public Builder withDescription(String description) {
            this.affaire.setDescription(description);
            return this;
        }

        public Builder withDpn(String dpn) {
            this.affaire.setDpn(dpn);
            return this;
        }

        public Builder withIdj(String idj) {
            this.affaire.setIdj(idj);
            return this;
        }

        public Builder withNbrDocument(String nbrDocument) {
            this.affaire.setNbrDocument(nbrDocument);
            return this;
        }

        public Builder withNoeud(String noeud) {
            this.affaire.setNoeud(noeud);
            return this;
        }

        public Builder withNumeroParquet(String numeroParquet) {
            this.affaire.setNumeroParquet(numeroParquet);
            return this;
        }

        public Builder withScelles(String scelles) {
            this.affaire.setScelles(scelles);
            return this;
        }

        public Builder withTaille(String taille) {
            this.affaire.setTaille(taille);
            return this;
        }

        public Builder withTypedossier(String typedossier) {
            this.affaire.setTypedossier(typedossier);
            return this;
        }
    }
    @ApiModelProperty(value = "Numero de parquet", example = "00075227_00173_2020")
    private String numeroParquet;
    @ApiModelProperty(value = "Type de dossier", example = "Dossier Pénal")
    private String typedossier;
    @ApiModelProperty(value = "Identifiant Justice", example = "9127354673E")
    private String idj;
    @ApiModelProperty(value = "Noeud dans le dossier de l'affaire", example = "aeb903ee-3794-4da8-a00c-2951bdeb90f0")
    private String noeud;
    @ApiModelProperty(value = "Dossier Penal Numerique", example = "O")
    private String dpn;
    @ApiModelProperty(value = "Description de l'affaire", example = "Resume de l'affaire")
    private String description;
    @ApiModelProperty(value = "Taille du dossier", example = "0.2 Mo")
    private String taille;
    @ApiModelProperty(value = "Nombre de documents", example = "2")
    private String nbrDocument;
    @ApiModelProperty(value = "Date de creation du document", example = "06-10-2020 18:30:00")
    private String dateCreation;
    @ApiModelProperty(value = "Date de modification du document", example = "07-10-2020 10:05:05")
    private String dateModification;
    @ApiModelProperty(value = "Scelles au niveau de l'affaire", example = "O")
    private String scelles;

    public String getDateCreation() {
        return dateCreation;
    }

    public String getDateModification() {
        return dateModification;
    }

    public String getDescription() {
        return description;
    }

    public String getDpn() {
        return dpn;
    }

    public String getIdj() {
        return idj;
    }

    public String getNbrDocument() {
        return nbrDocument;
    }

    public String getNoeud() {
        return noeud;
    }

    public String getNumeroParquet() {
        return numeroParquet;
    }

    public String getScelles() {
        return scelles;
    }

    public String getTaille() {
        return taille;
    }

    public String getTypedossier() {
        return typedossier;
    }

    public void setDateCreation(String dateCreation) {
        this.dateCreation = dateCreation;
    }

    public void setDateModification(String dateModification) {
        this.dateModification = dateModification;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDpn(String dpn) {
        this.dpn = dpn;
    }

    public void setIdj(String idj) {
        this.idj = idj;
    }

    public void setNbrDocument(String nbrDocument) {
        this.nbrDocument = nbrDocument;
    }

    public void setNoeud(String noeud) {
        this.noeud = noeud;
    }

    public void setNumeroParquet(String numeroParquet) {
        this.numeroParquet = numeroParquet;
    }

    public void setScelles(String scelles) {
        this.scelles = scelles;
    }

    public void setTaille(String taille) {
        this.taille = taille;
    }

    public void setTypedossier(String typedossier) {
        this.typedossier = typedossier;
    }
}
