package fr.gouv.justice.cpn.commun.beans.message.detail;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.time.LocalDateTime;

@ApiModel(description = "Sous ensemble du message utilise pour indiquer le status de la visualisation de la piece jointe du message.")
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class ViewedDTO extends AbstractAttachmentAudit {

    @ApiModelProperty(example = "02/06/2020 11:01:10", value = "La date et heure de la visualisation de la piece jointe")
    @Override
    public LocalDateTime getDate() {
        return super.getDate();
    }
}
