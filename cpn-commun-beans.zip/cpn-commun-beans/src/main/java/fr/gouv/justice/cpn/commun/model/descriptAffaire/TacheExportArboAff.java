package fr.gouv.justice.cpn.commun.model.descriptAffaire;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "TacheExportArboAff")
public class TacheExportArboAff {

    /**
     * Id de la juridiction à laquelle on doit transmettre l'affaire.
     */
    @XmlElement(name = "affaire", required = true)
    protected AffaireDescript affaire;

    public AffaireDescript getAffaire() {
        return affaire;
    }

    public void setAffaire(AffaireDescript affaire) {
        this.affaire = affaire;
    }

}
