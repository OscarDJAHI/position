package fr.gouv.justice.cpn.commun.beans.demande.envoi.npp;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.gouv.justice.cpn.commun.beans.generic.ResponseDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class ResponseEnvoiDocumentNppDTO extends ResponseDTO {

    @Data
    public static class NoeudNpp implements Serializable {

        private String noeud;

        private String nomfichier;

    }

    private List<NoeudNpp> noeuds = new ArrayList<>();

    private Integer codeRetour;

    private String codeInsee;

    private String statut;

    private String cause;

    private String idAffaire;

    private Long demandeId;

    private String nomArchive;

    @JsonProperty(value = "Resultat de traitement-->code 200")
    private String traitementFoncU200;

    @JsonProperty(value = "Resultat de traitement-->code 400")
    private String traitementFoncU400;

}
