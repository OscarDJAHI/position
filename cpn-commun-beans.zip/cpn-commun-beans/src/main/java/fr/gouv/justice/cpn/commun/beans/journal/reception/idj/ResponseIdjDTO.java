package fr.gouv.justice.cpn.commun.beans.journal.reception.idj;

import lombok.Data;

import java.util.List;

@Data
public class ResponseIdjDTO {
    private String       dateCreation;
    private List<String> listIdj;
    private String       message;
}
