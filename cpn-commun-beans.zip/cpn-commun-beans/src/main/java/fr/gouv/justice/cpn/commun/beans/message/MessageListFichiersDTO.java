package fr.gouv.justice.cpn.commun.beans.message;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.io.Serializable;

/**
 * A DTO for the MessageListFichiers entity.
 */
@Data
public class MessageListFichiersDTO implements Serializable {

    private Long id;

    private String idExterne;

    private String size;

    private String name;

    @JsonIgnore
    private Long messageId;
}
