package fr.gouv.justice.cpn.commun.model;

public final class ProcedureMetadataMIKeys {

    public static final String CODE_UNIT = "CodeUnit";

    public static final String IDJ = "Idj";

    public static final String NO_PARQUET = "NoParquet";

    public static final String CODE_INSEE = "CodeINSEE";

    public static final String ELEMENT_COURT_ELEMENT_STRUC = "ElementCourtElementStruct";

    public static final String NO_PROCEDURE_FORMATE = "NoProcedureFormate";

    public static final String PROCEDURE_NUMERO = "ProcedureNumero";

    private ProcedureMetadataMIKeys() {
    }
}
