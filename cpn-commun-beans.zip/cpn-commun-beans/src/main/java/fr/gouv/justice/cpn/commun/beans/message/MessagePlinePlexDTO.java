package fr.gouv.justice.cpn.commun.beans.message;

import fr.gouv.justice.cpn.commun.beans.erreur.ErreurDTO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
public class MessagePlinePlexDTO {

    @ApiModelProperty(value = "Est-ce une boite nominative", example = "false")
    private boolean boiteNominative;

    @ApiModelProperty(value = "Adresse mail de la boite structurelle", example = "boiteMail@acme.dtl")
    private String mailBoxMail;

    @ApiModelProperty(value = "Liste de tous les messages de la boite")
    private List<MessageViewDTO> messages;

    @ApiModelProperty(value = "Liste des erreurs potentielles")
    private List<ErreurDTO> erreurs;
}
