package fr.gouv.justice.cpn.commun.beans.demande;

/**
 * The Status enumeration.
 */
public enum DemandeEnvoiDocumentStatusEnum {
    DEMANDE,
    ECHEC,
    ERREUR_BPN,
    ERREUR_EXCHANGE,
    ERREUR_MAB_ECHANGE,
    ERREUR_MAB_INTERFACE,
    ERREUR_MAS_INTERFACE,
    ERREUR_NPP,
    ERREUR_FONC_NPP,
    ERREUR_PLEX_DOWNLOAD_FILE,
    ERREUR_PLINE_DOWNLOAD_FILE,
    ERREUR_SEQUESTRE,
    ERREUR_MAB_JOURNAL,
    ERREUR_UPDATE_STATUS,
    SUCCES,
    TEMPORAIRE,
    TRAITEE
}
