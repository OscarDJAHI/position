package fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn;

import fr.gouv.justice.cpn.commun.beans.demande.DemandeEnvoiDocumentStatusEnum;
import fr.gouv.justice.cpn.commun.beans.message.MessageOriginEnum;
import lombok.Data;

import java.time.Instant;
import java.util.Set;

@Data
public class DemandeEnvoiDocumentBpnDTO {

    private Long id;

    private Integer idMessage;

    private Instant createdDate;

    private String createdBy;

    private MessageOriginEnum originMessage;

    private DemandeEnvoiDocumentStatusEnum status;

    private Integer nbTry;

    private String idNoeud;

    private String userMail;

    private String idExterne;

    private String codeSrj;

    private String idLdap;

    private String emailBs;

    private Set<DemandeEnvoiDocumentBpnFileDTO> demandeEnvoiDocumentBpnFiles;

    private Set<DemandeEnvoiDocumentBpnStatusDTO> demandeEnvoiDocumentBpnStatus;
}
