package fr.gouv.justice.cpn.commun.model.ProcedureNPP;

public class EnvoiProcedureNPP {
}
