package fr.gouv.justice.cpn.commun.model.enumeration;

/**
 * The Origin enumeration.
 */
public enum AppName {
    BPN,
    CEPN,
    CPN,
    NPP,
    SPS,
    VIGIE
}
