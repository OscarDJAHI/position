package fr.gouv.justice.cpn.commun.beans.journal.reception.idj;

import com.fasterxml.jackson.annotation.JsonFormat;
import fr.gouv.justice.cpn.commun.beans.journal.reception.enumeration.EntiteServActif;
import fr.gouv.justice.cpn.commun.beans.journal.reception.enumeration.EntiteServInactif;
import lombok.Data;

import java.time.ZonedDateTime;

@Data
public class ServiceDTO {

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = IdjDTO.DEFAULT_DATE_PATTERN)
    private ZonedDateTime dateService;

    private EntiteServActif entiteServActif;
    private String          codeServActif;
    private String          libelleServActif;

    private EntiteServInactif entiteServInactif;
    private String            codeServInactif;
    private String            libelleServInactif;
}
