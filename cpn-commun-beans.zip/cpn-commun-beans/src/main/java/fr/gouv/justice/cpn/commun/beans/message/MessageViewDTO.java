package fr.gouv.justice.cpn.commun.beans.message;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Sous ensemble du message utilisé pour la récupération de la liste des messages.
 */
@ApiModel(description = "Sous ensemble du message utilisé pour la récupération de la liste des messages.")
@Data
public class MessageViewDTO {

    @ApiModelProperty(example = "26", value = "L'identifiant unique du message")
    @JsonProperty("message_id")
    private String messageId;

    @ApiModelProperty(example = "Very important files", value = "L'objet du message")
    private String subject;

    @ApiModelProperty(example = "20101006164010Z", value = "La date de création du message")
    @JsonProperty("creation_date")
    private LocalDateTime creationDate;

    @ApiModelProperty(example = "20101016164010Z", value = "La date d'éxipartion du message")
    @JsonProperty("expiration_date")
    private LocalDateTime expirationDate;

    @ApiModelProperty(example = "VIP Workgroup", value = "Quand le message est un projet, le nom du projet")
    private String project;

    @ApiModelProperty(example = "4", value = "Quand le message est un projet, l'id interne du projet")
    @JsonProperty("project_id")
    private String projectId;

    @ApiModelProperty(example = "john.doe@acme.ltd", value = "Adresse email de l'emetteur")
    private String sender;

    @ApiModelProperty(value = "Liste des destinataires, array de String (cet attribut est mutuellement exclusif avec project/project_id).")
    private List<String> recipients;

    @ApiModelProperty(example = "2", value = "Le nombre de fichiers contenu dans le message")
    @JsonProperty("nb_files")
    private int nbFiles;

    @ApiModelProperty(example = "0", value = "Indique si le message a été vu par la personne connecté  (boolean - toujours true si la personne connecté est l'émmetteur)")
    private int viewed;

    @ApiModelProperty(example = "0", value = "Indique si le message a été envoyé par la personne connecté (boolean - 0 ou 1)")
    private int sent;

    @JsonProperty("idExterne")
    private String idExterne;

    @JsonProperty("originMessage")
    private String originMessage;

    @JsonProperty("emailBoite")
    private String emailBoite;

    public void addRecipientsItem(String recipient) {
        if (this.recipients == null) {
            this.recipients = new ArrayList<>();
        }

        this.recipients.add(recipient);
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    public LocalDateTime getCreationDate() {
        return creationDate;
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    public LocalDateTime getExpirationDate() {
        return expirationDate;
    }

    public boolean isSent() {
        return Integer.compare(1, sent) == 0;
    }

    public boolean isViewed() {
        return Integer.compare(1, viewed) == 0;
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyyMMddHHmmss'Z'")
    public void setCreationDate(LocalDateTime creationDate) {
        this.creationDate = creationDate;
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyyMMddHHmmss'Z'")
    public void setExpirationDate(LocalDateTime expirationDate) {
        this.expirationDate = expirationDate;
    }
}
