package fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn;

import com.fasterxml.jackson.annotation.JsonIgnore;
import fr.gouv.justice.cpn.commun.beans.demande.DemandeEnvoiDocumentStatusEnum;
import lombok.Data;

import java.time.Instant;

@Data
public class DemandeEnvoiDocumentBpnStatusDTO {

    private Long id;

    private Instant dateStatus;

    private Integer responseCode;

    private DemandeEnvoiDocumentStatusEnum status;

	@JsonIgnore
    private String cause;

    private String message;

    private Long demandeId;
}
