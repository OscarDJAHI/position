package fr.gouv.justice.cpn.commun.model.enumeration;

public enum StatutProcedure {
    ENCOURS,
    TELECHARGE,
    SUCCES,
    ERREUR,
    ERREURDEFINITIVE
}
