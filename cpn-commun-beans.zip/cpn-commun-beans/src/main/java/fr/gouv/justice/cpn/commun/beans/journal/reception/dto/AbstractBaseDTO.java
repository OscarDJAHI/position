package fr.gouv.justice.cpn.commun.beans.journal.reception.dto;

import lombok.Data;

@Data
public abstract class AbstractBaseDTO {

    private Long id;

    private String libelle;
}
