package fr.gouv.justice.cpn.commun.model.enumeration;

public enum EtatRechercheDPN {
    ALL,
    HCP_FIRST,
    HCP_FIRST_UNIQUE_ETAT,
    NFS_FIRST,
    NFS_FIRST_UNIQUE_ETAT,
    NOT_DEFINITIF,
    NOT_FINALISE,
    NOT_BROUILLON,
    BROUILLON,
    FINALISE,
    DEFINITIF
}
