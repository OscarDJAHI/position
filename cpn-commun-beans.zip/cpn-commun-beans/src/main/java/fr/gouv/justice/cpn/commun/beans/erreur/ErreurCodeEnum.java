package fr.gouv.justice.cpn.commun.beans.erreur;

public enum ErreurCodeEnum {
    NO_RESULTAT_INFRACTION,
    MAX_RESULTAT_INFRACTION,
    PLINE_ERROR,
    PLEX_ERROR;
}
