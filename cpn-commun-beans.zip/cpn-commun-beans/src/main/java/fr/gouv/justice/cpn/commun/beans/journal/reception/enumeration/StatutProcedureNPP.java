package fr.gouv.justice.cpn.commun.beans.journal.reception.enumeration;

public enum StatutProcedureNPP {
    A_TRAITER,
    AFFECTEE,
    ECHEC_INTEGRATION,
    DONNEES_SUPPRIMEES,
    DONNEES_ARCHIVEES
}
