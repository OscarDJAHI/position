package fr.gouv.justice.cpn.commun.beans.journal.reception.idj;

import lombok.Data;

import java.util.List;

@Data
public class NatAffDTO {
    private String            dateNatAff;
    private List<String>      natAffsAp;
    private List<String> natAffsAv;
}
