package fr.gouv.justice.cpn.commun.beans.contact;

import fr.gouv.justice.cpn.commun.beans.erreur.ErreurDTO;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@ApiModel(description = "Contacts API")
@Data
public class ContactsDTO {

    private List<ErreurDTO> erreurs;

    private List<ContactDTO> contacts;

    public void addErreur(ErreurDTO erreur) {
        if (Objects.isNull(this.erreurs)) {
            this.erreurs = new ArrayList<>();
        }

        this.erreurs.add(erreur);
    }
}
