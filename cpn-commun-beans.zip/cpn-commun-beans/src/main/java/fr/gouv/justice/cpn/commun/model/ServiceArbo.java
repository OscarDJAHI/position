package fr.gouv.justice.cpn.commun.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

@ApiModel(description = "Detail du service")
public class ServiceArbo {

    public static class Builder {

        private final ServiceArbo service;


        public Builder() {
            this.service = new ServiceArbo();
        }

        public ServiceArbo build() {
            return service;
        }

        public Builder withAffaires(List<AffaireArbo> affaires) {
            this.service.setAffaires(affaires);
            return this;
        }

        public Builder withIdNoeud(String idNoeud) {
            this.service.setIdNoeud(idNoeud);
            return this;
        }

        public Builder withName(String name) {
            this.service.setName(name);
            return this;
        }

        public Builder withRegroupement(boolean regroupement) {
            this.service.setRegroupement(regroupement);
            return this;
        }

        public Builder withRegroupements(List<RegroupementArbo> regroupements) {
            this.service.setRegroupements(regroupements);
            return this;
        }

        public Builder withService(boolean service) {
            this.service.setService(service);
            return this;
        }

        public Builder withTitulaire(boolean titulaire) {
            this.service.setTitulaire(titulaire);
            return this;
        }
    }
    @ApiModelProperty(value = "Liste d'affaires", example = "Affaire1, Affaire2")
    protected List<AffaireArbo>      affaires;
    @ApiModelProperty(value = "Nom du service", example = "Archivage")
    private   String                 name;
    @ApiModelProperty(value = "Identifiant du noeud", example = "workspace://SpacesStore/88a8c040-650e-4a39-9134-197e2819f7cd")
    private   String                 idNoeud;
    @ApiModelProperty(value = "Utilisateur est titulaire", example = "true")
    private   boolean                titulaire;
    @ApiModelProperty(value = "Regroupement associe", example = "true")
    private   boolean                regroupement;
    @ApiModelProperty(value = "Service supplementaire", example = "true")
    private   boolean                service;
    @ApiModelProperty(value = "Liste de regroupement", example = "Regroupement1, Regroupement2")
    private   List<RegroupementArbo> regroupements;

    public List<AffaireArbo> getAffaires() {
        return affaires;
    }

    public String getIdNoeud() {
        return idNoeud;
    }

    public String getName() {
        return name;
    }

    public List<RegroupementArbo> getRegroupements() {
        return regroupements;
    }

    public boolean isRegroupement() {
        return regroupement;
    }

    public boolean isService() {
        return service;
    }

    public boolean isTitulaire() {
        return titulaire;
    }

    public void setAffaires(List<AffaireArbo> affaires) {
        this.affaires = affaires;
    }

    public void setIdNoeud(String idNoeud) {
        this.idNoeud = idNoeud;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setRegroupement(boolean regroupement) {
        this.regroupement = regroupement;
    }

    public void setRegroupements(List<RegroupementArbo> regroupements) {
        this.regroupements = regroupements;
    }

    public void setService(boolean service) {
        this.service = service;
    }

    public void setTitulaire(boolean titulaire) {
        this.titulaire = titulaire;
    }
}
