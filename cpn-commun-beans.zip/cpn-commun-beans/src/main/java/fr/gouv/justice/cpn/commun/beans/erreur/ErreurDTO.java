package fr.gouv.justice.cpn.commun.beans.erreur;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class ErreurDTO {

    private final ErreurCodeEnum code;

    private final ErreurTypeEnum type;

    private final String message;
}
