package fr.gouv.justice.cpn.commun.beans.message.detail;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.ByteArrayOutputStream;

@ApiModel(description = "Sous ensemble du message utilise pour afficher l'ensemble des pieces jointes du message.")
@Data
public class FileDTO {

    @ApiModelProperty(example = "0", value = "L'index lie a la piece jointe")
    private int index;

    @ApiModelProperty(example = "Objectifs du Projet", value = "Le nom de la piece jointe")
    private String name;

    @ApiModelProperty(example = "32115", value = "Taille de la piece jointe")
    private String size;

    @ApiModelProperty(example = "https://telecharger-moi-ici.com", value = "L'url de telechargement de la piece jointe")
    @JsonProperty("download_url")
    private String downloadUrl;

    @ApiModelProperty(example = "ftyu20daef81ebbd754f11153fe0d2f1f10b67aed1bc87f3fc5b72a3065", value = "Codage de la piece jointe")
    private String digest;

    @JsonIgnore
    private ByteArrayOutputStream content;

    @JsonIgnore
    private String contentType;
}
