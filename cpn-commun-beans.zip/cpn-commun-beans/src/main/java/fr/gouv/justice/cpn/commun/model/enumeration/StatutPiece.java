package fr.gouv.justice.cpn.commun.model.enumeration;

public enum StatutPiece {
    BROUILLON,
    DEFINITIF,
    FINALISE
}
