package fr.gouv.justice.cpn.commun.model.descriptAffaire;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;
import java.util.ArrayList;
import java.util.List;

/**
 * Element Affaire,
 * <p>
 * correspond aux éléments xml :
 * {@code
 *
 * <affaire>
 * <noderefParentAffaire>workspace://SpacesStore/d87bb825-0233-442a-888b-ff41b4675845</noderefParentAffaire>
 * <filtre>
 * <noderefId>workspace://SpacesStore/d87bb825-0233-442a-888b-ff41b4675846</noderefId>
 * <noderefId>workspace://SpacesStore/d87bb825-0233-442a-888b-ff41b4675847</noderefId>
 * </filtre>
 * </affaire>
 * }
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "affaire", propOrder = {
        "noderefParentAffaire",
        "listeNotesAff",
        "nodeRefIds", "numeroParquet", "idj", "typedossier", "noeud", "description", "dpn", "taille", "nbrDocument", "dateCreation", "dateModification", "scelles", "listeNodeAff"
})
public class AffaireDescript {

    public static class Builder {
        private final AffaireDescript affaire;

        public Builder() {
            this.affaire = new AffaireDescript();
        }

        public Builder addFilter(String nodeRefId) {
            this.affaire.getNodeRefIds().add(nodeRefId);
            return this;
        }

        public Builder addNodeAff(NodeAffDescript nodeAff) {
            this.affaire.getListeNodeAff().add(nodeAff);
            return this;
        }

        public Builder addNotesAff(NoteDescript note) {
            this.affaire.getListeNotesAff().add(note);
            return this;
        }

        public AffaireDescript build() {
            return affaire;
        }

        public Builder withDateCreation(String dateCreation) {
            this.affaire.setDateCreation(dateCreation);
            return this;
        }

        public Builder withDateModification(String dateModification) {
            this.affaire.setDateModification(dateModification);
            return this;
        }

        public Builder withDescription(String description) {
            this.affaire.setDescription(description);
            return this;
        }

        public Builder withDpn(String dpn) {
            this.affaire.setDpn(dpn);
            return this;
        }

        public Builder withIdj(String idj) {
            this.affaire.setIdj(idj);
            return this;
        }

        public Builder withLibelleService(String libelleService) {
            this.affaire.setLibService(libelleService);
            return this;
        }

        public Builder withListeNodeAff(List<NodeAffDescript> nodeAffs) {
            this.affaire.setListeNodeAff(nodeAffs);
            return this;
        }

        public Builder withListeNotes(List<NoteDescript> notesAff) {
            this.affaire.setListeNotesAff(notesAff);
            return this;
        }

        public Builder withNbrDocument(String nbrDocument) {
            this.affaire.setNbrDocument(nbrDocument);
            return this;
        }

        public Builder withNoeud(String noeud) {
            this.affaire.setNoeud(noeud);
            return this;
        }

        public Builder withNumeroParquet(String numeroParquet) {
            this.affaire.setNumeroParquet(numeroParquet);
            return this;
        }

        public Builder withParentAffaire(String nodeRef) {
            this.affaire.setNoderefParentAffaire(nodeRef);
            return this;
        }

        public Builder withScelles(String scelles) {
            this.affaire.setScelles(scelles);
            return this;
        }

        public Builder withTaille(String taille) {
            this.affaire.setTaille(taille);
            return this;
        }

        public Builder withType(String type) {
            this.affaire.setType(type);
            return this;
        }

        public Builder withTypedossier(String typedossier) {
            this.affaire.setTypedossier(typedossier);
            return this;
        }
    }
    /**
     * Liste des affaires a exporter.
     */
    @XmlElement(name = "nodeAff", required = true)
    @XmlElementWrapper(name = "listeNodeAff")
    protected List<NodeAffDescript> listeNodeAff;
    /**
     * Liste des notes pour chaque affaire.
     */
    @XmlElement(name = "note")
    @XmlElementWrapper(name = "notes")
    protected List<NoteDescript> listeNotesAff;
    /**
     * nodeRef alfresco de l'affaire parente.
     */
    @XmlElement(required = true)
    private String noderefParentAffaire;
    /**
     * Liste de nodeRef des éléments à exporter.
     */
    @XmlElementWrapper(name = "filtre")
    @XmlElement(name = "noderefId", required = true)
    private List<String> nodeRefIds;
    /**
     * Libellé du service.
     */
    @XmlAttribute(name = "libService")
    private String libService;
    @XmlAttribute(name = "numeroParquet")
    private String numeroParquet;
    @XmlAttribute(name = "typedossier")
    private String typedossier;
    @XmlAttribute(name = "idj")
    private String idj;
    @XmlAttribute(name = "noeud")
    private String noeud;
    @XmlAttribute(name = "dpn")
    private String dpn;
    @XmlAttribute(name = "description")
    private String description;
    @XmlAttribute(name = "taille")
    private String taille;
    @XmlAttribute(name = "nbrDocument")
    private String nbrDocument;
    @XmlAttribute(name = "dateCreation")
    private String dateCreation;
    @XmlAttribute(name = "dateModification")
    private String dateModification;
    /**
     * Affaire avec scelles 1
     * Pas de scelles 0
     */
    @XmlAttribute(name = "scelles")
    private String scelles;
    @XmlAttribute(name = "type")
    private String type;

    public String getDateCreation() {
        return dateCreation;
    }

    public String getDateModification() {
        return dateModification;
    }

    public String getDescription() {
        return description;
    }

    public String getDpn() {
        return dpn;
    }

    public String getIdj() {
        return idj;
    }

    /**
     * Obtient la valeur de la propriété libService.
     *
     * @return possible object is {@link String }
     */
    public String getLibService() {
        return libService;
    }

    public List<NodeAffDescript> getListeNodeAff() {
        return listeNodeAff;
    }

    /**
     * //	 * @return the listeNotesAff
     * //
     */
    public List<NoteDescript> getListeNotesAff() {
        if (listeNotesAff == null) {
            listeNotesAff = new ArrayList<>();
        }
        return this.listeNotesAff;
    }

    public String getNbrDocument() {
        return nbrDocument;
    }

    /**
     * Optient la valeur de la propriété nodeRefIds.
     *
     * <p>
     * Ce getter renvoie une référence directe vers la liste, et non une copie.
     * Chaque modification faite à cette liste sera présente dans l'objet JAXB.
     * C'est pourquoi il n'y a pas de setter sur la propriété noderefId.
     *
     * <p>
     * Par exemple, pour ajouter un nouvel item :
     * <pre>
     *    getNodeRefIds().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Seuls les objets de type {@link String} sont autorisés dans cette liste.
     *
     * @return une liste de String correspondant au nodeRef alfresco de l'export.
     */
    public List<String> getNodeRefIds() {
        if (nodeRefIds == null) {
            nodeRefIds = new ArrayList<>();
        }
        return this.nodeRefIds;
    }

    /**
     * Obtient la valeur de la propriété noderefParentAffaire.
     *
     * @return possible object is {@link String }
     */
    public String getNoderefParentAffaire() {
        return noderefParentAffaire;
    }

    public String getNoeud() {
        return noeud;
    }

    public String getNumeroParquet() {
        return numeroParquet;
    }

    public String getScelles() {
        return scelles;
    }

    public String getTaille() {
        return taille;
    }

    public String getType() {
        return type;
    }

    public String getTypedossier() {
        return typedossier;
    }

    public void setDateCreation(String dateCreation) {
        this.dateCreation = dateCreation;
    }

    public void setDateModification(String dateModification) {
        this.dateModification = dateModification;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDpn(String dpn) {
        this.dpn = dpn;
    }

    public void setIdj(String idj) {
        this.idj = idj;
    }

    /**
     * Définit la valeur de la propriété libService.
     *
     * @param value allowed object is {@link String }
     */
    public void setLibService(String value) {
        this.libService = value;
    }

    public void setListeNodeAff(List<NodeAffDescript> listeNodeAff) {
        this.listeNodeAff = listeNodeAff;
    }

    /**
     * @param listeNotesAff the listeNotesAff to set
     */
    public void setListeNotesAff(List<NoteDescript> listeNotesAff) {
        this.listeNotesAff = listeNotesAff;
    }

    public void setNbrDocument(String nbrDocument) {
        this.nbrDocument = nbrDocument;
    }

    /**
     * Définit la valeur de la propriété noderefParentAffaire.
     *
     * @param value allowed object is {@link String }
     */
    public void setNoderefParentAffaire(String value) {
        this.noderefParentAffaire = value;
    }

    public void setNoeud(String noeud) {
        this.noeud = noeud;
    }

    public void setNumeroParquet(String numeroParquet) {
        this.numeroParquet = numeroParquet;
    }

    public void setScelles(String scelles) {
        this.scelles = scelles;
    }

    public void setTaille(String taille) {
        this.taille = taille;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setTypedossier(String typedossier) {
        this.typedossier = typedossier;
    }


}
