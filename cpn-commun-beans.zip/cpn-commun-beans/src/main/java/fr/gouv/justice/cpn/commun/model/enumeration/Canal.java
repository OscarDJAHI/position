package fr.gouv.justice.cpn.commun.model.enumeration;

public enum Canal {
    PLINE,
    PLEX,
    EXCHANGE
}
