package fr.gouv.justice.cpn.commun.beans.journal.reception.enumeration;

public enum EntiteServActif {
    CE,
    CP,
    DJ,
    GN,
    IP,
    NA,
    PN
}
