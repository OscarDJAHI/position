package fr.gouv.justice.cpn.commun.beans.generic;

import lombok.Data;

@Data
public class BoiteStructurelleDTO {

    private Long id;

    private String name;

    private String email;

    private String userId;

    private boolean defaultBox;

    private boolean nominative;
}
