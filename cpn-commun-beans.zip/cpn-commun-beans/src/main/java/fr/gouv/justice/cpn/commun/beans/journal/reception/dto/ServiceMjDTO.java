package fr.gouv.justice.cpn.commun.beans.journal.reception.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.validation.constraints.NotNull;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class ServiceMjDTO extends AbstractBaseDTO {

    @NotNull
    private String codeSrj;
}
