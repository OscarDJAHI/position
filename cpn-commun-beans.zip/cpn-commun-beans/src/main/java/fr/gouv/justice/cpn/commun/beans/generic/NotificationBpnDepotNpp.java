package fr.gouv.justice.cpn.commun.beans.generic;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.time.Instant;

@Data
public class NotificationBpnDepotNpp implements Serializable {

    private static final long serialVersionUID = 1;

    @ApiModelProperty(example = "1009", value = "Id technique de la demande persistée dans CPN")
    private Long idDemandeInitiale;

    @ApiModelProperty(example = "2021-08-23T08:33:24Z", value = "Date d'envoi de document(s)")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant dateEnvoi;

    @ApiModelProperty(example = "OK ou KO", value = "OK")
    private String message;

    @ApiModelProperty(example = "Message d'erreur en cas de KO - Erreur lors du traitement de la demande",
                      value = "Echec du traitement")
    private String cause;

}
