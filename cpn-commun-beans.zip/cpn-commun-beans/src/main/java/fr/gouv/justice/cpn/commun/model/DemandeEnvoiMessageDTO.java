package fr.gouv.justice.cpn.commun.model;

import fr.gouv.justice.cpn.commun.model.enumeration.AppName;
import fr.gouv.justice.cpn.commun.model.enumeration.Status;
import lombok.Data;

import java.time.Instant;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;

@Data
public class DemandeEnvoiMessageDTO {

    private Long id;

    private String type;

    private String subject;

    private boolean editableSubject = true;

    private boolean mandatorySubject = false;

    private String comment;

    private boolean editableComment = true;

    private boolean mandatoryComment = false;

    private Instant date;

    private Integer lifetime;

    private Integer encrypted;

    private Integer signed;

    private Status status;

    private SenderDTO sender;

    private Integer nbTry;

    private AppName appName;

    private String misc;

    private boolean addFileFromPc;

    private Set<DemandeEnvoiMessageDestinataireDTO> messageDestinataires = new HashSet<>();

    private Set<FichierDemandeEnvoiMessageDTO> fichierMessages = new HashSet<>();

    private Set<DemandeEnvoiMessageStatutDTO> messageStatuts = new HashSet<>();

    public DemandeEnvoiMessageStatutDTO lastStatus() {
        return this.messageStatuts.stream().max(Comparator.comparing(DemandeEnvoiMessageStatutDTO::getDateStatut)).orElseThrow();
    }
}
