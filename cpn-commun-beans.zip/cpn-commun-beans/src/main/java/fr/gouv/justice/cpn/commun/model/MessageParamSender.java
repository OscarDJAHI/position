package fr.gouv.justice.cpn.commun.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

@ApiModel(description = "Modele servant a remplir les parametres de l'envoi d'un message")
@JsonIgnoreProperties
public class MessageParamSender {

    @JsonProperty("recipients")
    List<DemandeEnvoiMessageDestinataireDTO> recipients;

    @JsonProperty("subject")
    String subject;

    @JsonProperty("comment")
    String comment;

    @JsonProperty("encrypted")
    int encrypted;


    @JsonProperty("lifetime")
    int lifeTime;

    @JsonProperty("emailBoiteStructurelle")
    String emailBoiteStructurelle;

    @JsonProperty("wholeZip")
    boolean wholeZip;

    String zipFileName;

    @ApiModelProperty(example = "Voici le fichier demande", value = "Commentaire accompagnant le message. Ne doit pas contenir d'information sensible.")
    public String getComment() {
        return comment;
    }

    @ApiModelProperty(value = "email emmeteur de la boite structurel. Peut être vide en cas d'envoi via la boite nominative.", allowEmptyValue = true)
    public String getEmailBoiteStructurelle() {
        return emailBoiteStructurelle;
    }

    @ApiModelProperty(example = "0", value = "Par defaut, la platefoorme encrypte elle-meme le fichier ")
    public int getEncrypted() {
        return encrypted;
    }

    @ApiModelProperty(example = "15", value = "Duree de validite du message et de sa (ses) piece(s) jointe(s)")
    public int getLifeTime() {
        return lifeTime;
    }

    @ApiModelProperty(value = "Liste des destinataires du message, array de Objets.")
    public List<DemandeEnvoiMessageDestinataireDTO> getRecipients() {
        return recipients;
    }

    @ApiModelProperty(example = "Message important", value = "L'objet du message")
    public String getSubject() {
        return subject;
    }

    public String getZipFileName() {
        return zipFileName;
    }

    public boolean isWholeZip() {
        return wholeZip;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public void setEmailBoiteStructurelle(String emailBoiteStructurelle) {
        this.emailBoiteStructurelle = emailBoiteStructurelle;
    }

    public void setEncrypted(int encrypted) {
        this.encrypted = encrypted;
    }

    public void setLifeTime(int lifeTime) {
        this.lifeTime = lifeTime;
    }

    public void setRecipients(List<DemandeEnvoiMessageDestinataireDTO> recipients) {
        this.recipients = recipients;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public void setWholeZip(boolean wholeZip) {
        this.wholeZip = wholeZip;
    }

    public void setZipFileName(String zipFileName) {
        this.zipFileName = zipFileName;
    }
}
