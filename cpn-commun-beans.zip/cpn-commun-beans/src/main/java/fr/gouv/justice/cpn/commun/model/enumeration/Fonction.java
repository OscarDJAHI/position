package fr.gouv.justice.cpn.commun.model.enumeration;

/**
 * The Fonction enumeration.
 */
public enum Fonction {
    A,
    I
}
