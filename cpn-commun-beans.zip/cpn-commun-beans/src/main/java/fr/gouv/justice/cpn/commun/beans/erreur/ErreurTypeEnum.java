package fr.gouv.justice.cpn.commun.beans.erreur;

public enum ErreurTypeEnum {
    FONCTIONNELLE,
    TECHNIQUE;
}
