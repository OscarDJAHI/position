package fr.gouv.justice.cpn.commun.beans.message;

public enum MessagePropertiesEnum {
    SENDER("sender"),
    RECIPIENTS("recipients"),
    DATE_CREATION("creationDate");

    private final String value;

    MessagePropertiesEnum(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }
}
