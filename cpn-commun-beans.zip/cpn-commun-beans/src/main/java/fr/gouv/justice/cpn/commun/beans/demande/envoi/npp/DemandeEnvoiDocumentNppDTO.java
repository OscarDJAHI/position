package fr.gouv.justice.cpn.commun.beans.demande.envoi.npp;

import fr.gouv.justice.cpn.commun.beans.demande.DemandeEnvoiDocumentStatusEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.HashSet;
import java.util.Set;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class DemandeEnvoiDocumentNppDTO extends AbstractDemandeEnvoiDocumentNppDTO {

    private DemandeEnvoiDocumentStatusEnum status;

    private ContextDemande contextDemande;

    private DemandeEnvoiDocumentNppMessageDTO demandeEnvoiDocumentNppMessage;

    private Set<DemandeEnvoiDocumentNppFileDTO> demandeEnvoiDocumentNppFiles = new HashSet<>();

    private Set<DemandeEnvoiDocumentNppStatusDTO> demandeEnvoiDocumentNppStatus = new HashSet<>();

    private Set<ResponseEnvoiDocumentNppDTO> responsesEnvoiDocumentNpp = new HashSet<>();
}
