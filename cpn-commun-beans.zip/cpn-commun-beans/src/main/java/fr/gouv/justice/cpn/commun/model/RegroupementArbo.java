package fr.gouv.justice.cpn.commun.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

@ApiModel(description = "Informations sur le regroupement")
public class RegroupementArbo {

    public static class Builder {

        private final RegroupementArbo regroupement;


        public Builder() {
            this.regroupement = new RegroupementArbo();
        }

        public Builder addRegroupement(RegroupementArbo regroupement) {
            this.regroupement.regroupements.add(regroupement);
            return this;
        }

        public RegroupementArbo build() {
            return regroupement;
        }

        public Builder withAffaires(List<AffaireArbo> affaires) {
            this.regroupement.setAffaires(affaires);
            return this;
        }

        public Builder withNoeudRef(String noeudRef) {
            this.regroupement.setNoeudRef(noeudRef);
            return this;
        }

        public Builder withNom(String nom) {
            this.regroupement.setNom(nom);
            return this;
        }

        public Builder withRegroupements(List<RegroupementArbo> regroupements) {
            this.regroupement.setRegroupements(regroupements);
            return this;
        }

        public Builder withSousService(boolean sousService) {
            this.regroupement.setSousService(sousService);
            return this;
        }
    }
    @ApiModelProperty(value = "Liste d'affaires", example = "Affaire1, Affaire2")
    protected List<AffaireArbo>      affaires;
    @ApiModelProperty(value = "Nom du regroupement", example = "00-Petits X-old")
    private   String                 nom;
    @ApiModelProperty(value = "Noeuf referent", example = "workspace://SpacesStore/422af066-22fc-48c9-be93-d4b2366c13c4")
    private   String                 noeudRef;
    @ApiModelProperty(value = "Sous service existant", example = "true")
    private   boolean                sousService;
    @ApiModelProperty(value = "Liste de regroupement", example = "Regroupement1, Regroupement2")
    private   List<RegroupementArbo> regroupements;

    public List<AffaireArbo> getAffaires() {
        return affaires;
    }

    public String getNoeudRef() {
        return noeudRef;
    }

    public String getNom() {
        return nom;
    }

    public List<RegroupementArbo> getRegroupements() {
        return regroupements;
    }

    public boolean isSousService() {
        return sousService;
    }

    public void setAffaires(List<AffaireArbo> affaires) {
        this.affaires = affaires;
    }

    public void setNoeudRef(String noeudRef) {
        this.noeudRef = noeudRef;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setRegroupements(List<RegroupementArbo> regroupements) {
        this.regroupements = regroupements;
    }

    public void setSousService(boolean sousService) {
        this.sousService = sousService;
    }
}
