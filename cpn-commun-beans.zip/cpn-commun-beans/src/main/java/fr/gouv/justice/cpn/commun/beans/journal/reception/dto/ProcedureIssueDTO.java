package fr.gouv.justice.cpn.commun.beans.journal.reception.dto;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class ProcedureIssueDTO implements Comparable<ProcedureIssueDTO> {

    private Long id;

    private String defferement;

    private String modePoursuite;

    private String priorite;

    private Long procedureId;

    private OrientationDTO orientation;

    private Boolean estPrioritaire;

    private String codeSrj;

    @Override
    public int compareTo(@NotNull ProcedureIssueDTO o) {
        if (this.priorite == null) {
            return -1;
        }
        return this.priorite.compareTo(o.priorite);
    }


}
