package fr.gouv.justice.cpn.commun.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Elements wich permit to access at documents user")
public class DescriptAffApi {
    @ApiModelProperty(value = "Fonction appelee", example = "DescriptArbo")
    private String fonction;
    @ApiModelProperty(value = "Code de l'utilisateur", example = "username")
    private String codeUtilisateur;
    @ApiModelProperty(value = "identifiant justice", example = "01234567891I")
    private String idj;
    @ApiModelProperty(value = "numero parquet", example = "uwuOwOUwOOwU")
    private String numeroParquet;
    @ApiModelProperty(value = "type dossier", example = "dossierPenal")
    private String typeDossier;

    public DescriptAffApi codeUtilisateur(String codeUtilisateur) {
        this.setCodeUtilisateur(codeUtilisateur);
        return this;
    }

    public DescriptAffApi fonction(String fonction) {
        this.setFonction(fonction);
        return this;
    }

    public String getCodeUtilisateur() {
        return codeUtilisateur;
    }

    public String getFonction() {
        return fonction;
    }

    public String getIdj() {
        return idj;
    }

    public String getNumeroParquet() {
        return numeroParquet;
    }

    public String getTypeDossier() {
        return typeDossier;
    }

    public DescriptAffApi idj(String idj) {
        this.setIdj(idj);
        return this;
    }

    public DescriptAffApi numeroParquet(String numeroParquet) {
        this.setNumeroParquet(numeroParquet);
        return this;
    }

    public void setCodeUtilisateur(String codeUtilisateur) {
        this.codeUtilisateur = codeUtilisateur;
    }

    public void setFonction(String fonction) {
        this.fonction = fonction;
    }

    public void setIdj(String idj) {
        this.idj = idj;
    }

    public void setNumeroParquet(String numeroParquet) {
        this.numeroParquet = numeroParquet;
    }

    public void setTypeDossier(String typeDossier) {
        this.typeDossier = typeDossier;
    }

    public DescriptAffApi typeDossier(String typeDossier) {
        this.setTypeDossier(typeDossier);
        return this;
    }
}
