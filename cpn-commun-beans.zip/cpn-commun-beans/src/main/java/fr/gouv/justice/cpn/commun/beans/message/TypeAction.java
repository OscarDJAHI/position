package fr.gouv.justice.cpn.commun.beans.message;

public enum TypeAction {
    TRAITE,
    NON_TRAITE,
    SUPPRIME,
    RESTAURE
}
