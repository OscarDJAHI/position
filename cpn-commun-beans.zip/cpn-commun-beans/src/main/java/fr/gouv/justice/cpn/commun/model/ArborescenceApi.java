package fr.gouv.justice.cpn.commun.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Arborescence of authorised access documents user")
public class ArborescenceApi {

    @ApiModelProperty(value = "Date du jour", example = "04/03/2021 14:52:14")
    String  date;
    @ApiModelProperty(value = "Status code", example = "200")
    int     code;
    @ApiModelProperty(value = "Message", example = "OK")
    String  message;
    @ApiModelProperty(value = "Explication du code renvoye", example = "Traitement effectue avec succes")
    String  cause;
    @ApiModelProperty(value = "Contenu de l'arborescence", example = "Donnees utilisateur/service(s)")
    Content content;

    public String getCause() {
        return cause;
    }

    public int getCode() {
        return code;
    }

    public Content getContent() {return content;}

    public String getDate() {
        return date;
    }

    public String getMessage() {
        return message;
    }

    public void setCause(String cause) {
        this.cause = cause;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public void setContent(Content content) {this.content = content;}

    public void setDate(String date) {
        this.date = date;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
