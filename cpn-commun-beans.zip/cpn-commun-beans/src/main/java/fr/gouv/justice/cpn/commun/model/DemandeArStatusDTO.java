package fr.gouv.justice.cpn.commun.model;


import fr.gouv.justice.cpn.commun.model.enumeration.Status;

import java.time.Instant;
import java.util.Objects;

public class DemandeArStatusDTO {

    private Long id;

    private Instant dateStatus;

    private Integer responseCode;

    private Status status;

    private Long demandeAccusesReceptionId;

    private String message;

    private String cause;

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DemandeArStatusDTO demandeArStatusDTO = (DemandeArStatusDTO) o;
        if (demandeArStatusDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), demandeArStatusDTO.getId());
    }

    public String getCause() {
        return cause;
    }

    public Instant getDateStatus() {
        return dateStatus;
    }

    public Long getDemandeAccusesReceptionId() {
        return demandeAccusesReceptionId;
    }

    public Long getId() {
        return id;
    }

    public String getMessage() {
        return message;
    }

    public Integer getResponseCode() {
        return responseCode;
    }

    public Status getStatus() {
        return status;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    public void setCause(String cause) {
        this.cause = cause;
    }

    public void setDateStatus(Instant dateStatus) {
        this.dateStatus = dateStatus;
    }

    public void setDemandeAccusesReceptionId(Long demandeArId) {
        this.demandeAccusesReceptionId = demandeArId;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setResponseCode(Integer responseCode) {
        this.responseCode = responseCode;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "DemandeArStatusDTO{" +
                "id=" + getId() +
                ", dateStatus='" + getDateStatus() + "'" +
                ", responseCode=" + getResponseCode() +
                ", status='" + getStatus() + "'" +
                ", demandeAccusesReceptionId=" + getDemandeAccusesReceptionId() +
                ", message=" + getMessage() +
                ", cause=" + getCause() +
                "}";
    }
}
