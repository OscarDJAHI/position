package fr.gouv.justice.cpn.commun.model;


import com.fasterxml.jackson.annotation.JsonIgnore;
import fr.gouv.justice.cpn.commun.model.enumeration.Canal;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class DemandeEnvoiMessageDestinataireDTO {

    @EqualsAndHashCode.Include
    private Long id;

    @EqualsAndHashCode.Include
    private String email;

    private Canal canal;

    private String domain;

    @JsonIgnore
    private Long messageId;
}
