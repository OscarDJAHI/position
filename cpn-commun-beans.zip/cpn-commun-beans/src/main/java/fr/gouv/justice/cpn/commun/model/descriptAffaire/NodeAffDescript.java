package fr.gouv.justice.cpn.commun.model.descriptAffaire;

import java.util.List;


public class NodeAffDescript {
    public static class Builder {

        private final NodeAffDescript nodeAff;

        public Builder() {
            this.nodeAff = new NodeAffDescript();
        }

        public Builder addNodeAff(NodeAffDescript nodeAff) {
            this.nodeAff.getNodeAffs().add(nodeAff);
            return this;
        }

        public NodeAffDescript build() {
            return nodeAff;
        }

        public Builder withDescription(String description) {
            this.nodeAff.setDescription(description);
            return this;
        }

        public Builder withDoc_scelles(String doc_scelles) {
            this.nodeAff.setDoc_scelles(doc_scelles);
            return this;
        }

        public Builder withDownloadUrl(String downloadUrl) {
            this.nodeAff.setDownloadUrl(downloadUrl);
            return this;
        }

        public Builder withName(String name) {
            this.nodeAff.setName(name);
            return this;
        }

        public Builder withNodeAffs(List<NodeAffDescript> nodeAffs) {
            this.nodeAff.setNodeAffs(nodeAffs);
            return this;
        }

        public Builder withNodeRef(String nodeRef) {
            this.nodeAff.setNodeRef(nodeRef);
            return this;
        }

        public Builder withTaille(String taille) {
            this.nodeAff.setTaille(taille);
            return this;
        }

        public Builder withType(String type) {
            this.nodeAff.setType(type);
            return this;
        }
    }
    private String                nodeRef;
    private String                name;
    private String                description;
    private String                taille;
    private String                type;
    private String                downloadUrl;
    private List<NodeAffDescript> nodeAffs;
    private String                doc_scelles;

    public String getDescription() {
        return description;
    }

    public String getDoc_scelles() {
        return doc_scelles;
    }

    public String getDownloadUrl() {
        return downloadUrl;
    }

    public String getName() {
        return name;
    }

    public List<NodeAffDescript> getNodeAffs() {
        return nodeAffs;
    }

    public String getNodeRef() {
        return nodeRef;
    }

    public String getTaille() {
        return taille;
    }

    public String getType() {
        return type;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDoc_scelles(String doc_scelles) {
        this.doc_scelles = doc_scelles;
    }

    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNodeAffs(List<NodeAffDescript> nodeAffs) {
        this.nodeAffs = nodeAffs;
    }

    public void setNodeRef(String nodeRef) {
        this.nodeRef = nodeRef;
    }

    public void setTaille(String taille) {
        this.taille = taille;
    }

    public void setType(String type) {
        this.type = type;
    }

}
