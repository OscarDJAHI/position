package fr.gouv.justice.cpn.commun.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Informations sur l'Affaire supprimee")
public class AffaireSupprimeeArbo extends AffaireArbo {

    public static class Builder {
        private final AffaireSupprimeeArbo affaireSupprimee;

        public Builder() {
            this.affaireSupprimee = new AffaireSupprimeeArbo();
        }

        public AffaireSupprimeeArbo build() {
            return affaireSupprimee;
        }

        public Builder withIs_Corbeille(boolean is_corbeille) {
            this.affaireSupprimee.setIs_corbeille(is_corbeille);
            return this;
        }

        public Builder withIs_delete(boolean is_delete) {
            this.affaireSupprimee.setIs_delete(is_delete);
            return this;
        }
    }
    @ApiModelProperty(value = "affaire dans la corbeille", example = "true")
    private boolean is_corbeille;
    @ApiModelProperty(value = "affaire supprimee definitivement", example = "true")
    private boolean is_delete;

    public boolean isIs_corbeille() {
        return is_corbeille;
    }

    public boolean isIs_delete() {
        return is_delete;
    }

    public void setIs_corbeille(boolean is_corbeille) {
        this.is_corbeille = is_corbeille;
    }

    public void setIs_delete(boolean is_delete) {
        this.is_delete = is_delete;
    }
}
