package fr.gouv.justice.cpn.commun.beans.journal.reception.idj;

import com.fasterxml.jackson.annotation.JsonFormat;
import fr.gouv.justice.cpn.commun.beans.journal.reception.enumeration.CodeAction;
import fr.gouv.justice.cpn.commun.beans.journal.reception.enumeration.EntiteDemandeur;
import lombok.Data;

import java.time.ZonedDateTime;

@Data
public class IdjDTO {

    public static final String DEFAULT_DATE_PATTERN = "yyyy-MM-dd'T'HH:mm:ss[xxx]";

    private String anneeDemande;

    private CodeAction codeAction;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DEFAULT_DATE_PATTERN)
    private ZonedDateTime dateDemande;

    private DemandeIDJ demandeIDJ;

    private EntiteDemandeur entiteDemandeurEnum;

    private String idApplication;

    private int pool;

    private String typeFlux;
}
