package fr.gouv.justice.cpn.commun.beans.journal.reception.dto;

import lombok.Data;

@Data
public class ProcedureFichierDTO {

    private Long id;

    private String idPdf;

    private Long procedureId;

    private String uri;
}
