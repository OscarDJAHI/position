package fr.gouv.justice.cpn.commun.model.enumeration;

public enum JobsEnum {

    JOB_RECUP_PROC_MI("job_recuperation_procedure_mi"),
    JOB_REJEU_PROC_MI("job_reprise_procedure_mi_en_erreur"),
    JOB_EMISSION_PIECE_NPP("job_emission_NPP"),
    JOB_ENVOI_MSG("job_envoi_message_pline_plex"),
    JOB_ENVOI_AR("job_telechargement_accuses_reception");

    private final String jobName;

    JobsEnum(String jobName) {
        this.jobName = jobName;
    }

    public String jobName() {
        return jobName;
    }


}
