package fr.gouv.justice.cpn.commun.model.enumeration;

import org.springframework.util.StringUtils;

import java.util.Arrays;

public enum TypeIdDPN {
    UNA_UPVA(""),
    IDJ("Dossier P\u00E9nal"),
    MINUTIER("Minutier"),
    NO_PARQUET("Num\u00E9ro Parquet"),
    APPI("D.A.P");

    private final String label;

    TypeIdDPN(final String label) {
        this.label = label;
    }

    public static TypeIdDPN parse(final String label) {
        if (StringUtils.isEmpty(label)) {
            throw new IllegalArgumentException("Sorry ! Something went wrong when trying to fetch DPN Type from label : Please provide a non empty label");
        }

        return Arrays.stream(values())
                     .filter(value -> value.label.equalsIgnoreCase(label))
                     .findFirst()
                     .orElseThrow(() -> new IllegalArgumentException("Sorry ! No DPN Type found for the label : [" + label + "]"));
    }

    public String label() {
        return this.label;
    }
}
