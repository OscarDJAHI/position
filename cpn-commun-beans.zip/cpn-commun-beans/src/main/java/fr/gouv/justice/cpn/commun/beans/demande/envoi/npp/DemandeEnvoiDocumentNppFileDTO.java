package fr.gouv.justice.cpn.commun.beans.demande.envoi.npp;

import fr.gouv.justice.cpn.commun.beans.document.DocumentDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class DemandeEnvoiDocumentNppFileDTO extends DocumentDTO {

    private Long demandeId;

    private Integer index;

    private String idNoeudNpp;

    private Boolean hasErrorUpdateStatus;
}
