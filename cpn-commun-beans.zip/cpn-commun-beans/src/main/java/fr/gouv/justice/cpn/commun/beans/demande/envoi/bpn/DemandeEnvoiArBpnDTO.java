package fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn;

import lombok.Data;

@Data
public class DemandeEnvoiArBpnDTO {

    private long idMessage;

    private String idNoeud;

    private String userMail;

    private String codeSrj;

    private String idLdap;
}
