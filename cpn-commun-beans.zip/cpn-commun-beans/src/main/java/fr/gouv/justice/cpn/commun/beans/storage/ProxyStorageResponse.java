package fr.gouv.justice.cpn.commun.beans.storage;

import lombok.Data;

@Data
public class ProxyStorageResponse {
    private String typeMessage;
    private String message;
    private String operation;
}
