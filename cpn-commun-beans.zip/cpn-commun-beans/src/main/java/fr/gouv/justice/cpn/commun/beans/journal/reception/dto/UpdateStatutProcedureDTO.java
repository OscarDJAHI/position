package fr.gouv.justice.cpn.commun.beans.journal.reception.dto;

import fr.gouv.justice.cpn.commun.beans.journal.reception.enumeration.StatutProcedureNPP;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.time.LocalDateTime;

@ApiModel(description = "Modele servant a mettre a jour le statut de la procedure")
@Data
@ToString
@EqualsAndHashCode
public class UpdateStatutProcedureDTO {

    private Long idProcedure;

    private StatutProcedureNPP status;

    private LocalDateTime updateDate;

    private String nomUtilisateur;

    private String prenomUtilisateur;

    private String loginUtilisateur;

    private String idAffaire;

    private String message;

}
