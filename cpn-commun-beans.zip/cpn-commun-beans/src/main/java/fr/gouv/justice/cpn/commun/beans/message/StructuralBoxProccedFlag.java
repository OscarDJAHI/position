package fr.gouv.justice.cpn.commun.beans.message;

public enum StructuralBoxProccedFlag {
    TRAITE,
    NON_TRAITE,
    SANS_VALEUR
}
