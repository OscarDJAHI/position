package fr.gouv.justice.cpn.commun.beans.storage;

import lombok.Data;

import java.io.File;
import java.util.Map;

@Data
public class StorageRequest {

    private String path;

    private File file;

    private Map<String, String> filesNamesAndUri;
}
