package fr.gouv.justice.cpn.commun.beans.generic;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.time.Instant;

@Data
public class ResponseDTO {

    private Long id;

    private int code;

    @JsonIgnore
    private Instant date;

    private String message;
}
