package fr.gouv.justice.cpn.commun.beans.journal.reception.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
public class OrientationDTO extends AbstractBaseDTO {

    private String code;

    private Boolean favori;

    private ServiceMjDTO service;

    private SousServiceDTO sousService;

    private CouleurDTO couleur;

    private String codeSrj;
}
