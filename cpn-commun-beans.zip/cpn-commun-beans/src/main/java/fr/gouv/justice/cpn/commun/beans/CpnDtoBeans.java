package fr.gouv.justice.cpn.commun.beans;

public class CpnDtoBeans {

    public static void main(String[] args) {

    }
}
