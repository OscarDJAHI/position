package fr.gouv.justice.cpn.commun.beans.journal.reception.enumeration;

public enum DeferrementMP {
    N,
    O
}
