package fr.gouv.justice.cpn.commun.model;


import fr.gouv.justice.cpn.commun.model.enumeration.Status;

import java.time.Instant;

public class MessageStatutDTO {

    private Long id;

    private Status statutCode;

    private Integer responseCode;

    private Instant dateStatut;

    private Long messageId;

    private String traitementMessage;

    private String cause;

    public String getCause() {
        return cause;
    }

    public Instant getDateStatut() {
        return dateStatut;
    }

    public Long getId() {
        return id;
    }

    public Long getMessageId() {
        return messageId;
    }

    public Integer getResponseCode() {
        return responseCode;
    }

    public Status getStatutCode() {
        return statutCode;
    }

    public String getTraitementMessage() {
        return traitementMessage;
    }

    public void setCause(String cause) {
        this.cause = cause;
    }

    public void setDateStatut(Instant dateStatut) {
        this.dateStatut = dateStatut;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setMessageId(Long messageId) {
        this.messageId = messageId;
    }

    public void setResponseCode(Integer responseCode) {
        this.responseCode = responseCode;
    }

    public void setStatutCode(Status statutCode) {
        this.statutCode = statutCode;
    }

    public void setTraitementMessage(String traitementMessage) {
        this.traitementMessage = traitementMessage;
    }
}
