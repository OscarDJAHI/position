package fr.gouv.justice.cpn.commun.beans.message.detail;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@ApiModel(description = "Sous ensemble du message utilise pour indiquer le status du message envoye.")
@Data
public class AuditDTO {

    @ApiModelProperty(value = "List des Viewed, array d'objets")
    private List<ViewedDTO> viewed;

    @ApiModelProperty(value = "List des Dowloaded, array d'objets")
    private List<DownloadedDTO> downloaded;
}
