package fr.gouv.justice.cpn.commun.beans.message;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel(description = "Sous ensemble du message utilise pour une selection en fonction de l'identifiant du message.")
@Data
public class MessageRequestDTO {

    @ApiModelProperty(example = "2", value = "L'identifiant unique du message")
    private String id;

    @ApiModelProperty(example = "1", value = "Rend visible les éléments vu et telecharge a 1 et les cache sinon 0")
    @JsonProperty("with_audit")
    private int withAudit;
}
