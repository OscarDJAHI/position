package fr.gouv.justice.cpn.commun.model.enumeration;

public enum StatutEnvoiDemande {
    SUCCES,
    ECHEC
}
