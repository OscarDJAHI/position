package fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * @author sez
 */
@JsonIgnoreProperties
@Data
@NoArgsConstructor
public class NodeDto {
    private Long                      id;
    private String                    text;
    private String                    userUid;
    private boolean                   isOwner;
    private boolean                   children;
    private String                    icon;
    private String                    type;
    private String                    parent;
    private int                       level;
    private String                    kind;
    private String                    format;
    private boolean                   signed;
    private String                    path;
    private Boolean                   edit;
    private List<AssociatedNumberDto> associatedNumbers = new ArrayList<>();
}
