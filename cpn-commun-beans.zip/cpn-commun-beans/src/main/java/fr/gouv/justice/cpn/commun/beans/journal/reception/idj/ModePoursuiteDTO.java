package fr.gouv.justice.cpn.commun.beans.journal.reception.idj;

import fr.gouv.justice.cpn.commun.beans.journal.reception.enumeration.DeferrementMP;
import lombok.Data;

@Data
public class ModePoursuiteDTO {
    private DeferrementMP deferrementMP;
    private String        modePoursuite;
    private String        prioriteMP;
}
