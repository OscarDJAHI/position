package fr.gouv.justice.cpn.commun.beans.message;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.time.Instant;
import java.util.HashSet;
import java.util.Set;

@Data
public class MessageListDTO {

    private Long id = null;

    private String subject = null;

    @JsonProperty("creation_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant creationDate = null;

    @JsonProperty("expiration_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant expirationDate = null;

    private String project = null;

    @JsonProperty("project_id")
    private String projectId = null;

    private String sender = null;

    private Set<String> recipients = new HashSet<>();

    @JsonProperty("nb_files")
    private int nbFiles;

    private int viewed;

    private int sent;

    @JsonProperty("isAvocat")
    private boolean avocat;

    private StructuralBoxProccedFlag traite;

    private String idExterne;

    private String originMessage;

    private String emailBoite;

    private Boolean arEbarreauSent;

    private boolean deleted;

    private String deletedBy;

    private Instant deletedDate;

    private String comment;

    private Set<MessageListFichiersDTO> files = new HashSet<>();

    private Set<MessageActionHistoryDTO> messageActionHistory = new HashSet<>();
}
