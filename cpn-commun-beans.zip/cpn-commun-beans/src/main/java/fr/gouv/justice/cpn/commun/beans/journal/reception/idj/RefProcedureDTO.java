package fr.gouv.justice.cpn.commun.beans.journal.reception.idj;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.ZonedDateTime;

@Data
public class RefProcedureDTO {

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = IdjDTO.DEFAULT_DATE_PATTERN)
    private ZonedDateTime dateRef;

    private String refProcAjout;

    private String refProcSupp;
}
