package fr.gouv.justice.cpn.commun.model;

import java.io.Serializable;
import java.util.StringJoiner;

public class NoeudNpp implements Serializable {

    private String noeud;

    private String nomfichier;

    public String getNoeud() {
        return noeud;
    }

    public String getNomfichier() {
        return nomfichier;
    }

    public NoeudNpp noeud(String noeud) {
        this.noeud = noeud;
        return this;
    }

    public NoeudNpp nomfichier(String nomfichier) {
        this.nomfichier = nomfichier;
        return this;
    }

    public void setNoeud(String noeud) {
        this.noeud = noeud;
    }

    public void setNomfichier(String nomfichier) {
        this.nomfichier = nomfichier;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", NoeudNpp.class.getSimpleName() + "[", "]")
                .add("noeud='" + noeud + "'")
                .add("nomfichier='" + nomfichier + "'")
                .toString();
    }
}
