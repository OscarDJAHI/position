package fr.gouv.justice.cpn.commun.model.descriptAffaire;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Contenu de le l'affaire dans le descriptAffaire")
public class ContentDescript {

    @ApiModelProperty(value = "Donnees utilisateur/service(s)", example = "username, affaire")
    private TacheExportArboAff tacheArboAff;

    public TacheExportArboAff getTacheArboAff() {
        return tacheArboAff;
    }

    public void setTacheArboAff(TacheExportArboAff tacheArboAff) {
        this.tacheArboAff = tacheArboAff;
    }
}
