package fr.gouv.justice.cpn.commun.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.EqualsAndHashCode;


@Data
@EqualsAndHashCode
public class FichierDemandeEnvoiMessageDTO {

    private Long id;

    private String nom;

    private String type;

    private String idSps;

    @JsonIgnore
    private Long messageId;

    private String uri;

    private String source;
}
