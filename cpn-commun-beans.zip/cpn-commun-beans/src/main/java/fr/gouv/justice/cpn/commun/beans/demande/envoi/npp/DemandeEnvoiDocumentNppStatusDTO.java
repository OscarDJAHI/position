package fr.gouv.justice.cpn.commun.beans.demande.envoi.npp;

import com.fasterxml.jackson.annotation.JsonIgnore;
import fr.gouv.justice.cpn.commun.beans.demande.DemandeEnvoiDocumentStatusEnum;
import lombok.Data;

import java.time.Instant;

@Data
public class DemandeEnvoiDocumentNppStatusDTO {

    private Long id;

    private DemandeEnvoiDocumentStatusEnum statutCode;

    private Integer responseCode;

    private Instant dateStatut;

    private String message;

    @JsonIgnore
    private String cause;

    private Long demandeId;
}
