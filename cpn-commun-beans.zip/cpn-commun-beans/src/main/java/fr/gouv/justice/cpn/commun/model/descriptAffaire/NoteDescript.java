package fr.gouv.justice.cpn.commun.model.descriptAffaire;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "note", propOrder = {
        "dateCreation",
        "detailAction", "prenomUtilisateur", "typeAction"
})
public class NoteDescript {

    public static class Builder {

        private final NoteDescript note;

        public Builder() {
            this.note = new NoteDescript();
        }

        public NoteDescript build() {
            return note;
        }

        public Builder withDateDeCreation(String dateCreation) {
            this.note.setDateCreation(dateCreation);
            return this;
        }

        public Builder withText(String text) {
            this.note.setDetailAction(text);
            return this;
        }

        public Builder withTypeNote(String typeNote) {
            this.note.setTypeAction(typeNote);
            return this;
        }

        public Builder withUtilisateur(String utilisateur) {
            this.note.setPrenomUtilisateur(utilisateur);
            return this;
        }

    }
    /**
     * the dateCreation attribute.
     */
    @XmlAttribute(name = "dateCreation")
    private String dateCreation;
    /**
     * the detailAction attribute.
     */
    @XmlAttribute(name = "texte")
    private String detailAction;
    /**
     * the prenomUtilisateur attribute.
     */
    @XmlAttribute(name = "utilisateur")
    private String prenomUtilisateur;
    /**
     * the typeAction attribute.
     */
    @XmlAttribute(name = "typeNote")
    private String typeAction;

    /**
     * @return the dateCreation
     */
    public String getDateCreation() {
        return dateCreation;
    }

    /**
     * @return the detailAction
     */
    public String getDetailAction() {
        return detailAction;
    }

    /**
     * @return the prenomUtilisateur
     */
    public String getPrenomUtilisateur() {
        return prenomUtilisateur;
    }

    /**
     * @return the typeAction
     */
    public String getTypeAction() {
        return typeAction;
    }

    /**
     * @param dateCreation the dateCreation to set
     */
    public void setDateCreation(String dateCreation) {
        this.dateCreation = dateCreation;
    }

    /**
     * @param detailAction the detailAction to set
     */
    public void setDetailAction(String detailAction) {
        this.detailAction = detailAction;
    }

    /**
     * @param prenomUtilisateur the prenomUtilisateur to set
     */
    public void setPrenomUtilisateur(String prenomUtilisateur) {
        this.prenomUtilisateur = prenomUtilisateur;
    }

    /**
     * @param typeAction the typeAction to set
     */
    public void setTypeAction(String typeAction) {
        this.typeAction = typeAction;
    }
}
