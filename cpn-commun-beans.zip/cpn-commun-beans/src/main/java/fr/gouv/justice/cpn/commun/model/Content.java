package fr.gouv.justice.cpn.commun.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Contenu de l'Arborescence")
public class Content {

    @ApiModelProperty(value = "Donnees utilisateur/service(s)", example = "username, liste des services")
    private TacheArbo tacheArboNpp;

    public TacheArbo getTacheArboNpp() {
        return tacheArboNpp;
    }

    public void setTacheArboNpp(TacheArbo tacheArboNpp) {
        this.tacheArboNpp = tacheArboNpp;
    }
}
