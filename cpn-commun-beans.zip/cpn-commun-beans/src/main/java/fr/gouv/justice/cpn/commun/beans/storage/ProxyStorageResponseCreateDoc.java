package fr.gouv.justice.cpn.commun.beans.storage;

import lombok.Data;

@Data
public class ProxyStorageResponseCreateDoc extends ProxyStorageResponse {
    private String pathDocument;
}
