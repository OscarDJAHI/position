package fr.gouv.justice.cpn.commun.beans.demande.envoi.npp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.Instant;

@ApiModel(description = "Demande d'envoi de documents vers NPP")
@Data
public abstract class AbstractDemandeEnvoiDocumentNppDTO {

    private static final long serialVersionUID = 1;

    private Long id;

    @ApiModelProperty(value = "Origine de la demande : ANTAI, KSIOP …", example = "KSIOP")
    private String origine;

    @ApiModelProperty(required = true,
                      value = " I (création Affaire et Ajout des documents) ou A (Ajout des documents à une affaire existante)",
                      example = "A")
    private FonctionEnum fonction;

    @ApiModelProperty(value = "Permet a la PFE de définir quel NPP doit être appellé ", example = "")
    private String codeSrj;

    @ApiModelProperty(required = true,
                      value = "Nom de l’affaire à créer ou Nom de l’affaire (de NPP) où il faut déposer les fichiers.")
    private String affaire;

    @ApiModelProperty(required = true, value = "Nom du service où l’affaire doit être créée")
    private String service;

    @ApiModelProperty(value = "Nom du sous-service où l’affaire doit être créée")
    private String sservice;

    @ApiModelProperty(value = "Noeud Alfresco du service, du sous-service ou du regroupement où l'on souhaite déposer l'affaire.")
    private String noeudAlfresco;

    @ApiModelProperty(value = "identifiant justice")
    private String codeDossier;

   
    private boolean dpn;

    @ApiModelProperty(value = "dossier penal numerique")
    private String typeDossier;

    @ApiModelProperty(
            value = "Chaque valeur d’Éléments complémentaires (tel que le nom de la personne, son numéro de tel. etc) sera séparée par « ## ».",
            example = "2017114453##4545612315641331##Dupond##Pierre##1 Rue de Paris##75001##PARIS##75101")
    private String complement;

    private Instant createdDate;

    private String createdBy;

    private Integer nbTry;

    @ApiModelProperty(
            value = "Type de l'affaire : SIMPLE, PARQUET, INSTRUCTION",
            example = "PARQUET")
    private String typeAffaire;

    @ApiModelProperty(
            value = "Description de l'affaire")
    private String description;
}
