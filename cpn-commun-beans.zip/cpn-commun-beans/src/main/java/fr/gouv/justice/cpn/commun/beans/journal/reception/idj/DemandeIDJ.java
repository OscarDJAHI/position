package fr.gouv.justice.cpn.commun.beans.journal.reception.idj;

import lombok.Data;

import java.util.List;

@Data
public class DemandeIDJ {
    private String                 codeServDemandeur;
    private String                 idjActif;
    private String                 idjActif2;
    private String                 idjInactif;
    private String                 libelleServDemandeur;
    private List<ModePoursuiteDTO> modePoursuites;
    private List<NatAffDTO>        natAffs;
    private List<NatInfDTO>        natInfs;
    private int                    nbAutMajeur;
    private int                    nbAutMineur;
    private int                    nbVictMineur;
    private List<RefProcedureDTO>  refProcedures;
    private List<ServiceDTO>       services;
}
