package fr.gouv.justice.cpn.commun.model.enumeration;

/**
 * The Status enumeration.
 */
public enum Status {
    DEMANDE,
    ECHEC,
    ERREUR_EXCHANGE,
    ERREUR_MAB_ECHANGE,
    ERREUR_MAS_INTERFACE,
    ERREUR_NPP,
    ERREUR_SEQUESTRE,
    ERREUR_SPS,
    ERREUR_BPN,
    ERREUR_UPDATE_STATUS,
    SUCCES,
    TEMPORAIRE,
    TRAITEE
}
