package fr.gouv.justice.cpn.commun.beans.message;

public enum MessageTypeEnum {
    ALL,
    INBOX,
    SENT;
}
