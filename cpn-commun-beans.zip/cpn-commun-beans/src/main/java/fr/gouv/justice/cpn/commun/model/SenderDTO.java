package fr.gouv.justice.cpn.commun.model;

import java.util.Objects;

public class SenderDTO {

    private Long id;

    private String firstName;

    private String lastName;

    private String email;

    private String userId;

    private String codeSrj;

    private String emailBoiteStructurelle;

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        SenderDTO senderDTO = (SenderDTO) o;
        if (senderDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), senderDTO.getId());
    }

    public String getCodeSrj() {
        return codeSrj;
    }

    public String getEmail() {
        return email;
    }

    public String getEmailBoiteStructurelle() {
        return emailBoiteStructurelle;
    }

    public String getFirstName() {
        return firstName;
    }

    public Long getId() {
        return id;
    }

    public String getLastName() {
        return lastName;
    }

    public String getUserId() {
        return userId;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    public void setCodeSrj(String codeSrj) {
        this.codeSrj = codeSrj;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setEmailBoiteStructurelle(String emailBoiteStructurelle) {
        this.emailBoiteStructurelle = emailBoiteStructurelle;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "SenderDTO{" +
                "id=" + getId() +
                ", firsName='" + getFirstName() + "'" +
                ", lastName='" + getLastName() + "'" +
                ", email='" + getEmail() + "'" +
                ", userId='" + getUserId() + "'" +
                ", codeSrj='" + getCodeSrj() + "'" +
                "}";
    }
}
