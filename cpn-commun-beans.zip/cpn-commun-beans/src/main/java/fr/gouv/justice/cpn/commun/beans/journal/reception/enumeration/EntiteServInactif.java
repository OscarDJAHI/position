package fr.gouv.justice.cpn.commun.beans.journal.reception.enumeration;

public enum EntiteServInactif {
    CE,
    CP,
    DJ,
    GN,
    IP,
    NA,
    PN
}
