package fr.gouv.justice.cpn.commun.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "Elements wich permit to access at documents user")
public class DescriptArboApi {

    @ApiModelProperty(value = "Fonction appelee", example = "DescriptArbo")
    private String  fonction;
    @ApiModelProperty(value = "Code de l'utilisateur", example = "username")
    private String  codeUtilisateur;
    @ApiModelProperty(value = "Code de Srj", example = "100041")
    private String  codeSrj;
    @ApiModelProperty(value = "Date de la mise a jour", example = "19/02/2021 11:52:42")
    private String  filtreDateMaj;
    @ApiModelProperty(value = "Filtre uniquement sur elt DPN", example = "")
    private String  filtreQueDpn;
    @ApiModelProperty(value = "Filtre sur elt a retourner", example = "")
    private String  filtreRetour;
    @ApiModelProperty(value = "Service appele", example = "Archivage")
    private String  filtreService;
    @ApiModelProperty(value = "Information sur la taille connue", example = "true")
    private boolean infosTaille;
    @ApiModelProperty(value = "Information sur les affaires dans le corbeille NPP ou supprimees", example = "true")
    private boolean avecCorbeille;

    public DescriptArboApi codeSrj(String codeSrj) {
        this.codeSrj = codeSrj;
        return this;
    }

    public DescriptArboApi codeUtilisateur(String codeUtilisateur) {
        this.codeUtilisateur = codeUtilisateur;
        return this;
    }

    public DescriptArboApi filtreDateMaj(String filtreDateMaj) {
        this.filtreDateMaj = filtreDateMaj;
        return this;
    }

    public DescriptArboApi filtreQueDpn(String filtreQueDpn) {
        this.filtreQueDpn = filtreQueDpn;
        return this;
    }

    public DescriptArboApi filtreRetour(String filtreRetour) {
        this.filtreRetour = filtreRetour;
        return this;
    }

    public DescriptArboApi filtreService(String filtreService) {
        this.filtreService = filtreService;
        return this;
    }

    public DescriptArboApi fonction(String fonction) {
        this.fonction = fonction;
        return this;
    }

    public String getCodeSrj() {
        return codeSrj;
    }

    public String getCodeUtilisateur() {
        return codeUtilisateur;
    }

    public String getFiltreDateMaj() {
        return filtreDateMaj;
    }

    public String getFiltreQueDpn() {
        return filtreQueDpn;
    }

    public String getFiltreRetour() {
        return filtreRetour;
    }

    public String getFiltreService() {
        return filtreService;
    }

    public String getFonction() {
        return fonction;
    }

    public DescriptArboApi infosTaille(boolean infosTaille) {
        this.infosTaille = infosTaille;
        return this;
    }

    public boolean isAvecCorbeille() {
        return avecCorbeille;
    }

    public boolean isInfosTaille() {
        return infosTaille;
    }

    public void setAvecCorbeille(boolean avecCorbeille) {
        this.avecCorbeille = avecCorbeille;
    }

    public void setCodeSrj(String codeSrj) {
        this.codeSrj = codeSrj;
    }

    public void setCodeUtilisateur(String codeUtilisateur) {
        this.codeUtilisateur = codeUtilisateur;
    }

    public void setFiltreDateMaj(String filtreDateMaj) {
        this.filtreDateMaj = filtreDateMaj;
    }

    public void setFiltreQueDpn(String filtreQueDpn) {
        this.filtreQueDpn = filtreQueDpn;
    }

    public void setFiltreRetour(String filtreRetour) {
        this.filtreRetour = filtreRetour;
    }

    public void setFiltreService(String filtreService) {
        this.filtreService = filtreService;
    }

    public void setFonction(String fonction) {
        this.fonction = fonction;
    }

    public void setInfosTaille(boolean infosTaille) {
        this.infosTaille = infosTaille;
    }
}
