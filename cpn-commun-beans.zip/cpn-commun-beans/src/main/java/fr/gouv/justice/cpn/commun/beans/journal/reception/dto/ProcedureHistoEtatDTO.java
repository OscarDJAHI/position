package fr.gouv.justice.cpn.commun.beans.journal.reception.dto;

import fr.gouv.justice.cpn.commun.beans.journal.reception.enumeration.StatutProcedureJournal;
import lombok.Data;

import java.time.Instant;

@Data
public class ProcedureHistoEtatDTO {

    private Long id;

    private StatutProcedureJournal etat;

    private Instant dateEtat;

    private String uidUtilisateur;

    private Long procedureId;
}
