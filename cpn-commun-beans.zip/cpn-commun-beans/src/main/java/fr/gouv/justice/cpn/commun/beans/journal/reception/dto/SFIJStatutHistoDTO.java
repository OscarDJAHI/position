package fr.gouv.justice.cpn.commun.beans.journal.reception.dto;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
public class SFIJStatutHistoDTO implements Serializable {

    private Long id;

    private int etape;

    private String statut;

    private Long idSFIJ;

    private Long procedureId;

    private LocalDateTime dateEnvoi;

    public SFIJStatutHistoDTO dateEnvoi(LocalDateTime dateEnvoi) {
        this.dateEnvoi = dateEnvoi;
        return this;
    }

    public SFIJStatutHistoDTO etape(int etape) {
        this.etape = etape;
        return this;
    }

    public SFIJStatutHistoDTO idSFIJ(Long idSFIJ) {
        this.idSFIJ = idSFIJ;
        return this;
    }

    public SFIJStatutHistoDTO procedureId(Long procedureId) {
        this.procedureId = procedureId;
        return this;
    }

    public SFIJStatutHistoDTO statut(String statut) {
        this.statut = statut;
        return this;
    }
}
