package fr.gouv.justice.cpn.commun.beans.message;

public enum MessageOriginEnum {
    PLINE,
    PLEX,
    BS_PLEX,
    BS_PLINE,
    EXCHANGE_CEP;
}
