package fr.gouv.justice.cpn.commun.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.time.LocalDateTime;

@ApiModel(description = "Sous ensemble du message utilise pour indiquer le status du telechargement de la piece jointe du message.")
public class Downloaded {

    @JsonProperty("user_index")
    private int userIndex;

    @JsonProperty("file_index")
    private int fileIndex;

    @JsonProperty("date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private LocalDateTime date;

    @ApiModelProperty(example = "02/06/2020 11:01:10", value = "La date et heure du telechargement de la piece jointe")
    public LocalDateTime getDate() {
        return this.date;
    }

    @ApiModelProperty(example = "0", value = "Index correspondant a celui de la piece jointe")
    public int getFileIndex() {
        return this.fileIndex;
    }

    @ApiModelProperty(example = "1", value = "L'index utilisateur identique a celui attribue au destinataire du message")
    public int getUserIndex() {
        return this.userIndex;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public void setFileIndex(int fileIndex) {
        this.fileIndex = fileIndex;
    }

    public void setUserIndex(int userIndex) {
        this.userIndex = userIndex;
    }
}
