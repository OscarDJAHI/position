package fr.gouv.justice.cpn.commun.beans.message.detail;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel(description = "Sous ensemble du message utilise pour indiquer la liste des destinataires du message.")
@Data
abstract class AbstractContact {

    @ApiModelProperty(example = "0", value = "L'index attribue au destinataire/emetteur du message")
    private int index;

    @ApiModelProperty(example = "johndoe@acme.dtl", value = "Email du destinataire")
    private String email;

    @ApiModelProperty(example = "johneo@acme.dtl", value = "Identite du destinataire")
    @JsonProperty("uid")
    private String userId;

    @ApiModelProperty(example = "CPN", value = "Le domaine vers lequel est destine l'envoi")
    private String domain;

    @ApiModelProperty(example = "registered", value = "Type ")
    private String type;
}
