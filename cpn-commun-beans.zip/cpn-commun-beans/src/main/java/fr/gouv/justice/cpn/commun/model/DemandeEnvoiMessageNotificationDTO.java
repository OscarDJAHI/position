package fr.gouv.justice.cpn.commun.model;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class DemandeEnvoiMessageNotificationDTO {

    private DemandeEnvoiMessageDTO demand;

    private DemandeEnvoiMessageResponseDTO response;
}
