package fr.gouv.justice.cpn.commun.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import fr.gouv.justice.cpn.commun.model.enumeration.Status;
import lombok.Data;

import java.time.Instant;

@Data
public class UpdateEnvoiDTO {

    /**
     * identifiant de la demande
     */
    private String idDemande;

    /**
     * Status de l'envoi
     */
    private Status status;

    /**
     * details status
     */
    private String message;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private Instant dateRetour;
}
