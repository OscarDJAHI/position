package fr.gouv.justice.cpn.commun.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

@ApiModel(description = "Donnees utilisateur/service(s)")
public class TacheArbo {

    public static class Builder {

        private final TacheArbo tacheArbo;

        public Builder() {
            this.tacheArbo = new TacheArbo();
        }

        public TacheArbo build() {
            return this.tacheArbo;
        }

        public Builder withAffaireSupprimees(List<AffaireSupprimeeArbo> affaireSupprimees) {
            this.tacheArbo.setAffairesSupprimees(affaireSupprimees);
            return this;
        }

        public Builder withServices(List<ServiceArbo> services) {
            this.tacheArbo.setServices(services);
            return this;
        }

        public Builder withUtilisateur(String utilisateur) {
            this.tacheArbo.setUtilisateur(utilisateur);
            return this;
        }

    }
    @ApiModelProperty(value = "Nom de l'utilisateur", example = "admin")
    private String                     utilisateur;
    @ApiModelProperty(value = "Liste des services", example = "Service jusridique, Service detention")
    private List<ServiceArbo>          services;
    @ApiModelProperty(value = "Liste d'affaires supprimees", example = "AffaireSupprimee1, AffaireSupprimee2")
    private List<AffaireSupprimeeArbo> affairesSupprimees;

    public List<AffaireSupprimeeArbo> getAffairesSupprimees() {
        return affairesSupprimees;
    }

    public List<ServiceArbo> getServices() {
        return services;
    }

    public String getUtilisateur() {
        return utilisateur;
    }

    public void setAffairesSupprimees(List<AffaireSupprimeeArbo> affairesSupprimees) {
        this.affairesSupprimees = affairesSupprimees;
    }

    public void setServices(List<ServiceArbo> services) {
        this.services = services;
    }

    public void setUtilisateur(String utilisateur) {
        this.utilisateur = utilisateur;
    }
}
