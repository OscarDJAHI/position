package fr.gouv.justice.cpn.commun.beans.journal.reception.dto;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class RefSourceDTO {

    @NotNull
    private String libelleCourt;

    private String libelle;
}
