package fr.gouv.justice.cpn.commun.beans.document;

import lombok.Data;

@Data
public class DocumentDTO {

    private Long id;

    private String name;

    private Integer size;

    private String type;

    private String externalId;

    private String source;
}
