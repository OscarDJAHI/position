package fr.gouv.justice.cpn.commun.model.descriptAffaire;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "description affaire of authorised access documents user")
public class DescriptAffaireApi {
    @ApiModelProperty(value = "Date du jour", example = "23/06/2021 13:56:02")
    String          date;
    @ApiModelProperty(value = "Status code", example = "200")
    int             code;
    @ApiModelProperty(value = "Message", example = "OK")
    String          message;
    @ApiModelProperty(value = "Explication du code renvoye", example = "Traitement effectue avec succes")
    String          cause;
    @ApiModelProperty(value = "Contenu de l'arborescence", example = "Donnees utilisateur/affaire(s)")
    ContentDescript content;

    public String getCause() {
        return cause;
    }

    public int getCode() {
        return code;
    }

    public ContentDescript getContent() {
        return content;
    }

    public String getDate() {
        return date;
    }

    public String getMessage() {
        return message;
    }

    public void setCause(String cause) {
        this.cause = cause;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public void setContent(ContentDescript content) {
        this.content = content;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
