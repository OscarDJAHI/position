package fr.gouv.justice.cpn.commun.beans.annuaires;

public enum Status {
    IN_PROGRESS{
        @Override
        public String toString() {
            return "En cours";
        }
    },
    TRUE {
        @Override
        public String toString() {
            return "OK";
        }
    },
    FALSE{
        @Override
        public String toString() {
            return "NO";
        }
    };
}
