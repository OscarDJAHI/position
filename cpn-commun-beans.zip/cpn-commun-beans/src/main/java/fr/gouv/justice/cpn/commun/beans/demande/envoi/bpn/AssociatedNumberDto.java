package fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn;

import lombok.Data;

@Data
public class AssociatedNumberDto {

    private String numero;
    private String type;
}
