package fr.gouv.justice.cpn.commun.beans.message.detail;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.time.LocalDateTime;

@ApiModel(description = "Sous ensemble du message utilise pour indiquer le status du telechargement de la piece jointe du message.")
@Data
public abstract class AbstractAttachmentAudit {

    @ApiModelProperty(example = "1", value = "L'index utilisateur identique a celui attribue au destinataire du message")
    @JsonProperty("user_index")
    private int userIndex;

    @ApiModelProperty(example = "0", value = "Index correspondant a celui de la piece jointe")
    @JsonProperty("file_index")
    private int fileIndex;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    private LocalDateTime date;
}
