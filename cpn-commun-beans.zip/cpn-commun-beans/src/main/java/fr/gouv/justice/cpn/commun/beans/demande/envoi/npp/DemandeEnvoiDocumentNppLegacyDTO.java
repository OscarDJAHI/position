package fr.gouv.justice.cpn.commun.beans.demande.envoi.npp;

import fr.gouv.justice.cpn.commun.beans.demande.DemandeEnvoiDocumentStatusEnum;
import fr.gouv.justice.cpn.commun.beans.message.MessageOriginEnum;
import lombok.Data;

import java.time.Instant;
import java.util.Set;

@Data
public class DemandeEnvoiDocumentNppLegacyDTO {

    private Long id;

    private Integer idMessage;

    private Instant creationDate;

    private String idj;

    private String idExterne;

    private MessageOriginEnum originMessage;

    private DemandeEnvoiDocumentStatusEnum status;

    private Integer nbTry;

    private String codeSrj;

    private String codeAppi;

    private String email;

    private String emailBs;

    private Set<DemandeEnvoiDocumentNppFileDTO> files;

    private Set<DemandeEnvoiDocumentNppStatusDTO> statuts;
}
