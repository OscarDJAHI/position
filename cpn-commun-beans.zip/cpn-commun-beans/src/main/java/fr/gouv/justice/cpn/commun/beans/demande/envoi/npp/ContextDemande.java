package fr.gouv.justice.cpn.commun.beans.demande.envoi.npp;

/**
 * <p>Enum qui sert pour les logs indicateurs.</p>
 * <p>Cette propriétée sert à déterminer dans quel contexte on se trouve lors du cut sur
 * <code>sendDocumentToNPP</code></p>
 */
public enum ContextDemande {
    DL_DOC,
    DL_AR
}
