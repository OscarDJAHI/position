package fr.gouv.justice.cpn.commun.beans.journal.reception.enumeration;

public enum StatutProcedureJournal {
    A_TRAITER,
    EN_COURS,
    TRAITE,
    ECHEC
}
