package fr.gouv.justice.cpn.commun.beans.journal.reception.idj;

import com.google.code.beanmatchers.BeanMatchers;
import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.Random;

import static com.google.code.beanmatchers.BeanMatchers.hasValidBeanConstructor;
import static com.google.code.beanmatchers.BeanMatchers.hasValidBeanEquals;
import static com.google.code.beanmatchers.BeanMatchers.hasValidBeanHashCode;
import static com.google.code.beanmatchers.BeanMatchers.hasValidBeanToString;
import static com.google.code.beanmatchers.BeanMatchers.hasValidGettersAndSetters;
import static org.hamcrest.Matchers.allOf;


class ResponseIdjDTOTest {

    @Test
    void responseIdjDTO_testAll() {
        Random random = new Random();
        BeanMatchers.registerValueGenerator(
                () -> Instant.now().minusSeconds(random.nextLong() / 1000),
                Instant.class);

        MatcherAssert.assertThat(DemandeIDJ.class, allOf(hasValidBeanConstructor(), hasValidBeanEquals(), hasValidGettersAndSetters(),
                                                         hasValidBeanHashCode(), hasValidBeanToString()));
    }
}
