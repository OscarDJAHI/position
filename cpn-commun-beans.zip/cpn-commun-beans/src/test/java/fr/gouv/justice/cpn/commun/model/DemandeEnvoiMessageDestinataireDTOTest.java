package fr.gouv.justice.cpn.commun.model;

import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;

import static com.google.code.beanmatchers.BeanMatchers.hasValidBeanConstructor;
import static com.google.code.beanmatchers.BeanMatchers.hasValidBeanEqualsExcluding;
import static com.google.code.beanmatchers.BeanMatchers.hasValidBeanHashCodeExcluding;
import static com.google.code.beanmatchers.BeanMatchers.hasValidBeanToString;
import static com.google.code.beanmatchers.BeanMatchers.hasValidGettersAndSetters;
import static org.hamcrest.Matchers.allOf;

class DemandeEnvoiMessageDestinataireDTOTest {

    @Test
    void beanDemandeEnvoiMessageDestinataireDTO_testAllMethods() {
        MatcherAssert.assertThat(DemandeEnvoiMessageDestinataireDTO.class,
                                 allOf(hasValidBeanConstructor(),
                                       hasValidGettersAndSetters(),
                                       hasValidBeanToString(),
                                       hasValidBeanEqualsExcluding("canal", "domain", "email", "messageId"),
                                       hasValidBeanHashCodeExcluding("canal", "domain", "email", "messageId")));
    }
}
