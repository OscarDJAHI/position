package fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn;

import org.hamcrest.MatcherAssert;
import org.junit.jupiter.api.Test;

import static com.google.code.beanmatchers.BeanMatchers.hasValidBeanConstructor;
import static com.google.code.beanmatchers.BeanMatchers.hasValidBeanEquals;
import static com.google.code.beanmatchers.BeanMatchers.hasValidBeanHashCode;
import static com.google.code.beanmatchers.BeanMatchers.hasValidBeanToString;
import static com.google.code.beanmatchers.BeanMatchers.hasValidGettersAndSetters;
import static org.hamcrest.Matchers.allOf;

class DemandeEnvoiDocumentBpnFileDTOTest {

    @Test
    void demandeEnvoiDocumentBpnFileDTO_testAll() {
        MatcherAssert.assertThat(DemandeEnvoiDocumentBpnFileDTO.class, allOf(hasValidBeanConstructor(),
                                                                             hasValidBeanEquals(),
                                                                             hasValidGettersAndSetters(),
                                                                             hasValidBeanHashCode(),
                                                                             hasValidBeanToString()));
    }
}
