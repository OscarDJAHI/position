package fr.gouv.justice.cpn.commun.security.jwt;

public class TokenProviderTest {
//
//    private static final long ONE_MINUTE = 864000;
//
//    private Key key;
//
//    @Autowired
//    private TokenProvider tokenProvider;
//
//    /** @BeforeEach
//    public void setup() {
//    key = Keys.hmacShaKeyFor(Decoders.BASE64
//    .decode("NTdlYjAyOWVkZjJhODNkZmI1NzI2MmRmZGY3MzI0MDZiZDc4YmJkMTZlNDhjNjA1YTA1NzgyYmYzZWRjNGJlMzFkNjMwOTNhZTgzZjk3YmU5Nzc0MGRkY2U1MTU3YjM5ZjBmZTk5MjJlZDM0M2NlZWU2ZjE2NTllMzRiN2UwZDE"));
//
//    ReflectionTestUtils.setField(tokenProvider, "key", key);
//    ReflectionTestUtils.setField(tokenProvider, "tokenValidityInMilliseconds", ONE_MINUTE);
//    }*/
//
//    @Test
//    public void createTokenWithDevSignature() {
//        Map<String, Object> map = new HashMap<>();
//        map.put("logonId","L0000780");
//        map.put("roles",Arrays.asList("test"));
//        map.put("mail","sandra.ramier.ext@gfi.world");
//        String admin = tokenProvider.creationTokenFromMap(map);
//        System.out.println("Bearer " + admin);
//        boolean isTokenValid = tokenProvider.validateToken(admin);
//        assertThat(isTokenValid).isEqualTo(true);
//    }
//
//    @Test
//    public void testReturnFalseWhenJWThasInvalidSignature() {
//        String jwt = createTokenWithDifferentSignature();
//        boolean isTokenValid = tokenProvider.validateToken(jwt);
//        assertThat(isTokenValid).isEqualTo(false);
//        Authentication ath = tokenProvider.getAuthentication(jwt);
//        assertThat(ath).isNotNull();
//    }
//
//    @Test
//    public void testReturnFalseWhenJWTisMalformed() {
//        Authentication authentication = createAuthentication();
//        String token = tokenProvider.createToken(authentication, false);
//        String invalidToken = token.substring(1);
//        boolean isTokenValid = tokenProvider.validateToken(invalidToken);
//
//        assertThat(isTokenValid).isEqualTo(false);
//    }
//
//    @Test
//    public void testReturnFalseWhenJWTisExpired() {
//        ReflectionTestUtils.setField(tokenProvider, "dureeValiditeGlobale", -ONE_MINUTE);
//        ReflectionTestUtils.setField(tokenProvider, "dureeValiditeToken", -ONE_MINUTE);
//        Authentication authentication = createAuthentication();
//        String token = tokenProvider.createToken(authentication, false);
//        boolean isTokenValid = tokenProvider.validateToken(token);
//        assertThat(isTokenValid).isEqualTo(false);
//        ReflectionTestUtils.setField(tokenProvider, "dureeValiditeGlobale", 360l);
//        ReflectionTestUtils.setField(tokenProvider, "dureeValiditeToken", 60l);
//    }
//
//
//    @Test
//    public void testReturnFalseWhenJWTisInvalid() {
//        boolean isTokenValid = tokenProvider.validateToken("");
//        assertThat(isTokenValid).isEqualTo(false);
//    }
//
//    private Authentication createAuthentication() {
//        Collection<GrantedAuthority> authorities = new ArrayList<>();
//        authorities.add(new SimpleGrantedAuthority(AuthoritiesConstants.ANONYMOUS));
//        return new UsernamePasswordAuthenticationToken("anonymous", "anonymous", authorities);
//    }
//
//
//
//    private String createTokenWithDifferentSignature() {
//        ReflectionTestUtils.setField(tokenProvider, "b64SigningKey", "Xfd54a45s65fds737b9aafcb3412e07ed99b267f33413274720ddbb7f6c5e64e9f14075f2d7ed041592f0b7657baf8");
//        Map<String, Object> map = new HashMap<>();
//        map.put("logonId","L0000780");
//        map.put("mail","sandra.ramier.ext@gfi.world");
//        String admin = tokenProvider.creationTokenFromMap(map);
//        ReflectionTestUtils.setField(tokenProvider, "b64SigningKey", "sMYKl8NLuZULrXiyRNkHxeRhuy/DdYHPevZiMBnmVnlJSUlwmF9eaSRM58W685xvUynpS5uE3PhkVRfk5eSevQ==");
//        return admin;
//    }
//
//
}
