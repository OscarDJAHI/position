package fr.gouv.justice.cpn.commun.model;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

class RegroupementArboTest {

    RegroupementArbo regroupementArbo;

    @Test
    void forBuilders() {
        List<AffaireArbo>      affaireArbos  = new ArrayList<>();
        String                 nom           = "nom";
        String                 noeudRef      = "workspace://SpacesStore/8c4d7b3d-787d-43b0-9c62-2a5ee0a2241b";
        List<RegroupementArbo> regroupements = new ArrayList<>();
        boolean                sousService   = true;
        RegroupementArbo regroupementArbo = new RegroupementArbo.Builder().withAffaires(affaireArbos)
                                                                          .withNom(nom).withNoeudRef(noeudRef).withRegroupements(regroupements)
                                                                          .withSousService(sousService).build();
        Assert.assertNotNull(regroupementArbo);
        Assert.assertEquals(affaireArbos, regroupementArbo.getAffaires());
        Assert.assertEquals(nom, regroupementArbo.getNom());
        Assert.assertEquals(noeudRef, regroupementArbo.getNoeudRef());
        Assert.assertEquals(regroupements, regroupementArbo.getRegroupements());
        Assert.assertEquals(sousService, regroupementArbo.isSousService());
    }

    @Test
    void getAffaires() {
        List<AffaireArbo> attribut = new ArrayList<>();
        regroupementArbo.setAffaires(attribut);
        Assert.assertEquals(attribut, regroupementArbo.getAffaires());
    }

    @Test
    void getNoeudRef() {
        String attribut = "workspace://SpacesStore/8c4d7b3d-787d-43b0-9c62-2a5ee0a2241b";
        regroupementArbo.setNoeudRef(attribut);
        Assert.assertEquals(attribut, regroupementArbo.getNoeudRef());
    }

    @Test
    void getNom() {
        String attribut = "20201013";
        regroupementArbo.setNom(attribut);
        Assert.assertEquals(attribut, regroupementArbo.getNom());
    }

    @Test
    void getRegroupements() {
        List<RegroupementArbo> attribut = new ArrayList<>();
        regroupementArbo.setRegroupements(attribut);
        Assert.assertEquals(attribut, regroupementArbo.getRegroupements());
    }

    @Test
    void isSousService() {
        boolean attribut = true;
        regroupementArbo.setSousService(attribut);
        Assert.assertEquals(attribut, regroupementArbo.isSousService());
    }

    @BeforeEach
    void setUp() {
        regroupementArbo = new RegroupementArbo();
    }

}
