package fr.gouv.justice.cpn.commun.converter;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.jodconverter.core.document.DefaultDocumentFormatRegistry;
import org.jodconverter.core.office.OfficeException;
import org.junit.Before;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
public class GenericPdfConverterTest {

    @Value("${common.conversion.path.file-to-convert}")
    private String sourceFilePath;

    @Value("${common.conversion.path.converted-file}")
    private String convertedFilePath;

    @Before
    public void initDirectory() throws IOException {
        File directory = new File(convertedFilePath);
        if (directory.exists()) {
            FileUtils.deleteDirectory(directory);
        }
        FileUtils.forceMkdir(directory);
    }

    // @Test
    public void testDocx() throws IOException, OfficeException {
        File                  file = FileUtils.getFile(sourceFilePath.concat("FX147-Contrat-Service-Echange-NPP-PFE-BPN-V0-2.docx"));
        ByteArrayOutputStream baos = GenericPdfConverter.convert(file, DefaultDocumentFormatRegistry.DOCX);
        writeBaos(baos, convertedFilePath.concat("docxToPdf.pdf"));
    }

    // @Test
    public void testOdt() throws IOException, OfficeException {
        File                  file = FileUtils.getFile(sourceFilePath.concat("Test.odt"));
        ByteArrayOutputStream baos = GenericPdfConverter.convert(file, DefaultDocumentFormatRegistry.ODT);
        writeBaos(baos, convertedFilePath.concat("odtToPdf.pdf"));
    }

    // @Test
    public void testOnName() {
        File   file                 = FileUtils.getFile(sourceFilePath.concat("FLEX_Desk_07092020.xlsx"));
        String nameWithoutExtension = FilenameUtils.removeExtension(file.getName());
        String nameWithPdfExtension = nameWithoutExtension.concat(".pdf");

        assertEquals("FLEX_Desk_07092020.pdf", nameWithPdfExtension);
    }

    // @Test
    public void testXls() throws IOException, OfficeException {
        File                  file = FileUtils.getFile(sourceFilePath.concat("FLEX Desk 07092020.xls"));
        ByteArrayOutputStream baos = GenericPdfConverter.convert(file, DefaultDocumentFormatRegistry.XLS);
        writeBaos(baos, convertedFilePath.concat("xlsToPdf.pdf"));
    }

    // @Test
    public void testXlsx() throws IOException, OfficeException {
        File                  file = FileUtils.getFile(sourceFilePath.concat("FLEX_Desk_07092020.xlsx"));
        ByteArrayOutputStream baos = GenericPdfConverter.convert(file, DefaultDocumentFormatRegistry.XLSX);
        writeBaos(baos, convertedFilePath.concat("xlsxToPdf.pdf"));
    }

    // @Test
    public void testdoc() throws IOException, OfficeException {
        File                  file = FileUtils.getFile(sourceFilePath.concat("FX147-Contrat-Service-Echange-NPP-PFE-BPN-V0-2.doc"));
        ByteArrayOutputStream baos = GenericPdfConverter.convert(file, DefaultDocumentFormatRegistry.DOC);
        writeBaos(baos, convertedFilePath.concat("docToPdf.pdf"));
    }

    public void writeBaos(ByteArrayOutputStream baos, String pathFile) throws IOException {
        File pdfFile = new File(pathFile);
        try (FileOutputStream fos = new FileOutputStream(pdfFile)) {
            baos.writeTo(fos);
        }
    }
}
