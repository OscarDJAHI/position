package fr.gouv.justice.cpn.commun.client.bpn;

import fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn.DemandeEnvoiDocumentBpnDTO;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn.NodeDto;
import fr.gouv.justice.cpn.commun.builder.DemandeEnvoiDocumentBpnDtoBuilder;
import lombok.CustomLog;
import lombok.RequiredArgsConstructor;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@ActiveProfiles("integration")
@CustomLog
@RequiredArgsConstructor(onConstructor_ = @Autowired)
@Disabled("BPN integration url is not available")
class RestClientBpnIT {

    private final RestClientBpn restClientBpn;

    @Test
    void downloadDocuments_should_returnOk_when_idsExists() throws Exception {
        ByteArrayOutputStream zip = this.restClientBpn.downloadDocuments(List.of("5693", "5694"), "L0305254");
        assertNotNull(zip);

        Collection<ZipEntry> unzipFiles = unzip(zip);
        assertNotNull(unzipFiles);
        assertEquals(2, unzipFiles.size());
    }

    @Test
    void uploadFiles_should_returnNodes() throws IOException, BpnException {
        File file = new File("src/test/resources/TestZip.zip");

        log.info("File exists {}", file.exists());

        FileInputStream       fis = new FileInputStream(file);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[]                buf = new byte[1024];
        try {
            for (int readNum; (readNum = fis.read(buf)) != -1; ) {
                bos.write(buf, 0, readNum);
            }
        } catch (IOException ex) {
            log.error("Problème lors de l'écriture du fichier dans le bytoutputStream !!");
        }

        DemandeEnvoiDocumentBpnDTO demande = DemandeEnvoiDocumentBpnDtoBuilder.createDto();
        demande.setIdNoeud("2351");

        List<NodeDto> nodes = this.restClientBpn.uploadFilesIntoPochette(demande, List.of(file));

        assertEquals(1, nodes.size());
    }

    private static Collection<ZipEntry> unzip(final ByteArrayOutputStream zip) throws Exception {
        Set<ZipEntry> entries = new HashSet<>();

        try (ZipInputStream zipStream = new ZipInputStream(new ByteArrayInputStream(zip.toByteArray()))) {
            ZipEntry entry;
            while ((entry = zipStream.getNextEntry()) != null) {
                entries.add(entry);
            }

            return entries;
        }
    }
}
