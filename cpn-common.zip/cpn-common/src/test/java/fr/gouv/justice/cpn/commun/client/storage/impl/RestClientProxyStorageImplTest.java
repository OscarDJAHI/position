package fr.gouv.justice.cpn.commun.client.storage.impl;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.gouv.justice.cpn.commun.beans.storage.ProxyStorageResponseCreateDoc;
import fr.gouv.justice.cpn.commun.beans.storage.StorageRequest;
import fr.gouv.justice.cpn.commun.beans.storage.StorageResponse;
import fr.gouv.justice.cpn.commun.client.storage.RestClientProxyStorage;
import fr.gouv.justice.cpn.commun.exception.StorageException;
import fr.gouv.justice.cpn.commun.utils.Base64Utils;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockserver.integration.ClientAndServer;
import org.mockserver.model.Header;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockserver.integration.ClientAndServer.startClientAndServer;
import static org.mockserver.matchers.Times.exactly;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

@SpringBootTest
public class RestClientProxyStorageImplTest {

    private static final ObjectMapper    om = new ObjectMapper();
    private static       ClientAndServer mockServer;

    @Autowired
    private RestClientProxyStorage restClientProxyStorage;

    @BeforeAll
    static void startServer() {
        mockServer = startClientAndServer(8525);
        JavaTimeModule module = new JavaTimeModule();
        om.registerModule(module);
        om.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
    }

    @AfterAll
    static void stopServer() {
        mockServer.stop();
    }


    @Test
    void uploadDocument_whenPdfGiven_shouldReturnPath() throws IOException, StorageException {
        String                        returnPath  = Base64Utils.encode("/test/response");
        String                        encodedPath = Base64Utils.encode("bla");
        ProxyStorageResponseCreateDoc responseDoc = new ProxyStorageResponseCreateDoc();
        responseDoc.setPathDocument(returnPath);
        responseDoc.setTypeMessage("INFO");
        mockServer
                .when(request().withMethod("POST")
                               .withPath("/document/" + encodedPath), exactly(1))
                .respond(response().withStatusCode(200)
                                   .withHeaders(new Header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE))
                                   .withBody(om.writeValueAsString(responseDoc))
                                   .withDelay(TimeUnit.SECONDS, 1));

        StorageRequest request = new StorageRequest();
        request.setPath("bla");
        request.setFile(File.createTempFile("51dz", ".pdf"));

        StorageResponse response = restClientProxyStorage.uploadDocument(request);

        assertThat(response.isSucess()).isTrue();
        assertThat(response.getPath()).isEqualTo(returnPath);
    }

    @Test
    void deleteDOcument_whenPathIsOk_SHould_REturnMSg() throws JsonProcessingException, StorageException {
        String                        returnPath  = Base64Utils.encode("/test/response");
        ProxyStorageResponseCreateDoc responseDoc = new ProxyStorageResponseCreateDoc();
        responseDoc.setPathDocument(returnPath);
        responseDoc.setTypeMessage("INFO");
        mockServer
                .when(request().withMethod("DELETE")
                               .withPath("/document/bla"), exactly(1))
                .respond(response().withStatusCode(200)
                                   .withHeaders(new Header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE))
                                   .withBody(om.writeValueAsString(responseDoc))
                                   .withDelay(TimeUnit.SECONDS, 1));

        StorageRequest request = new StorageRequest();
        request.setPath("bla");


        StorageResponse response = restClientProxyStorage.deleteDocument(request);

        assertThat(response.isSucess()).isTrue();
    }
}
