package fr.gouv.justice.cpn.commun.builder;

import fr.gouv.justice.cpn.commun.beans.demande.DemandeEnvoiDocumentStatusEnum;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn.DemandeEnvoiDocumentBpnDTO;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn.DemandeEnvoiDocumentBpnFileDTO;
import fr.gouv.justice.cpn.commun.beans.message.MessageOriginEnum;

import java.time.Instant;
import java.util.HashSet;
import java.util.Set;

public class DemandeEnvoiDocumentBpnDtoBuilder {

    public static DemandeEnvoiDocumentBpnDTO createDto() {
        DemandeEnvoiDocumentBpnDTO demande = new DemandeEnvoiDocumentBpnDTO();
        demande.setCreatedDate(Instant.parse("2020-01-02T17:01:24.00Z"));
        demande.setId(1L);
        demande.setIdExterne("456");
        demande.setIdNoeud("1243");
        demande.setNbTry(0);
        demande.setOriginMessage(MessageOriginEnum.PLINE);
        demande.setStatus(DemandeEnvoiDocumentStatusEnum.DEMANDE);
        demande.setUserMail("Fanny.Tessier@justice.gouv.fr");
        demande.setCodeSrj("100190");
        demande.setIdLdap("L0009000");

        DemandeEnvoiDocumentBpnFileDTO file = new DemandeEnvoiDocumentBpnFileDTO();
        file.setExternalId("http://pline.download.htpl?id=123");
        file.setName("File 1.odt");
        file.setDemandeId(1L);
        file.setId(1L);

        DemandeEnvoiDocumentBpnFileDTO file2 = new DemandeEnvoiDocumentBpnFileDTO();
        file2.setExternalId("http://pline.download.htpl?id=342");
        file2.setName("File 2.pdf");
        file2.setDemandeId(1L);
        file2.setId(2L);

        demande.setDemandeEnvoiDocumentBpnFiles(Set.of(file, file2));
        demande.setDemandeEnvoiDocumentBpnStatus(new HashSet<>());

        return demande;
    }
}
