package fr.gouv.justice.cpn.commun.utils;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.util.ResourceUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ZipUtilsTest {

    @Test
    void escapeStringAsFilename_should_return_name_without_special_carac() throws Exception {
        String nameWithotCarcSpec = ZipUtils.escapeStringAsFilename("testNPP3!@#&$()[] -éà@!.pdf");

        assertTrue(StringUtils.isNotBlank(nameWithotCarcSpec));

        System.out.println(StringUtils.stripAccents("testNPP3!@#&$()[] -éàççéùû@!.pdf"));
        assertEquals("testNPP3!@#&$()[] -E9E0@!.pdf", nameWithotCarcSpec);
    }

    @Test
    void getUnZipUploadedFiles_should_return_all_zip_files() throws Exception {
        File          file          = FileUtils.getFile("src", "test", "resources", "fichiers", "TestZip.zip");
        MultipartFile multipartFile = new MockMultipartFile("test", Files.readAllBytes(file.toPath()));
        List<File>    unzipedFile   = ZipUtils.getUnZipUploadedFiles(multipartFile);
        assertNotNull(unzipedFile);
        assertEquals(unzipedFile.size(), 2, "Doit contenir deux fichier");
        List<String> filesName = unzipedFile.stream().map(File::getName).collect(Collectors.toList());
        System.out.println(filesName);
        assertEquals(filesName.stream().filter(e -> e.startsWith("Flux-WebService")).count(), 1);
        assertEquals(filesName.stream().filter(e -> e.startsWith("Backlog_Simulation_PI planning vf")).count(), 1);
    }

    @Test
    void test_creat_tmp_file_without_random_name() throws Exception {
        File       file  = new File("src/test/resources/TestZip.zip");
        List<File> files = ZipUtils.unZip(file);

        files.forEach(f -> System.out.println(f.getPath() + " " + f.getName() + "  file.getParent() " + file.getParent()));
        files.forEach(File::deleteOnExit);
    }

    @Test
    void unzip_should_returnEmptySet_when_zipIsNull() throws Exception {
        assertEquals(0, ZipUtils.unzip(null).size());
    }

    @Test
    void unzip_should_returnEntries_when_zipIsValid() throws Exception {
        final File file = ResourceUtils.getFile("classpath:fichiers/documents-to-send-bpn.zip");

        final ByteArrayOutputStream              zippedFile   = CpnFileUtils.toByteArrayOutputStream(file);
        final Map<String, ByteArrayOutputStream> unzippedFile = ZipUtils.unzip(zippedFile);

        assertNotNull(unzippedFile);
        assertEquals(2, unzippedFile.size());
        assertTrue(unzippedFile.containsKey("scrum_guide_french.pdf"));
        assertTrue(unzippedFile.containsKey("state_diagram_npp.pdf"));
        assertEquals(304675, unzippedFile.get("scrum_guide_french.pdf").size());
        assertEquals(34630, unzippedFile.get("state_diagram_npp.pdf").size());
    }

    @Test
    void unzip_should_return_all_zip_files() throws Exception {
        File       file        = FileUtils.getFile("src", "test", "resources", "fichiers", "TestZip.zip");
        List<File> unzipedFile = ZipUtils.unZip(file);
        assertNotNull(unzipedFile);
        assertEquals(unzipedFile.size(), 2, "Doit contenir deux fichier");
        List<String> filesName = unzipedFile.stream().map(File::getName).collect(Collectors.toList());
        System.out.println(filesName);
        assertEquals(filesName.stream().filter(e -> e.startsWith("Flux-WebService")).count(), 1);
        assertEquals(filesName.stream().filter(e -> e.startsWith("Backlog_Simulation_PI planning vf")).count(), 1);
    }

    @Test
    void zip_files_should_be_ok() throws IOException {
        List<File> lstFile = List.of(FileUtils.getFile("src/test/resources/fichiers", "doc1.pdf"),
                                     FileUtils.getFile("src/test/resources/fichiers", "doc2.pdf"));
        ByteArrayOutputStream byteArrayOutputStream = ZipUtils.zip(lstFile);

        assertNotNull(byteArrayOutputStream);
    }
}
