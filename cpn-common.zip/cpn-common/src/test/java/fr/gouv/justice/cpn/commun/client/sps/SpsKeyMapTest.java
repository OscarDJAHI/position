package fr.gouv.justice.cpn.commun.client.sps;

import fr.gouv.justice.cpn.commun.builder.SpsBuilder;
import org.junit.jupiter.api.Test;

import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SpsKeyMapTest {

    @Test
    void entryOf() {
        assertNotNull(SpsKeyMap.entryOf(null, null));

        final Map.Entry<SpsKeyMap, String> metadatum = SpsKeyMap.entryOf(SpsKeyMap.NOM_JURIDICTION, "DIJON");
        assertEquals(SpsKeyMap.NOM_JURIDICTION, metadatum.getKey());
        assertEquals("DIJON", metadatum.getValue());
    }

    @Test
    void mapOfNonEmpty() {
        assertEquals(Collections.emptyMap(), SpsKeyMap.mapOfNonEmpty((Map.Entry<SpsKeyMap, String>[]) null));
        assertEquals(Collections.emptyMap(), SpsKeyMap.mapOfNonEmpty());

        final Map<SpsKeyMap, String> metadata = SpsBuilder.metadata();

        assertEquals(5, metadata.size());
        assertFalse(metadata.containsKey(SpsKeyMap.NOM_JURIDICTION));
        assertEquals("BROUILLON", metadata.get(SpsKeyMap.ETAT_FICHIER));
        assertEquals("PDF", metadata.get(SpsKeyMap.TYPE_FICHIER));
    }

    @Test
    void mergeOfNonEmpty() {
        final Map<SpsKeyMap, String> commonMetadata = SpsBuilder.metadata();
        final Map<SpsKeyMap, String> metadata = new EnumMap<>(SpsKeyMap.class) {{
            put(SpsKeyMap.TYPE_DOSSIER, null);
            put(SpsKeyMap.TYPE_FICHIER, "DOCX");
            put(SpsKeyMap.CODE_NIVEAU_ORGATNISATION_2, "CODE NIVEAU ORGATNISATION 2");
        }};

        final Map<String, String> mergedMaps = SpsKeyMap.mergeOfNonEmpty(commonMetadata, metadata);

        assertEquals(6, mergedMaps.size());
        assertFalse(mergedMaps.containsKey(SpsKeyMap.NOM_JURIDICTION.value()));
        assertTrue(mergedMaps.containsKey(SpsKeyMap.CODE_NIVEAU_ORGATNISATION_2.value()));
        assertEquals("PP", mergedMaps.get(SpsKeyMap.TYPE_DOSSIER.value()));
        assertEquals("BROUILLON", mergedMaps.get(SpsKeyMap.ETAT_FICHIER.value()));
        assertEquals("DOCX", mergedMaps.get(SpsKeyMap.TYPE_FICHIER.value()));
    }
}
