package fr.gouv.justice.cpn.commun.model;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

class ServiceArboTest {

    ServiceArbo serviceArbo;

    @Test
    void forBuilders() {
        List<AffaireArbo>      attribut  = new ArrayList<>();
        String                 attribut2 = "name";
        String                 attribut3 = "aeb903ee-3794-4da8-a00c-2951bdeb90f0";
        boolean                attribut4 = true;
        boolean                attribut5 = true;
        List<RegroupementArbo> attribut6 = new ArrayList<>();
        boolean                attribut7 = true;
        ServiceArbo serviceArbo = new ServiceArbo.Builder().withAffaires(attribut).withName(attribut2)
                                                           .withIdNoeud(attribut3).withService(attribut4).withRegroupement(attribut5)
                                                           .withRegroupements(attribut6).withTitulaire(attribut7).build();
        Assert.assertNotNull(serviceArbo);
        Assert.assertEquals(attribut, serviceArbo.getAffaires());
        Assert.assertEquals(attribut2, serviceArbo.getName());
        Assert.assertEquals(attribut3, serviceArbo.getIdNoeud());
        Assert.assertEquals(attribut4, serviceArbo.isService());
        Assert.assertEquals(attribut5, serviceArbo.isRegroupement());
        Assert.assertEquals(attribut6, serviceArbo.getRegroupements());
        Assert.assertEquals(attribut7, serviceArbo.isTitulaire());
    }

    @Test
    void getAffaires() {
        List<AffaireArbo> attribut = new ArrayList<>();
        serviceArbo.setAffaires(attribut);
        Assert.assertEquals(attribut, serviceArbo.getAffaires());
    }

    @Test
    void getIdNoeud() {
        String attribut = "aeb903ee-3794-4da8-a00c-2951bdeb90f0";
        serviceArbo.setIdNoeud(attribut);
        Assert.assertEquals(attribut, serviceArbo.getIdNoeud());
    }

    @Test
    void getName() {
        String attribut = "20201013";
        serviceArbo.setName(attribut);
        Assert.assertEquals(attribut, serviceArbo.getName());
    }

    @Test
    void getRegroupements() {
        List<RegroupementArbo> attribut = new ArrayList<>();
        serviceArbo.setRegroupements(attribut);
        Assert.assertEquals(attribut, serviceArbo.getRegroupements());
    }

    @Test
    void isRegroupement() {
        boolean attribut = true;
        serviceArbo.setRegroupement(attribut);
        Assert.assertEquals(attribut, serviceArbo.isRegroupement());
    }

    @Test
    void isService() {
        boolean attribut = true;
        serviceArbo.setService(attribut);
        Assert.assertEquals(attribut, serviceArbo.isService());
    }

    @Test
    void isTitulaire() {
        boolean attribut = true;
        serviceArbo.setTitulaire(attribut);
        Assert.assertEquals(attribut, serviceArbo.isTitulaire());
    }

    @BeforeEach
    void setUp() {
        serviceArbo = new ServiceArbo();
    }
}
