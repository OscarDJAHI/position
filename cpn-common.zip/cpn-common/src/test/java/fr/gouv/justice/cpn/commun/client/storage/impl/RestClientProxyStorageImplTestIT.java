package fr.gouv.justice.cpn.commun.client.storage.impl;

import fr.gouv.justice.cpn.commun.beans.storage.StorageRequest;
import fr.gouv.justice.cpn.commun.beans.storage.StorageResponse;
import fr.gouv.justice.cpn.commun.client.storage.RestClientProxyStorage;
import fr.gouv.justice.cpn.commun.exception.StorageException;
import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles("integration")
class RestClientProxyStorageImplTestIT {

    @Autowired
    private RestClientProxyStorage restClientProxyStorage;

    @Value("${test.proxy_storage.output_directory}")
    private String outputDirectory;

    @Test
    @Order(1)
    void uploadDocument_withPath_shouldCreateDocumentInHcp() throws StorageException {
        StorageRequest request = new StorageRequest();
        File           file    = FileUtils.getFile("src", "test", "resources", "Scrum-Guide-French.pdf");
        File           zipFile = FileUtils.getFile("src", "test", "resources", "TestZip.zip");
        File           file8   = FileUtils.getFile("src", "test", "resources", "fichiers", "doc.pdf");

        assertThat(zipFile).isNotNull();
        request.setFile(zipFile);
        request.setPath("CPN/fx071/1053-468184fthf85/" + zipFile.getName());

        StorageResponse response = restClientProxyStorage.uploadDocument(request);

        System.out.println(response.getPath());
        assertThat(response.isSucess()).isTrue();
    }

    @Test
    @Order(2)
    void downloadDocument_whenPathIsOk_should_return() throws StorageException, IOException, URISyntaxException {
        StorageRequest request = new StorageRequest();
        request.setPath("Q1BOL2Z4MDcxLzEwNTMtNDY4MTg0ZnRoZjg1L1Rlc3RaaXAuemlw");

        StorageResponse response = restClientProxyStorage.downloadDocument(request);

        assertThat(response.isSucess()).isTrue();
        assertThat(response.getFile()).isNotNull();

        File tmpFile = new File(Path.of(outputDirectory).resolve("TestZIp2.zip").toString());
        FileUtils.writeByteArrayToFile(tmpFile, response.getFile().toByteArray());
    }

    @Test
    @Order(3)
    void downloadDocuments_whenPathIsOk_should_return() throws StorageException, IOException {
        StorageRequest      request      = new StorageRequest();
        Map<String, String> filesRequest = new HashMap<>();
        filesRequest.put("test1.pdf", "MjAyMi8zLzI5LzE2NDg1NDQxNjMwODUvMTY0ODU0NDE2MzA4NS5wZGY=");
        filesRequest.put("test2.pdf", "MjAyMi8zLzI4LzE2NDg0ODE1MTA4NjMvMTY0ODQ4MTUxMDg2My5wZGY=");
        filesRequest.put("test3.pdf", "MjAyMi80LzEvMTY0ODgwMDU1NjY2NS8xNjQ4ODAwNTU2NjY1LnBkZg==");
        filesRequest.put("test4.pdf", "MjAyMi80LzEvMTY0ODgwMDk1MTQzNC8xNjQ4ODAwOTUxNDM0LnBkZg==");
        request.setFilesNamesAndUri(filesRequest);

        StorageResponse response = restClientProxyStorage.downloadDocuments(request);

        assertThat(response.isSucess()).isTrue();
        assertThat(response.getFile()).isNotNull();

        File tmpFile = new File(Path.of(outputDirectory).resolve("test.zip").toString());
        FileUtils.writeByteArrayToFile(tmpFile, response.getFile().toByteArray());
    }

    @Test
    void deleteDocument_whenPathGiven_shouldDelete() throws StorageException {
        StorageRequest request = new StorageRequest();
        request.setPath("MjAyMi80LzEvMTY0ODgwMjQ4ODc0NS8xNjQ4ODAyNDg4NzQ1LnBkZg==");

        StorageResponse response = restClientProxyStorage.deleteDocument(request);

        assertThat(response.isSucess()).isTrue();
    }
}
