package fr.gouv.justice.cpn.commun.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import fr.gouv.justice.cpn.commun.beans.generic.NotificationBpnDepotNpp;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

import java.time.Instant;

public class JsonUtilsTest {

    @Test
    void test_json_format_date() throws JsonProcessingException {
        NotificationBpnDepotNpp notificationBpn = new NotificationBpnDepotNpp();
        notificationBpn.setIdDemandeInitiale(1234l);
        notificationBpn.setDateEnvoi(Instant.parse("2021-12-25T19:10:28Z"));
        notificationBpn.setMessage("ok");
        notificationBpn.setCause("aucun");
        String json = JsonUtils.JSON_MAPPER.writeValueAsString(notificationBpn);
        Assertions.assertThat(json).isEqualTo("{\"idDemandeInitiale\":1234,\"dateEnvoi\":\"2021-12-25T19:10:28Z\",\"message\":\"ok\",\"cause\":\"aucun\"}");
        System.out.println(json);
    }
}
