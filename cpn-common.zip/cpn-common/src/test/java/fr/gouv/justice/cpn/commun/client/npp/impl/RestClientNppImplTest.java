package fr.gouv.justice.cpn.commun.client.npp.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.npp.AbstractDemandeEnvoiDocumentNppDTO;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.npp.FonctionEnum;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.npp.ResponseEnvoiDocumentNppDTO;
import fr.gouv.justice.cpn.commun.builder.MessageDTOBuilder;
import fr.gouv.justice.cpn.commun.builder.NppBuilder;
import fr.gouv.justice.cpn.commun.builder.ResponseEnvoiDocumentNppBuilder;
import fr.gouv.justice.cpn.commun.client.npp.RestClientNPP;
import fr.gouv.justice.cpn.commun.exception.NppException;
import fr.gouv.justice.cpn.commun.model.ArborescenceApi;
import fr.gouv.justice.cpn.commun.model.DemandeEnvoiMessageDTO;
import fr.gouv.justice.cpn.commun.model.DescriptArboApi;
import fr.gouv.justice.cpn.commun.model.UpdateEnvoiDTO;
import fr.gouv.justice.cpn.commun.model.enumeration.Status;
import lombok.CustomLog;
import lombok.RequiredArgsConstructor;
import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockserver.integration.ClientAndServer;
import org.mockserver.model.Header;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockserver.integration.ClientAndServer.startClientAndServer;
import static org.mockserver.matchers.Times.exactly;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;
import static org.springframework.test.util.AssertionErrors.assertEquals;

@SpringBootTest(classes = RestClientNPPImpl.class)
@RequiredArgsConstructor(onConstructor_ = @Autowired)
@CustomLog
@Disabled("Disbale test integration don't work on jenkins")
class RestClientNppImplTest {

    private static ClientAndServer mockServer;

    private final RestClientNPP restClientNPP;

    @Value("${npp.endpoint.confirmation_path}")
    private String confirmationPath;

    @BeforeAll
    static void startServer() {
        mockServer = startClientAndServer(8085);
    }

    @AfterAll
    static void stopServer() {
        mockServer.stop();
    }

    @Test
    void confirmSending_should_be_Ok() throws JsonProcessingException, NppException {
        UpdateEnvoiDTO updateEnvoiDTO = new UpdateEnvoiDTO();
        updateEnvoiDTO.setIdDemande("123456");
        updateEnvoiDTO.setMessage("MAJDEMAND123456");
        updateEnvoiDTO.setStatus(Status.SUCCES);

        ResponseEnvoiDocumentNppDTO bodyResponse = ResponseEnvoiDocumentNppBuilder.createResponseEnvoiDocumentNpp(200, "OK");

        ObjectMapper om = new ObjectMapper();
        mockServer.when(request().withMethod("POST")
                                 .withPath("/deposer/FX187/100190/npp/rest/modifierenvoi"), exactly(1))
                  .respond(response().withStatusCode(200)
                                     .withHeaders(new Header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE))
                                     .withBody(om.writeValueAsString(bodyResponse))
                                     .withDelay(TimeUnit.SECONDS, 1));

        ResponseEnvoiDocumentNppDTO response = restClientNPP.confirmSending(updateEnvoiDTO, "100190");

        assertEquals("code", 200, response.getCode());
        assertEquals("status", "OK", response.getStatut());
        assertEquals("demandeId", 1L, response.getDemandeId());
    }

    @Test
    void confirmSending_should_be_ko() throws JsonProcessingException, NppException {
        UpdateEnvoiDTO updateEnvoiDTO = new UpdateEnvoiDTO();
        updateEnvoiDTO.setIdDemande("123456");
        updateEnvoiDTO.setMessage("MAJDEMAND123456");
        updateEnvoiDTO.setStatus(Status.SUCCES);

        ResponseEnvoiDocumentNppDTO bodyResponse = ResponseEnvoiDocumentNppBuilder.createResponseEnvoiDocumentNpp(500, "KO");

        ObjectMapper om = new ObjectMapper();
        mockServer.when(request().withMethod("POST")
                                 .withPath("/deposer/FX187/100190/npp/rest/modifierenvoi"), exactly(1))
                  .respond(response().withStatusCode(500)
                                     .withHeaders(new Header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE))
                                     .withBody(om.writeValueAsString(bodyResponse))
                                     .withDelay(TimeUnit.SECONDS, 1));

        try {
            restClientNPP.confirmSending(updateEnvoiDTO, "100190");
            Assertions.fail();
        } catch (Exception ex) {
            Assertions.assertTrue(ex instanceof NppException);
        }
    }

    @Test
    void getArborecense_should_be_Ok() throws JsonProcessingException, NppException {
        ArborescenceApi arbo = new ArborescenceApi();
        arbo.setDate("25/02/2021 17:14:14");
        arbo.setCode(200);
        arbo.setMessage("OK");
        arbo.setCause("Traitement effectué avec succes");

        DescriptArboApi filtreArbo = NppBuilder.createDescriptArboApi();
        ObjectMapper    om         = new ObjectMapper();

        mockServer.when(request().withMethod("POST")
                                 .withPath("/retirer/FX187/100190/npp/rest/dossierget/!descriptArbo.json"), exactly(1))
                  .respond(response().withStatusCode(200)
                                     .withHeaders(new Header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE))
                                     .withBody(om.writeValueAsString(arbo))
                                     .withDelay(TimeUnit.SECONDS, 1));

        ArborescenceApi response = restClientNPP.getArborecense(filtreArbo);

        assertEquals("code", 200, response.getCode());
        assertEquals("message", "OK", response.getMessage());
        assertEquals("cause", "Traitement effectué avec succes", response.getCause());
    }

    @Test
    void sendDocumentsToNpp_should_be_ok() throws Exception {
        File file = FileUtils.getFile("src", "test", "resources", "TestZip.zip");

        log.info("File exists {}", file.exists());

        FileInputStream       fis = new FileInputStream(file);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[]                buf = new byte[1024];

        try {
            for (int readNum; (readNum = fis.read(buf)) != -1; ) {
                bos.write(buf, 0, readNum);
            }
        } catch (IOException ex) {
            log.error("Problème lors de l'écriture du fichier dans le bytoutputStream !!");
        }

        AbstractDemandeEnvoiDocumentNppDTO demande = Mockito.spy(AbstractDemandeEnvoiDocumentNppDTO.class);
        demande.setId(1L);
        demande.setCodeDossier("1");
        demande.setCodeSrj("100548");
        demande.setFonction(FonctionEnum.A);

        ResponseEnvoiDocumentNppDTO bodyResponse = ResponseEnvoiDocumentNppBuilder.createResponseEnvoiDocumentNpp(200, "OK");

        mockServer.when(request().withMethod("POST").withPath("/deposer/FX147/" + demande.getCodeSrj()), exactly(1))
                  .respond(response().withStatusCode(200)
                                     .withHeaders(new Header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE))
                                     .withBody(new ObjectMapper().writeValueAsString(bodyResponse))
                                     .withDelay(TimeUnit.SECONDS, 1));

        ResponseEnvoiDocumentNppDTO response = restClientNPP.sendDocumentsToNpp(demande, bos);

        assertEquals("Code de retour", 200, response.getCode());
        assertEquals("statut de retour", "OK", response.getStatut());
    }

    @Test
    void sendDocumentsToNpp_should_throw_npp_exception() {
        mockServer.when(request().withMethod("POST").withPath("/deposer/FX147/105589"), exactly(1))
                  .respond(response().withStatusCode(500).withDelay(TimeUnit.SECONDS, 1));

        assertThrows(NppException.class, () -> restClientNPP.sendDocumentsToNpp(Mockito.mock(AbstractDemandeEnvoiDocumentNppDTO.class),
                                                                                new ByteArrayOutputStream()));
    }

    @Test
    void send_documents_fonction_u_should_extract_ok_from_response() throws Exception {
        File file = FileUtils.getFile("src", "test", "resources", "TestZip.zip");

        log.info("File exists {}", file.exists());

        FileInputStream       fis = new FileInputStream(file);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[]                buf = new byte[1024];

        try {
            for (int readNum; (readNum = fis.read(buf)) != -1; ) {
                bos.write(buf, 0, readNum);
            }
        } catch (IOException ex) {
            log.error("Problème lors de l'écriture du fichier dans le bytoutputStream !!");
        }

        AbstractDemandeEnvoiDocumentNppDTO demande = Mockito.spy(AbstractDemandeEnvoiDocumentNppDTO.class);
        demande.setId(1L);
        demande.setCodeDossier("1");
        demande.setCodeSrj("100548");
        demande.setFonction(FonctionEnum.U);

        String bodyResponse = "{\"origine\":\"BPN\",\"fonction\":\"U\",\"service\":\"\",\"sservice\":\"\",\"typeDossier\":\"\",\"affaire\":\"19781204affaire Minute\",\"zip\":\"testFonctionU.zip\",\"complement\":\"477b046b-583a-40ef-9ae1-94a5baeb62a1\",\"Resultat de traitement-->code 200\":\"Traitement effectué avec succes\",\"noeuds\":[{\"noeud\":\"ebccf554-e1d6-472b-adf8-739ce67807ff\",\"nomfichier\":\"1231224568R.pdf\"},{\"noeud\":\"58c9737e-194e-40b8-a087-76f6609cdfc1\",\"nomfichier\":\"12333333.pdf\"}]}";

        mockServer.when(request().withMethod("POST").withPath("/deposer/FX147/" + demande.getCodeSrj()), exactly(1))
                  .respond(response().withStatusCode(200)
                                     .withHeaders(new Header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE))
                                     .withBody(bodyResponse)
                                     .withDelay(TimeUnit.SECONDS, 1));

        ResponseEnvoiDocumentNppDTO response = restClientNPP.sendDocumentsToNpp(demande, bos);

        assertEquals("Code de retour", 200, response.getCode());
        assertEquals("statut de retour", "OK", response.getStatut());
        assertEquals("massage", "Traitement effectué avec succes", response.getMessage());
    }

    @Test
    void send_documents_fonction_u_when_npp_response_with_ko_we_should_extract_KO_from_response() throws Exception {
        File file = FileUtils.getFile("src", "test", "resources", "TestZip.zip");

        log.info("File exists {}", file.exists());

        FileInputStream       fis = new FileInputStream(file);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[]                buf = new byte[1024];

        try {
            for (int readNum; (readNum = fis.read(buf)) != -1; ) {
                bos.write(buf, 0, readNum);
            }
        } catch (IOException ex) {
            log.error("Problème lors de l'écriture du fichier dans le bytoutputStream !!");
        }

        AbstractDemandeEnvoiDocumentNppDTO demande = Mockito.spy(AbstractDemandeEnvoiDocumentNppDTO.class);
        demande.setId(1L);
        demande.setCodeDossier("1");
        demande.setCodeSrj("100548");
        demande.setFonction(FonctionEnum.U);

        String bodyResponse = "{\"origine\":\"BPN\",\"fonction\":\"U\",\"service\":\"\",\"sservice\":\"\",\"typeDossier\":\"\",\"affaire\":\"19781204affaire Minute\",\"zip\":\"testFonctionU.zip\",\"complement\":\"477b046b-583a-40ef-9ae1-94a5baeb62a1\",\"Resultat de traitement-->code 400\":\" les documents suivants: [1231224568R.pdf]  existent dèja dans la chemise cible ;\",\"noeuds\":[]}";

        mockServer.when(request().withMethod("POST").withPath("/deposer/FX147/" + demande.getCodeSrj()), exactly(1))
                  .respond(response().withStatusCode(200)
                                     .withHeaders(new Header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE))
                                     .withBody(bodyResponse)
                                     .withDelay(TimeUnit.SECONDS, 1));

        ResponseEnvoiDocumentNppDTO response = restClientNPP.sendDocumentsToNpp(demande, bos);

        assertEquals("Code de retour", 400, response.getCode());
        assertEquals("statut de retour", "KO", response.getStatut());
        assertEquals("massage", "Bad Request", response.getMessage());
        assertEquals("cause", " les documents suivants: [1231224568R.pdf]  existent dèja dans la chemise cible ;", response.getCause());
    }

    @Test
    void validateRequest_should_be_ok() throws Exception {
        DemandeEnvoiMessageDTO      demandeEnvoiMessageDTO = MessageDTOBuilder.create();
        ResponseEnvoiDocumentNppDTO bodyResponse           = ResponseEnvoiDocumentNppBuilder.createResponseEnvoiDocumentNppForConfirmation();
        ObjectMapper                om                     = new ObjectMapper();

        mockServer.when(request().withMethod("POST")
                                 .withPath("/deposer/FX187/" + demandeEnvoiMessageDTO.getSender().getCodeSrj() + confirmationPath), exactly(1))
                  .respond(response().withStatusCode(200)
                                     .withHeaders(new Header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE))
                                     .withBody(om.writeValueAsString(bodyResponse)).withDelay(TimeUnit.SECONDS, 1));

        ResponseEnvoiDocumentNppDTO response = restClientNPP.validateRequest(demandeEnvoiMessageDTO);

        assertEquals("Code de retour", 200, response.getCode());
        assertEquals("Statut de retour", "ok", response.getStatut());
        assertEquals("Message", "Demande effectuée avec succès", response.getMessage());
        assertEquals("Nom archive", "1234_dossier.zip", response.getNomArchive());
    }

    @Test
    void validateRequest_should_throw_exception() {
        DemandeEnvoiMessageDTO demandeEnvoiMessageDTO = MessageDTOBuilder.create();

        mockServer.when(request().withMethod("POST")
                                 .withPath("/deposer/FX187/" + demandeEnvoiMessageDTO.getSender().getCodeSrj() + confirmationPath), exactly(1))
                  .respond(response().withStatusCode(500)
                                     .withDelay(TimeUnit.SECONDS, 1));

        Exception exception = Assertions.assertThrows(NppException.class, () -> {
            restClientNPP.validateRequest(demandeEnvoiMessageDTO);
        });

        assertEquals("Message erreur", exception.getMessage(), "500 Internal Server Error: [no body]");
    }
}
