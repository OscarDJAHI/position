package fr.gouv.justice.cpn.commun.builder;

import fr.gouv.justice.cpn.commun.beans.demande.envoi.npp.ResponseEnvoiDocumentNppDTO;

public class ResponseEnvoiDocumentNppBuilder {

    public static ResponseEnvoiDocumentNppDTO createResponseEnvoiDocumentNpp(int code, String statut) {
        ResponseEnvoiDocumentNppDTO response = new ResponseEnvoiDocumentNppDTO();
        response.setCode(code);
//        response.setDate(LocalDate.of(2020, 10, 12));
        response.setStatut(statut);
        response.setDemandeId(1L);

        return response;
    }

    public static ResponseEnvoiDocumentNppDTO createResponseEnvoiDocumentNppForConfirmation() {
        ResponseEnvoiDocumentNppDTO response = new ResponseEnvoiDocumentNppDTO();
        response.setCode(200);
        response.setStatut("ok");
        response.setDemandeId(1234L);
        response.setMessage("Demande effectuée avec succès");
        response.setNomArchive("1234_dossier.zip");

        return response;
    }
}
