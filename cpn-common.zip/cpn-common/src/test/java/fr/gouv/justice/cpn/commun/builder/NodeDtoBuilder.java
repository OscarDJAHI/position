package fr.gouv.justice.cpn.commun.builder;

import fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn.NodeDto;

import java.util.ArrayList;
import java.util.List;

public class NodeDtoBuilder {

    public static List<NodeDto> createDtoList() {
        NodeDto node = new NodeDto();
        node.setText("Fichier_uploader.pdf");
        node.setPath("1452F34D-876TG2-IDSPS");

        NodeDto node2 = new NodeDto();
        node2.setText("Fichier_uploader2.pdf");
        node2.setPath("6782F34D-876TG2-IDSPS");


        List<NodeDto> nodes = new ArrayList<>();
        nodes.add(node);
        nodes.add(node2);

        return nodes;
    }
}
