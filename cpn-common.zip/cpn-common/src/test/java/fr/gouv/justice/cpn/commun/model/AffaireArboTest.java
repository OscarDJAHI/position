package fr.gouv.justice.cpn.commun.model;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AffaireArboTest {

    AffaireArbo affaireArbo;

    @Test
    void forBuilders() {
        String attribut   = "00006_002231_2020";
        String attribut2  = "inconnu";
        String attribut3  = "inconnu";
        String attribut4  = "12345678999A";
        String attribut5  = "to found";
        String attribut6  = "0.1 Mo";
        String attribut7  = "2";
        String attribut8  = "0";
        String attribut9  = "13-10-2020 10:35:13";
        String attribut10 = "13-10-2020 10:35:16";
        AffaireArbo affaireArbo = new AffaireArbo.Builder().withNumeroParquet(attribut)
                                                           .withTypedossier(attribut2).withDescription(attribut3).withIdj(attribut4).withNoeud(attribut5)
                                                           .withTaille(attribut6).withNbrDocument(attribut7).withDpn(attribut8)
                                                           .withDateCreation(attribut9).withDateModification(attribut10).build();
        Assert.assertNotNull(affaireArbo);
        Assert.assertEquals(attribut, affaireArbo.getNumeroParquet());
        Assert.assertEquals(attribut2, affaireArbo.getTypedossier());
        Assert.assertEquals(attribut3, affaireArbo.getTypedossier());
        Assert.assertEquals(attribut4, affaireArbo.getIdj());
        Assert.assertEquals(attribut5, affaireArbo.getNoeud());
        Assert.assertEquals(attribut6, affaireArbo.getTaille());
        Assert.assertEquals(attribut7, affaireArbo.getNbrDocument());
        Assert.assertEquals(attribut8, affaireArbo.getDpn());
        Assert.assertEquals(attribut9, affaireArbo.getDateCreation());
        Assert.assertEquals(attribut10, affaireArbo.getDateModification());
    }

    @Test
    void getDateCreation() {
        String attribut = "13-10-2020 10:35:13";
        affaireArbo.setDateCreation(attribut);
        Assert.assertEquals(attribut, affaireArbo.getDateCreation());
    }

    @Test
    void getDateModification() {
        String attribut = "13-10-2020 10:35:16";
        affaireArbo.setDateModification(attribut);
        Assert.assertEquals(attribut, affaireArbo.getDateModification());
    }

    @Test
    void getDescription() {
        String attribut = "to found";
        affaireArbo.setDescription(attribut);
        Assert.assertEquals(attribut, affaireArbo.getDescription());
    }

    @Test
    void getDpn() {
        String attribut = "0";
        affaireArbo.setDpn(attribut);
        Assert.assertEquals(attribut, affaireArbo.getDpn());
    }

    @Test
    void getIdj() {
        String attribut = "12345678999A";
        affaireArbo.setIdj(attribut);
        Assert.assertEquals(attribut, affaireArbo.getIdj());
    }

    @Test
    void getNbrDocument() {
        String attribut = "2";
        affaireArbo.setNbrDocument(attribut);
        Assert.assertEquals(attribut, affaireArbo.getNbrDocument());
    }

    @Test
    void getNoeud() {
        String attribut = "13696529-0c16-48f6-9737-1c82386d86bd";
        affaireArbo.setNoeud(attribut);
        Assert.assertEquals(attribut, affaireArbo.getNoeud());
    }

    @Test
    void getNumeroParquet() {
        String attribut = "00006_002231_2020";
        affaireArbo.setNumeroParquet(attribut);
        Assert.assertEquals(attribut, affaireArbo.getNumeroParquet());
    }

    @Test
    void getTaille() {
        String attribut = "0.1 Mo";
        affaireArbo.setTaille(attribut);
        Assert.assertEquals(attribut, affaireArbo.getTaille());
    }

    @Test
    void getTypedossier() {
        String attribut = "inconnu";
        affaireArbo.setTypedossier(attribut);
        Assert.assertEquals(attribut, affaireArbo.getTypedossier());
    }

    @BeforeEach
    void setUp() {
        affaireArbo = new AffaireArbo();
    }
}
