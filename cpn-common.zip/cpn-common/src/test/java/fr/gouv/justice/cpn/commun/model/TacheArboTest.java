package fr.gouv.justice.cpn.commun.model;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

class TacheArboTest {

    TacheArbo tacheArboNpp;

    @Test
    void forBuilders() {
        String            utilisateur = "user";
        List<ServiceArbo> services    = new ArrayList<>();
        TacheArbo tacheArbo = new TacheArbo.Builder().withUtilisateur(utilisateur)
                                                     .withServices(services).build();
        Assert.assertNotNull(tacheArbo);
        Assert.assertEquals(utilisateur, tacheArbo.getUtilisateur());
        Assert.assertEquals(services, tacheArbo.getServices());
    }

    @Test
    void getServices() {
        List<ServiceArbo> attribut = new ArrayList<>();
        tacheArboNpp.setServices(attribut);
        Assert.assertEquals(attribut, tacheArboNpp.getServices());
    }

    @Test
    void getUtilisateur() {
        String attribut = "username";
        tacheArboNpp.setUtilisateur(attribut);
        Assert.assertEquals(attribut, tacheArboNpp.getUtilisateur());
    }

    @BeforeEach
    void setUp() {
        tacheArboNpp = new TacheArbo();
    }

}
