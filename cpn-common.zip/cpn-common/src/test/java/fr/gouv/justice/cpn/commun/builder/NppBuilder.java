package fr.gouv.justice.cpn.commun.builder;

import fr.gouv.justice.cpn.commun.model.DescriptAffApi;
import fr.gouv.justice.cpn.commun.model.DescriptArboApi;

public class NppBuilder {

	private NppBuilder() {
	}

	public static DescriptAffApi createDescriptAffApi() {
		DescriptAffApi descriptAffApi = new DescriptAffApi();
		descriptAffApi.setFonction("DescriptAff");
		descriptAffApi.setCodeUtilisateur("adminNpp");
		descriptAffApi.setIdj("1234567891B");
		descriptAffApi.setNumeroParquet("");
		descriptAffApi.typeDossier("Dossier Pénal");

		return descriptAffApi;
	}

	public static DescriptArboApi createDescriptArboApi() {
		DescriptArboApi arboApi = new DescriptArboApi();
		arboApi.setFonction("DescriptArbo");
		arboApi.setCodeUtilisateur("adminNpp");
		arboApi.setCodeSrj("100154");
		arboApi.setFiltreDateMaj("25/02/2021 17:25:35");
		arboApi.setFiltreService("Archivage");
		arboApi.setInfosTaille(true);

		return arboApi;
	}

	public static DescriptArboApi createDescriptArboApiFull() {
		DescriptArboApi descript = new DescriptArboApi();
		descript.fonction("DescriptArbo");
		descript.codeUtilisateur("adminNpp");
		descript.codeSrj("100041");
		descript.filtreDateMaj("26/09/2020 15:00:41");
		descript.filtreQueDpn("");
		descript.filtreRetour("");
		descript.filtreService("Archivage");
		descript.infosTaille(true);

		return descript;
	}
}
