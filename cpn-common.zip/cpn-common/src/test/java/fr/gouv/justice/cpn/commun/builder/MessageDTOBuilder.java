package fr.gouv.justice.cpn.commun.builder;

import fr.gouv.justice.cpn.commun.model.DemandeEnvoiMessageDTO;
import fr.gouv.justice.cpn.commun.model.DemandeEnvoiMessageDestinataireDTO;
import fr.gouv.justice.cpn.commun.model.FichierDemandeEnvoiMessageDTO;
import fr.gouv.justice.cpn.commun.model.SenderDTO;

import java.time.Instant;
import java.util.Set;

public class MessageDTOBuilder {

    public static DemandeEnvoiMessageDTO create() {
        DemandeEnvoiMessageDTO demandeEnvoiMessageDTO = new DemandeEnvoiMessageDTO();
        demandeEnvoiMessageDTO.setId(1L);
        demandeEnvoiMessageDTO.setComment("Corps du message");
        demandeEnvoiMessageDTO.setDate(Instant.now());
        demandeEnvoiMessageDTO.setMisc("Appli appelante");

        SenderDTO sender = new SenderDTO();
        sender.setCodeSrj("100154");
        demandeEnvoiMessageDTO.setSender(sender);

        DemandeEnvoiMessageDestinataireDTO messageDestinataireDTO1 = new DemandeEnvoiMessageDestinataireDTO();
        messageDestinataireDTO1.setEmail("email1@justice.gouv.fr");
        DemandeEnvoiMessageDestinataireDTO messageDestinataireDTO2 = new DemandeEnvoiMessageDestinataireDTO();
        messageDestinataireDTO2.setEmail("email2@justice.gouv.fr");

        demandeEnvoiMessageDTO
                .setMessageDestinataires(Set.of(messageDestinataireDTO1, messageDestinataireDTO2));

        FichierDemandeEnvoiMessageDTO fichierDemandeEnvoiMessageDTO1 = new FichierDemandeEnvoiMessageDTO();
        fichierDemandeEnvoiMessageDTO1.setUri("999ef5f9");
        FichierDemandeEnvoiMessageDTO fichierDemandeEnvoiMessageDTO2 = new FichierDemandeEnvoiMessageDTO();
        fichierDemandeEnvoiMessageDTO2.setUri("a833182f");

        demandeEnvoiMessageDTO.setFichierMessages(Set.of(fichierDemandeEnvoiMessageDTO1,
                                                         fichierDemandeEnvoiMessageDTO2));

        return demandeEnvoiMessageDTO;
    }
}
