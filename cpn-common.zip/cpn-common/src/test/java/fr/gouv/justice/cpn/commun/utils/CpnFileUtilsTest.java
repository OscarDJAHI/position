package fr.gouv.justice.cpn.commun.utils;

import fr.gouv.justice.cpn.commun.exception.TechException;
import org.junit.jupiter.api.Test;
import org.springframework.util.FileSystemUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class CpnFileUtilsTest {

    @Test
    void convertFileToByteArray_shouldReturn_ByteArrayOutputStream() throws Exception {
        Path                  source         = Path.of("src", "test", "resources", "fichiers");
        List<String>          pathList       = List.of(source.resolve("doc1.pdf").toString(), source.resolve("doc2.pdf").toString());
        ByteArrayOutputStream fileDataStream = CpnFileUtils.convertFileToByteArray(pathList);

        assertNotNull(fileDataStream);
    }

    @Test
    void deleteRecursively_whenDeleteFail_shouldThrowTechException() {
        Path wrongPath = Path.of("src", "test", "resources", "fichiers", "destinationBlabla");

        final TechException techException = assertThrows(TechException.class, () -> CpnFileUtils.deleteRecursively(wrongPath));
        assertEquals(MessageFormat.format("Could not deleteRecursively the Directory {0} :", wrongPath), techException.getMessage());
    }

    @Test
    void deleteRecursively_whenIsOk_shouldDeleteTheFile() throws TechException {
        Path source      = Path.of("src", "test", "resources", "fichiers");
        Path destination = Path.of("src", "test", "resources", "fichiers", "destination");

        CpnFileUtils.upload(source.resolve("Flux-WebService1.pdf").toFile(), destination.resolve("newfile.pdf"));
        CpnFileUtils.deleteRecursively(destination);

        assertFalse(destination.toFile().exists());
    }

    @Test
    void delete_whenDeleteFail_shouldThrowTechException() {
        Path destination = Path.of("src", "test", "resources", "fichiers", "destination");

        final TechException techException = assertThrows(TechException.class, () -> CpnFileUtils.delete(destination.resolve("notExistsFile.txt")));
        assertEquals(MessageFormat.format("Could not delete the file {0} :", destination.resolve("notExistsFile.txt")), techException.getMessage());
    }

    @Test
    void delete_whenIsOk_shouldDeleteTheFile() throws TechException {
        Path source      = Path.of("src", "test", "resources", "fichiers");
        Path destination = Path.of("src", "test", "resources", "fichiers", "destination");
        CpnFileUtils.upload(source.resolve("Flux-WebService1.pdf").toFile(), destination);
        CpnFileUtils.delete(destination.resolve("Flux-WebService1.pdf"));

        assertFalse(destination.resolve("Flux-WebService1.pdf").toFile().exists());
    }

    @Test
    void getFile_shouldReturn_file() throws Exception {
        Path         source   = Path.of("src", "test", "resources", "fichiers");
        List<String> pathList = List.of(source.resolve("doc1.pdf").toString());

        ByteArrayOutputStream fileDataStream = CpnFileUtils.convertFileToByteArray(pathList);

        final File file = CpnFileUtils.getFile(fileDataStream, "toto");
        assertNotNull(file);
    }

    @Test
    void mkdirs_should_createFolders() {
        final String filePath1 = System.getProperty("java.io.tmpdir") + File.separator + "mdu/folder1";
        final String filePath2 = System.getProperty("java.io.tmpdir") + File.separator + "mdu/folder/subfolder";

        final File file1 = new File(filePath1);
        final File file2 = new File(filePath2);
        assertFalse(file1.exists());
        assertFalse(file2.exists());

        CpnFileUtils.mkdirs(filePath1, filePath2);
        assertTrue(file1.exists());
        assertTrue(file2.exists());

        assertDoesNotThrow(() -> CpnFileUtils.delete(file1.toPath()));
        assertDoesNotThrow(() -> CpnFileUtils.delete(file2.toPath()));
    }

    @Test
    void upload_whenDirectoryExists_shouldUploadTheFile() throws TechException, IOException {
        Path source      = Path.of("src", "test", "resources", "fichiers");
        Path destination = Path.of("src", "test", "resources", "fichiers", "destination");

        FileSystemUtils.deleteRecursively(destination);
        Files.createDirectories(destination);

        CpnFileUtils.upload(source.resolve("Flux-WebService1.pdf").toFile(), destination);

        Path uploaded = Paths.get(destination.resolve("Flux-WebService1.pdf").toUri());
        assertEquals("Flux-WebService1.pdf", uploaded.toFile().getName());
    }

    @Test
    void upload_whenDirectoryNotExists_shouldCreateDirectoryAndUploadTheFile() throws TechException, IOException {
        Path source      = Path.of("src", "test", "resources", "fichiers");
        Path destination = Path.of("src", "test", "resources", "fichiers", "destination");

        FileSystemUtils.deleteRecursively(destination);
        CpnFileUtils.upload(source.resolve("Flux-WebService1.pdf").toFile(), destination);

        Path uploaded = Paths.get(destination.resolve("Flux-WebService1.pdf").toUri());
        assertEquals("Flux-WebService1.pdf", uploaded.toFile().getName());
    }

    @Test
    void upload_whenUploadFail_shouldThrowTechException() {
        Path source      = Path.of("src", "test", "resources", "fichier");
        Path destination = Path.of("src", "test", "resources", "fichiers", "destination");

        final TechException techException = assertThrows(TechException.class, () -> CpnFileUtils.upload(source.resolve("Flux-WebService1.pdf").toFile(), destination.resolve("Flux-WebService1.pdf")));
        assertEquals(MessageFormat.format("Could not store the file {0} into {1} :", source.resolve("Flux-WebService1.pdf").toFile().getName(), destination.resolve("Flux-WebService1.pdf")),
                     techException.getMessage());
    }
}
