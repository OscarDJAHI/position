package fr.gouv.justice.cpn.commun.utils;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class DateUtilsTest {

    @Test
    void is_date_when_date_chars_should_return_false() {
        assertFalse(DateUtils.isDateDdMmYyyy("test"));
        assertFalse(DateUtils.isDateDdMmYyyy("12/12/2021*test"));

        /*
        bizarre pour lui c'est true!!
        Réponse : c'est true parce que ce qu'il check c'est le format jour deux chars, moi deux chars, année 4 chars
        après pour le mois 45 ce qu'il fait, c'est qu'il divise 45/12 ==> 3ans. à la fin la date qu'il
        retourne c'est ça "2336-09-12T00:00:00.000+0200". donc c'est true
        */
        assertTrue(DateUtils.isDateDdMmYyyy("12/45/2333"));
        assertFalse(DateUtils.isDateDdMmYyyy("test*12/01/2021"));
        assertTrue(DateUtils.isDateDdMmYyyy("12/01/2021"));
    }

    @Test
    void toLocalDate_should_beOK_when_dateAndPatternAreCorrect() {
        final LocalDate localDate = DateUtils.toLocalDate("06/10/1993", "dd/MM/yyyy");

        assertNotNull(localDate);
        assertEquals(LocalDate.of(1993, 10, 6), localDate);
    }

    @Test
    void toLocalDate_should_throwException_when_patternDoesntMatchDate() {
        assertThrows(DateTimeParseException.class, () -> DateUtils.toLocalDate("06/10/1993", "dd/mm/yyyy"));
    }
}
