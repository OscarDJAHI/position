package fr.gouv.justice.cpn.commun.service;

import fr.gouv.justice.cpn.commun.converter.FileConverter;
import org.apache.commons.io.FileUtils;
import org.apache.tika.Tika;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.ByteArrayOutputStream;
import java.io.File;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@Disabled("test desabled because converter nedd oppen office and we don't have open office on jenkins")
class PdfConverterServiceImplTest {

    @Autowired
    private PdfConverterService pdfConverterService;

    @Value("${common.conversion.path.file-to-convert}")
    private String sourceFilePath;

    private final Tika tika = new Tika();

    @Test
    void convert_docx_to_pdf_OK() throws Exception {
        File   file               = new File(this.getClass().getClassLoader().getResource("fileToConvert/DocxBig.docx").toURI());
        File   fileConvertedToPdf = pdfConverterService.getFileConvertedToPdf(file);
        String mimeType           = tika.detect(fileConvertedToPdf);
        assertEquals("application/pdf", mimeType);
    }

    //@Test
    void testConvertXlsx() throws Exception {
        File                  file         = FileUtils.getFile(sourceFilePath.concat("FLEX_Desk_07092020.xlsx"));
        ByteArrayOutputStream baos         = FileConverter.fileToByteArrayOutputStream(file);
        ByteArrayOutputStream baosReturned = pdfConverterService.convertToByteArrayOutputStream(baos, "FLEX_Desk_07092020.xlsx");

        assertNotNull(baosReturned);
        File returnedFile = FileConverter.byteArrayOutputStreamToStreamFile(baosReturned, "FLEX_Desk_07092020.xlsx");

        String mimeType = tika.detect(returnedFile);
        assertEquals("application/pdf", mimeType);
    }

    //@Test
    void testConvert_should_return_original_byte_array() throws Exception {
        File                  file         = FileUtils.getFile(sourceFilePath.concat("accuse.pdf"));
        ByteArrayOutputStream baos         = FileConverter.fileToByteArrayOutputStream(file);
        ByteArrayOutputStream baosReturned = pdfConverterService.convertToByteArrayOutputStream(baos, "accuse.pdf");

        assertNotNull(baosReturned);
        File returnedFile = FileConverter.byteArrayOutputStreamToStreamFile(baosReturned, "accuse.pdf");

        String mimeType = tika.detect(returnedFile);
        assertEquals("application/pdf", mimeType);
    }

    // @Test
    void test_convert_wordperfect() throws Exception {
        File                  file         = FileUtils.getFile(sourceFilePath.concat("TEST.wpd"));
        ByteArrayOutputStream baos         = FileConverter.fileToByteArrayOutputStream(file);
        ByteArrayOutputStream baosReturned = pdfConverterService.convertToByteArrayOutputStream(baos, "TEST.wpd");

        assertNotNull(baosReturned);
        File returnedFile = FileConverter.byteArrayOutputStreamToStreamFile(baosReturned, "TEST.wpd");

        String mimeType = tika.detect(returnedFile);
        assertEquals("application/pdf", mimeType);
    }
}
