package fr.gouv.justice.cpn.commun;

import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.retry.annotation.EnableRetry;

@SpringBootApplication
@EnableRetry
@EnableConfigurationProperties()
@ComponentScan(basePackages = {"fr.gouv.justice", "justice.gouv.fr.cpn"})
public class CommunAppTests {

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(CommunAppTests.class);
    }

    @Test
    void CommunAppTest() {
        CommunAppTests.main(new String[]{});
    }
}
