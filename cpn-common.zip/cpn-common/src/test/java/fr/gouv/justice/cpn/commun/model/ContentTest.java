package fr.gouv.justice.cpn.commun.model;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ContentTest {

    Content content;

    @Test
    void getTacheArbo() {
        TacheArbo tacheArbo = new TacheArbo();
        content.setTacheArboNpp(tacheArbo);
        Assert.assertEquals(tacheArbo, content.getTacheArboNpp());
    }

    @BeforeEach
    void setUp() {
        content = new Content();
    }
}
