package fr.gouv.justice.cpn.commun.client.bpn;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn.DemandeEnvoiArBpnDTO;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn.DemandeEnvoiDocumentBpnDTO;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn.NodeDto;
import fr.gouv.justice.cpn.commun.builder.DemandeEnvoiDocumentBpnDtoBuilder;
import fr.gouv.justice.cpn.commun.builder.NodeDtoBuilder;
import fr.gouv.justice.cpn.commun.exception.TechException;
import fr.gouv.justice.cpn.commun.utils.CpnFileUtils;
import lombok.CustomLog;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockserver.integration.ClientAndServer;
import org.mockserver.model.Header;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.util.ResourceUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockserver.integration.ClientAndServer.startClientAndServer;
import static org.mockserver.matchers.Times.exactly;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

@SpringBootTest
@CustomLog
class RestClientBpnImplTest {

    private static final ObjectMapper om = new ObjectMapper();

    private static ClientAndServer mockServer;

    @Autowired
    private RestClientBpn restClientBpn;

    @BeforeAll
    static void startServer() {
        mockServer = startClientAndServer(9080);
        JavaTimeModule module = new JavaTimeModule();
        om.registerModule(module);
    }

    @AfterAll
    static void stopServer() {
        mockServer.stop();
    }

    @Test
    void downloadDocuments_whenIdsExists_shouldReturnOk() throws Exception {
        final File fileToDownload = getFile("fichiers/TestZip.zip");
        mockServer.when(request().withMethod("GET")
                                 .withPath("/api/v1/ged/documents"), exactly(1))
                  .respond(response().withStatusCode(200)
                                     .withBody(CpnFileUtils.toByteArrayOutputStream(fileToDownload).toByteArray())
                                     .withDelay(TimeUnit.SECONDS, 1));

        ByteArrayOutputStream byteArrayOutputStream = restClientBpn.downloadDocuments(List.of("1630", "1629"), "Uuid2");
        assertNotNull(byteArrayOutputStream);
    }

    @Test
    void sendArToBpn_should_respondWith200_when_everythingIsOk() {
        try {
            String nodeId = "1523";
            File   file   = getFile("fichiers/Flux-WebService1.pdf");

            NodeDto node1 = new NodeDto();
            node1.setId(1L);
            node1.setLevel(2);
            NodeDto node2 = new NodeDto();
            node2.setId(2L);
            node2.setLevel(1);

            mockServer.when(request().withMethod("POST").withPath("/api/upload/" + nodeId), exactly(1))
                      .respond(response().withStatusCode(200)
                                         .withHeaders(new Header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE))
                                         .withBody(om.writeValueAsString(List.of(node1, node2)))
                                         .withDelay(TimeUnit.SECONDS, 1));

            DemandeEnvoiArBpnDTO dto = new DemandeEnvoiArBpnDTO();
            dto.setIdNoeud(nodeId);
            dto.setUserMail("fanny.tessier@justice.gouv.fr");
            dto.setCodeSrj("10900");
            dto.setIdLdap("L00800");
            dto.setIdMessage(152L);

            assertDoesNotThrow(() -> restClientBpn.sendArToBpn(dto, file));
        } catch (Exception e) {
            Assertions.fail("message fail", e);
        }
    }

    @Test
    void sendArToBpn_should_throwTechException_when_responseIsNot200() throws Exception {
        String id   = "1523";
        File   file = getFile("fichiers/Flux-WebService1.pdf");

        NodeDto node1 = new NodeDto();
        node1.setId(1L);
        node1.setLevel(2);
        NodeDto node2 = new NodeDto();
        node2.setId(2L);
        node2.setLevel(1);

        mockServer.when(request().withMethod("POST").withPath("/api/upload/" + id), exactly(1))
                  .respond(response().withStatusCode(400)
                                     .withHeaders(new Header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE))
                                     .withBody(om.writeValueAsString(List.of(node1, node2)))
                                     .withDelay(TimeUnit.SECONDS, 1));

        DemandeEnvoiArBpnDTO dto = new DemandeEnvoiArBpnDTO();
        dto.setIdNoeud(id);
        dto.setUserMail("fanny.tessier@justice.gouv.fr");
        dto.setCodeSrj("10900");
        dto.setIdLdap("L00800");
        dto.setIdMessage(152L);

        assertThrows(TechException.class, () -> restClientBpn.sendArToBpn(dto, file));
    }

    @Test
    void uploadFiles_should_returnNodes() throws IOException, BpnException {
        File file = getTestZip();

        DemandeEnvoiDocumentBpnDTO demande = DemandeEnvoiDocumentBpnDtoBuilder.createDto();
        demande.setIdNoeud("485");

        List<NodeDto> dummyNodes = NodeDtoBuilder.createDtoList();
        mockServer.when(request().withMethod("POST").withPath("/api/upload/485"), exactly(1))
                  .respond(response().withStatusCode(200)
                                     .withHeaders(new Header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE))
                                     .withBody(om.writeValueAsString(dummyNodes))
                                     .withDelay(TimeUnit.SECONDS, 1));

        List<NodeDto> nodes = restClientBpn.uploadFilesIntoPochette(demande, List.of(file));

        assertNotNull(nodes);
        assertEquals(2, nodes.size());
    }

    @Test
    void uploadFiles_should_throwException() throws IOException {
        File file = getTestZip();

        DemandeEnvoiDocumentBpnDTO demande = DemandeEnvoiDocumentBpnDtoBuilder.createDto();
        demande.setIdNoeud("485");

        List<NodeDto> dummyNodes = NodeDtoBuilder.createDtoList();
        mockServer.when(request().withMethod("POST").withPath("/api/upload/485"), exactly(1))
                  .respond(response().withStatusCode(399)
                                     .withHeaders(new Header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE))
                                     .withBody(om.writeValueAsString(dummyNodes))
                                     .withDelay(TimeUnit.SECONDS, 1));

        List<File> files = new ArrayList<>();
        files.add(file);

        Exception exception = assertThrows(BpnException.class, () -> restClientBpn.uploadFilesIntoPochette(demande, files));
        assertEquals("A problem occurred while trying to upload files into bpn. ResponseCode : 399", exception.getMessage());
    }

    private static File getFile(final String filaName) throws FileNotFoundException {
        File file = ResourceUtils.getFile("classpath:" + filaName);
        assertNotNull(file);

        return file;
    }

    private static File getTestZip() throws FileNotFoundException {
        File file = getFile("TestZip.zip");
        log.info("File exists {}", file.exists());

        byte[] buf = new byte[1024];
        try (FileInputStream fis = new FileInputStream(file);
             ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            for (int readNum; (readNum = fis.read(buf)) != -1; ) {
                bos.write(buf, 0, readNum);
            }
        } catch (IOException ex) {
            log.error("Problème lors de l'écriture du fichier dans le bytoutputStream !!");
        }

        return file;
    }
}
