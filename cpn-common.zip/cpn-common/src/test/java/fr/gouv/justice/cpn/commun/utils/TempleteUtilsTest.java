package fr.gouv.justice.cpn.commun.utils;

import org.junit.jupiter.api.Test;
import org.thymeleaf.util.StringUtils;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TemplateUtilsTest {

    @Test
    void get_template() {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("message", "le message du template");

        String templateBody = TemplateUtils.getTemplate("thymleaf_test", params);

        assertEquals("<p>le message du template</p>", StringUtils.trim(templateBody));
    }
}
