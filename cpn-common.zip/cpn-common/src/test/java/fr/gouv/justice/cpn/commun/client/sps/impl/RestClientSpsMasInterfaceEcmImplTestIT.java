package fr.gouv.justice.cpn.commun.client.sps.impl;

import fr.gouv.justice.cpn.commun.builder.SpsBuilder;
import fr.gouv.justice.cpn.commun.client.sps.RestClientSpsMasInterfaceEcm;
import fr.gouv.justice.cpn.commun.client.sps.SpsException;
import fr.gouv.justice.cpn.commun.exception.FoncException;
import fr.gouv.justice.cpn.commun.model.enumeration.StatutPiece;
import fr.gouv.justice.cpn.commun.model.enumeration.TypeIdDPN;
import fr.gouv.justice.cpn.commun.utils.CpnFileUtils;
import lombok.CustomLog;
import lombok.RequiredArgsConstructor;
import org.apache.tika.Tika;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.util.ResourceUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@ActiveProfiles("integration")
@RequiredArgsConstructor(onConstructor_ = @Autowired)
@CustomLog
@Disabled("Disbale test integration don't work on jenkins")
class RestClientSpsMasInterfaceEcmImplTestIT {

    private static final String ID_PATTERN = "^.+;\\d+\\.0$";

    private static String documentId;

    private final RestClientSpsMasInterfaceEcm restClientSpsMasInterfaceEcm;

    @Test
    @Order(7)
    void deleteDocument_should_be_ok() throws Exception {
        assertNotNull(documentId);

        String response = this.restClientSpsMasInterfaceEcm.deleteDocument(SpsBuilder.document(documentId, StatutPiece.DEFINITIF),
                                                                           SpsBuilder.userId());
        assertEquals("le document est supprimé", response);
    }

    @Test
    @Order(2)
    void downloadDocument_should_be_ok() throws Exception {
        final ByteArrayOutputStream outputStream = this.restClientSpsMasInterfaceEcm.downloadDocument(documentId, SpsBuilder.userId());
        this.checkFile(outputStream, "application/pdf");
    }

    @Test
    void downloadDocument_should_throw_spsException_when_technicalId_doesnt_exist() {
        assertThrows(SpsException.class, () -> this.restClientSpsMasInterfaceEcm.downloadDocument("0123456789", SpsBuilder.userId()));
    }

    @Test
    @Order(3)
    void downloadDocuments_should_be_ok() throws Exception {
        final ByteArrayOutputStream outputStream = this.restClientSpsMasInterfaceEcm.downloadDocuments(List.of(documentId), SpsBuilder.userId());
        this.checkFile(outputStream, "application/zip");
    }

    @Test
    void downloadDocuments_should_return_empty_zip_when_technicalIds_dont_exist() throws Exception {
        final ByteArrayOutputStream stream = this.restClientSpsMasInterfaceEcm.downloadDocuments(List.of("0123456789", "9876543210"), SpsBuilder.userId());

        this.checkFile(stream, "application/zip");
        assertEquals(22, stream.size());
    }

    @Test
    @Order(6)
    void updateDocumentStatus_should_be_ok() throws Exception {
        final String technicalId = this.restClientSpsMasInterfaceEcm.updateDocumentStatus(SpsBuilder.document(documentId, StatutPiece.DEFINITIF),
                                                                                          SpsBuilder.userId());

        assertNotNull(technicalId);
        assertTrue(technicalId.matches(ID_PATTERN));

        documentId = technicalId;
    }

    @Test
    void updateDocumentStatus_should_throw_spsException_when_technicalId_doesnt_exist() {
        assertThrows(SpsException.class, () -> this.restClientSpsMasInterfaceEcm.updateDocumentStatus(SpsBuilder.document("12345-ABCDE-67890", StatutPiece.DEFINITIF),
                                                                                                      SpsBuilder.userId()));
    }

    @Test
    @Order(4)
    void updateDocument_should_be_ok() throws Exception {
        final String technicalId = this.restClientSpsMasInterfaceEcm.updateDocument(SpsBuilder.document(documentId,
                                                                                                        ResourceUtils.getFile("classpath:client/sps/impl/file-to-update-to-sps.pdf")),
                                                                                    SpsBuilder.userId());

        assertEquals(documentId.split(";")[0] + ";2.0", technicalId);
    }

    @Test
    @Order(5)
    void updateDocument_should_throw_foncException_when_update_forbidden_metadata() {
        assertThrows(FoncException.class,
                     () -> this.restClientSpsMasInterfaceEcm.updateDocument(RestClientSpsMasInterfaceEcm.DocumentSPS.builder()
                                                                                                                    .id(documentId)
                                                                                                                    .codeDossier("1234567890Y")
                                                                                                                    .typeDossier(TypeIdDPN.IDJ)
                                                                                                                    .file(ResourceUtils.getFile(
                                                                                                                            "classpath:client/sps/impl/file-to-update-to-sps.pdf"))
                                                                                                                    .juridiction("100109")
                                                                                                                    .status(StatutPiece.BROUILLON)
                                                                                                                    .build(),
                                                                            SpsBuilder.userId()));
    }

    @Test
    @Order(1)
    void uploadDocument_should_be_ok() throws Exception {
        String id = this.restClientSpsMasInterfaceEcm.uploadDocument(SpsBuilder.document(), SpsBuilder.userId());
        assertNotNull(id);
        assertTrue(id.matches(ID_PATTERN));

        documentId = id.split(";")[0];
    }

    private void checkFile(final ByteArrayOutputStream outputStream, final String contentType) throws IOException {
        assertNotNull(outputStream);

        final File file = CpnFileUtils.getFile(outputStream, "toto");
        assertNotNull(file);

        Tika   tika     = new Tika();
        String mimeType = tika.detect(file);
        assertEquals(contentType, mimeType);
    }
}
