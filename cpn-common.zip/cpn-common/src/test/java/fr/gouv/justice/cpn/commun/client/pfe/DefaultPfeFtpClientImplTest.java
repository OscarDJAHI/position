package fr.gouv.justice.cpn.commun.client.pfe;

import com.github.stefanbirkner.fakesftpserver.rule.FakeSftpServerRule;
import lombok.CustomLog;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@RunWith(SpringRunner.class)
@SpringBootTest
@CustomLog
public class DefaultPfeFtpClientImplTest {

    @Rule
    public final FakeSftpServerRule sftpServer = new FakeSftpServerRule().setPort(22).addUser("root", "");

    private static final String DEFAULT_FOLDER = "/pfe/folder/";

    private static Path ftpTmpFolder;

    @Autowired
    private PfeClients.DefaultFtpClient defaultFtpClient;

    @BeforeClass
    public static void init() {
        try {
            ftpTmpFolder = Files.createTempDirectory("ftp_");
        } catch (Exception exception) {
            log.error("Sorry ! Something went wrong when trying to create a tmp folder", exception);
        }
    }

    @Test
    public void downloadFile_should_beOk_when_fileExists() throws Exception {
        this.startServer();

        assertDoesNotThrow(() -> this.defaultFtpClient.downloadFile(DEFAULT_FOLDER + "file-2.zip", Path.of(ftpTmpFolder.toString(), "file-2.zip")));
        assertTrue(Files.exists(Path.of(ftpTmpFolder.toString(), "/file-2.zip")));

        Files.deleteIfExists(Path.of(ftpTmpFolder.toString(), "/file-2.zip"));
    }

    @Test
    public void downloadFile_should_beOk_when_fileExistsAndTargetFolderIsNull() throws Exception {
        this.startServer();

        final File file = assertDoesNotThrow(() -> this.defaultFtpClient.downloadFile(DEFAULT_FOLDER + "file-3.zip", null));
        assertNotNull(file);
        assertTrue(Files.exists(file.toPath()));

        Files.deleteIfExists(file.toPath());
    }

    @Test
    public void downloadFile_should_throwPfeException_when_fileDoesntExists() {
        assertThrows(PfeException.class, () -> this.defaultFtpClient.downloadFile(DEFAULT_FOLDER + "file-mdu.zip", ftpTmpFolder));
    }

    @Test
    public void getFolderContent_should_beOk_when_folderExists() throws Exception {
        this.startServer();

        final Set<String> folderContent = this.defaultFtpClient.listContent(DEFAULT_FOLDER);

        assertNotNull(folderContent);
        assertEquals(3, folderContent.size());
    }

    @Test
    public void getFolderContent_should_throwPfeException_when_folderIsNull() {
        assertThrows(PfeException.class, () -> this.defaultFtpClient.listContent(null));
    }

    @Test
    public void uploadFile_should_beOk_when_fileNotNullAndTargetExists() throws Exception {
        this.startServer();

        File file = ResourceUtils.getFile("classpath:client/pfe/file-to-upload-to-sftp.zip");

        assertDoesNotThrow(() -> this.defaultFtpClient.uploadFile(file, DEFAULT_FOLDER));
        assertTrue(this.sftpServer.existsFile(DEFAULT_FOLDER + "/" + file.getName()));
    }

    @Test
    public void uploadFile_should_throwPfeException_when_fileIsNull() {
        assertThrows(PfeException.class, () -> this.defaultFtpClient.uploadFile(null, DEFAULT_FOLDER));
    }

    @Test
    public void uploadFile_should_throwPfeException_when_targetFolderIsNull() throws Exception {
        File file = ResourceUtils.getFile("classpath:client/pfe/file-to-upload-to-sftp.zip");

        assertThrows(PfeException.class, () -> this.defaultFtpClient.uploadFile(file, null));
    }

    private void startServer() throws Exception {
        log.info("Creating files in : [{}]", DEFAULT_FOLDER);
        this.sftpServer.createDirectory(DEFAULT_FOLDER);

        File file = ResourceUtils.getFile("classpath:client/pfe/file-to-upload-to-sftp.zip");
        this.uploadFile("file-1.zip", file);
        this.uploadFile("file-2.zip", file);
        this.uploadFile("file-3.zip", file);
    }

    private void uploadFile(final String filename, final File file) throws Exception {
        try (final FileInputStream fileInputStream = new FileInputStream(file)) {
            this.sftpServer.putFile(DEFAULT_FOLDER + filename, fileInputStream);
        }
    }
}
