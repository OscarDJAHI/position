package fr.gouv.justice.cpn.commun.client.npp.impl;

import fr.gouv.justice.cpn.commun.beans.demande.envoi.npp.AbstractDemandeEnvoiDocumentNppDTO;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.npp.DemandeEnvoiDocumentNppDTO;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.npp.FonctionEnum;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.npp.ResponseEnvoiDocumentNppDTO;
import fr.gouv.justice.cpn.commun.builder.MessageDTOBuilder;
import fr.gouv.justice.cpn.commun.builder.NppBuilder;
import fr.gouv.justice.cpn.commun.client.npp.RestClientNPP;
import fr.gouv.justice.cpn.commun.exception.NppException;
import fr.gouv.justice.cpn.commun.model.ArborescenceApi;
import fr.gouv.justice.cpn.commun.model.UpdateEnvoiDTO;
import fr.gouv.justice.cpn.commun.model.descriptAffaire.DescriptAffaireApi;
import fr.gouv.justice.cpn.commun.model.enumeration.Status;
import lombok.CustomLog;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.util.ResourceUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.time.Instant;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest()
@ActiveProfiles("integration")
@CustomLog
@Disabled("Disbale test integration don't work on jenkins")
class RestClientNppImplIT {

    @Autowired
    private RestClientNPP restClientNPP;

    @Test
    void confirmSending_should_be_ok() throws Exception {
        UpdateEnvoiDTO updateEnvoi = new UpdateEnvoiDTO();
        updateEnvoi.setIdDemande("431");
        updateEnvoi.setMessage("ok");
        updateEnvoi.setStatus(Status.SUCCES);
        updateEnvoi.setDateRetour(Instant.now());

        ResponseEnvoiDocumentNppDTO response = this.restClientNPP.confirmSending(updateEnvoi, "100154");

        assertNotNull(response);
        assertEquals(200, response.getCode());
        assertEquals("Traitement effectué avec succes", response.getCause());
    }

    @Test
    void getArborecense_should_be_Ok() throws NppException {
        ArborescenceApi response = this.restClientNPP.getArborecense(NppBuilder.createDescriptArboApi());

        assertSuccess(response.getCode(), response.getMessage(), response.getCause());
    }

    @Test
    void getDescriptAffaireNpp_should_be_Ok() throws NppException {
        DescriptAffaireApi response = this.restClientNPP.getDescriptAffaireNpp(NppBuilder.createDescriptAffApi(), "100154");

        assertSuccess(response.getCode(), response.getMessage(), response.getCause());
    }

    @Test
    void sendDocumentsToNpp_should_be_ok() throws Exception {
        File file = ResourceUtils.getFile("classpath:client/npp/impl/file-to-send-to-npp.zip");
        log.info("File exists {}", file.exists());

        AbstractDemandeEnvoiDocumentNppDTO demande = new DemandeEnvoiDocumentNppDTO();
        demande.setOrigine("CPN");
        demande.setFonction(FonctionEnum.A);
        demande.setService("");
        demande.setSservice("");
        demande.setCodeDossier("1234567891B");
        demande.setCodeSrj("100154");
        demande.setComplement("");
        demande.setTypeDossier("Dossier pénal");

        try (ByteArrayOutputStream bos = this.toByteArrayOutputStream(file)) {
            ResponseEnvoiDocumentNppDTO response = this.restClientNPP.sendDocumentsToNpp(demande, bos);

            assertSuccess(response);
            assertNotNull(response.getIdAffaire());
        }
    }

    @Test
    void validateRequest_should_be_ok() throws Exception {
        ResponseEnvoiDocumentNppDTO response = this.restClientNPP.validateRequest(MessageDTOBuilder.create());

        assertSuccess(response);
        assertEquals("1234_dossier.zip", response.getNomArchive());
    }

    private void assertSuccess(final ResponseEnvoiDocumentNppDTO response) {
        this.assertSuccess(response.getCode(), response.getMessage(), response.getCause());
    }

    private void assertSuccess(final int code, final String message, final String cause) {
        assertEquals(200, code);
        assertEquals("OK", message);
        assertEquals("Traitement effectué avec succes", cause);
    }

    private ByteArrayOutputStream toByteArrayOutputStream(final File file) throws Exception {
        byte[] buf = new byte[1024];
        try (FileInputStream fis = new FileInputStream(file); ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            for (int readNum; (readNum = fis.read(buf)) != -1; ) {
                bos.write(buf, 0, readNum);
            }

            return bos;
        }
    }
}
