package fr.gouv.justice.cpn.commun.builder;

import fr.gouv.justice.cpn.commun.client.sps.RestClientSpsMasInterfaceEcm;
import fr.gouv.justice.cpn.commun.client.sps.SpsKeyMap;
import fr.gouv.justice.cpn.commun.model.enumeration.StatutPiece;
import fr.gouv.justice.cpn.commun.model.enumeration.TypeIdDPN;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Map;
import java.util.Objects;

public class SpsBuilder {

	private SpsBuilder() {
	}

	public static RestClientSpsMasInterfaceEcm.DocumentSPS document() throws FileNotFoundException {
		File file = ResourceUtils.getFile("classpath:client/sps/impl/file-to-upload-to-sps.pdf");

		return document(null, "100142", file);
	}

	public static RestClientSpsMasInterfaceEcm.DocumentSPS document(final String id, final File file) {
		return minDocumentSPSBuilder(id, file).build();
	}

	public static RestClientSpsMasInterfaceEcm.DocumentSPS document(final String id, final StatutPiece status) {
		return RestClientSpsMasInterfaceEcm.DocumentSPS.builder()
		                                               .id(id)
		                                               .nppId("12345-abcde-67890")
		                                               .status(status)
		                                               .build();
	}

	public static Map<SpsKeyMap, String> metadata() {
		return SpsKeyMap.mapOfNonEmpty(SpsKeyMap.entryOf(SpsKeyMap.NOM_JURIDICTION, null),
		                               SpsKeyMap.entryOf(SpsKeyMap.TYPE_ID_DPN, "IDJ"),
		                               SpsKeyMap.entryOf(SpsKeyMap.VALEUR_ID_DPN, "1234567896A"),
		                               SpsKeyMap.entryOf(SpsKeyMap.TYPE_DOSSIER, "PP"),
		                               SpsKeyMap.entryOf(SpsKeyMap.NOM_FICHIER, null),
		                               SpsKeyMap.entryOf(SpsKeyMap.TYPE_FICHIER, null),
		                               SpsKeyMap.entryOf(SpsKeyMap.ETAT_FICHIER, "BROUILLON"),
		                               SpsKeyMap.entryOf(SpsKeyMap.TYPE_FICHIER, "PDF"));
	}

	public static String userId() {
		return "email1@justice.gouv.fr";
	}

	private static RestClientSpsMasInterfaceEcm.DocumentSPS document(final String id, final String juridiction, final File file) {
		return minDocumentSPSBuilder(id, file).codeDossier("1234567896A")
		                                      .typeDossier(TypeIdDPN.IDJ)
		                                      .juridiction(juridiction)
		                                      .build();
	}

	private static RestClientSpsMasInterfaceEcm.DocumentSPS.DocumentSPSBuilder minDocumentSPSBuilder(final String id, final File file) {
		return minDocumentSPSBuilder(id, file, null);
	}

	private static RestClientSpsMasInterfaceEcm.DocumentSPS.DocumentSPSBuilder minDocumentSPSBuilder(final String id, final File file, final StatutPiece status) {
		return RestClientSpsMasInterfaceEcm.DocumentSPS.builder()
		                                               .id(id)
		                                               .file(file)
		                                               .status(Objects.isNull(status) ? StatutPiece.BROUILLON : status);
	}
}
