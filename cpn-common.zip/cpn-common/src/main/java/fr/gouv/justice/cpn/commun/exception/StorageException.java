package fr.gouv.justice.cpn.commun.exception;

import lombok.Data;

@Data
public class StorageException extends Exception {

    private String httpStatus;

    public StorageException() {
    }

    public StorageException(String message) {
        super(message);
    }

    public StorageException(String message, Throwable cause) {
        super(message, cause);
    }

    public StorageException(Throwable cause) {
        super(cause);
    }
}
