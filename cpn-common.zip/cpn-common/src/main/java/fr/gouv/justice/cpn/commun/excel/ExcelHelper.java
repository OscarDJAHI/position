package fr.gouv.justice.cpn.commun.excel;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelHelper {

    public static void autoSizeColumns(Sheet sheet, boolean autoSize, int... columns) {
        if (null == columns) {
            return;
        }

        for (int column : columns) {
            sheet.autoSizeColumn(column, autoSize);
        }
    }

    public static Cell buildCell(Row line, int index, String value, CellStyle cellStyle) {
        Cell cell = line.createCell(index);
        cell.setCellStyle(cellStyle);
        cell.setCellValue(value);

        return cell;
    }

    public static XSSFFont buildFont(XSSFWorkbook workbook, String fontName, int fontSize, boolean isBold, IndexedColors color) {
        XSSFFont font = workbook.createFont();
        font.setFontName(fontName);
        font.setFontHeightInPoints((short) fontSize);
        font.setBold(isBold);
        font.setColor(color.getIndex());

        return font;
    }
}
