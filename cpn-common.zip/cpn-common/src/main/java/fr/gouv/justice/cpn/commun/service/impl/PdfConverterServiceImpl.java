package fr.gouv.justice.cpn.commun.service.impl;

import fr.gouv.justice.cpn.commun.converter.FileConverter;
import fr.gouv.justice.cpn.commun.converter.GenericPdfConverter;
import fr.gouv.justice.cpn.commun.exception.TechException;
import fr.gouv.justice.cpn.commun.service.PdfConverterService;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.tika.Tika;
import org.jodconverter.core.document.DefaultDocumentFormatRegistry;
import org.jodconverter.core.document.DocumentFormat;
import org.jodconverter.core.office.OfficeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

/**
 * PdfConverterService take a File that is not a pdf and convert it t pdf format
 */
@Service
public class PdfConverterServiceImpl implements PdfConverterService {

    private static final Logger LOGGER        = LoggerFactory.getLogger(PdfConverterServiceImpl.class);
    private static final String MIME_TYPE_PDF = "application/pdf";
    private static final Tika   tika          = new Tika();
    private static final String PDF_EXTENSION = ".pdf";

    @Override
    public ByteArrayOutputStream convertToByteArrayOutputStream(ByteArrayOutputStream inFile, String fileName) throws IOException, OfficeException {
        File file = FileConverter.byteArrayOutputStreamToStreamFile(inFile, fileName);

        String mimeType = tika.detect(file);
        if (isNotToConvert(mimeType)) {
            return inFile;
        }

        DocumentFormat format = DefaultDocumentFormatRegistry.getFormatByMediaType(mimeType);

        if (StringUtils.containsIgnoreCase(mimeType, "wordperfect")) {
            format = DefaultDocumentFormatRegistry.WPD;
        }

        return GenericPdfConverter.convert(file, format);
    }

    @Override
    public File getFileConvertedToPdf(File file) throws TechException {
        try (ByteArrayOutputStream baos = FileConverter.fileToByteArrayOutputStream(file);
             ByteArrayOutputStream baosConverted = convertToByteArrayOutputStream(baos, file.getName())) {
            String nameWithoutExtension = FilenameUtils.removeExtension(file.getName());
            String nameWithPdfExtension = nameWithoutExtension.concat(PDF_EXTENSION);
            return FileConverter.byteArrayOutputStreamToStreamFile(baosConverted, nameWithPdfExtension);
        } catch (Exception exception) {
            LOGGER.error("getFileConvertedToPdf : {}", exception.getMessage());
            throw new TechException(exception.getMessage(), exception);
        }
    }

    private boolean isNotToConvert(String mimeType) {
        return StringUtils.equalsIgnoreCase(MIME_TYPE_PDF, mimeType);
    }
}
