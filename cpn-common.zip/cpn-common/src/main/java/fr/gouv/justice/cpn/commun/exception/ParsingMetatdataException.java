package fr.gouv.justice.cpn.commun.exception;

public class ParsingMetatdataException extends Exception {

    public ParsingMetatdataException(Throwable cause) {
        super(cause);
    }

    public ParsingMetatdataException(String message, Throwable cause) {
        super(message, cause);
    }
}
