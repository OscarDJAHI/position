package fr.gouv.justice.cpn.commun.utils;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class Base64Utils {

    public static String encode(String key) {
        byte[] encodedBytes = Base64.getUrlEncoder().encode(key.getBytes(StandardCharsets.UTF_8));
        return new String(encodedBytes, StandardCharsets.UTF_8);
    }
}
