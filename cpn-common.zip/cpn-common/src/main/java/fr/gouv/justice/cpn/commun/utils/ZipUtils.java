package fr.gouv.justice.cpn.commun.utils;

import com.google.common.io.Files;
import fr.gouv.justice.cpn.commun.exception.TechException;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class ZipUtils {

    private static final Pattern PATTERN = Pattern.compile("[^A-Za-z0-9_!@#&$\\- \\.()\\]\\[]");

    private static final int MAX_LENGTH = 127;

    private ZipUtils() {
    }

    public static String escapeStringAsFilename(final String in) {
        StringBuffer sb = new StringBuffer();

        // Apply the regex.
        Matcher m = PATTERN.matcher(in);
        while (m.find()) {
            String replacement = Integer.toHexString(m.group().charAt(0)).toUpperCase();
            m.appendReplacement(sb, replacement);
        }
        m.appendTail(sb);

        String encoded = sb.toString();
        int    end     = Math.min(encoded.length(), MAX_LENGTH);

        return encoded.substring(0, end);
    }

    public static List<File> getUnZipUploadedFiles(final MultipartFile multipartFile) throws IOException {
        File zipFile = File.createTempFile("file", ".zip");
        FileUtils.writeByteArrayToFile(zipFile, multipartFile.getBytes());

        return ZipUtils.unZip(zipFile);
    }

    public static File multipartToFile(final MultipartFile multipartFile, final String fileName) throws IOException {
        File zipFile = new File(Files.createTempDir(), fileName);
        FileUtils.writeByteArrayToFile(zipFile, multipartFile.getBytes());

        return zipFile;
    }

    /**
     * Décompresse le fichier zip dans le répertoire donné
     *
     * @param zipFile le fichier zip à décompresser
     */
    public static List<File> unZip(final File zipFile) throws IOException {
        List<File> unzipedFile = new ArrayList<>();

        try (ZipInputStream zis = new ZipInputStream(new BufferedInputStream(new FileInputStream(zipFile.getCanonicalFile())))) {
            ZipEntry ze;
            while ((ze = zis.getNextEntry()) != null) {
                File         f   = new File(Files.createTempDir(), StringUtils.stripAccents(ze.getName()));//File.createTempFile (fileNameWithoutExtension,  "."+ extension);
                OutputStream fos = new BufferedOutputStream(new FileOutputStream(f));

                try {
                    try {
                        final byte[] buf = new byte[8192];
                        int          bytesRead;
                        while (-1 != (bytesRead = zis.read(buf))) {
                            fos.write(buf, 0, bytesRead);
                        }
                        unzipedFile.add(f);
                    } finally {
                        fos.close();
                    }
                } catch (final IOException ioe) {
                    f.delete();
                    throw ioe;
                }
            }
        }

        return unzipedFile;
    }

    public static Map<String, ByteArrayOutputStream> unzip(final ByteArrayOutputStream zip) throws TechException {
        if (Objects.isNull(zip)) {
            return Collections.emptyMap();
        }

        Map<String, ByteArrayOutputStream> entries = new HashMap<>();
        try (ZipInputStream zipStream = new ZipInputStream(new ByteArrayInputStream(zip.toByteArray()))) {
            ZipEntry entry;
            while ((entry = zipStream.getNextEntry()) != null) {
                entries.put(entry.getName(), toByteArrayOutputStream(zipStream));
            }

            return entries;
        } catch (Exception exception) {
            throw new TechException(exception);
        }
    }

    public static ByteArrayOutputStream zip(final Collection<File> files) throws IOException {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream(); ZipOutputStream zipOut = new ZipOutputStream(baos)) {
            for (File srcFile : files) {
                try (FileInputStream fis = new FileInputStream(srcFile)) {
                    ZipEntry zipEntry = new ZipEntry(srcFile.getName());
                    zipOut.putNextEntry(zipEntry);
                    IOUtils.copy(fis, zipOut);
                }
            }

            return baos;
        }
    }

    private static ByteArrayOutputStream toByteArrayOutputStream(final ZipInputStream zipStream) throws TechException {
        try (final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream()) {
            byteArrayOutputStream.write(zipStream.readAllBytes());

            return byteArrayOutputStream;
        } catch (Exception exception) {
            throw new TechException(exception);
        }
    }
}
