package fr.gouv.justice.cpn.commun.exception;

public class MasInterfacePlinePlexException extends Exception {

    public MasInterfacePlinePlexException() {
    }

    public MasInterfacePlinePlexException(final String message) {
        super(message);
    }

    public MasInterfacePlinePlexException(final String message, final Throwable throwable) {
        super(message, throwable);
    }
}
