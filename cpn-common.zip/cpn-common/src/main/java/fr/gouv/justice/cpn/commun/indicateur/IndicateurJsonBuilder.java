package fr.gouv.justice.cpn.commun.indicateur;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.gouv.justice.cpn.commun.beans.journal.reception.enumeration.TypeProcedure;

import java.time.LocalDateTime;
import java.util.Objects;

public class IndicateurJsonBuilder {

    private final IndicateurJson json;

    private ObjectMapper om;

    public IndicateurJsonBuilder() {
        this.json = new IndicateurJson();
    }

    public IndicateurJsonBuilder appli(String appli) {
        this.json.setAppli(appli);

        return this;
    }

    public IndicateurJsonBuilder canal(String canal) {
        this.json.setCanal(canal);

        return this;
    }

    public IndicateurJsonBuilder domaine(String domaine) {
        this.json.setDomaine(domaine);

        return this;
    }

    public IndicateurJsonBuilder idIndic(IndicateurId idIndic) {
        this.json.setIndic(idIndic);

        return this;
    }

    public IndicateurJsonBuilder juri(String juri) {
        this.json.setJuri(juri);

        return this;
    }

    public IndicateurJsonBuilder nb(int nb) {
        this.json.setNb(nb);

        return this;
    }

    public IndicateurJsonBuilder orpe(String orpe) {
        this.json.setOrpe(orpe);

        return this;
    }

    public String toLogString() throws JsonProcessingException {
        Objects.requireNonNull(this.json.getIndic());
        this.json.setTs(LocalDateTime.now());

        return getMapper().writeValueAsString(json);
    }

    public IndicateurJsonBuilder typeProc(TypeProcedure typeProc) {
        this.json.setTypeproc(typeProc);

        return this;
    }

    private ObjectMapper getMapper() {
        if (null == om) {
            om = new ObjectMapper();
            om.configure(SerializationFeature.WRITE_DURATIONS_AS_TIMESTAMPS, false);
            om.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
            om.registerModule(new JavaTimeModule());
        }

        return om;
    }
}
