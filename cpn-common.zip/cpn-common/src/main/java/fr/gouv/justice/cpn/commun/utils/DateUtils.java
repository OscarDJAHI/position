package fr.gouv.justice.cpn.commun.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.util.regex.Pattern.compile;

public class DateUtils {

    public static final String           DATE_PATTERN = "^[0-9]{2}\\/[0-9]{2}\\/[0-9]{4}$";
    public static final SimpleDateFormat DF           = new SimpleDateFormat("dd/MM/yyyy");

    private DateUtils() {
    }

    public static LocalDateTime convertToClientTimeZone(LocalDateTime date) {
        ZonedDateTime ldtZoned   = date.atZone(ZoneId.of("UTC"));
        ZonedDateTime localZoned = ldtZoned.withZoneSameInstant(ZoneId.of("Europe/Paris"));

        return localZoned.toLocalDateTime();
    }

    public static Date convertToDate(LocalDate localDate) {
        return Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
    }

    public static Date convertToDate(LocalDateTime localDateTime) {
        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }

    public static LocalDateTime convertToLocalDateTimeViaSqlTimestamp(Date dateToConvert) {
        return new java.sql.Timestamp(dateToConvert.getTime()).toLocalDateTime();
    }

    public static Date getDateDdMmYyyy(String dateToPars) {
        try {
            return DF.parse(dateToPars);
        } catch (ParseException e) {
            return null;
        }
    }

    public static Instant getInstantDdMmYyyy(String dateToPars) {
        try {
            return DF.parse(dateToPars).toInstant();
        } catch (ParseException e) {
            return Instant.now();
        }
    }

    public static boolean isDateDdMmYyyy(String dateToPars) {
        Pattern p = compile(DATE_PATTERN);
        Matcher m = p.matcher(dateToPars);
        if (!m.find()) {
            return Boolean.FALSE;
        }

        try {
            DF.parse(dateToPars);
            return Boolean.TRUE;
        } catch (Exception e) {
            return Boolean.FALSE;
        }
    }

    public static Instant toInstant(LocalDateTime date) {
        return date.atZone(ZoneId.systemDefault()).toInstant();
    }

    public static LocalDate toLocalDate(Date dateToConvert) {
        return Instant.ofEpochMilli(dateToConvert.getTime())
                      .atZone(ZoneId.systemDefault())
                      .toLocalDate();
    }

    public static LocalDate toLocalDate(Instant instant) {
        return LocalDate.ofInstant(instant, ZoneId.systemDefault());
    }

    public static LocalDate toLocalDate(final String dateAsString, final String dateformat) {
        return LocalDate.parse(dateAsString, DateTimeFormatter.ofPattern(dateformat));
    }

    public static LocalDateTime toLocalDateTime(Instant instant) {
        return LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
    }

    public static LocalDateTime toLocalDateTime(Date dateToConvert) {
        return Instant.ofEpochMilli(dateToConvert.getTime())
                      .atZone(ZoneId.systemDefault())
                      .toLocalDateTime();
    }
}
