package fr.gouv.justice.cpn.commun.client.sps;

import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.AbstractMap;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public enum SpsKeyMap {

    CODE_NIVEAU_ORGATNISATION_1("ppn:codeNiveauOrganisation1"),
    CODE_NIVEAU_ORGATNISATION_2("ppn:codeNiveauOrganisation2"),
    CODE_NIVEAU_ORGATNISATION_3("ppn:codeNiveauOrganisation3"),
    CODE_NIVEAU_ORGATNISATION_4("ppn:codeNiveauOrganisation4"),
    CODE_NIVEAU_ORGATNISATION_5("ppn:codeNiveauOrganisation5"),
    CODE_NIVEAU_ORGATNISATION_6("ppn:codeNiveauOrganisation6"),
    DATE_DERNIERE_MISE_A_JOUR("ppn:dateDerniereMiseAjour"),
    ID_PARQUET("ppn:idParquet"),
    TYPE_DOSSIER("ppn:typeDossier"),
    NOM_JURIDICTION("ppn:nomJuridiction"),
    NOM_DPN("ppn:nomDpn"),
    UNA_UPVA("ppn:unaUpva"),
    TYPE_ID_DPN("ppn:typeIdDpn"),
    VALEUR_ID_DPN("ppn:valeurIdDpn"),
    CHEMIN("ppn:chemin"),
    DATE_DERNIERE_MAJ("ppn:dateDerniereMAJ"),
    ETAT_FICHIER("ppn:etatFichier"),
    ID_NOEUD_NPP("ppn:idNoeudNPP"),
    NOM_FICHIER("ppn:nomFichier"),
    TYPE_FICHIER("ppn:typeFichier");

    private final String value;

    SpsKeyMap(final String value) {
        this.value = value;
    }

    public static Map.Entry<SpsKeyMap, String> entryOf(final SpsKeyMap spsKeyMap, final String value) {
        return new AbstractMap.SimpleEntry<>(spsKeyMap, value);
    }

    @SafeVarargs
    public static Map<SpsKeyMap, String> mapOfNonEmpty(final Map.Entry<SpsKeyMap, String>... entries) {
        if (isEmpty(entries)) {
            return Collections.emptyMap();
        }

        return Arrays.stream(entries)
                     .filter(p -> !StringUtils.isEmpty(p.getValue()))
                     .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }

    @SafeVarargs
    public static Map<String, String> mergeOfNonEmpty(final Map<SpsKeyMap, String>... maps) {
        if (isEmpty(maps)) {
            return Collections.emptyMap();
        }

        return Stream.of(maps)
                     .flatMap(map -> clean(map).entrySet().stream())
                     .collect(Collectors.toMap(entry -> entry.getKey().value, Map.Entry::getValue, (entry1, entry2) -> entry2));
    }

    public String value() {
        return value;
    }

    private static Map<SpsKeyMap, String> clean(final Map<SpsKeyMap, String> map) {
        if (CollectionUtils.isEmpty(map)) {
            return Collections.emptyMap();
        }

        return map.entrySet()
                  .stream()
                  .filter(entry -> !StringUtils.isEmpty(entry.getValue()))
                  .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }

    @SafeVarargs
    private static <T> boolean isEmpty(T... elements) {
        return Objects.isNull(elements) || CollectionUtils.isEmpty(Arrays.asList(elements));
    }
}
