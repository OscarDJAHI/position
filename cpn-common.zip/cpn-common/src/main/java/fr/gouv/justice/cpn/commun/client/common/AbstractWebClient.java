package fr.gouv.justice.cpn.commun.client.common;

import fr.gouv.justice.cpn.commun.exception.TechException;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import lombok.Builder;
import lombok.CustomLog;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.util.ResourceUtils;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;

import javax.annotation.PostConstruct;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.TrustManagerFactory;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.util.Objects;

@CustomLog
public abstract class AbstractWebClient {

    private WebClient webClient;

    private static ExchangeFilterFunction logRequest() {
        return ExchangeFilterFunction.ofRequestProcessor(clientRequest -> {
            log.info("Request: {} {}", clientRequest.method(), clientRequest.url());
            clientRequest.headers().forEach((name, values) -> values.forEach(value -> log.info("Header{name:{}, value:{}}", name, value)));
            log.info("Body: {}", clientRequest.body());

            return Mono.just(clientRequest);
        });
    }

    private static ExchangeFilterFunction logResponse() {
        return ExchangeFilterFunction.ofResponseProcessor(clientResponse -> {
            log.info("Response Status {}", clientResponse.statusCode());
            clientResponse.headers().asHttpHeaders().forEach((name, values) -> values.forEach(value -> log.info("Header{name:{}, value:{}}", name, value)));

            return Mono.just(clientResponse);
        });
    }

    protected WebClient.RequestHeadersUriSpec<?> delete() {
        return webClient.delete();
    }

    protected WebClient.RequestHeadersUriSpec<?> get() {
        return this.webClient.get();
    }

    protected abstract String getBaseUrl();

    protected ReactorClientHttpConnector getClientConnector() {
        return null;
    }

    protected SecureContext getSecureContext() {
        return null;
    }

    protected WebClient.RequestBodyUriSpec post() {
        return this.webClient.post();
    }

    protected WebClient.RequestBodyUriSpec put() {
        return this.webClient.put();
    }

    private ReactorClientHttpConnector connector() throws TechException {
        final SecureContext secureContext = this.getSecureContext();
        return !Objects.isNull(secureContext) && !secureContext.isEmpty() ? this.newSecureConnector(secureContext) : this.getClientConnector();
    }

    private KeyManagerFactory newKeyManagerFactory(final LocalKeyStore securekeyStore) throws TechException {
        try (InputStream keyStoreFile = new FileInputStream(ResourceUtils.getFile(securekeyStore.getPath()))) {
            KeyStore keyStore = KeyStore.getInstance(securekeyStore.getType());
            keyStore.load(keyStoreFile, securekeyStore.getPassword().toCharArray());

            // Set up key manager factory to use our key store
            KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            keyManagerFactory.init(keyStore, securekeyStore.getPrivateKeyPassword().toCharArray());

            return keyManagerFactory;
        } catch (Exception exception) {
            throw new TechException(exception);
        }
    }

    private ReactorClientHttpConnector newSecureConnector(final SecureContext secureContext) throws TechException {
        // Set up key manager factory to use our key store
        KeyManagerFactory keyManagerFactory = this.newKeyManagerFactory(secureContext.getKeyStore());

        // truststore
        TrustManagerFactory trustManagerFactory = this.newTrustManagerFactory(secureContext.getTrustStore());

        try {
            SslContext sslContext = SslContextBuilder.forClient()
                                                     .keyManager(keyManagerFactory)
                                                     .trustManager(trustManagerFactory)
                                                     .build();

            HttpClient httpClient = HttpClient.create().secure(sslContextSpec -> sslContextSpec
                    .sslContext(sslContext)
                    .handlerConfigurator(sslHandler -> {
                        SSLEngine     engine = sslHandler.engine();
                        SSLParameters params = new SSLParameters(engine.getSSLParameters().getCipherSuites(), engine.getSSLParameters().getProtocols());
                        params.setEndpointIdentificationAlgorithm(StringUtils.EMPTY);
                        engine.setSSLParameters(params);
                    }));

            return new ReactorClientHttpConnector(httpClient);

        } catch (Exception exception) {
            throw new TechException(exception);
        }
    }

    private TrustManagerFactory newTrustManagerFactory(final LocalKeyStore secureTrustStore) throws TechException {
        try (InputStream trustStoreFile = new FileInputStream(ResourceUtils.getFile(secureTrustStore.getPath()))) {
            KeyStore trustStore = KeyStore.getInstance(secureTrustStore.getType());
            trustStore.load(trustStoreFile, secureTrustStore.getPassword().toCharArray());

            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            trustManagerFactory.init(trustStore);

            return trustManagerFactory;
        } catch (Exception exception) {
            throw new TechException(exception);
        }
    }

    @PostConstruct
    private void webClient() throws TechException {
        final String baseUrl = this.getBaseUrl();
        Objects.requireNonNull(baseUrl, "Sorry ! The base url can not be empty; Please override getBaseUrl() method");

        WebClient.Builder webclientBuilder = WebClient.builder()
                                                      .baseUrl(baseUrl)
                                                      .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                                                      .filter(logRequest())
                                                      .filter(logResponse());

        final ReactorClientHttpConnector connector = this.connector();
        if (!Objects.isNull(connector)) {
            webclientBuilder = webclientBuilder.clientConnector(connector);
        }

        this.webClient = webclientBuilder.build();
    }

    @Builder
    @Getter
    @ToString
    @EqualsAndHashCode
    protected static class LocalKeyStore {

        private String path;
        private String type;
        private String password;
        private String privateKeyPassword;
    }

    @Builder
    @Getter
    @ToString
    @EqualsAndHashCode
    protected static class SecureContext {

        private LocalKeyStore keyStore;
        private LocalKeyStore trustStore;

        public boolean isEmpty() {
            return Objects.isNull(this.keyStore) || Objects.isNull(this.trustStore);
        }
    }
}
