package fr.gouv.justice.cpn.commun.client.storage;

import fr.gouv.justice.cpn.commun.beans.storage.StorageRequest;
import fr.gouv.justice.cpn.commun.beans.storage.StorageResponse;
import fr.gouv.justice.cpn.commun.exception.StorageException;

public interface RestClientProxyStorage {

    StorageResponse deleteDocument(final StorageRequest request) throws StorageException;

    StorageResponse downloadDocument(final StorageRequest request) throws StorageException;

    StorageResponse downloadDocuments(final StorageRequest request) throws StorageException;

    StorageResponse uploadDocument(final StorageRequest request) throws StorageException;
}
