package fr.gouv.justice.cpn.commun.excel;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFFont;

public class CellStyleBuilder {

    private final CellStyle cellStyle;

    public CellStyleBuilder(Workbook workbook) {
        this.cellStyle = workbook.createCellStyle();
    }

    public CellStyleBuilder alignCenter() {
        cellStyle.setAlignment(HorizontalAlignment.CENTER);
        cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);

        return this;
    }

    public CellStyleBuilder alignment(HorizontalAlignment alignment) {
        cellStyle.setAlignment(alignment);

        return this;
    }

    public CellStyleBuilder border(BorderStyle borderStyle) {
        cellStyle.setBorderBottom(borderStyle);
        cellStyle.setBorderLeft(borderStyle);
        cellStyle.setBorderRight(borderStyle);
        cellStyle.setBorderTop(borderStyle);

        return this;
    }

    public CellStyle build() {
        return cellStyle;
    }

    public CellStyleBuilder fillForegroundColor(int color) {
        cellStyle.setFillForegroundColor((short) color);

        return this;
    }

    public CellStyleBuilder fillPattern(FillPatternType pattern) {
        cellStyle.setFillPattern(pattern);

        return this;
    }

    public CellStyleBuilder font(XSSFFont font) {
        cellStyle.setFont(font);

        return this;
    }

    public CellStyleBuilder verticalAlignment(VerticalAlignment verticalAlignment) {
        cellStyle.setVerticalAlignment(verticalAlignment);

        return this;
    }
}
