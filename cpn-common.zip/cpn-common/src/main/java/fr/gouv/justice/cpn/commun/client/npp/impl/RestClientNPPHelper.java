package fr.gouv.justice.cpn.commun.client.npp.impl;

import fr.gouv.justice.cpn.commun.beans.demande.envoi.npp.AbstractDemandeEnvoiDocumentNppDTO;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.npp.FonctionEnum;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.npp.ResponseEnvoiDocumentNppDTO;
import fr.gouv.justice.cpn.commun.model.DemandeEnvoiMessageDTO;
import fr.gouv.justice.cpn.commun.model.DemandeEnvoiMessageDestinataireDTO;
import fr.gouv.justice.cpn.commun.model.DescriptAffApi;
import fr.gouv.justice.cpn.commun.model.DescriptArboApi;
import fr.gouv.justice.cpn.commun.model.FichierDemandeEnvoiMessageDTO;
import lombok.CustomLog;
import lombok.Data;
import net.minidev.json.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.FileSystemResource;
import org.springframework.data.util.Pair;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.ClientResponse;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.MissingFormatArgumentException;
import java.util.Objects;
import java.util.stream.Collectors;

@CustomLog
class RestClientNPPHelper {
    private final static DateTimeFormatter UTC_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'")
                                                                            .withZone(ZoneId.of("UTC"));

    private RestClientNPPHelper() {
    }

    @SafeVarargs
    static FileSystemResource toJson(final String filename, final Pair<String, Object>... entries) throws IOException {
        if (StringUtils.isEmpty(filename) || Objects.isNull(entries) || entries.length == 0) {
            throw new MissingFormatArgumentException("Sorry ! Something went wrong when trying to generate JSON file for NPP :: Filename and Content can not be empty");
        }

        JSONObject content = new JSONObject();
        Arrays.stream(entries).forEach(entry -> content.put(entry.getFirst(), entry.getSecond()));

        File jsonFile = File.createTempFile(filename, ".json");
        try (FileWriter jsonOut = new FileWriter(jsonFile, StandardCharsets.UTF_8)) {
            jsonOut.write(content.toJSONString());
        }

        log.info("The JSON file to send to NPP was generated successfully -> {}", content);

        return new FileSystemResource(jsonFile);
    }

    static FileSystemResource toJsonFile(final AbstractDemandeEnvoiDocumentNppDTO demande, final String fileName) throws IOException {
        return demande.getFonction() == FonctionEnum.I ? toJsonFileFoncI(demande, fileName) : toJsonFileNonFoncI(demande, fileName);
    }

    static FileSystemResource toJsonFileNonFoncI(final AbstractDemandeEnvoiDocumentNppDTO demande, final String fileName) throws IOException {
        return toJson("jsonFile",
                      Pair.of("origine", StringUtils.defaultString(demande.getOrigine(), "CPN")),
                      Pair.of("fonction", demande.getFonction().name()),
                      Pair.of("affaire", demande.getFonction() == FonctionEnum.A ? StringUtils.EMPTY : demande.getAffaire()),
                      Pair.of("service", StringUtils.defaultString(demande.getService(), StringUtils.EMPTY)),
                      Pair.of("sservice", StringUtils.defaultString(demande.getSservice(), StringUtils.EMPTY)),
                      Pair.of("noeudService", StringUtils.defaultString(demande.getNoeudAlfresco(), StringUtils.EMPTY)),
                      Pair.of("idj", demande.getCodeDossier()),
                      Pair.of("zip", fileName),
                      Pair.of("Type de Dossier", demande.getTypeDossier()),
                      Pair.of("complement", FonctionEnum.U == demande.getFonction() ? demande.getNoeudAlfresco() : StringUtils.defaultString(demande.getComplement(), StringUtils.EMPTY)));
    }

    static FileSystemResource toJsonFileFoncI(final AbstractDemandeEnvoiDocumentNppDTO demande, final String fileName) throws IOException {
        return toJson("jsonFile",
                      Pair.of("origine", StringUtils.defaultString(demande.getOrigine(), "CPN")),
                      Pair.of("fonction", demande.getFonction().name()),
                      Pair.of("affaire", demande.getFonction() == FonctionEnum.A ? StringUtils.EMPTY : demande.getAffaire()),
                      Pair.of("service", StringUtils.defaultString(demande.getService(), StringUtils.EMPTY)),
                      Pair.of("sservice", StringUtils.defaultString(demande.getSservice(), StringUtils.EMPTY)),
                      Pair.of("noeudService", StringUtils.defaultString(demande.getNoeudAlfresco(), StringUtils.EMPTY)),
                      Pair.of("idj", demande.getCodeDossier()),
                      Pair.of("zip", fileName),
                      Pair.of("Type de Dossier", demande.getTypeDossier()),
                      Pair.of("complement", FonctionEnum.U == demande.getFonction() ? demande.getNoeudAlfresco() : StringUtils.defaultString(demande.getComplement(), StringUtils.EMPTY)),
                      Pair.of("description", StringUtils.defaultString(demande.getDescription(), StringUtils.EMPTY)),
                      Pair.of("Type_Affaire", StringUtils.defaultString(demande.getTypeAffaire(), StringUtils.EMPTY)),
                      Pair.of("rgpDate", "false"),
                      Pair.of("dpn", demande.isDpn()));
    }

    static FileSystemResource toJsonFile(final DemandeEnvoiMessageDTO demandeEnvoiMessageDTO) throws IOException {


        return toJson("jsonFile",
                      Pair.of("demandeId", demandeEnvoiMessageDTO.getId()),
                      Pair.of("commentaire", StringUtils.defaultString(demandeEnvoiMessageDTO.getComment(), StringUtils.EMPTY)),
                      Pair.of("dateDemande", UTC_FORMATTER.format(demandeEnvoiMessageDTO.getDate())),
                      Pair.of("destinataires", demandeEnvoiMessageDTO.getMessageDestinataires()
                                                                     .stream()
                                                                     .map(DemandeEnvoiMessageDestinataireDTO::getEmail)
                                                                     .collect(Collectors.toList())),
                      Pair.of("nodeRefs", demandeEnvoiMessageDTO.getFichierMessages()
                                                                .stream()
                                                                .map(FichierDemandeEnvoiMessageDTO::getUri)
                                                                .collect(Collectors.toList())),
                      Pair.of("misc", StringUtils.defaultString(demandeEnvoiMessageDTO.getMisc(), StringUtils.EMPTY)));
    }

    static FileSystemResource toJsonFile(final DescriptArboApi filterArbo) throws IOException {
        return toJson("descriptArbo",
                      Pair.of("fonction", StringUtils.defaultString(filterArbo.getFonction(), StringUtils.EMPTY)),
                      Pair.of("codeUtilisateur", StringUtils.defaultString(filterArbo.getCodeUtilisateur(), StringUtils.EMPTY)),
                      Pair.of("filtreDateMaj", StringUtils.defaultString(filterArbo.getFiltreDateMaj(), StringUtils.EMPTY)),
                      Pair.of("filtreQueDPN", StringUtils.defaultString(filterArbo.getFiltreQueDpn(), StringUtils.EMPTY)),
                      Pair.of("filtreRetour", StringUtils.defaultString(filterArbo.getFiltreRetour(), StringUtils.EMPTY)),
                      Pair.of("filtreService", StringUtils.defaultString(filterArbo.getFiltreService(), StringUtils.EMPTY)),
                      Pair.of("infosTaille", StringUtils.defaultString(Boolean.toString(filterArbo.isInfosTaille()), StringUtils.EMPTY)),
                      Pair.of("avecCorbeille", StringUtils.defaultString(Boolean.toString(filterArbo.isAvecCorbeille()), String.valueOf(false))));
    }

    static FileSystemResource toJsonFile(final DescriptAffApi filterArbo) throws IOException {
        return toJson("descriptAff",
                      Pair.of("fonction", StringUtils.defaultString(filterArbo.getFonction(), StringUtils.EMPTY)),
                      Pair.of("codeUtilisateur", StringUtils.defaultString(filterArbo.getCodeUtilisateur(), StringUtils.EMPTY)),
                      Pair.of("idj", filterArbo.getIdj()),
                      Pair.of("numeroParquet", filterArbo.getNumeroParquet()),
                      Pair.of("typeDossier", filterArbo.getTypeDossier()));
    }

    static ResponseEnvoiDocumentNppDTO toResponseEnvoiDocumentNppDTO(final ClientResponse response) {
        ResponseEnvoiDocumentNppDTO responseNppDTO = Objects.isNull(response) ? null : response.bodyToMono(ResponseEnvoiDocumentNppDTO.class).block();

        if (Objects.isNull(responseNppDTO)) {
            responseNppDTO = new ResponseEnvoiDocumentNppDTO();
            responseNppDTO.setCode(Objects.isNull(response) ? HttpStatus.INTERNAL_SERVER_ERROR.value() : response.rawStatusCode());
        } else if (StringUtils.isNotBlank(responseNppDTO.getTraitementFoncU200())) {
            responseNppDTO.setCode(HttpStatus.OK.value());
            responseNppDTO.setStatut(HttpStatus.OK.getReasonPhrase());
            responseNppDTO.setMessage(responseNppDTO.getTraitementFoncU200());
        } else if (StringUtils.isNotBlank(responseNppDTO.getTraitementFoncU400())) {
            responseNppDTO.setCode(HttpStatus.BAD_REQUEST.value());
            responseNppDTO.setStatut("KO");
            responseNppDTO.setMessage(HttpStatus.BAD_REQUEST.getReasonPhrase());
            responseNppDTO.setCause(responseNppDTO.getTraitementFoncU400());
        }

        return responseNppDTO;
    }

    static ResponseEnvoiDocumentNppDTO toResponseEnvoiDocumentNppDTO(final ConfirmSendingResponse response) {
        ResponseEnvoiDocumentNppDTO responseNppDTO = new ResponseEnvoiDocumentNppDTO();

        if (Objects.isNull(response)) {
            responseNppDTO.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
        } else {
            responseNppDTO.setCause(response.getCauseMessage());
            responseNppDTO.setCode(response.getCodeRetour());
            responseNppDTO.setCodeRetour(response.getCodeRetour());
            responseNppDTO.setDemandeId(response.getIdDemande());
            responseNppDTO.setMessage(response.getMessage());
            responseNppDTO.setStatut(response.getStatus());
        }

        return responseNppDTO;
    }

    static File toZip(final ByteArrayOutputStream zipFilesBaos) throws IOException {
        File file = File.createTempFile("file", ".zip");
        try (FileOutputStream fos = new FileOutputStream(file)) {
            zipFilesBaos.writeTo(fos);
        }

        return file;
    }

    @Data
    static class ConfirmSendingResponse {
        private String  causeMessage;
        private Integer codeRetour;
        private Long    idDemande;
        private String  message;
        private String  status;
    }
}
