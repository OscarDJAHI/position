package fr.gouv.justice.cpn.commun.exception;

public class FoncException extends Exception {

    public FoncException(String message, Throwable cause) {
        super(message, cause);
    }

    public FoncException(String message) {
        super(message);
    }
}
