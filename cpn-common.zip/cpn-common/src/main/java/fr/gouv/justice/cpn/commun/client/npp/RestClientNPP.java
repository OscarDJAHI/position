package fr.gouv.justice.cpn.commun.client.npp;

import fr.gouv.justice.cpn.commun.beans.demande.envoi.npp.AbstractDemandeEnvoiDocumentNppDTO;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.npp.ResponseEnvoiDocumentNppDTO;
import fr.gouv.justice.cpn.commun.exception.NppException;
import fr.gouv.justice.cpn.commun.model.ArborescenceApi;
import fr.gouv.justice.cpn.commun.model.DemandeEnvoiMessageDTO;
import fr.gouv.justice.cpn.commun.model.DescriptAffApi;
import fr.gouv.justice.cpn.commun.model.DescriptArboApi;
import fr.gouv.justice.cpn.commun.model.UpdateEnvoiDTO;
import fr.gouv.justice.cpn.commun.model.descriptAffaire.DescriptAffaireApi;

import java.io.ByteArrayOutputStream;

public interface RestClientNPP {

    ResponseEnvoiDocumentNppDTO confirmSending(final UpdateEnvoiDTO updateEnvoi, final String codeSrj) throws NppException;

    ArborescenceApi getArborecense(final DescriptArboApi filterArbo) throws NppException;

    DescriptAffaireApi getDescriptAffaireNpp(final DescriptAffApi filterArbo, final String codeSrj) throws NppException;

    ResponseEnvoiDocumentNppDTO sendDocumentsToNpp(final AbstractDemandeEnvoiDocumentNppDTO demande, final ByteArrayOutputStream zipOutputStream) throws NppException;

    ResponseEnvoiDocumentNppDTO validateRequest(final DemandeEnvoiMessageDTO message) throws NppException;

}
