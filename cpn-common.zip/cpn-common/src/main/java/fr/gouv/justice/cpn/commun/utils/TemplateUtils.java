package fr.gouv.justice.cpn.commun.utils;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;

import java.util.Locale;
import java.util.Map;

/**
 * Utilitaire qui sert a obtenir un template HTML en utilisant Thymleaf.
 * <p>
 * Une dépendance avec Apache ognl est nécéssaire
 * <dependency>
 * <groupId>ognl</groupId>
 * <artifactId>ognl</artifactId>
 * <version>3.1.12</version>
 * </dependency>
 * <p>
 * see https://github.com/jkuhnert/ognl
 */
public class TemplateUtils {

    private TemplateUtils() {
    }

    public static String getTemplate(String templateName, Map<String, Object> params) {
        ClassLoaderTemplateResolver resolver = new ClassLoaderTemplateResolver();
        resolver.setTemplateMode("HTML");
        resolver.setSuffix(".html");
        TemplateEngine templateEngine = new TemplateEngine();
        templateEngine.setTemplateResolver(resolver);
        final Context context = new Context(Locale.FRANCE);
        params.forEach(context::setVariable);

        return templateEngine.process("templates/" + templateName, context);
    }
}
