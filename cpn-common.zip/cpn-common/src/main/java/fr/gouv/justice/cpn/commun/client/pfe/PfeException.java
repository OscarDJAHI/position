package fr.gouv.justice.cpn.commun.client.pfe;

public class PfeException extends Exception {

	public PfeException() {
	}

	public PfeException(String message) {
		super(message);
	}

	public PfeException(String message, Throwable cause) {
		super(message, cause);
	}

	public PfeException(Throwable cause) {
		super(cause);
	}
}
