package fr.gouv.justice.cpn.commun.exception;

public class NppException extends Exception {

    public NppException() {
    }

	public NppException(Throwable cause) {
		super(cause);
	}

	public NppException(String message) {
        super(message);
    }
}
