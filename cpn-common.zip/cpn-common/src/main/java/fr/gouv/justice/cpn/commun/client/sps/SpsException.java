package fr.gouv.justice.cpn.commun.client.sps;

public class SpsException extends Exception {

    public SpsException() {
    }

    public SpsException(String message) {
        super(message);
    }

    public SpsException(String message, Throwable cause) {
        super(message, cause);
    }
}
