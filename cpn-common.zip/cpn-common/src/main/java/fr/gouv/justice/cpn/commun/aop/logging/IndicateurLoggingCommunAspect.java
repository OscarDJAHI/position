package fr.gouv.justice.cpn.commun.aop.logging;

import fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn.DemandeEnvoiDocumentBpnDTO;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn.NodeDto;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.npp.ContextDemande;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.npp.DemandeEnvoiDocumentNppDTO;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.npp.ResponseEnvoiDocumentNppDTO;
import fr.gouv.justice.cpn.commun.exception.NppException;
import fr.gouv.justice.cpn.commun.indicateur.IndicateurAspect;
import lombok.CustomLog;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.List;

@Aspect
@Component
@CustomLog
public class IndicateurLoggingCommunAspect extends IndicateurAspect {


    @Pointcut("execution(* fr.gouv.justice.cpn.commun.client.npp.impl.RestClientNPPImpl.sendDocumentsToNpp(..)) && args(demande, zipOutputStream)")
    public void cutSendToNpp(DemandeEnvoiDocumentNppDTO demande, ByteArrayOutputStream zipOutputStream) {
    }

    @Pointcut("execution(* " +
                      "fr.gouv.justice.cpn.commun.client.bpn.impl.RestClientBpnImpl.uploadFilesIntoPochette(..)) " +
                      "&& args(demande, files)")
    public void cutUploadFilesIntoPochette(final DemandeEnvoiDocumentBpnDTO demande, List<File> files) {
        /* pointcut */
    }

    @Around("cutSendToNpp(demande, zipOutputStream)")
    public ResponseEnvoiDocumentNppDTO doLogSendTONpp(ProceedingJoinPoint pjp, DemandeEnvoiDocumentNppDTO demande, ByteArrayOutputStream zipOutputStream) throws NppException {
        try {
            ResponseEnvoiDocumentNppDTO response = (ResponseEnvoiDocumentNppDTO) pjp.proceed();
            logByContext(demande);
            return response;
        } catch (Throwable throwable) {
            log.error("DownloadFile in NPP failed, no indicator will be log. {}", ExceptionUtils.getMessage(throwable));
            throw new NppException(throwable.getMessage());
        }
    }


    @Around("cutUploadFilesIntoPochette(demande, files)")
    public List<NodeDto> aroundCutUploadFileIntoPochette(ProceedingJoinPoint pjp,
                                                         final DemandeEnvoiDocumentBpnDTO demande, List<File> files)
            throws Throwable {
        @SuppressWarnings("unchecked")
        List<NodeDto> nodes = (List<NodeDto>) pjp.proceed();
        logCpn14(demande);
        return nodes;
    }




    private void logByContext(DemandeEnvoiDocumentNppDTO demande) {
        try {
            if (ContextDemande.DL_DOC == demande.getContextDemande()) {
                logCpn14(demande);
            }

            if (ContextDemande.DL_AR == demande.getContextDemande()) {
                logCpn16(demande);
            }
        } catch (Exception e) {
            log.error("Aucun context trouvé, aucun indicateur log ne sera fait.");
        }
    }

}
