package fr.gouv.justice.cpn.commun.client.bpn.impl;

import fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn.DemandeEnvoiArBpnDTO;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn.DemandeEnvoiDocumentBpnDTO;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn.NodeDto;
import fr.gouv.justice.cpn.commun.client.bpn.BpnException;
import fr.gouv.justice.cpn.commun.client.bpn.RestClientBpn;
import fr.gouv.justice.cpn.commun.client.common.AbstractWebClient;
import fr.gouv.justice.cpn.commun.exception.FoncException;
import fr.gouv.justice.cpn.commun.exception.TechException;
import fr.gouv.justice.cpn.commun.security.jwt.TokenProviderCommun;
import fr.gouv.justice.cpn.commun.utils.JsonUtils;
import lombok.CustomLog;
import lombok.RequiredArgsConstructor;
import org.apache.tika.Tika;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.data.util.Pair;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

// TODO : Refactore to use webclient to upload files into BPN + use BPNDocument POJO like SPS
@Component
@RequiredArgsConstructor
@CustomLog
public class RestClientBpnImpl extends AbstractWebClient implements RestClientBpn {

    private static final String BEARER                 = "Bearer ";
    private static final String ERREUR_BPN_CODE_RETOUR = "Erreur BPN code retour ";
    private static final String MESSAGE                = " message ";

    private final TokenProviderCommun tokenProvider;

    @Value("${bpn.base_url:changeme}")
    private String baseUrl;

    @Value("${bpn.resource.documents.path:/api/v1/ged/documents}")
    private String documentDownloadResource;

    @Override
    public ByteArrayOutputStream downloadDocuments(final List<String> ids, final String userId) throws BpnException, FoncException, TechException {
        final ClientResponse response = this.callBpn(this.get(),
                                                     this.documentDownloadResource,
                                                     userId,
                                                     Pair.of("documentIds", String.join(",", ids)));

        return this.outputStream(response);
    }

    @Override
    public void sendArToBpn(final DemandeEnvoiArBpnDTO demande, final File file) throws TechException {
        try {
            ResponseEntity<List<NodeDto>> response = initHttpParamsAndCall(demande.getUserMail(), demande.getCodeSrj(), demande.getIdLdap(), demande.getIdNoeud(), List.of(file));
            log.info("Reponse du webservice 'uploadARIntoPochette' vers BPN-MAS : {}", response.getStatusCodeValue());
        } catch (IOException e) {
            throw new TechException(String.format("Sorry ! Something went wrong when trying to guess mime type of the file : %s", file), e);
        } catch (RestClientException e) {
            throw new TechException("A problem occured while trying to upload AR into BPN.", e);
        }
    }

    @Override
    public List<NodeDto> uploadFilesIntoPochette(DemandeEnvoiDocumentBpnDTO demande, List<File> files) throws IOException, BpnException {
        ResponseEntity<List<NodeDto>> response = initHttpParamsAndCall(demande.getUserMail(), demande.getCodeSrj(), demande.getIdLdap(), demande.getIdNoeud(), files);

        log.info("Reponse du webservice 'uploadFileIntoPochette' vers BPN-MAS : {}", response.getStatusCodeValue());

        if (response.getStatusCodeValue() > 299) {
            throw new BpnException("A problem occurred while trying to upload files into bpn. ResponseCode : " + response.getStatusCodeValue());
        }

        return response.getBody();
    }

    @Override
    protected String getBaseUrl() {
        return this.baseUrl;
    }

    @SafeVarargs
    private ClientResponse callBpn(final WebClient.RequestHeadersUriSpec<?> method, final String path, final String user, final Pair<String, String>... params) throws BpnException,
                                                                                                                                                                       FoncException,
                                                                                                                                                                       TechException {
        final WebClient.RequestHeadersSpec<?> request = method.uri(uriBuilder -> uriBuilder.path(path)
                                                                                           .queryParams(new LinkedMultiValueMap<>(Arrays.stream(params)
                                                                                                                                        .collect(Collectors.toMap(Pair::getFirst,
                                                                                                                                                                  s -> List.of(s.getSecond())))))
                                                                                           .build())
                                                              .header(HttpHeaders.AUTHORIZATION, BEARER + this.token(user));
        return this.callBpn(request);
    }

    @Retryable(value = BpnException.class, maxAttemptsExpression = "${bpn.retry.max-attempts:1}",
               backoff = @Backoff(delayExpression = "${bpn.retry.delay:1000}"))
    private ClientResponse callBpn(final WebClient.RequestHeadersSpec<?> request) throws BpnException, FoncException, TechException {
        try {
            final ClientResponse response = request.exchange().block();

            Objects.requireNonNull(response, "Sorry ! Something went wrong when trying to upload a document into BPN");

            if (!response.statusCode().is2xxSuccessful()) {
                throw new HttpServerErrorException(response.statusCode());
            }

            return response;
        } catch (HttpStatusCodeException httpStatusCodeException) {
            log.error("Sorry ! Something went wrong when trying to call BPN", httpStatusCodeException);

            if (HttpStatus.BAD_REQUEST == (httpStatusCodeException.getStatusCode())) {
                throw new FoncException(ERREUR_BPN_CODE_RETOUR + httpStatusCodeException.getStatusCode().value() + MESSAGE + httpStatusCodeException.getMessage(), httpStatusCodeException);
            }

            throw new BpnException(ERREUR_BPN_CODE_RETOUR + httpStatusCodeException.getStatusCode().value() + MESSAGE + httpStatusCodeException.getMessage() + httpStatusCodeException);
        } catch (Exception exception) {
            log.error("Sorry ! Something went wrong when trying to call BPN", exception);
            throw new TechException("Sorry ! Something went wrong when trying to call BPN", exception);
        }
    }

    private String createTokenFromMail(String userId, String codeSrj, String idLdap) {
        Map<String, Object> mapData = new HashMap<>();
        mapData.put("logonId", userId);
        mapData.put("mail", userId);
        mapData.put("roles", Arrays.asList("USER_TECH", "PPN:USER"));
        mapData.put("droits", new String[]{"PPN:USER"});
        mapData.put("idJuridiction", codeSrj);
        mapData.put("idsJuridictions", new String[]{codeSrj});
        mapData.put("igcid", idLdap);

        return tokenProvider.creationTokenFromMap(mapData);
    }

    // TODO : Use the webclient instead of RestTemplate
    private ResponseEntity<List<NodeDto>> initHttpParamsAndCall(String userMail, String codeSrj, String idLdap, String idNoeud, List<File> files) throws IOException {
        LinkedMultiValueMap<String, Object> map = new LinkedMultiValueMap<>();

        File   dummyFileForBpn = files.get(0);
        String mimeType        = new Tika().detect(dummyFileForBpn);

        files.forEach(f -> map.add("files[]", new FileSystemResource(f)));
        map.add("name", dummyFileForBpn.getName());
        map.add("type", mimeType);
        map.add("docMetadata", JsonUtils.JSON_MAPPER.writeValueAsString(Collections.singletonMap("traitement_doc", "ocr")));

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.set(HttpHeaders.AUTHORIZATION, BEARER + createTokenFromMail(userMail, codeSrj, idLdap));

        HttpEntity<LinkedMultiValueMap<String, Object>> request = new HttpEntity<>(map, headers);

        return new RestTemplate().exchange(baseUrl + "/api/upload/" + idNoeud,
                                           HttpMethod.POST,
                                           request,
                                           new ParameterizedTypeReference<>() {
                                           });
    }

    private ByteArrayOutputStream outputStream(final ClientResponse response) throws BpnException {
        final Flux<DataBuffer> dataStream = response.bodyToFlux(DataBuffer.class);

        try (final ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            DataBufferUtils.write(dataStream, outputStream)
                           .map(DataBufferUtils::release)
                           .then()
                           .block();

            return outputStream;
        } catch (Exception exception) {
            throw new BpnException("Sorry ! Something went wrong when trying to extract the downloaded document from BPN response. " + exception);
        }
    }

    private String token(final String userId) {
        final Map<String, Object> data = new HashMap<>();
        data.put("logonId", userId);
        data.put("mail", userId);
        data.put("igcid", userId);
        data.put("roles", List.of("USER_TECH", "PPN:USER"));
        data.put("droits", new String[]{"PPN:USER"});

        return this.tokenProvider.creationTokenFromMap(data);
    }
}
