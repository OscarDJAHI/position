package fr.gouv.justice.cpn.commun.domain;

import fr.gouv.justice.cpn.commun.model.enumeration.Fonction;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
abstract class AbstractDemandeEnvoiDocumentNpp extends AbstractEntity {

    @Column
    private String origine;

    @Column
    @Enumerated(EnumType.STRING)
    private Fonction fonction;

    @Column
    private String codeSrj;

    @Column
    private String affaire;

    @Column
    private String service;

    @Column
    private String sservice;

    @Column
    private String noeudService;

    /**
     * IDJ or APPI ... etc
     */
    @Column
    private String codeDossier;

    @Column
    private String typeDossier;

    @Column
    private String complement;
}
