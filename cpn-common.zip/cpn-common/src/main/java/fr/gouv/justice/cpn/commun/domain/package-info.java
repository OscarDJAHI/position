/**
 * JPA domain objects.
 */
package fr.gouv.justice.cpn.commun.domain;
