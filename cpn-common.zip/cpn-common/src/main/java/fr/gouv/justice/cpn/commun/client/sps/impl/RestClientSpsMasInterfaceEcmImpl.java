package fr.gouv.justice.cpn.commun.client.sps.impl;

import fr.gouv.justice.cpn.commun.client.common.AbstractWebClient;
import fr.gouv.justice.cpn.commun.client.sps.RestClientSpsMasInterfaceEcm;
import fr.gouv.justice.cpn.commun.client.sps.SpsException;
import fr.gouv.justice.cpn.commun.client.sps.SpsKeyMap;
import fr.gouv.justice.cpn.commun.exception.FoncException;
import fr.gouv.justice.cpn.commun.exception.TechException;
import fr.gouv.justice.cpn.commun.security.jwt.TokenProviderCommun;
import lombok.CustomLog;
import lombok.RequiredArgsConstructor;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.data.util.Pair;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@EnableRetry
@RequiredArgsConstructor
@CustomLog
public class RestClientSpsMasInterfaceEcmImpl extends AbstractWebClient implements RestClientSpsMasInterfaceEcm {

	private static final String BEARER                 = "Bearer ";
	private static final String MESSAGE                = " message ";
	private static final String ERREUR_SPS_CODE_RETOUR = "Erreur SPS code retour ";

	private final TokenProviderCommun tokenProvider;

	@Value("${sps.interface-ecm.base-url:changeme}")
	private String baseUrl;
	@Value("${sps.interface-ecm.resource.documents.path:/v2/interface-ecm/documents}")
	private String documentResource;
	@Value("${sps.interface-ecm.resource.procedures.path:/v2/interface-ecm/procedures}")
	private String procedureResource;

	@Override
	public String deleteDocument(final DocumentSPS document, final String userId) throws SpsException, FoncException, TechException {
		final ClientResponse response = this.callSps(this.delete(),
		                                             this.documentResource + "/" + document.getId(),
		                                             userId,
		                                             Pair.of("EtatRechercheDPN", document.getStatus().name()));

		final String responseBody = response.bodyToMono(String.class).block();
		log.debug("SPS response for : Document deletion : {}", responseBody);

		return responseBody;
	}

	/**
	 * Download a document, in its original format, by its technical id
	 */
	@Override
	public ByteArrayOutputStream downloadDocument(final String documentId, final String userId) throws SpsException, FoncException, TechException {
		final ClientResponse response = this.callSps(this.get(),
		                                             this.documentResource + "/idTechnique/" + documentId,
		                                             userId);

		return this.outputStream(response);
	}

	/**
	 * Download a ZIP of the given documents (even if there is only one document)
	 * N.B : in SPS when an exception is thrown while generating the ZIP; an empty ZIP is sent back.
	 */
	@Override
	public ByteArrayOutputStream downloadDocuments(final List<String> ids, final String userId) throws SpsException, FoncException, TechException {
		final ClientResponse response = this.callSps(this.get(),
		                                             this.documentResource + "/idsTechniques",
		                                             userId,
		                                             Pair.of("idTechnique", String.join(",", ids)));

		return this.outputStream(response);
	}

	@Override
	public String updateDocument(final DocumentSPS document, final String userId) throws SpsException, FoncException, TechException {
		final String response = this.callSps(document.getId(), this.put(), document, userId);
		log.debug("SPS response for : Document update : {}", response);

		return response;
	}

	@Override
	public String updateDocumentStatus(final DocumentSPS document, final String userId) throws SpsException, FoncException, TechException {
		final ClientResponse response = this.callSps(this.put(),
		                                             this.documentResource + "/etat/" + document.getId(),
		                                             userId,
		                                             Pair.of("etatPieceProcedureFinal", document.getStatus().name()),
		                                             Pair.of("idNoeudNPP", document.getNppId()));

		final String responseBody = response.bodyToMono(String.class).block();
		log.debug("SPS response for : Document status update : {}", responseBody);

		return responseBody;
	}

	@Override
	public List<String> updateIdj(final String idJustice, final String noProcedureFormate, final String noParquet, final String nomJuridiction, final String userId) throws SpsException,
	                                                                                                                                                                        FoncException,
	                                                                                                                                                                        TechException {
		final ClientResponse response = this.callSps(this.put(),
		                                             this.procedureResource + "/procedure/updateIdj",
		                                             userId,
		                                             Pair.of("IDJ", idJustice),
		                                             Pair.of("NoProcedureFormate", noProcedureFormate),
		                                             Pair.of("nomJuridiction", nomJuridiction),
		                                             Pair.of("NoParquet", noParquet));

		final List<String> responseBody = response.bodyToFlux(String.class)
		                                          .collectList()
		                                          .block();
		log.debug("SPS response for : IDJ update : {}", responseBody);

		return responseBody;
	}

	@Override
	public String uploadDocument(final DocumentSPS document, final String userId) throws SpsException, FoncException, TechException {
		final String response = this.callSps(document.getJuridiction(), this.post(), document, userId);
		log.debug("SPS response for : Document upload : {}", response);

		return response;
	}

	@Override
	protected String getBaseUrl() {
		return this.baseUrl;
	}

	@SafeVarargs
	private ClientResponse callSps(final WebClient.RequestHeadersUriSpec<?> method, final String path, final String user, final Pair<String, String>... params) throws SpsException,
	                                                                                                                                                                   FoncException,
	                                                                                                                                                                   TechException {
		final WebClient.RequestHeadersSpec<?> request = method.uri(uriBuilder -> uriBuilder.path(path)
		                                                                                   .queryParams(new LinkedMultiValueMap<>(Arrays.stream(params)
		                                                                                                                                .collect(Collectors.toMap(Pair::getFirst,
		                                                                                                                                                          s -> List.of(s.getSecond())))))
		                                                                                   .build())
		                                                      .header(HttpHeaders.AUTHORIZATION, BEARER + this.token(user));

		return this.callSps(request);
	}

	@Retryable(value = SpsException.class, maxAttemptsExpression = "${sps.interface-ecm.retry.max-attempts:3}",
	           backoff = @Backoff(delayExpression = "${sps.interface-ecm.retry.delay:1000}"))
	private ClientResponse callSps(final WebClient.RequestHeadersSpec<?> request) throws SpsException, FoncException, TechException {
		try {
			final ClientResponse response = request.exchange().block();

			Objects.requireNonNull(response, "Sorry ! Something went wrong when trying to upload a document into SPS");

			if (!response.statusCode().is2xxSuccessful()) {
				throw new HttpServerErrorException(response.statusCode());
			}

			return response;
		} catch (HttpStatusCodeException httpStatusCodeException) {
			log.error("Sorry ! Something went wrong when Thread [{}] was trying to call SPS", Thread.currentThread().getName(), httpStatusCodeException);

			if (HttpStatus.BAD_REQUEST == (httpStatusCodeException.getStatusCode())) {
				throw new FoncException(ERREUR_SPS_CODE_RETOUR + httpStatusCodeException.getStatusCode().value() + MESSAGE + httpStatusCodeException.getMessage(), httpStatusCodeException);
			}

			throw new SpsException(ERREUR_SPS_CODE_RETOUR + httpStatusCodeException.getStatusCode().value() + MESSAGE + httpStatusCodeException.getMessage(), httpStatusCodeException);
		} catch (Exception exception) {
			log.error("Sorry ! Something went wrong when Thread [{}] was trying to call SPS", Thread.currentThread().getName(), exception);

			throw new TechException("Sorry ! Something went wrong when trying to call SPS", exception);
		}
	}

	private String callSps(final String path, final WebClient.RequestBodyUriSpec method, final DocumentSPS document, final String user) throws SpsException, FoncException, TechException {
		final MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
		body.add("file", new FileSystemResource(document.getFile()));
		body.add("mapMetadata", metadata(document));

		final WebClient.RequestHeadersSpec<?> request = method.uri(this.documentResource + "/" + path)
		                                                      .header(HttpHeaders.AUTHORIZATION, BEARER + this.token(user))
		                                                      .header(HttpHeaders.CONTENT_TYPE, MediaType.MULTIPART_FORM_DATA_VALUE)
		                                                      .body(BodyInserters.fromMultipartData(body));

		return this.callSps(request).bodyToMono(String.class).block();
	}

	private Map<String, String> metadata(final DocumentSPS document) {
		final Map<SpsKeyMap, String> mapOfCommonMetadata = SpsKeyMap.mapOfNonEmpty(SpsKeyMap.entryOf(SpsKeyMap.NOM_JURIDICTION, document.getJuridiction()),
		                                                                           SpsKeyMap.entryOf(SpsKeyMap.TYPE_ID_DPN,
		                                                                                             Objects.isNull(document.getTypeDossier()) ? null : document.getTypeDossier().name()),
		                                                                           SpsKeyMap.entryOf(SpsKeyMap.VALEUR_ID_DPN, document.getCodeDossier()),
		                                                                           SpsKeyMap.entryOf(SpsKeyMap.TYPE_DOSSIER, "PP"),
		                                                                           SpsKeyMap.entryOf(SpsKeyMap.NOM_FICHIER,
		                                                                                             Objects.isNull(document.getFile()) ? null
		                                                                                                                                : FilenameUtils.getBaseName(document.getFile().getName())),
		                                                                           SpsKeyMap.entryOf(SpsKeyMap.TYPE_FICHIER, StringUtils.isEmpty(document.getType()) ? "P" : document.getType()),
		                                                                           SpsKeyMap.entryOf(SpsKeyMap.ETAT_FICHIER,
		                                                                                             Objects.isNull(document.getStatus()) ? null : document.getStatus().name()));

		return SpsKeyMap.mergeOfNonEmpty(mapOfCommonMetadata, document.getProperties());
	}

	private ByteArrayOutputStream outputStream(final ClientResponse response) throws SpsException {
		final Flux<DataBuffer> dataStream = response.bodyToFlux(DataBuffer.class);

		try (final ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
			DataBufferUtils.write(dataStream, outputStream)
			               .map(DataBufferUtils::release)
			               .then()
			               .block();

			return outputStream;
		} catch (Exception exception) {
			throw new SpsException("Sorry ! Something went wrong when trying to extract the downloaded document from SPS response.", exception);
		}
	}

	private String token(final String userId) {
		final Map<String, Object> data = new HashMap<>();
		data.put("logonId", userId);
		data.put("mail", userId);
		data.put("igcid", userId);
		data.put("roles", List.of("USER_TECH", "PPN:USER"));
		data.put("droits", new String[]{"PPN:USER"});

		return this.tokenProvider.creationTokenFromMap(data);
	}
}
