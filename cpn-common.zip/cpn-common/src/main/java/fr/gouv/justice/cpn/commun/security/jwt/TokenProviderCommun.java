package fr.gouv.justice.cpn.commun.security.jwt;

import com.nimbusds.jose.EncryptionMethod;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWEAlgorithm;
import com.nimbusds.jose.JWEHeader;
import com.nimbusds.jose.JWEObject;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.KeyLengthException;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.DirectDecrypter;
import com.nimbusds.jose.crypto.DirectEncrypter;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jose.crypto.MACVerifier;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import lombok.CustomLog;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.DatatypeConverter;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@CustomLog
public class TokenProviderCommun {

    private static final String SECRET_KEY        = "4siltUsBQ+PP9A1OKD/LrA==";
    private static final String DVG_TOKEN         = "dvg";
    private static final String DROITS_HEADER     = "droits";
    private static final String LOGON_ID          = "logonId";
    private static final String IGCID             = "igcId";
    private static final String MAIL              = "mail";
    private static final String ROLE_HANDSHAKE    = "ROLE_HANDSHAKE";
    private static final String SUBJECT_HANDSHAKE = "Handshake";
    private static final String ROLE_CLAIMNAME    = "roles";

    private static final int  SIZE_BUFFER       = 50;
    private static final long ONE_MIN_IN_MILLIS = 60000L;

    private final SecureRandom secureRandom = new SecureRandom();

    private String issuer;

    @Value("${jwt.security.key}")
    private String b64SigningKey;

    @Value("${jwt.security.dureeValiditeToken}")
    private Long dureeValiditeToken;

    @Value("${jwt.security.dureeRenouvellementToken}")
    private Long dureeRenouvellementToken;

    @Value("${jwt.security.dureeValiditeGlobale}")
    private Long dureeValiditeGlobale;

    public TokenProviderCommun() {
        try {
            this.issuer = InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            log.warn("Pas de hostname trouvRetour au issuer par d: \"auth-server\"");
            this.issuer = "auth-server";
        }
    }

    public String createToken(Authentication authentication, boolean rememberMe) {
        String authorities = authentication.getAuthorities().stream()
                                           .map(GrantedAuthority::getAuthority)
                                           .collect(Collectors.joining(","));
        Map<String, Object> mapData = new HashMap<>();
        mapData.put(LOGON_ID, authentication.getName());
        return creationTokenFromMap(mapData);
    }

    public String createTokenFromMail(String email) {
        Map<String, Object> mapData = new HashMap<>();
        mapData.put(LOGON_ID, email);
        mapData.put(MAIL, email);
        return creationTokenFromMap(mapData);
    }

    public String creationTokenFromMap(Map<String, Object> mapData) {

        JWTClaimsSet.Builder claimsSetBuilder = getClaimSetBuilder(dureeValiditeToken, dureeValiditeGlobale, this.issuer);
        if (mapData.containsKey(LOGON_ID)) {
            claimsSetBuilder.subject((String) mapData.get(LOGON_ID));
        } else if (mapData.containsKey(IGCID)) {
            claimsSetBuilder.subject((String) mapData.get(IGCID));
        }
        mapData.keySet().forEach(cle -> claimsSetBuilder.claim(cle, mapData.get(cle)));
        log.debug("Forge d'un nouveau JWT pour le profil {}", mapData.get(DROITS_HEADER));
        return creationToken(claimsSetBuilder.build());
    }

    /**
     * @deprecated We dont need this Method because ...
     */
    @Deprecated(since = "6.3.0")
    public String creationTokenFromMapWithoutLogon(Map<String, Object> mapData) {
        JWTClaimsSet.Builder claimsSetBuilder = getClaimSetBuilder(dureeValiditeToken, dureeValiditeGlobale, this.issuer);
        mapData.keySet().forEach(cle -> claimsSetBuilder.claim(cle, mapData.get(cle)));
        log.debug("Forge d'un nouveau JWT pour le profil {}", mapData.get(DROITS_HEADER));
        return creationToken(claimsSetBuilder.build());
    }

    public String generateCSRFToken() {
        byte[] buffer = new byte[SIZE_BUFFER];
        this.secureRandom.nextBytes(buffer);
        return DatatypeConverter.printHexBinary(buffer);
    }

    public Authentication getAuthentication(String jwt) {
        JWTClaimsSet claims      = jwtStringToJWTClaim(jwt);
        String       userSubject = claims.getSubject();
        if (claims.getClaim(MAIL) != null) {
            userSubject = (String) claims.getClaim(MAIL);
        }

        Collection<? extends GrantedAuthority> authorities = getGrantedAuthorities(claims);

        User principal = new User(userSubject, "", authorities);

        return new UsernamePasswordAuthenticationToken(principal, jwt, authorities);
    }

    public String getHandshakeToken() {
        return getTokenCustom(SUBJECT_HANDSHAKE, ROLE_HANDSHAKE);
    }

    public JWTClaimsSet jwtStringToJWTClaim(String pJwtString) throws RuntimeException {
        try {
            JWEObject jweObject = JWEObject.parse(pJwtString);
            jweObject.decrypt(new DirectDecrypter(Base64.getDecoder().decode(SECRET_KEY)));
            SignedJWT    signedJwt = jweObject.getPayload().toSignedJWT();
            JWTClaimsSet claimsSet = signedJwt.getJWTClaimsSet();

            if (log.isDebugEnabled()) {
                claimsSet.getClaims().forEach((claimName, value) -> log.debug("claimName : {}\t\t|\tvalue : {}", claimName, value));
            }
            return claimsSet;
        } catch (Exception e) {
            log.error("Erreur lors du parse du JWT.", e);
            throw new RuntimeException(e.getMessage());
        }
    }

    public boolean needRefresh(String pJwtString) {
        try {
            JWTClaimsSet claimsSet           = jwtStringToJWTClaim(pJwtString);
            Date         dateexpiration      = claimsSet.getExpirationTime();
            long         expiration          = dateexpiration.getTime();
            long         ldureeValiditeToken = ONE_MIN_IN_MILLIS * dureeRenouvellementToken;
            long         now                 = (new Date()).getTime();
            return (expiration - now <= ldureeValiditeToken);
        } catch (IllegalArgumentException e) {
            log.warn("mauvaise duree renouvellement.");
            if (log.isDebugEnabled()) {
                log.debug("mauvaise duree renouvellement: {}", e.getMessage());
            }
            return false;
        }
    }

    public String recuperationToken(HttpServletRequest pHttpRequest) {
        String bearerToken = pHttpRequest.getHeader("Authorization-Application");
        if (log.isDebugEnabled()) {
            log.debug("contenu du header \"authorization\" : {}", bearerToken);
        }
        if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
            log.debug("JWT prdans le header http");
            String jwtString = bearerToken.substring(7);
            log.debug("token r: {}", jwtString);
            return jwtString;
        }
        log.debug("Pas de JWT prdans le header http");
        return null;
    }

    public String refreshToken(String pJwtString) {
        log.debug("Renouvellement du JWT");
        JWTClaimsSet         claimsSet        = jwtStringToJWTClaim(pJwtString);
        long                 nowMillis        = System.currentTimeMillis();
        long                 expMillis        = nowMillis + ONE_MIN_IN_MILLIS * dureeValiditeToken;
        JWTClaimsSet.Builder claimsSetBuilder = (new JWTClaimsSet.Builder(claimsSet)).expirationTime(new Date(expMillis));
        JWTClaimsSet         newClaimsSet     = claimsSetBuilder.build();
        log.debug("build claimset");
        return creationToken(newClaimsSet);
    }

    public boolean validateToken(String pJwtString) {

        try {
            JWEObject jweObject = JWEObject.parse(pJwtString);
            jweObject.decrypt(new DirectDecrypter(Base64.getDecoder().decode(SECRET_KEY)));
            SignedJWT signedJwt      = jweObject.getPayload().toSignedJWT();
            boolean   signedVerified = signedJwt.verify(new MACVerifier(Base64.getDecoder().decode(this.b64SigningKey)));
            log.debug(signedVerified ? "Le JWT est valide" : "Le JWT est non valide");
            JWTClaimsSet claimsSet              = signedJwt.getJWTClaimsSet();
            String       stringDVG              = claimsSet.getStringClaim(DVG_TOKEN);
            long         dateFinValiditeGlobale = Long.parseLong(stringDVG);
            long         now                    = (new Date()).getTime();
            boolean      experded               = dateFinValiditeGlobale < now;
            log.warn(experded ? "" : "Le JWT est actif pour une dursupla durmaximale");
            return !experded && signedVerified;

        } catch (Exception e) {
            log.error("Erreur lors de la validation du JWT.", e);
            return false;
        }
    }

    private String creationToken(JWTClaimsSet pClaimsSet) {
        try {
            SecretKey signingKey = new SecretKeySpec(Base64.getDecoder().decode(this.b64SigningKey), "AES");
            if (log.isDebugEnabled()) {
                log.debug("SECRET_KEY.string : {}", SECRET_KEY);
                log.debug("SECRET_KEY.getEncoded : {}", Base64.getDecoder().decode(SECRET_KEY));
                log.debug("signingKey.string : {}", this.b64SigningKey);
                log.debug("signingKey.getEncoded : {}", signingKey.getEncoded());
                pClaimsSet.getClaims().forEach((claimName, value) -> log.debug("claimName : {}\t|\tvalue : {}", claimName, value));
            }
            MACSigner mACSigner = new MACSigner(signingKey.getEncoded());
            SignedJWT signedJwt = new SignedJWT(new JWSHeader(JWSAlgorithm.HS512), pClaimsSet);
            if (log.isDebugEnabled()) {
                log.debug("build JWT");
            }
            signedJwt.sign(mACSigner);
            if (log.isDebugEnabled()) {
                log.debug("signature du JWT");
            }
            JWEObject jweObject = new JWEObject((new JWEHeader.Builder(JWEAlgorithm.DIR, EncryptionMethod.A128GCM)).contentType("JWT").build(), new Payload(signedJwt));
            if (log.isDebugEnabled()) {
                log.debug("creation JWE");
            }
            jweObject.encrypt(new DirectEncrypter(Base64.getDecoder().decode(SECRET_KEY)));
            if (log.isDebugEnabled()) {
                log.debug("JWT encryption");
            }
            String jweRetour = jweObject.serialize();
            log.debug("JWT forg: {}", jweRetour);
            return jweRetour;
        } catch (KeyLengthException e) {
            log.warn("echec de crdu JWT, \"KeyLengthException\". Erreur : {}", e.getMessage());
            return null;
        } catch (JOSEException e) {
            log.warn("echec de crdu JWT, \"JOSEException\". Erreur : {}", e.getMessage());
            return null;
        }
    }

    private JWTClaimsSet.Builder getClaimSetBuilder(long dureeValidite, long dureeValiditeGlobale, String issuer) {
        long   nowMillis     = System.currentTimeMillis();
        long   expMillis     = nowMillis + ONE_MIN_IN_MILLIS * dureeValidite;
        String globaleMillis = Long.toString(nowMillis + ONE_MIN_IN_MILLIS * dureeValiditeGlobale);
        return (new JWTClaimsSet.Builder()).issuer(issuer).issueTime(new Date(nowMillis))
                                           .expirationTime(new Date(expMillis)).claim(DVG_TOKEN, globaleMillis);
    }

    private Collection<? extends GrantedAuthority> getGrantedAuthorities(JWTClaimsSet claims) {

        if (claims.getClaims() != null && claims.getClaims().values() != null) {
            return claims.getClaims().values().stream().map(Object::toString)
                         .map(SimpleGrantedAuthority::new)
                         .collect(Collectors.toList());
        }

        return Collections.emptyList();
    }

    private String getTokenCustom(String pSubject, String pRole) {
        long                 nowMillis        = System.currentTimeMillis();
        long                 expMillis        = nowMillis + ONE_MIN_IN_MILLIS * dureeValiditeToken;
        String               globaleMillis    = Long.toString(nowMillis + ONE_MIN_IN_MILLIS * dureeValiditeGlobale);
        JWTClaimsSet.Builder claimsSetBuilder = new JWTClaimsSet.Builder();
        JWTClaimsSet claimsSet = claimsSetBuilder.issuer(this.issuer)
                                                 .issueTime(new Date(nowMillis))
                                                 .expirationTime(new Date(expMillis))
                                                 .subject(pSubject)
                                                 .claim(ROLE_CLAIMNAME, Arrays.asList(pRole))
                                                 .claim(DVG_TOKEN, globaleMillis)
                                                 .build();
        return creationToken(claimsSet);
    }
}
