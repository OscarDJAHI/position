package fr.gouv.justice.cpn.commun.indicateur;

public enum IndicateurId {
    CPN02,
    CPN03,
    CPN04,
    CPN05,
    CPN06,
    CPN07,
    CPN08,
    CPN11,
    CPN12,
    CPN13,
    CPN14,
    CPN16,
    CPN21,
    CPN25,
    CPN40,
    CPN41,
    CPN42,
    CPN43,
    CPN44,
    CPN45,
    CPN46,
    CPN47,
    CPN48,
    CPN49,
    CPN50
}
