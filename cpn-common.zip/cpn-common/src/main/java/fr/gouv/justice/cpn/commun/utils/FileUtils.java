package fr.gouv.justice.cpn.commun.utils;

import fr.gouv.justice.cpn.commun.exception.TechException;
import org.springframework.util.FileSystemUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class FileUtils {

    private FileUtils() {
    }

    public static void delete(final Path filePath) throws TechException {
        try {
            Files.delete(filePath);
        } catch (Exception e) {
            throw new TechException(MessageFormat.format("Could not delete the file {0} :", filePath), e);
        }
    }

    public static void deleteRecursively(final Path filePath) throws TechException {
        try {
            if (!FileSystemUtils.deleteRecursively(filePath)) {
                throw new Exception();
            }
        } catch (Exception e) {
            throw new TechException(MessageFormat.format("Could not deleteRecursively the Directory {0} :", filePath), e);
        }
    }

    public static File getFile(final ByteArrayOutputStream baos, final String filename) throws IOException {
        File file = new File(org.apache.commons.io.FileUtils.getTempDirectory(), filename);
        try (FileOutputStream fos = new FileOutputStream(file)) {
            baos.writeTo(fos);
        }

        return file;
    }

    public static void mkdirs(final String... folders) {
        if (Objects.isNull(folders) || folders.length == 0) {
            return;
        }

        Arrays.stream(folders).forEach(folder -> {
            File folderToCreate = new File(folder);
            if (!folderToCreate.exists()) {
                folderToCreate.mkdirs();
            }
        });
    }

    public static ByteArrayOutputStream toByteArrayOutputStream(final List<String> fileUri) throws Exception {
        try (ByteArrayOutputStream fileDataStream = new ByteArrayOutputStream()) {
            for (String f : fileUri) {
                byte[] fileByte = Files.readAllBytes(Paths.get(f));
                fileDataStream.write(fileByte);
            }

            return fileDataStream;
        }
    }

    public static ByteArrayOutputStream toByteArrayOutputStream(final File file) throws TechException {
        try (final FileInputStream fileInputStream = new FileInputStream(file);
             final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream()) {
            byte[] arr = new byte[(int) file.length()];
            fileInputStream.read(arr);

            byteArrayOutputStream.write(arr);

            return byteArrayOutputStream;
        } catch (Exception exception) {
            throw new TechException(exception);
        }
    }

    public static void upload(final File file, final Path destination) throws TechException {
        if (Objects.isNull(file)) {
            throw new TechException("Sorry ! The file to upload can not be null.");
        }

        if (Objects.isNull(destination)) {
            throw new TechException("Sorry ! The destination folder can not be null.");
        }

        try {
            mkdirs(destination.toString());
            Files.copy(file.toPath(), destination.resolve(file.getName()));
        } catch (Exception exception) {
            throw new TechException(MessageFormat.format("Could not store the file {0} into {1} :", file.getName(), destination), exception);
        }
    }
}
