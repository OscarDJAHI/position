/**
 * Service layer beans.
 */
package fr.gouv.justice.cpn.commun.service;
