package fr.gouv.justice.cpn.commun.converter;

import lombok.CustomLog;
import org.jodconverter.core.document.DefaultDocumentFormatRegistry;
import org.jodconverter.core.document.DocumentFormat;
import org.jodconverter.core.job.ConversionJobWithSourceSpecified;
import org.jodconverter.core.office.OfficeException;
import org.jodconverter.local.JodConverter;
import org.jodconverter.local.office.LocalOfficeManager;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;

@CustomLog
public class GenericPdfConverter {

    private static final LocalOfficeManager LOCAL_OFFICE_MANAGER;

    static {
        try {
            long deb = System.currentTimeMillis();
            LOCAL_OFFICE_MANAGER = LocalOfficeManager.install();
            LOCAL_OFFICE_MANAGER.start();

            log.info("Démarrage du serveur LocalOfficeManager en {}", System.currentTimeMillis() - deb);
        } catch (Exception exception) {
            log.error("Sorry ! Something went wrong when trying to start LocalOfficeManager server", exception);
            throw new RuntimeException(exception);
        }
    }

    private GenericPdfConverter() {
    }

    public static ByteArrayOutputStream convert(File inFile, DocumentFormat format) throws IOException, OfficeException {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             InputStream inputStream = new FileInputStream(inFile)) {
            ConversionJobWithSourceSpecified convert = Objects.isNull(format) ? JodConverter.convert(inputStream) : JodConverter.convert(inputStream).as(format);
            convert.to(baos)
                   .as(DefaultDocumentFormatRegistry.PDF)
                   .execute();

            return baos;
        }
    }
}
