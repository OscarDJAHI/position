package fr.gouv.justice.cpn.commun.indicateur;

import com.fasterxml.jackson.annotation.JsonFormat;
import fr.gouv.justice.cpn.commun.beans.journal.reception.enumeration.TypeProcedure;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class IndicateurJson {

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'", timezone = "UTC")
    private LocalDateTime ts;

    private IndicateurId indic;

    private int nb;

    private String juri;

    private String domaine;

    private String appli;

    private String orpe;

    private String canal;

    private TypeProcedure typeproc;
}
