package fr.gouv.justice.cpn.commun.converter;

import com.google.common.io.Files;
import lombok.CustomLog;
import org.apache.commons.io.IOUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

@CustomLog
public class FileConverter {

    private FileConverter() {
    }

    public static File byteArrayOutputStreamToStreamFile(final ByteArrayOutputStream baos, final String fileName) {
        final File file = new File(Files.createTempDir(), fileName);
        try (final FileOutputStream fos = new FileOutputStream(file)) {
            baos.writeTo(fos);
        } catch (IOException exception) {
            log.error("Sorry ! Something went wrong when trying to convert to File", exception);
        }

        return file;
    }

    public static ByteArrayOutputStream fileToByteArrayOutputStream(final File file) throws IOException {
        try (final ByteArrayOutputStream baos = new ByteArrayOutputStream();
             final FileInputStream fileInputStream = new FileInputStream(file)) {
            IOUtils.write(IOUtils.toByteArray(fileInputStream), baos);
            return baos;
        }
    }
}
