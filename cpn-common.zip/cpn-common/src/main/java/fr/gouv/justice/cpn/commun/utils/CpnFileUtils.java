package fr.gouv.justice.cpn.commun.utils;

import fr.gouv.justice.cpn.commun.exception.TechException;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

/**
 * @deprecated Please use FileUtils instead
 */
public class CpnFileUtils {

    private CpnFileUtils() {
    }

    public static ByteArrayOutputStream convertFileToByteArray(List<String> fileUri) throws Exception {
        return FileUtils.toByteArrayOutputStream(fileUri);
    }

    public static void delete(Path filePath) throws TechException {
        FileUtils.delete(filePath);
    }

    public static void deleteRecursively(Path filePath) throws TechException {
        FileUtils.deleteRecursively(filePath);
    }

    public static File getFile(ByteArrayOutputStream baos, String filename) throws IOException {
        return FileUtils.getFile(baos, filename);
    }

    public static void mkdirs(final String... folders) {
        FileUtils.mkdirs(folders);
    }

    public static ByteArrayOutputStream toByteArrayOutputStream(final File file) throws TechException {
        return FileUtils.toByteArrayOutputStream(file);
    }

    public static void upload(File file, Path fileDestination) throws TechException {
        FileUtils.upload(file, fileDestination);
    }
}
