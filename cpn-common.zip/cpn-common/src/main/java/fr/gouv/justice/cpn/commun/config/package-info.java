/**
 * Spring Framework configuration files.
 */
package fr.gouv.justice.cpn.commun.config;
