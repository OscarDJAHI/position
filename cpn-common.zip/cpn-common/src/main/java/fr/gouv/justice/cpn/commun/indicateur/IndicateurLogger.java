package fr.gouv.justice.cpn.commun.indicateur;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class IndicateurLogger {

    private static final Logger INDICATEUR_LOG = LoggerFactory.getLogger(IndicateurLogger.class);

    private static final IndicateurLogger instance = new IndicateurLogger();

    private IndicateurLogger() {
    }

    public static IndicateurLogger getInstance() {
        return instance;
    }

    public void debug(String msg) {
        INDICATEUR_LOG.debug(msg);
    }

    public void error(String msg) {
        INDICATEUR_LOG.error(msg);
    }

    public void info(String msg) {
        INDICATEUR_LOG.info(msg);
    }

    public void trace(String msg) {
        INDICATEUR_LOG.trace(msg);
    }

    public void warn(String msg) {
        INDICATEUR_LOG.warn(msg);
    }
}
