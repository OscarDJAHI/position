package fr.gouv.justice.cpn.commun.client.vigie;

public class VigieException extends Exception {

    public VigieException() {
    }

    public VigieException(String message) {
        super(message);
    }

    public VigieException(String message, Throwable cause) {
        super(message, cause);
    }

    public VigieException(Throwable cause) {
        super(cause);
    }
}
