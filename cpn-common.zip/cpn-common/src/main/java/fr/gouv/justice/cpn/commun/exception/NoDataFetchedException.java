package fr.gouv.justice.cpn.commun.exception;

public class NoDataFetchedException extends Exception {
    public NoDataFetchedException() {
        super();
    }

    public NoDataFetchedException(String message) {
        super(message);
    }
}
