package fr.gouv.justice.cpn.commun.client.npp.impl;

import fr.gouv.justice.cpn.commun.beans.demande.envoi.npp.AbstractDemandeEnvoiDocumentNppDTO;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.npp.ResponseEnvoiDocumentNppDTO;
import fr.gouv.justice.cpn.commun.client.npp.RestClientNPP;
import fr.gouv.justice.cpn.commun.client.pfe.PfeClients;
import fr.gouv.justice.cpn.commun.exception.NppException;
import fr.gouv.justice.cpn.commun.model.ArborescenceApi;
import fr.gouv.justice.cpn.commun.model.DemandeEnvoiMessageDTO;
import fr.gouv.justice.cpn.commun.model.DescriptAffApi;
import fr.gouv.justice.cpn.commun.model.DescriptArboApi;
import fr.gouv.justice.cpn.commun.model.UpdateEnvoiDTO;
import fr.gouv.justice.cpn.commun.model.descriptAffaire.DescriptAffaireApi;
import lombok.CustomLog;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.data.util.Pair;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.Arrays;
import java.util.Objects;

@Component
@EnableRetry
@RequiredArgsConstructor
@CustomLog
public class RestClientNPPImpl extends PfeClients.AbstractHttpClient implements RestClientNPP {

    private static final String FILE_JSON = "fileJson";

    private static final String DEPOSER_FX_147 = "/deposer/FX147/";
    private static final String DEPOSER_FX_187 = "/deposer/FX187/";
    private static final String RETIRER_FX_187 = "/retirer/FX187/";

    @Value("${pfe.flux.fx187.enable:true}")
    private boolean activeDeposerFx187;

    @Value("${npp.endpoint.confirmation_path:/npp/rest/confirmationenvoi!create}")
    private String confirmationPath;
    @Value("${npp.endpoint.get_arborecense:/npp/rest/dossierget/!descriptArbo.json}")
    private String getArborecensePath;
    @Value("${npp.endpoint.get_descript_affaire:/npp/rest/dossierget/!descriptAff.json}")
    private String getDescriptAffairePath;
    @Value("${npp.endpoint.post_modifier_envoi:/npp/rest/modifierenvoi}")
    private String postModifierEnvoiPath;
    @Value("${npp.endpoint.depose:/npp/rest/echanges/!create.json}")
    private String deposePath;

    @Override
    @Retryable(value = NppException.class,
               maxAttemptsExpression = "${npp.endpoint.retry.maxAttempts:3}",
               backoff = @Backoff(delayExpression = "${npp.endpoint.retry.delay:1000}"))
    public ResponseEnvoiDocumentNppDTO confirmSending(final UpdateEnvoiDTO updateEnvoiDto, final String codeSrj) throws NppException {
        try {
            final String path = buildNppEndpointPath(DEPOSER_FX_187, codeSrj, postModifierEnvoiPath);
            log.info("Trying to confirm request sending to NPP for the message : [{}], using Path : [{}]", updateEnvoiDto.getIdDemande(), path);

            final RestClientNPPHelper.ConfirmSendingResponse clientResponse = Objects.requireNonNull(this.post()
                                                                                                         .uri(path)
                                                                                                         .bodyValue(updateEnvoiDto)
                                                                                                         .exchange()
                                                                                                         .block())
                                                                                     .bodyToMono(RestClientNPPHelper.ConfirmSendingResponse.class)
                                                                                     .block();

            return RestClientNPPHelper.toResponseEnvoiDocumentNppDTO(clientResponse);
        } catch (Exception exception) {
            throw new NppException(exception);
        }
    }

    @Override
    // TODO : Refactore to use @ResponseEnvoiDocumentNppDTO
    public ArborescenceApi getArborecense(final DescriptArboApi filterArbo) throws NppException {
        try {
            final String path = buildNppEndpointPath(RETIRER_FX_187, filterArbo.getCodeSrj(), getArborecensePath);
            log.info("Trying to get Arborecense from NPP for CodeSrj : [{}], using Path : [{}]", filterArbo.getCodeSrj(), path);

            return this.send(path,
                             ArborescenceApi.class,
                             Pair.of(FILE_JSON, RestClientNPPHelper.toJsonFile(filterArbo)));
        } catch (Exception exception) {
            throw new NppException(exception);
        }
    }

    @Override
    // TODO : Refactore to use @ResponseEnvoiDocumentNppDTO
    public DescriptAffaireApi getDescriptAffaireNpp(final DescriptAffApi filterArbo, final String codeSrj) throws NppException {
        try {
            final String path = buildNppEndpointPath(RETIRER_FX_187, codeSrj, getDescriptAffairePath);
            log.info("Trying to get DescriptAffaire from NPP for CodeSrj : [{}], using Path : [{}]", codeSrj, path);

            return this.send(path,
                             DescriptAffaireApi.class,
                             Pair.of(FILE_JSON, RestClientNPPHelper.toJsonFile(filterArbo)));
        } catch (Exception exception) {
            throw new NppException(exception);
        }
    }

    @Override
    public ResponseEnvoiDocumentNppDTO sendDocumentsToNpp(final AbstractDemandeEnvoiDocumentNppDTO demande, final ByteArrayOutputStream zipOutputStream) throws
                                                                                                                                                         NppException {
        try {
            final String path = getDeposeEndPoint(demande);
            log.info("Trying to send documents to NPP using Path : [{}]", path);

            File file = RestClientNPPHelper.toZip(zipOutputStream);

            return this.send(path,
                             Pair.of(FILE_JSON, RestClientNPPHelper.toJsonFile(demande, file.getName())),
                             Pair.of("fileZip", new FileSystemResource(file)));
        } catch (Exception exception) {
            throw new NppException(exception);
        }
    }

    @Override
    public ResponseEnvoiDocumentNppDTO validateRequest(final DemandeEnvoiMessageDTO message) throws NppException {
        final String path = DEPOSER_FX_187 + message.getSender().getCodeSrj() + confirmationPath;
        log.info("Trying to send request validation to NPP for the message : [{}], using Path : [{}]", message.getId(), path);

        try {
            return this.send(path, Pair.of("envoiCPN", RestClientNPPHelper.toJsonFile(message)));
        } catch (Exception exception) {
            throw new NppException(exception);
        }
    }

    /**
     * permet de construire l'url de l'endpoind NPP
     * le type de flux est sous format methode/numFlux
     * exemple : retirer/FX187
     * deposer/FX147
     * <p>
     * le codeSrj est fourni par l'appelant
     * <p>
     * le nppEndPoint est le endpoint exposé par NPP à reporter dans les fichiers
     * application yaml des modules intégrant cpn_common comme mab-echange...
     */
    private String buildNppEndpointPath(final String typeFlux, final String codeSrj, final String nppEndPoint) throws NppException {
        final String path = typeFlux + codeSrj + nppEndPoint;
        if (StringUtils.isBlank(path)) {
            throw new NppException("Sorry ! Something went wrong when trying to send request to NPP -> URL can not be empty.");
        }

        return path;
    }

    private String getDeposeEndPoint(final AbstractDemandeEnvoiDocumentNppDTO demande) throws NppException {
        return activeDeposerFx187 ? buildNppEndpointPath(DEPOSER_FX_187, demande.getCodeSrj(), deposePath)
                                  : buildNppEndpointPath(DEPOSER_FX_147, demande.getCodeSrj(), StringUtils.EMPTY);
    }

    @SafeVarargs
    private <T> T send(final String url, final Class<T> responseType, final Pair<String, Object>... params) throws NppException {
        return Objects.requireNonNull(this.sendToNpp(url, params))
                      .bodyToMono(responseType)
                      .block();
    }

    @SafeVarargs
    private ResponseEnvoiDocumentNppDTO send(final String uri, final Pair<String, Object>... params) throws NppException {
        final ClientResponse clientResponse = this.sendToNpp(uri, params);
        return RestClientNPPHelper.toResponseEnvoiDocumentNppDTO(clientResponse);
    }

    @SafeVarargs
    private ClientResponse sendToNpp(final String uri, final Pair<String, Object>... params) throws NppException {
        if (Objects.isNull(params) || params.length == 0) {
            throw new NppException("Sorry ! Something went wrong when trying to send request to NPP -> Body can not be empty.");
        }

        final MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        Arrays.stream(params).forEach(param -> body.add(param.getFirst(), param.getSecond()));

        try {
            return this.post()
                       .uri(uri)
                       .header(HttpHeaders.CONTENT_TYPE, MediaType.MULTIPART_FORM_DATA_VALUE)
                       .body(BodyInserters.fromMultipartData(body))
                       .exchange()
                       .block();
        } catch (Exception exception) {
            throw new NppException(exception);
        }
    }
}
