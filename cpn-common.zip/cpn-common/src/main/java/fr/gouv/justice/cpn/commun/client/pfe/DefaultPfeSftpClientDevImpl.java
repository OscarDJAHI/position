package fr.gouv.justice.cpn.commun.client.pfe;

import com.google.common.io.Files;
import lombok.RequiredArgsConstructor;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Set;

@RequiredArgsConstructor
public class DefaultPfeSftpClientDevImpl extends AbstractPfeSftpClient implements PfeClients.DefaultFtpClient {

    @Override
    public File downloadFile(String fileAbsolutePath, Path target) throws PfeException {
        try {
            File file      = new File(target.toString());
            File fileValue = new File(fileAbsolutePath);
            Files.copy(fileValue, file);
            fileValue.delete();
            return file;
        } catch (Exception e) {
            throw new PfeException("Error dowloading file", e);
        }
    }

    @Override
    public Set<String> listContent(String folder, String... filters) throws PfeException {
        return Set.of(new File(folder).list());
    }

    @Override
    public void uploadFile(File file, String target) throws PfeException {
        try {
            Files.copy(file, new File(target + File.separator + file.getName()));
        } catch (IOException e) {
            throw new PfeException(e);
        }
    }
}
