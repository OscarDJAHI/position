package fr.gouv.justice.cpn.commun.client.vigie.impl;

import fr.gouv.justice.cpn.commun.beans.generic.ResponseDTO;
import fr.gouv.justice.cpn.commun.client.common.AbstractWebClient;
import fr.gouv.justice.cpn.commun.client.vigie.RestClientVIGIE;
import fr.gouv.justice.cpn.commun.client.vigie.VigieException;
import fr.gouv.justice.cpn.commun.exception.NppException;
import lombok.CustomLog;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.time.Instant;
import java.util.Objects;

@Component
@EnableRetry
@RequiredArgsConstructor
@CustomLog
public class RestClientVIGIEImpl extends AbstractWebClient implements RestClientVIGIE {

	@Value("${vigie.base-url:changeme}")
	private String baseUrl;
	@Value("${vigie.api.notify.path:/api/notifierMiseAJourDemandeEnvoi}")
	private String notificationPath;

	@Override
	@Retryable(value = NppException.class,
	           maxAttemptsExpression = "${vigie.api.notify.retry.max-attempts:3}",
	           backoff = @Backoff(delayExpression = "${vigie.api.notify.retry.delay:3000}"))
	public ResponseDTO confirmSending(final NotificationRequest notificationRequest) throws VigieException {
		return this.send(notificationRequest, "confirmation");
	}

	@Override
	public ResponseDTO validateRequest(final NotificationRequest notificationRequest) throws VigieException {
		return this.send(notificationRequest, "validation");
	}

	@Override
	protected String getBaseUrl() {
		return this.baseUrl;
	}

	private ResponseDTO send(final NotificationRequest notificationRequest, final String operation) throws VigieException {
		log.info("Trying to send {} notification to [VIGIE] using data : {}", operation, notificationRequest);

		try {
			final ResponseEntity<NotificationResponse> response = this.post()
			                                                          .uri(uriBuilder -> uriBuilder.path(this.notificationPath).build())
			                                                          .bodyValue(notificationRequest)
			                                                          .retrieve()
			                                                          .toEntity(NotificationResponse.class)
			                                                          .block();

			log.info("[VIGIE] notification response : {}", response);

			Objects.requireNonNull(response);

			final NotificationResponse vigieResponse = response.getBody();

			final ResponseDTO responseDTO = new ResponseDTO();
			responseDTO.setId(Objects.isNull(vigieResponse) ? null : vigieResponse.getPgavId());
			responseDTO.setCode(response.getStatusCodeValue());
			responseDTO.setDate(Instant.now());
			responseDTO.setMessage(Objects.isNull(vigieResponse) ? StringUtils.EMPTY : vigieResponse.getErrmsg());

			return responseDTO;
		} catch (WebClientResponseException webClientResponseException) {
			final String message = String.format("{status: %s, body: %s, message: %s, cause: %s}",
			                                     webClientResponseException.getStatusCode(),
			                                     webClientResponseException.getResponseBodyAsString(),
			                                     webClientResponseException.getMessage(),
			                                     webClientResponseException.getCause());

			throw new VigieException(message, webClientResponseException);
		} catch (Exception exception) {
			throw new VigieException(exception);
		}
	}
}
