package fr.gouv.justice.cpn.commun.client.sps;

import fr.gouv.justice.cpn.commun.exception.FoncException;
import fr.gouv.justice.cpn.commun.exception.TechException;
import fr.gouv.justice.cpn.commun.model.enumeration.StatutPiece;
import fr.gouv.justice.cpn.commun.model.enumeration.TypeIdDPN;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.List;
import java.util.Map;

public interface RestClientSpsMasInterfaceEcm {

    @Builder
    @Getter
    @ToString
    @EqualsAndHashCode
    class DocumentSPS {
        private String      id;
        private String      type;
        private String      nppId;
        private String      juridiction;
        private File        file;
        private StatutPiece status;
        private String      codeDossier;
        private TypeIdDPN   typeDossier;

        private Map<SpsKeyMap, String> properties;
    }

    String deleteDocument(final DocumentSPS document, final String userId) throws SpsException, FoncException, TechException;

    ByteArrayOutputStream downloadDocument(final String documentId, final String userId) throws SpsException, FoncException, TechException;

    ByteArrayOutputStream downloadDocuments(final List<String> ids, final String userId) throws SpsException, FoncException, TechException;

    String updateDocument(final DocumentSPS document, final String userId) throws SpsException, FoncException, TechException;

    String updateDocumentStatus(final DocumentSPS document, final String userId) throws SpsException, FoncException, TechException;

    List<String> updateIdj(final String idJustice, final String noProcedureFormate, final String level0, final String nomJuridiction, final String userId) throws SpsException,
                                                                                                                                                                  FoncException,
                                                                                                                                                                  TechException;

    String uploadDocument(final DocumentSPS document, final String userId) throws SpsException, FoncException, TechException;
}
