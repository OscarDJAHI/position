package fr.gouv.justice.cpn.commun.client.storage.impl;

import fr.gouv.justice.cpn.commun.beans.storage.ProxyStorageResponseCreateDoc;
import fr.gouv.justice.cpn.commun.beans.storage.ProxyStorageUploadRequest;
import fr.gouv.justice.cpn.commun.beans.storage.StorageRequest;
import fr.gouv.justice.cpn.commun.beans.storage.StorageResponse;
import fr.gouv.justice.cpn.commun.client.common.AbstractWebClient;
import fr.gouv.justice.cpn.commun.client.storage.RestClientProxyStorage;
import fr.gouv.justice.cpn.commun.exception.StorageException;
import fr.gouv.justice.cpn.commun.utils.Base64Utils;
import lombok.CustomLog;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Flux;

import java.io.ByteArrayOutputStream;
import java.util.Objects;

@Component
@CustomLog
public class RestClientProxyStorageImpl extends AbstractWebClient implements RestClientProxyStorage {

    public static final String DOCUMENT_PATH = "/document/{path}";

    private static final String APPLICATION_KEY = "applicationKey";

    @Value("${cpn.mas.proxy_storage.base_url:changeme}")
    private String baseUrl;

    /**
     * Base64 encoded key
     */
    @Value("${cpn.mas.proxy_storage.application_key:CePN}")
    private String applicationKeyValue;

    @Override
    public StorageResponse deleteDocument(final StorageRequest request) throws StorageException {
        ClientResponse httpResponse = this.delete()
                                          .uri(uriBuilder -> uriBuilder.path(DOCUMENT_PATH).build(request.getPath()))
                                          .header(APPLICATION_KEY, applicationKeyValue)
                                          .exchange()
                                          .block();

        checkResponse(httpResponse);

        ProxyStorageResponseCreateDoc responseCreateDoc = getResponseCreateDoc(httpResponse);

        StorageResponse response = new StorageResponse();
        response.setSucess(isSuccess(responseCreateDoc.getTypeMessage()));
        response.setMessage(response.getMessage());

        return response;
    }

    @Override
    public StorageResponse downloadDocument(final StorageRequest request) throws StorageException {
        ClientResponse clientResponse = this.get()
                                            .uri(uriBuilder -> uriBuilder.path(DOCUMENT_PATH).build(request.getPath()))
                                            .header(APPLICATION_KEY, applicationKeyValue)
                                            .exchange()
                                            .block();

        checkResponse(clientResponse);

        return readResponse(clientResponse);
    }

    @Override
    public StorageResponse downloadDocuments(final StorageRequest request) throws StorageException {
        MultipartBodyBuilder builder = new MultipartBodyBuilder();
        builder.part("paths", request.getFilesNamesAndUri());

        ClientResponse clientResponse = this.post()
                                            .uri(uriBuilder -> uriBuilder.path("/get/documents").build())
                                            .header(APPLICATION_KEY, applicationKeyValue)
                                            .contentType(MediaType.MULTIPART_FORM_DATA)
                                            .body(BodyInserters.fromMultipartData(builder.build()))
                                            .exchange()
                                            .block();

        checkResponse(clientResponse);

        return readResponse(clientResponse);
    }

    @Override
    public StorageResponse uploadDocument(final StorageRequest request) throws StorageException {
        String encodedPath = Base64Utils.encode(request.getPath());

        ProxyStorageUploadRequest params = new ProxyStorageUploadRequest();
        params.setExtension(FilenameUtils.getExtension(request.getFile().getName()));

        FileSystemResource file = new FileSystemResource(request.getFile());

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("file", file);
        body.add("body", params);

        ClientResponse httpResponse = this.post()
                                          .uri(uriBuilder -> uriBuilder.path(DOCUMENT_PATH).build(encodedPath))
                                          .header(APPLICATION_KEY, applicationKeyValue)
                                          .contentType(MediaType.MULTIPART_FORM_DATA)
                                          .contentType(MediaType.MULTIPART_MIXED)
                                          .body(BodyInserters.fromMultipartData(body))
                                          .exchange()
                                          .block();

        checkResponse(httpResponse);

        ProxyStorageResponseCreateDoc responseCreateDoc = getResponseCreateDoc(httpResponse);

        StorageResponse response = new StorageResponse();
        response.setSucess(isSuccess(responseCreateDoc.getTypeMessage()));
        response.setPath(responseCreateDoc.getPathDocument());
        response.setMessage(response.getMessage());

        return response;
    }

    @Override
    protected String getBaseUrl() {
        return this.baseUrl;
    }

    private void checkResponse(final ClientResponse response) throws StorageException {
        if (Objects.isNull(response)) {
            throw storageException("A problem occurred while trying to contact HCP. No response returned.", "500");
        }

        HttpStatus status = response.statusCode();
        if (status.is4xxClientError() || status.is5xxServerError()) {
            throw storageException("A problem occurred while trying to contact HCP. HTTP " + status.value() + " - " + status.getReasonPhrase(),
                                   String.valueOf(status.value()));
        }
    }

    private ProxyStorageResponseCreateDoc getResponseCreateDoc(final ClientResponse httpResponse) throws StorageException {
        ProxyStorageResponseCreateDoc response = httpResponse.bodyToMono(ProxyStorageResponseCreateDoc.class).block();
        if (Objects.isNull(response)) {
            throw storageException("A problem occurred while trying to get ResponseCreateDoc in HCP response", "500");
        }

        return response;
    }

    private boolean isSuccess(final String typeResponse) {
        return "INFO".equalsIgnoreCase(typeResponse);
    }

    private StorageResponse readResponse(final ClientResponse clientResponse) throws StorageException {
        try (ByteArrayOutputStream file = new ByteArrayOutputStream()) {
            Flux<DataBuffer> fileDataStream = clientResponse.bodyToFlux(DataBuffer.class);

            DataBufferUtils.write(fileDataStream, file)
                           .map(DataBufferUtils::release)
                           .then()
                           .block();

            StorageResponse response = new StorageResponse();
            response.setFile(file);
            response.setSucess(true);

            return response;
        } catch (Exception e) {
            throw storageException("Sorry ! Something went wrong while trying to get files from HCP server :(", "500", e);
        }
    }

    private StorageException storageException(final String msg, final String status, final Exception e) throws StorageException {
        StorageException exception = new StorageException(msg, e);
        exception.setHttpStatus(status);

        throw exception;
    }

    private StorageException storageException(final String msg, final String status) throws StorageException {
        StorageException exception = new StorageException(msg);
        exception.setHttpStatus(status);

        throw exception;
    }
}
