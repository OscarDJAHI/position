package fr.gouv.justice.cpn.commun.converter;

import com.lowagie.text.Cell;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.PdfWriter;
import fr.gouv.justice.cpn.commun.beans.message.MessageDTO;
import fr.gouv.justice.cpn.commun.beans.message.detail.AuditDTO;
import fr.gouv.justice.cpn.commun.beans.message.detail.DownloadedDTO;
import fr.gouv.justice.cpn.commun.beans.message.detail.FileDTO;
import fr.gouv.justice.cpn.commun.beans.message.detail.RecipientDTO;
import fr.gouv.justice.cpn.commun.beans.message.detail.ViewedDTO;
import fr.gouv.justice.cpn.commun.utils.DateUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.IterableUtils;
import org.apache.commons.collections4.Predicate;
import org.apache.commons.lang3.StringUtils;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * helper pour générer les pdf  accusé de réception
 */
public class ArMessageConverter {

    private static final DateTimeFormatter DATE_FORMATTER      = DateTimeFormatter.ofPattern("dd LLLL yyyy").localizedBy(Locale.FRANCE);
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    private ArMessageConverter() {
    }

    public static ByteArrayOutputStream toAr(final MessageDTO message) throws DocumentException, IOException {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             Document document = new Document()) {
            PdfWriter.getInstance(document, baos);
            document.open();

            addHeader(message, document);
            addComment(message, document);
            // List des fichiers
            addFiles(message, document);
            // Audit
            addAudit(message, document);

            document.close();

            return baos;
        }
    }

    private static void addAudit(final MessageDTO message, Document document) throws DocumentException {
        Table tableAudit = new Table(3);
        tableAudit.setBorderColor(new Color(33, 33, 33));
        tableAudit.setPadding(5);
        Cell taH1 = new Cell("Destinataire");
        Cell taH2 = new Cell("Lu le");
        Cell taH3 = new Cell("T\u00e9l\u00e9charg\u00e9(s) le");
        taH1.setHeader(true);
        taH2.setHeader(true);
        taH3.setHeader(true);
        tableAudit.addCell(taH1);
        tableAudit.addCell(taH2);
        tableAudit.addCell(taH3);
        tableAudit.endHeaders();
        AuditDTO audit = message.getAudit();

        for (RecipientDTO recipent : message.getRecipients()) {
            final int userIndex = recipent.getIndex();

            tableAudit.addCell(new Cell(recipent.getEmail()));

            ViewedDTO viewed = IterableUtils.find(audit.getViewed(), findViewedByUserIndex(userIndex));
            tableAudit.addCell(new Cell(Objects.isNull(viewed) ? "-" : DATE_FORMATTER.format(DateUtils.convertToClientTimeZone(viewed.getDate()))));

            List<DownloadedDTO> downloads = new ArrayList<>(CollectionUtils.select(audit.getDownloaded(), findDownloadedByUserIndex(userIndex)));
            if (CollectionUtils.isEmpty(downloads)) {
                tableAudit.addCell(new Cell("Aucun fichier n'a \u00E9t\u00E9 t\u00E9l\u00E9charg\u00E9"));
            } else {
                String contentCell;
                int    size = downloads.size();
                tableAudit.addCell(new Cell(size + size > 1 ? " fichiers ont \u00E9t\u00E9 t\u00E9l\u00E9charg\u00E9s"
                                                            : " fichier a \u00E9t\u00E9 t\u00E9l\u00E9charg\u00E9"));
            }
        }

        document.add(tableAudit);
    }

    private static void addComment(final MessageDTO message, Document document) throws DocumentException {
        Paragraph p = new Paragraph(Chunk.NEWLINE);
        document.add(p);

        Font      fontBody = new Font(Font.HELVETICA, 14, Font.NORMAL, Color.BLACK);
        Paragraph comment  = new Paragraph(message.getComment(), fontBody);
        document.add(comment);
    }

    private static void addFiles(final MessageDTO message, Document document) {
        Font      font      = new Font(Font.HELVETICA, 18, Font.BOLD, Color.BLACK);
        Paragraph fileTitle = new Paragraph("Fichiers", font);
        fileTitle.getFont().setSize(16);

        document.add(fileTitle);
        Table table = new Table(2);
        table.setBorderColor(new Color(33, 33, 33));
        table.setPadding(5);
        //                    table.setSpacing(5);
        Cell c  = new Cell("Fichier");
        Cell c2 = new Cell("Taille");
        c.setHeader(true);
        c2.setHeader(true);
        table.addCell(c);
        table.addCell(c2);
        table.endHeaders();

        for (FileDTO file : message.getFiles()) {
            table.addCell(file.getName());
            double        taille        = Float.parseFloat(file.getSize());
            DecimalFormat decimalFormat = new DecimalFormat("#,###.00");
            String        formattedSize = decimalFormat.format(taille / 1000);
            table.addCell(formattedSize + " Mo");
        }
        document.add(table);
    }

    private static void addHeader(final MessageDTO message, Document document) {
        Paragraph recipientsP = new Paragraph();
        List<String> recipientsMails = message.getRecipients().stream().map(RecipientDTO::getEmail).collect(
                Collectors.toList());
        String recipients = StringUtils.join(recipientsMails, ", ");
        recipientsP.add(new Phrase(recipients, new Font(Font.HELVETICA, 13, Font.NORMAL, Color.BLACK)));
        document.add(recipientsP);
        // font and color settings
        Font      font    = new Font(Font.HELVETICA, 18, Font.BOLD, Color.BLACK);
        Paragraph subject = new Paragraph(message.getSubject(), font);
        document.add(subject);

        Font      metaData  = new Font(Font.HELVETICA, 12, Font.ITALIC, Color.DARK_GRAY);
        Paragraph metaDataP = new Paragraph();

        Phrase recieved = new Phrase("Recu le : " + DATE_TIME_FORMATTER.format(DateUtils.convertToClientTimeZone(message.getDate())) + ".", metaData);
        recieved.getFont().setStyle(Font.ITALIC | Font.BOLD);
        Phrase from = new Phrase("De : " + message.getSender().getEmail(), metaData);
        metaDataP.add(recieved);
        metaDataP.add(Chunk.NEWLINE);
        metaDataP.add(from);
        document.add(metaDataP);
    }

    private static Predicate<DownloadedDTO> findDownloadedByUserIndex(int index) {
        return downloaded -> index == downloaded.getUserIndex();
    }

    private static Predicate<ViewedDTO> findViewedByUserIndex(int index) {
        return viewed -> index == viewed.getUserIndex();
    }
}
