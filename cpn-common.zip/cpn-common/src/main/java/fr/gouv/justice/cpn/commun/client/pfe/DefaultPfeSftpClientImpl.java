package fr.gouv.justice.cpn.commun.client.pfe;

import com.jcraft.jsch.ChannelSftp;
import lombok.CustomLog;
import lombok.RequiredArgsConstructor;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.Objects;
import java.util.Set;
import java.util.Vector;
import java.util.stream.Collectors;

@Component
@EnableRetry
@RequiredArgsConstructor
@CustomLog
public class DefaultPfeSftpClientImpl extends AbstractPfeSftpClient implements PfeClients.DefaultFtpClient {

    @Override
    public File downloadFile(final String fileAbsolutePath, final Path target) throws PfeException {
        if (StringUtils.isEmpty(fileAbsolutePath)) {
            throw new PfeException("Sorry ! The absolute path of the file to download can not be empty");
        }

        Path targetFile;
        if (Objects.isNull(target)) {
            targetFile = createFileInTempFolder(fileAbsolutePath);
            log.warn("No target folder provided; the file <{}> will be downloaded to : <{}>", fileAbsolutePath, targetFile);
        } else {
            targetFile = target;
        }

        ChannelSftp channel = this.newChannel();

        File file = targetFile.toFile();
        try (OutputStream writer = new FileOutputStream(file)) {
            log.info("Start downloading file : <{}> from PFE to folder : <{}> ...", fileAbsolutePath, target);
            channel.get(fileAbsolutePath, writer);
            log.info("End downloading file : <{}> from PFE to folder : <{}>", fileAbsolutePath, target);

            return file;
        } catch (Exception exception) {
            throw new PfeException(String.format("Sorry ! Something went wrong when trying to download file : <%s> from PFE", fileAbsolutePath), exception);
        } finally {
            closeChannel(channel);
        }
    }

    @Override
    public Set<String> listContent(final String folder, final String... filters) throws PfeException {
        if (StringUtils.isEmpty(folder)) {
            throw new PfeException(String.format("Sorry ! Can not list the content of the folder : <%s>", folder));
        }

        final Set<String> filtersToUse = Objects.isNull(filters) || filters.length == 0 ? Set.of("./*") : Set.of(filters);
        log.info("Try to list the content of the folder : <{}> using the filters : {}", folder, filtersToUse);

        ChannelSftp channel = this.newChannel();

        Vector<ChannelSftp.LsEntry> folderContent = new Vector<>();
        for (String filter : filtersToUse) {
            try {
                log.info("Try to list the content of the folder : <{}> using the filter : <{}>", folder, filter);
                folderContent.addAll(channel.ls(folder + filter));
            } catch (Exception exception) {
                closeChannel(channel);
                throw new PfeException(String.format("Sorry ! Something went wrong when trying to list the content of the folder : <%s> using the filter : <%s>", folder, filter), exception);
            }
        }

        closeChannel(channel);

        folderContent.sort(Comparator.comparingInt(item -> item.getAttrs().getMTime()));

        final Set<String> content = folderContent.stream()
                                                 .map(ChannelSftp.LsEntry::getFilename)
                                                 .collect(Collectors.toSet());

        log.info("The folder : <{}> contains : <{}> files filtered using : <{}>", folder, content.size(), filtersToUse);
        log.debug("The folder : <{}>, filtered using : <{}>, contains the following files : {} ", folder, filtersToUse, content);

        return content;
    }

    @Override
    public void uploadFile(final File file, final String target) throws PfeException {
        if (Objects.isNull(file)) {
            throw new PfeException("Sorry ! Can not upload an NULL file to PFE.");
        }

        if (StringUtils.isEmpty(target)) {
            throw new PfeException(String.format("Sorry ! Can not upload file : <%s> to PFE folder : <%s>", file.getName(), target));
        }

        ChannelSftp channel = this.newChannel();
        try {
            channel.put(file.getAbsolutePath(), target);
            channel.exit();
        } catch (Exception exception) {
            throw new PfeException(String.format("Sorry ! Something went wrong when trying to upload file : <%s> to PFE folder : <%s>", file.getAbsolutePath(), target),
                                   exception);
        } finally {
            closeChannel(channel);
        }
    }

    private static Path createFileInTempFolder(final String fileAbsolutePath) throws PfeException {
        final Path tmpFolder;
        try {
            tmpFolder = Files.createTempDirectory("pfe_sftp_");
            log.debug("Tmp folder created successfully in <{}>", tmpFolder);
        } catch (Exception exception) {
            throw new PfeException("Sorry ! Something went wrong when trying to create a temp folder with prefix : <pfe_sftp_>", exception);
        }

        try {
            final String filename = fileAbsolutePath.substring(fileAbsolutePath.lastIndexOf("/"));

            return Path.of(tmpFolder.toString(), filename);
        } catch (Exception exception) {
            throw new PfeException(String.format("Sorry ! Something went wrong when trying to create the file : <%s> in the temp folder : <%s>", fileAbsolutePath, tmpFolder), exception);
        }
    }
}
