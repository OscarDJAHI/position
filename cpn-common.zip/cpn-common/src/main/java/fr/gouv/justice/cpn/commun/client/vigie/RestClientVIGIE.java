package fr.gouv.justice.cpn.commun.client.vigie;

import fr.gouv.justice.cpn.commun.beans.generic.ResponseDTO;
import fr.gouv.justice.cpn.commun.model.enumeration.Status;
import lombok.Data;

public interface RestClientVIGIE {

    @Data
    class NotificationRequest {

        private Long idDemande;

        private Status status;

        private NotificationOperation operation;

        private String message;

        private String sender;
    }

    @Data
    class NotificationResponse {

        private Long pgavId;

        private String errmsg;

        private String oldStatus;

        private String newStatus;
    }

    enum NotificationOperation {
        VALIDATION,
        ENVOI
    }

    ResponseDTO confirmSending(final NotificationRequest notificationRequest) throws VigieException;

    ResponseDTO validateRequest(final NotificationRequest notificationRequest) throws VigieException;
}
