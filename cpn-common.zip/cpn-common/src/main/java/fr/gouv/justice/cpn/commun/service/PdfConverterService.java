package fr.gouv.justice.cpn.commun.service;

import fr.gouv.justice.cpn.commun.exception.TechException;
import org.jodconverter.core.office.OfficeException;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

public interface PdfConverterService {

    ByteArrayOutputStream convertToByteArrayOutputStream(ByteArrayOutputStream baos, String fileName) throws IOException, OfficeException;

    File getFileConvertedToPdf(File file) throws IOException, OfficeException, TechException;

}
