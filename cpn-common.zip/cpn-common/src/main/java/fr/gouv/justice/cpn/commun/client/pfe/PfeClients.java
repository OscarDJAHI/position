package fr.gouv.justice.cpn.commun.client.pfe;

import java.io.File;
import java.nio.file.Path;
import java.util.Set;

public final class PfeClients {

    public abstract static class AbstractHttpClient extends AbstractPfeHttpClient {
    }

    public abstract static class AbstractSftpClient extends AbstractPfeSftpClient {
    }

    public interface DefaultFtpClient {

        void closeSession() throws PfeException;

        File downloadFile(final String fileAbsolutePath, final Path target) throws PfeException;

        Set<String> listContent(final String folder, final String... filters) throws PfeException;

        void openSession() throws PfeException;

        void uploadFile(final File file, final String target) throws PfeException;
    }

    private PfeClients() {
    }
}
