package fr.gouv.justice.cpn.commun.client.bpn;

import fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn.DemandeEnvoiArBpnDTO;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn.DemandeEnvoiDocumentBpnDTO;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn.NodeDto;
import fr.gouv.justice.cpn.commun.exception.FoncException;
import fr.gouv.justice.cpn.commun.exception.TechException;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.List;

public interface RestClientBpn {

    ByteArrayOutputStream downloadDocuments(final List<String> ids, final String userId) throws BpnException, FoncException, TechException;

    void sendArToBpn(final DemandeEnvoiArBpnDTO demande, final File file) throws TechException;

    // TODO : Throw TechException instead of IO
    List<NodeDto> uploadFilesIntoPochette(final DemandeEnvoiDocumentBpnDTO demande, final List<File> files) throws IOException, BpnException;
}
