package fr.gouv.justice.cpn.commun.exception;

public class TechException extends Exception {

	public TechException(String message) {
		super(message);
	}

	public TechException(Throwable cause) {
		super(cause);
	}

	public TechException(String message, Throwable cause) {
		super(message, cause);
	}
}
