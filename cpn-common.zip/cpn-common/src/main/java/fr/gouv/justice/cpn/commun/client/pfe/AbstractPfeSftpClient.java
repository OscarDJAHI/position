package fr.gouv.justice.cpn.commun.client.pfe;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import lombok.CustomLog;
import org.springframework.beans.factory.annotation.Value;

import javax.annotation.PostConstruct;
import java.util.Objects;

@CustomLog
abstract class AbstractPfeSftpClient {

    @Value("${pfe.sftp.host:changeme}")
    private String  host;
    @Value("${pfe.sftp.port:22}")
    private Integer port;
    @Value("${pfe.sftp.user.name:changeme}")
    private String  user;

    @Value("${pfe.sftp.user.private-key:changeme}")
    private String userPrivateKeyPath;

    private Session session;

    public void closeSession() throws PfeException {
        if (Objects.isNull(session)) {
            return;
        }

        try {
            this.session.disconnect();
        } catch (Exception exception) {
            throw new PfeException(exception);
        }
    }

    public void openSession() throws PfeException {
        try {
            JSch jsch = new JSch();
            jsch.addIdentity(userPrivateKeyPath);

            this.session = jsch.getSession(user, host, port);
            this.session.setConfig("StrictHostKeyChecking", "no");
            this.session.connect();
        } catch (Exception exception) {
            if (!Objects.isNull(this.session) && this.session.isConnected()) {
                this.session.disconnect();
            }

            throw new PfeException(exception);
        }
    }

    protected static void closeChannel(final Channel channel) throws PfeException {
        if (Objects.isNull(channel)) {
            return;
        }

        try {
            channel.disconnect();
        } catch (Exception exception) {
            throw new PfeException(exception);
        }
    }

    protected ChannelSftp newChannel() throws PfeException {
        ChannelSftp channel = null;

        try {
            channel = (ChannelSftp) this.session().openChannel("sftp");
            channel.connect();

            return channel;
        } catch (Exception exception) {
            if (!Objects.isNull(channel) && channel.isConnected()) {
                channel.disconnect();
            }

            throw new PfeException(exception);
        }
    }

    @PostConstruct
    private void logSSHData() {
        log.info("SSH Host: {}", host);
        log.info("SSH Port: {}", port);
        log.info("SSH User: {}", user);
        log.info("SSH Private Key Path: {}", userPrivateKeyPath);
    }

    private Session session() throws PfeException {
        if (Objects.isNull(this.session) || !this.session.isConnected()) {
            this.openSession();
        }

        return this.session;
    }
}
