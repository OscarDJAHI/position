package fr.gouv.justice.cpn.commun.utils;

import fr.gouv.justice.cpn.commun.beans.demande.DemandeEnvoiDocumentStatusEnum;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.npp.ResponseEnvoiDocumentNppDTO;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;

import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternUtils {

    public static final Set<HttpStatus.Series> HTTP_SERIES_RETOUR_NPP_FON_ERROR = Set.of(HttpStatus.Series.SUCCESSFUL, HttpStatus.Series.CLIENT_ERROR);

    private static String IDJ_PATTERN = "[0-9]{10}[A,B,C,D,E,F,G,H,J,K,M,N,P,Q,R,S,T,U,V,W,X,Y,Z]{1}";

    private static final String APPI_PATTERN = "[0-9]{12}[T]{0,1}";

    private PatternUtils() {

    }

    public static boolean isAppiNotValid(String appi) {
        return !isAppiValid(appi);
    }

    public static boolean isAppiValid(String appi) {
        if (StringUtils.isBlank(appi)) {
            return false;
        }

        Pattern p = Pattern.compile(APPI_PATTERN);
        Matcher m = p.matcher(appi);

        return m.find();
    }

    public static boolean isSrjNotValid(String srj) {
        return !isSrjValid(srj);
    }

    public static boolean isSrjValid(String srj) {
        if (StringUtils.isBlank(srj)) {
            return false;
        }

        Pattern p = Pattern.compile(IDJ_PATTERN);
        Matcher m = p.matcher(srj);

        return m.find();
    }

    public static DemandeEnvoiDocumentStatusEnum getStatus(ResponseEnvoiDocumentNppDTO response) {
        int code = response.getCode();
        if (code == HttpStatus.OK.value()) {
            return DemandeEnvoiDocumentStatusEnum.TRAITEE;
        } else if (HTTP_SERIES_RETOUR_NPP_FON_ERROR.contains(HttpStatus.Series.resolve(code))) {
            return DemandeEnvoiDocumentStatusEnum.ERREUR_FONC_NPP;
        }
        return DemandeEnvoiDocumentStatusEnum.ERREUR_NPP;
    }
}
