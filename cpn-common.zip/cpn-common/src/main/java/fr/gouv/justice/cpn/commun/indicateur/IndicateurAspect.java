package fr.gouv.justice.cpn.commun.indicateur;

import com.fasterxml.jackson.core.JsonProcessingException;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.bpn.DemandeEnvoiDocumentBpnDTO;
import fr.gouv.justice.cpn.commun.beans.demande.envoi.npp.DemandeEnvoiDocumentNppDTO;
import fr.gouv.justice.cpn.commun.beans.message.MessageListDTO;
import fr.gouv.justice.cpn.commun.model.DemandeEnvoiMessageDTO;
import fr.gouv.justice.cpn.commun.model.enumeration.AppName;
import fr.gouv.justice.cpn.commun.model.enumeration.Canal;
import fr.gouv.justice.cpn.commun.model.enumeration.OriginMessage;
import lombok.CustomLog;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;

import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

@CustomLog
public abstract class IndicateurAspect {

    private static final String MESSAGE_LOG = "Problem log indicator {}. {}";

    protected void logCpn02(DemandeEnvoiMessageDTO demande) {
        try {
            IndicateurJsonBuilder b = new IndicateurJsonBuilder();
            b.idIndic(IndicateurId.CPN02)
             .juri(demande.getSender().getCodeSrj())
             .nb(1)
             .appli(demande.getAppName().toString());
            IndicateurLogger.getInstance().info(b.toLogString());
        } catch (Exception e) {
            log.error(MESSAGE_LOG, IndicateurId.CPN02, ExceptionUtils.getMessage(e));
        }
    }

    protected void logCpn03(DemandeEnvoiMessageDTO demande) {
        try {
            IndicateurJsonBuilder b = new IndicateurJsonBuilder();
            b.idIndic(IndicateurId.CPN03)
             .juri(demande.getSender().getCodeSrj())
             .nb(demande.getFichierMessages().size())
             .appli(demande.getAppName().toString());
            IndicateurLogger.getInstance().info(b.toLogString());
        } catch (Exception e) {
            log.error(MESSAGE_LOG, IndicateurId.CPN03, ExceptionUtils.getMessage(e));
        }
    }

    protected void logCpn04(DemandeEnvoiMessageDTO demande) {
        logSendMessageByCanal(demande, IndicateurId.CPN04);
    }

    protected void logCpn05(DemandeEnvoiMessageDTO demande) {
        try {
            HashSet<String> domaines = new HashSet<>();
            demande.getMessageDestinataires().forEach(d ->
                                                              domaines.add(d.getDomain())
            );
            for (String d : domaines) {
                IndicateurJsonBuilder b = new IndicateurJsonBuilder();
                b.idIndic(IndicateurId.CPN05)
                 .juri(demande.getSender().getCodeSrj())
                 .nb(1)
                 .domaine(d);
                IndicateurLogger.getInstance().info(b.toLogString());
            }
        } catch (Exception e) {
            log.error(MESSAGE_LOG, IndicateurId.CPN05, ExceptionUtils.getMessage(e));
        }
    }

    /**
     * ====================================================================
     * ============================ MAS-ECHANGE ===========================
     * ====================================================================
     */

    protected void logCpn11(int sizeMessage, String codeSrj, String canal) {
        try {
            IndicateurJsonBuilder indic11 = new IndicateurJsonBuilder();
            indic11.idIndic(IndicateurId.CPN11).canal(canal).nb(sizeMessage).juri(codeSrj);
            IndicateurLogger.getInstance().info(indic11.toLogString());
        } catch (Exception e) {
            log.error(MESSAGE_LOG, IndicateurId.CPN11, ExceptionUtils.getMessage(e));
        }
    }

    protected void logCpn12(int nb, String codeSrj) {
        try {
            IndicateurJsonBuilder indic = new IndicateurJsonBuilder();
            indic.idIndic(IndicateurId.CPN12)
                 .juri(codeSrj)
                 .nb(nb);
            IndicateurLogger.getInstance().info(indic.toLogString());
        } catch (Exception e) {
            log.error(MESSAGE_LOG, IndicateurId.CPN12, ExceptionUtils.getMessage(e));
        }
    }

    /**
     * ====================================================================
     * ========================== MAB-PLINE-PLEX ==========================
     * ====================================================================
     */

    protected void logCpn14(DemandeEnvoiDocumentBpnDTO demande) {
        try {
            IndicateurJsonBuilder indic = new IndicateurJsonBuilder();
            indic.nb(demande.getDemandeEnvoiDocumentBpnFiles().size())
                 .idIndic(IndicateurId.CPN14)
                 .juri(demande.getCodeSrj())
                 .appli(AppName.BPN.toString());
            IndicateurLogger.getInstance().info(indic.toLogString());
        } catch (Exception e) {
            log.error(MESSAGE_LOG, IndicateurId.CPN14, ExceptionUtils.getMessage(e));
        }
    }

    protected void logCpn21(int sizeMessage, String codeSrj) {
        try {
            IndicateurJsonBuilder indic21 = new IndicateurJsonBuilder();
            indic21.nb(sizeMessage).idIndic(IndicateurId.CPN21).juri(codeSrj);
            IndicateurLogger.getInstance().info(indic21.toLogString());
        } catch (JsonProcessingException e) {
            log.error(MESSAGE_LOG, IndicateurId.CPN21, ExceptionUtils.getMessage(e));
        }
    }

    protected void logCpn46(DemandeEnvoiMessageDTO message) {
        try {
            IndicateurJsonBuilder indic = new IndicateurJsonBuilder();
            indic.nb(1).idIndic(IndicateurId.CPN46).juri(message.getSender().getCodeSrj()).appli(message.getAppName().toString());
            IndicateurLogger.getInstance().info(indic.toLogString());
        } catch (JsonProcessingException var3) {
            log.error(MESSAGE_LOG, IndicateurId.CPN46, ExceptionUtils.getMessage(var3));
        }
    }

    protected void logCpn47(DemandeEnvoiMessageDTO message) {
        logSendMessageByCanal(message, IndicateurId.CPN47);
    }

    protected void logCpn48(DemandeEnvoiMessageDTO demande) {
        try {
            HashSet<String> domaines = new HashSet<>();
            demande.getMessageDestinataires().forEach(dx -> domaines.add(dx.getDomain()));

            for (String d : domaines) {
                IndicateurJsonBuilder b = new IndicateurJsonBuilder();
                b.idIndic(IndicateurId.CPN48).juri(demande.getSender().getCodeSrj()).nb(1).domaine(d);
                IndicateurLogger.getInstance().info(b.toLogString());
            }
        } catch (Exception var6) {
            log.error(MESSAGE_LOG, IndicateurId.CPN48, ExceptionUtils.getMessage(var6));
        }
    }

    protected void logCpn49(List<MessageListDTO> messages, String codeSrj) {
        try {
            IndicateurJsonBuilder indic49 = new IndicateurJsonBuilder();
            indic49.idIndic(IndicateurId.CPN49).nb(messages.size()).juri(codeSrj);
            IndicateurLogger.getInstance().info(indic49.toLogString());
        } catch (JsonProcessingException e) {
            log.error(MESSAGE_LOG, IndicateurId.CPN49, ExceptionUtils.getMessage(e));
        }
    }

    protected void logCpn50(List<MessageListDTO> messages, String codeSrj) {
        try {
            EnumMap<OriginMessage, Integer> canaux = new EnumMap<>(OriginMessage.class);
            for (MessageListDTO message : messages) {
                OriginMessage origin = OriginMessage.valueOf(message.getOriginMessage());
                if (StringUtils.containsIgnoreCase(OriginMessage.PLEX.toString(), message.getOriginMessage())) {
                    origin = OriginMessage.PLEX;
                }
                if (StringUtils.containsIgnoreCase(OriginMessage.PLINE.toString(), message.getOriginMessage())) {
                    origin = OriginMessage.PLINE;
                }
                if (canaux.containsKey(origin)) {
                    canaux.put(origin, canaux.get(origin) + 1);
                } else {
                    canaux.put(origin, 1);
                }
            }
            for (Map.Entry<OriginMessage, Integer> origin : canaux.entrySet()) {
                IndicateurJsonBuilder b = new IndicateurJsonBuilder();
                b.idIndic(IndicateurId.CPN50)
                 .juri(codeSrj)
                 .nb(origin.getValue())
                 .canal(origin.getKey().toString());
                IndicateurLogger.getInstance().info(b.toLogString());
            }
        } catch (JsonProcessingException e) {
            log.error(MESSAGE_LOG, IndicateurId.CPN50, ExceptionUtils.getMessage(e));
        }
    }


    protected void logCpn14(DemandeEnvoiDocumentNppDTO demande) throws JsonProcessingException {
        try {
            IndicateurJsonBuilder indic = new IndicateurJsonBuilder();
            indic.idIndic(IndicateurId.CPN14)
                 .juri(demande.getCodeSrj())
                 .appli(AppName.NPP.toString())
                 .nb(demande.getDemandeEnvoiDocumentNppFiles().size());
            IndicateurLogger.getInstance().info(indic.toLogString());
        } catch (Exception e) {
            log.error("Problem log indicator {}. {}", IndicateurId.CPN14, ExceptionUtils.getMessage(e));
        }
    }

    protected void logCpn16(DemandeEnvoiDocumentNppDTO demande) throws JsonProcessingException {
        try {
            IndicateurJsonBuilder indic = new IndicateurJsonBuilder();
            indic.idIndic(IndicateurId.CPN16)
                 .juri(demande.getCodeSrj())
                 .appli(AppName.NPP.toString())
                 .nb(1);
            IndicateurLogger.getInstance().info(indic.toLogString());
        } catch (Exception e) {
            log.error("Problem log indicator {}. {}", IndicateurId.CPN16, ExceptionUtils.getMessage(e));
        }
    }

    private void logSendMessageByCanal(DemandeEnvoiMessageDTO message, IndicateurId indicateurId) {
        try {
            HashSet<Canal> canaux = new HashSet<>();
            message.getMessageDestinataires().forEach(d -> canaux.add(d.getCanal()));

            for (Canal c : canaux) {
                IndicateurJsonBuilder b = new IndicateurJsonBuilder();
                b.idIndic(indicateurId)
                 .juri(message.getSender().getCodeSrj())
                 .nb(1)
                 .canal(c.name());
                IndicateurLogger.getInstance().info(b.toLogString());
            }
        } catch (JsonProcessingException var6) {
            log.error(MESSAGE_LOG, indicateurId, ExceptionUtils.getMessage(var6));
        }
    }
}
