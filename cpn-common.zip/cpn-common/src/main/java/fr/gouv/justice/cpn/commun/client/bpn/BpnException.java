package fr.gouv.justice.cpn.commun.client.bpn;

public class BpnException extends Exception {

    public BpnException(final String message) {
        super(message);
    }

    public BpnException(final Throwable cause) {
        super(cause);
    }

    public BpnException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
