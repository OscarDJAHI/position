package fr.gouv.justice.cpn.commun.client.pfe;

import fr.gouv.justice.cpn.commun.client.common.AbstractWebClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;

abstract class AbstractPfeHttpClient extends AbstractWebClient {

    @Value("${pfe.mtls.base-url:changeme}")
    private String baseUrl;

    @Value("${pfe.mtls.stores.path:}")
    private String keyStoresPath;

    @Value("${pfe.mtls.stores.trust-store.name:pfe_truststore.jks}")
    private String trustStoreName;
    @Value("${pfe.mtls.stores.trust-store.type:PKCS12}")
    private String trustStoreType;
    @Value("${pfe.mtls.stores.trust-store.password:changeme}")
    private String trustStorePassword;

    @Value("${pfe.mtls.stores.key-store.name:cpn_keystore.jks}")
    private String keyStoreName;
    @Value("${pfe.mtls.stores.key-store.type:PKCS12}")
    private String keytStoreType;
    @Value("${pfe.mtls.stores.key-store.password:changeme}")
    private String keyStorePassword;
    @Value("${pfe.mtls.stores.key-store.private-key.password:changeme}")
    private String privateKeyPassword;

    @Override
    protected String getBaseUrl() {
        return this.baseUrl;
    }

    @Override
    protected SecureContext getSecureContext() {
        if (StringUtils.isEmpty(this.keyStoresPath)) {
            return null;
        }

        final LocalKeyStore keyStore = LocalKeyStore.builder()
                                                    .path(this.keyStoresPath + this.keyStoreName)
                                                    .type(this.keytStoreType)
                                                    .password(this.keyStorePassword)
                                                    .privateKeyPassword(this.privateKeyPassword)
                                                    .build();

        final LocalKeyStore trustStore = LocalKeyStore.builder()
                                                      .path(this.keyStoresPath + this.trustStoreName)
                                                      .type(this.trustStoreType)
                                                      .password(this.trustStorePassword)
                                                      .build();

        return AbstractWebClient.SecureContext.builder()
                                              .keyStore(keyStore)
                                              .trustStore(trustStore)
                                              .build();
    }
}
