// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

const URL_CPN_MAS_ECHANGE = '/api/mas-echanges';
const URL_CPN_MAS_INTERFACE_PLINE_PLEX = '/api/mas-interface-pline-plex';
const URL_CPN_MAS_ANNUAIRE = '/api/mas-annuaires';

export const environment = {

    production: false,
    REST_URL_BPN_INFO_UTILISATEUR: '/api/utilisateur',

    /**
     * Module message
     */
    REST_URL_CPN_MESSAGES_LEGACY: URL_CPN_MAS_ECHANGE + '/demandesEnvoiMessages',
    REST_URL_CPN_MESSAGES: URL_CPN_MAS_ECHANGE + '/demandes-envoi-messages/validation',
    REST_URL_CPN_SEND_MESSAGE_SYNCHRONE: URL_CPN_MAS_INTERFACE_PLINE_PLEX + '/sendMessageSynchrone',
    REST_URL_APPLICATION_NOTIDOC: URL_CPN_MAS_ECHANGE + '/application/notidoc/url',

    /**
     * Module contact
     */
    REST_URL_APPLICATION_DOMAIN_LIST: URL_CPN_MAS_ECHANGE + '/application/domaines',
    REST_URL_CONTACT_ANNUAIRE_CHECK: URL_CPN_MAS_INTERFACE_PLINE_PLEX + '/annuaires/check',
    REST_URL_CONTACT_ANNUAIRE: URL_CPN_MAS_INTERFACE_PLINE_PLEX + '/annuaires/contacts',
    REST_URL_CONTACT_AVOCAT_ANNUAIRE: URL_CPN_MAS_ANNUAIRE + '/contacts',
    /**
     * Module Mailbox
     */
    REST_URL_MAILBOX: URL_CPN_MAS_ECHANGE + '/boiteStructurelle',
    REST_URL_CHECK_BOITE_STRUCTURELLE: URL_CPN_MAS_ECHANGE + '/boiteStructurelle/check',
    REST_URL_CHECK_NOM_BOITE_STRUCTURELLE: URL_CPN_MAS_ECHANGE + '/boiteStructurelle/name',
    REST_URL_CHECK_MAIL_BOITE_STRUCTURELLE: URL_CPN_MAS_ECHANGE + '/boiteStructExistence',
    REST_URL_UPDATE_BOITES_STRUCTURELLES: URL_CPN_MAS_ECHANGE + '/boiteStructurelles',

    /**
     * CPN CONFIG
     */
    REST_URL_GET_CPN_CONFIG: URL_CPN_MAS_ECHANGE + '/settings/config',
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
