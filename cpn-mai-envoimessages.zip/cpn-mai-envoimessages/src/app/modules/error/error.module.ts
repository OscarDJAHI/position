import { NgModule } from '@angular/core';

import { GlobalErrorHandlerService } from './services/global-error-handler.service';
import { ErrorHandlerService } from './services/error-handler.service';

@NgModule({
    declarations: [],
    imports: [],
    exports: [],
    providers: [
        ErrorHandlerService,
        GlobalErrorHandlerService
    ],
    entryComponents: []
})
export class ErrorModule {
}
