import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { map } from 'rxjs/operators';
import { UserService } from 'src/app/modules/shared/services/user.service';
import { MailboxModel } from '../../models/mailbox.model';

@Component({
    selector: 'cpn-mailbox-manage-default',
    templateUrl: './mailbox-manage-default.component.html',
    styleUrls: ['./mailbox-manage-default.component.scss']
})
export class MailboxManageDefaultComponent implements OnInit {

    formGroup: FormGroup;
    mailboxes: MailboxModel[] = [];

    @Input() previousChoice: MailboxModel;

    constructor(
        public activeModal: NgbActiveModal,
        private userService: UserService
    ) {
    }

    ngOnInit(): void {
        const userInfo = this.userService.userInfo;
        let currentDefault: MailboxModel = userInfo.parametrage.defaultMailbox;

        this.formGroup = new FormGroup({
            email: new FormControl('', [Validators.required])
        });

        this.userService.userMailboxes$
            .pipe(map((data: MailboxModel[]) => {
                let mailBoxesFiltered: MailboxModel[] = data;
                if (currentDefault) {
                    mailBoxesFiltered = data.filter(el => el.email !== currentDefault.email);
                }

                let nominativeBox = data.find(el => el.nominative);
                if (currentDefault == null && nominativeBox == null) {
                    nominativeBox = {
                        id: undefined,
                        userId: userInfo.idLdap,
                        email: userInfo.mail,
                        name: '',
                        defaultBox: false,
                        nominative: true
                    };

                    mailBoxesFiltered.push(nominativeBox);
                }

                return mailBoxesFiltered;
            }))
            .subscribe((data: MailboxModel[]) => {
                this.mailboxes = data;

                if (this.previousChoice) {
                    currentDefault = this.previousChoice;
                }

                const currentDefaultView = data.find(el => el.email === currentDefault?.email);
                this.formGroup.patchValue({ email: currentDefaultView });
            });
    }

    onClose() {
        this.activeModal.dismiss('Cross click');
    }

    onValid() {
        const cepMail: MailboxModel = this.formGroup.get('email').value as MailboxModel;
        this.activeModal.close(cepMail);
    }
}
