import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderService } from 'ngx-ui-loader';

import { MailboxService } from 'src/app/modules/mailbox/services/mailbox.service';
import { UtilsService } from '../../../shared/services/utils.service';
import { UserInfoModel } from 'src/app/modules/shared/models/user-info.model';
import { MailboxModel } from '../../models/mailbox.model';
import { UserService } from 'src/app/modules/shared/services/user.service';

@Component({
    selector: 'app-delete-mailbox',
    templateUrl: './delete-mailbox.component.html',
    styleUrls: ['./delete-mailbox.component.scss']
})
export class DeleteMailboxComponent implements OnInit {

    form: FormGroup;

    mailbox: MailboxModel;
    mailboxes: Array<MailboxModel>;

    stepOne = true;
    stepTwo = false;
    stepThree = false;

    emailEmpty = false;
    invalidForm = true;

    constructor(
        public activeModal: NgbActiveModal,
        private userService: UserService,
        private mailboxService: MailboxService,
        private ngxUiLoaderService: NgxUiLoaderService
    ) { }

    ngOnInit() {
        this.form = new FormGroup({
            id: new FormControl(''),
            boxName: new FormControl(''),
            email: new FormControl(''),
        });

        this.mailbox = {
            id: '',
            name: '',
            email: '',
            userId: '',
            access: true
        };

        this.mailboxService.mailboxes$.subscribe(
            data => {
                this.mailboxes = data.filter((box: MailboxModel) => !box.nominative);
            },
            error => {
                UtilsService.printMessage(error, 'to get mailboxes');
            }
        );
    }

    setMailbox() {
        this.mailbox = this.mailboxes.find(r => r.email === this.form.get('email').value);
        this.form.patchValue({ boxName: this.mailbox.name });
        this.form.patchValue({ id: this.mailbox.id });

        this.emailEmpty = false;
        this.invalidForm = false;
    }

    confirmMailboxDeletion() {
        if (this.form.get('email').value.length === 0) {
            this.emailEmpty = true;
            this.invalidForm = true;
        } else {
            this.invalidForm = false;
            this.stepOne = false;
            this.stepTwo = true;
        }
    }

    deleteMailbox() {
        if (this.form.get('email').value.length === 0) {
            this.emailEmpty = true;
            this.invalidForm = true;
        } else {
            this.emailEmpty = false;
            this.invalidForm = false;
            this.ngxUiLoaderService.startLoader('loader-mailbox-delete');
            this.mailboxService.deleteMailbox(this.mailbox.id).subscribe(
                () => {
                    this.ngxUiLoaderService.stopLoader('loader-mailbox-delete');
                    this.stepTwo = false;
                    this.stepThree = true;
                    this.updateDefaultMailBoxIfDeletedWasDefaultOne(this.mailbox.email);
                },
                () => {
                    this.ngxUiLoaderService.stopLoader('loader-mailbox-delete');
                }
            );
        }
    }

    private updateDefaultMailBoxIfDeletedWasDefaultOne(email: string) {
        const userInfo: UserInfoModel = this.userService.userInfo;
        if (this.userService.hasDefaultMailbox() && email === userInfo.parametrage?.defaultMailbox.email) {
            this.userService.reInitializeNominativMailboxAsDefaultOne();
        }
    }
}
