import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';

import { NgbActiveModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderModule } from 'ngx-ui-loader';

import { DeleteMailboxComponent } from './delete-mailbox.component';
import { DataService } from '../../../shared/services/data.service';

describe('DeleteBoiteStructurelleComponent', () => {
    let component: DeleteMailboxComponent;
    let fixture: ComponentFixture<DeleteMailboxComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [DeleteMailboxComponent],
                imports: [
                    NgxUiLoaderModule,
                    FormsModule,
                    NgbModule,
                    ReactiveFormsModule,
                    RouterTestingModule,
                    HttpClientModule
                ],
                providers: [
                    NgbActiveModal,
                    DataService
                ]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(DeleteMailboxComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
