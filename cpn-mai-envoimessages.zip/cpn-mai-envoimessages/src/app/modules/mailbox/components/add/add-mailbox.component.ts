import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderService } from 'ngx-ui-loader';

import { MailboxService } from 'src/app/modules/mailbox/services/mailbox.service';
import { ModalService } from '../../../shared/services/modal.service';
import { UserService } from 'src/app/modules/shared/services/user.service';
import { UserInfoModel } from 'src/app/modules/shared/models/user-info.model';
import { MailboxModel } from '../../models/mailbox.model';
import { ModalContent } from '../../../shared/models/modal-content.model';
import { MessageConstants } from '../../../message/constants/message.constants';

@Component({
    selector: 'app-add-mailbox',
    templateUrl: './add-mailbox.component.html',
    styleUrls: ['./add-mailbox.component.scss']
})
export class AddMailboxComponent implements OnInit {

    user: UserInfoModel;

    mailbox: MailboxModel;
    alertModalContent: ModalContent;

    emailEmpty = false;
    emailInvalid = false;
    emailAlreadyExist = false;
    invalidForm = true;
    nameAlreadyExist = false;
    isBSMailboxNotExist = false;
    noAccess = false;

    modalTilte = 'Ajouter - Boite structurelle';
    form: FormGroup;
    closeForm = false;
    showSuccessMsg = false;
    reqSpinner = false;

    constructor(
        public activeModal: NgbActiveModal,
        private userService: UserService,
        private mailboxService: MailboxService,
        private ngxUiLoaderService: NgxUiLoaderService,
        private modalService: ModalService
    ) {
    }

    ngOnInit() {
        this.user = this.userService.userInfo;
        this.form = new FormGroup({
            boxName: new FormControl(''),
            email: new FormControl(''),
        });

        this.mailbox = {
            id: '',
            name: '',
            email: '',
            userId: '',
            access: true
        };

        this.alertModalContent = {
            title: '',
            message: ''
        };
    }

    checkEmail() {
        const email = this.form.get('email').value.trim();
        const emailOk = MessageConstants.EMAIL_PATTERN.test(email);

        if (email.length === 0) {
            this.emailEmpty = true;
            this.invalidForm = true;
            this.emailInvalid = false;
        } else if (!emailOk) {
            this.emailEmpty = false;
            this.emailInvalid = true;
            this.invalidForm = true;
        } else {
            this.checkMailboxByEmail();
            this.emailInvalid = false;
            this.invalidForm = false;
            this.emailEmpty = false;
        }

        this.emailAlreadyExist = false;
        this.nameAlreadyExist = false;
        this.isBSMailboxNotExist = false;
        this.noAccess = false;
    }

    checkMailboxByName() {
        const boxName = this.form.get('boxName').value.trim();
        if (boxName.length !== 0) {
            this.mailboxService.checkMailboxByName(boxName).subscribe(
                data => {
                    if (data === null) {
                        this.nameAlreadyExist = false;
                    } else {
                        this.nameAlreadyExist = true;
                        this.invalidForm = true;
                    }
                },
                error => {
                    this.ngxUiLoaderService.stopLoader('loader-mailbox-create');
                    this.showErrors(error);
                }
            );
        }
    }

    checkMailboxByEmail() {
        this.reqSpinner = true;

        this.mailboxService.checkMailboxByEmail(this.form.get('email').value.trim().toLocaleLowerCase()).subscribe(
            data => {
                this.reqSpinner = false;
                if (data === true) {
                    this.isBSMailboxNotExist = false;
                    this.noAccess = false;
                    this.checkMailboxAuthorization();
                } else {
                    this.ngxUiLoaderService.stopLoader('loader-mailbox-create');
                    this.noAccess = false;
                    this.isBSMailboxNotExist = true;
                    this.invalidForm = true;
                }
            },
            error => {
                this.invalidForm = true;
                this.emailInvalid = true;
                this.reqSpinner = false;
                this.ngxUiLoaderService.stopLoader('loader-mailbox-create');

                this.showErrors(error);
            }
        );
    }

    checkMailboxAuthorization() {
        this.reqSpinner = true;

        this.mailboxService.checkMailboxAuthorization(this.form.get('email').value.trim().toLocaleLowerCase()).subscribe(
            data => {
                this.reqSpinner = false;
                const mailbox: MailboxModel = data[0];
                if (mailbox.access) {
                    this.ngxUiLoaderService.stopLoader('loader-mailbox-create');
                    this.noAccess = false;
                } else {
                    this.ngxUiLoaderService.stopLoader('loader-mailbox-create');
                    this.noAccess = true;
                    this.invalidForm = true;
                }
            },
            error => {
                this.reqSpinner = false;
                this.ngxUiLoaderService.stopLoader('loader-mailbox-create');

                this.showErrors(error);
            }
        );
    }

    addMailbox() {
        if (!this.invalidForm) {
            this.emailEmpty = false;
            this.ngxUiLoaderService.startLoader('loader-mailbox-create');
            this.mailbox.name = this.form.get('boxName').value;
            this.mailbox.email = this.form.get('email').value.toLocaleLowerCase();
            this.mailbox.userId = this.user.idLdap;

            this.mailboxService.createMailbox(this.mailbox).subscribe(
                () => {
                    this.ngxUiLoaderService.stopLoader('loader-mailbox-create');
                    this.modalTilte = 'Information';
                    this.closeForm = true;
                    this.showSuccessMsg = true;
                },
                error => {
                    this.ngxUiLoaderService.stopLoader('loader-mailbox-create');
                    if (error.error.includes('cepmail_already_added')) {
                        this.emailAlreadyExist = true;
                        this.invalidForm = true;
                    } else {
                        this.showErrors(error);
                    }
                }
            );
        } else {
            this.invalidForm = false;
            this.emailInvalid = false;
        }
    }

    private showErrors(error) {
        console.log('Status error : ', error.status);
        console.log('Msg error : ', error.statusText);
    }
}
