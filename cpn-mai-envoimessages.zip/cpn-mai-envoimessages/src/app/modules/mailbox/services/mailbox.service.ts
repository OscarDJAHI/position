import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { BehaviorSubject, Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { MailboxModel } from '../models/mailbox.model';

@Injectable()
export class MailboxService {

    // Broadcast user structural mail box to all components
    private mailboxes = new BehaviorSubject<Array<MailboxModel>>(null);
    mailboxes$ = this.mailboxes.asObservable();

    constructor(protected http: HttpClient) {
    }

    all(): Observable<MailboxModel[]> {
        this.http.get<MailboxModel[]>(environment.REST_URL_MAILBOX).subscribe(
            data => this.mailboxes.next(data),
            error => this.mailboxes.error(error));

        return this.mailboxes$;
    }

    createMailbox(mailbox: MailboxModel): Observable<MailboxModel> {
        return new Observable<MailboxModel>(observer => {
            this.http.post<MailboxModel>(environment.REST_URL_MAILBOX, mailbox).subscribe(
                createdMailbox => {
                    const mailboxes = this.currentMailboxes();
                    mailboxes.push(createdMailbox);
                    mailboxes.sort();

                    this.mailboxes.next(mailboxes);
                    observer.next(createdMailbox);
                },
                error => observer.error(error),
                () => observer.complete()
            );
        });
    }

    deleteMailbox(id: any): Observable<any> {
        return new Observable<MailboxModel>(observer => {
            this.http.delete(environment.REST_URL_MAILBOX, { params: { id } }).subscribe(
                () => {
                    const mailboxes = this.currentMailboxes().filter(mailbox => mailbox.id !== id);
                    mailboxes.sort();

                    this.mailboxes.next(mailboxes);
                    observer.next();
                },
                error => observer.error(error),
                () => observer.complete()
            );
        });
    }

    checkMailboxAuthorization(emails: any): Observable<any> {
        return this.http.get(environment.REST_URL_CHECK_BOITE_STRUCTURELLE, { params: { mailBoxesMail: emails } });
    }

    checkMailboxByName(name: any): Observable<any> {
        return this.http.get(environment.REST_URL_CHECK_NOM_BOITE_STRUCTURELLE, { params: { mailBoxName: name } });
    }

    checkMailboxByEmail(email: any): Observable<any> {
        return this.http.get(environment.REST_URL_CHECK_MAIL_BOITE_STRUCTURELLE, { params: { mailBoxMail: email } });
    }

    updateMailBoxes(mailBoxes: MailboxModel[]): Observable<MailboxModel[]> {
        return this.http.put<MailboxModel[]>(environment.REST_URL_UPDATE_BOITES_STRUCTURELLES, mailBoxes);
    }

    updateMailBox(mailBox: MailboxModel): Observable<MailboxModel> {
        return this.http.put<MailboxModel>(environment.REST_URL_MAILBOX, mailBox);
    }

    private currentMailboxes(): Array<MailboxModel> {
        return this.mailboxes.getValue() || new Array<MailboxModel>();
    }
}
