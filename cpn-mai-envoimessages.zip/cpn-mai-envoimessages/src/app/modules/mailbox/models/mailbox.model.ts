export interface MailboxModel {
    id: string;
    name: string;
    email: string;
    userId: string;
    access?: boolean;
    defaultBox?: boolean;
    nominative?: boolean;
}
