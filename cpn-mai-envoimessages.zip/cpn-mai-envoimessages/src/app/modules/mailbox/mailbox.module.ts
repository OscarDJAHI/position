import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { AddMailboxComponent } from './components/add/add-mailbox.component';
import { DeleteMailboxComponent } from './components/delete/delete-mailbox.component';
import { MailboxManageDefaultComponent } from './components/manage-default/mailbox-manage-default.component';
import { MailboxService } from './services/mailbox.service';


@NgModule({
    declarations: [
        AddMailboxComponent,
        DeleteMailboxComponent,
        MailboxManageDefaultComponent
    ],
    exports: [
        AddMailboxComponent,
        DeleteMailboxComponent
    ],
    imports: [
        SharedModule
    ],
    entryComponents: [
        AddMailboxComponent,
        DeleteMailboxComponent,
        MailboxManageDefaultComponent
    ],
    providers: [
        MailboxService
    ]
})
export class MailboxModule {
}
