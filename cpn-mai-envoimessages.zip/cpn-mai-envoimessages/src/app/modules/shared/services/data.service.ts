import { EventEmitter, Injectable } from '@angular/core';

@Injectable()
export class DataService {

    // use to emit true when the write new mail modal component is destroy
    openTinyWindowRequest: EventEmitter<boolean> = new EventEmitter();
}
