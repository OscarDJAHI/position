import { TestBed } from '@angular/core/testing';

import { CpnConfigService } from './cpn-config.service';

describe('CpnConfigService', () => {
  let service: CpnConfigService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CpnConfigService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
