import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';

import { BehaviorSubject, Observable } from 'rxjs';
import { filter, take, tap } from 'rxjs/operators';

import { environment } from "../../../../environments/environment";
import { Injectable } from "@angular/core";
import { UserInfoModel } from '../models/user-info.model';

@Injectable()
export class AuthenticationService {

    enAttenteDeUnlock = new BehaviorSubject(false);

    /**
     * Un Behaviorsubject qui permet de récupérer les informations sur l'utilisateur.
     */
    private _userInfo$ = new BehaviorSubject<UserInfoModel>(null);

    constructor(private httpClient: HttpClient, private router: Router) {
    }

    /**
     * Retourne un Observable qui contient l'utilisateur actif pour cette session.
     * @returns un observable de userInfo.
     */
    user(): Observable<UserInfoModel> {
        return this._userInfo$.asObservable();
    }

    /**
     *  Met à jour le BehaviorSubject lié à l'utilisateur
     */
    setUser(user: UserInfoModel): void {
        this._userInfo$.next(user);
    }

    /**
     * Retourne un observable qui permet de savoir si l'utilisateur est connecté avec les bon droits ou non.
     * @param forcerRedirection true si l'utilisateur veut aller à sa page d'accueil
     */
    authenticate(tkn: string) {
        const urlGetInformationsUtilisateur = environment.REST_URL_BPN_INFO_UTILISATEUR;

        let takeTknFromHeader = tkn != null && tkn.length > 0;
        return this.httpClient
            .get(urlGetInformationsUtilisateur, { headers: new HttpHeaders().set('Authorization', 'Bearer ' + tkn).set("isModaleAuthentification", takeTknFromHeader.toString()) })
            .pipe(
                filter(Boolean),
                take(1),
                tap((userInfo: UserInfoModel) => {
                    this.setUser(userInfo);
                })
            )
            .subscribe();
    }

    /**
     * Permet de déconnecter l'utilisateur de l'application
     */
    disconnect(): void {
        // windows.location kill l'application avant que les OnDestroy ait fini de travailler.
        // Pour temporiser, si on attent un delock on redirige vers une page vide pour déclencher
        // le unloock et on kill l'application après.
        // Si on est pas en attente d'un delock, on kill l'application directement
        if (this.enAttenteDeUnlock.value) {
            this.router.navigate(['/deconnexion']).then(() => {
                this.enAttenteDeUnlock.pipe(
                    filter(lock => !lock)
                ).subscribe(lock => {
                    window.location.href = '/saml/logout';
                });
            });
        } else {
            window.location.href = '/saml/logout';
        }
    }
}
