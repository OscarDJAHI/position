import { Injectable } from '@angular/core';

@Injectable()
export class UtilsService {

    static formatDate(value: string): Date {
        let dt = new Date();
        if (value.length > 0) {
            dt = new Date(value);
        }

        return dt;
    }

    static isListEmpty(list: any[]) {
        return !list || !list.length;
    }

    static isStringEmpty(value: string) {
        return !value || !value.length;
    }

    static printMessage(fail: any, service: string) {
        console.error(`Sorry ! Something went wrong when trying to ${service} -> Please see details belows`);
        console.error(UtilsService.toMessage(fail));
    }

    static toMessage(fail: any) {
        if (typeof (fail.error) === 'object') {
            return fail.error.hasOwnProperty('response') ? fail.error.response : fail.message;
        }

        return fail.error;
    }
}
