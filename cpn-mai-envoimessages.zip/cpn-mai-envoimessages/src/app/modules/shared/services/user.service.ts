import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { BehaviorSubject } from 'rxjs';
import { take } from 'rxjs/operators';
import { MailboxService } from '../../mailbox/services/mailbox.service';
import { UserInfoModel } from '../models/user-info.model';
import { MailboxModel } from '../../mailbox/models/mailbox.model';

@Injectable({
    providedIn: 'root'
})
export class UserService {

    // Broadcast user structural mail box to all components
    private userMailboxes = new BehaviorSubject<MailboxModel[]>(null);
    userMailboxes$ = this.userMailboxes.asObservable();

    userInfo: UserInfoModel;

    constructor(
        protected http: HttpClient,
        private mailBoxServices: MailboxService
    ) {
    }

    hasDefaultMailbox(): boolean {
        return !!(this.userInfo.parametrage && this.userInfo.parametrage.defaultMailbox);
    }

    reInitializeNominativMailboxAsDefaultOne() {
        this.userMailboxes$
            .pipe(take(1))
            .subscribe(
                (data: MailboxModel[]) => {
                    if (data && data.length > 0) {
                        const nominativeBox = data.find(boxe => boxe.nominative);
                        if (nominativeBox) {
                            nominativeBox.defaultBox = true;
                            this.saveNominativeMailboxAsDefaultOneInDataBase(nominativeBox);
                        }
                    }
                });
    }

    saveNominativeMailboxAsDefaultOneInDataBase(nominativeBox: MailboxModel) {
        this.mailBoxServices.updateMailBox(nominativeBox).subscribe(
            () => {
                const user = this.userInfo;
                user.parametrage.defaultMailbox = nominativeBox;
                this.userInfo = user;
            },
            error => {
                console.error(error);
            }
        );
    }

    updateOrCreateUserParametersWithDefaultMailbox(mailBoxes: MailboxModel[]) {
        if (mailBoxes) {
            const defaultCepMail: MailboxModel = mailBoxes.find(el => el.defaultBox);
            const userInfo = this.userInfo;

            if (userInfo.parametrage) {
                userInfo.parametrage.defaultMailbox = defaultCepMail;
            } else {
                userInfo.parametrage = { defaultMailbox: defaultCepMail };
            }

            this.userInfo = userInfo;
        }
    }

    updateUserCepMails(mails: MailboxModel[]) {
        this.userMailboxes.next(mails);
    }
}
