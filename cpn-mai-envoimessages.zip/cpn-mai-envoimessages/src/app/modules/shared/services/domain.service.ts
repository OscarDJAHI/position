import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Injectable } from '@angular/core';

@Injectable()
export class DomainService {

    constructor(private http: HttpClient) {
    }

    getDomains(appName: string): Observable<any> {
        return this.http.get(`${ environment.REST_URL_APPLICATION_DOMAIN_LIST }/${ appName }`);
    }

    getUrlNotidoc(): Observable<any> {
        return this.http.get(environment.REST_URL_APPLICATION_NOTIDOC, {responseType: 'text'});
    }
}
