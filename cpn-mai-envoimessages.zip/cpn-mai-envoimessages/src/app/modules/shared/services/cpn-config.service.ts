import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { CpnConfig } from '../models/cpn-config.model';

@Injectable({
    providedIn: 'root'
})
export class CpnConfigService {

    constructor(protected http: HttpClient) {
        /* silence is golden sonar !! */
    }

    cpnConfig: CpnConfig;

    getCpnConfig(): Observable<CpnConfig> {
        return this.http.get<CpnConfig>(environment.REST_URL_GET_CPN_CONFIG);
    }
}
