import { Injectable } from '@angular/core';

import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

import { ErrorModalComponent } from '../modals/error-modal/error-modal.component';
import { SuccessModalComponent } from '../modals/success-modal/success-modal.component';
import { ModalContent } from '../models/modal-content.model';
import { ModalConstants } from '../constants/modal.constants';
import { ValidationModalComponent } from '../modals/validation-modal/validation-modal.component';

@Injectable()
export class ModalService {

    constructor(private modalService: NgbModal) {
    }

    openGenericErrorModal() {
        this.openErrorModal({
            title: ModalConstants.GENERIC_ERROR_TITLE,
            message: ModalConstants.GENERIC_ERROR_MESSAGE
        });
    }

    openGenericValidationModal() {
        this.openErrorModal({
            title: ModalConstants.GENERIC_ERROR_TITLE,
            message: ModalConstants.GENERIC_ERROR_MESSAGE
        });
    }

    openErrorModal(modalContent: ModalContent) {
        const options = { centered: true, windowClass: 'cpn-error-modal', size: 'none' };

        const modal = this.modalService.open(ErrorModalComponent, options);
        modal.componentInstance.title = modalContent.title;
        modal.componentInstance.message = modalContent.message;
    }

    openSuccessModal(modalContent: ModalContent) {
        const options = { centered: true, windowClass: 'cpn-succes-modal', size: 'none' };

        const modal = this.modalService.open(SuccessModalComponent, options);
        modal.componentInstance.title = modalContent.title;
        modal.componentInstance.message = modalContent.message;
    }

    openValidationModal(modalContent: ModalContent): NgbModalRef {
        const options = { centered: true, windowClass: 'cpn-succes-modal', size: 'none' };
        const modal = this.modalService.open(ValidationModalComponent, options);
        modal.componentInstance.title = modalContent.title;
        modal.componentInstance.message = modalContent.message;

        return modal;
    }
}
