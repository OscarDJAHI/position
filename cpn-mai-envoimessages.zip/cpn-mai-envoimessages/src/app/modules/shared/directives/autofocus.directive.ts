import { AfterViewInit, Directive, ElementRef, Renderer2 } from '@angular/core';

@Directive({
    selector: '[autofocus]',
})
export class AutofocusDirective implements AfterViewInit {

    constructor(private hostElement: ElementRef, private renderer: Renderer2) {
    }

    ngAfterViewInit(): void {
        this.hostElement.nativeElement.focus();
    }
}
