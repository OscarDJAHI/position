export const ModalConstants = {

    GENERIC_ERROR_TITLE: 'Demande non enregistrée',

    GENERIC_ERROR_MESSAGE: 'Un problème est survenue lors de votre requête, veuillez réessayer plus tard. Si le problème persiste, contactez le service informatique.'
}
