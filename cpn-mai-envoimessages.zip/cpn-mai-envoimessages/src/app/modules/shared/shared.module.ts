import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { NgxUiLoaderModule } from 'ngx-ui-loader';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AuthenticationService } from './services/authentication.service';
import { DomainService } from './services/domain.service';
import { DataService } from './services/data.service';
import { ModalService } from './services/modal.service';
import { UtilsService } from './services/utils.service';

import { ConfirmModalComponent } from './modals/confirm-modal/confirm-modal.component';
import { ErrorModalComponent } from './modals/error-modal/error-modal.component';
import { SuccessModalComponent } from './modals/success-modal/success-modal.component';

import { AutofocusDirective } from './directives/autofocus.directive';
import { ValidationModalComponent } from './modals/validation-modal/validation-modal.component';

@NgModule({
    declarations: [
        ConfirmModalComponent,
        ErrorModalComponent,
        SuccessModalComponent,
        ValidationModalComponent,
        AutofocusDirective
    ],
    imports: [
        CommonModule,
        FormsModule,
        HttpClientModule,
        NgbModule,
        NgxUiLoaderModule,
        ReactiveFormsModule,
        RouterModule
    ],
    exports: [
        CommonModule,
        FormsModule,
        HttpClientModule,
        NgbModule,
        NgxUiLoaderModule,
        ReactiveFormsModule,
        RouterModule,

        ConfirmModalComponent,
        ErrorModalComponent,
        SuccessModalComponent,

        AutofocusDirective
    ],
    entryComponents: [
        ConfirmModalComponent,
        ErrorModalComponent,
        SuccessModalComponent
    ],
    providers: [
        AuthenticationService,
        DomainService,
        DataService,
        ModalService,
        UtilsService
    ]
})
export class SharedModule {
}
