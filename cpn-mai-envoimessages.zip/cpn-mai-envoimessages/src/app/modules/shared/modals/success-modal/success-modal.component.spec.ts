import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { NgxUiLoaderModule } from 'ngx-ui-loader';

import { DataService } from '../../services/data.service';
import { SuccessModalComponent } from './success-modal.component';

describe('SuccesModalComponent', () => {
    let component: SuccessModalComponent;
    let fixture: ComponentFixture<SuccessModalComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [SuccessModalComponent],
                imports: [
                    NgxUiLoaderModule,
                    FormsModule,
                    ReactiveFormsModule,
                    HttpClientModule
                ],
                providers: [
                    NgbActiveModal,
                    DataService
                ]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(SuccessModalComponent);
        component = fixture.componentInstance;
        // fixture.detectChanges();
    });

    beforeEach(function () {
        jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
