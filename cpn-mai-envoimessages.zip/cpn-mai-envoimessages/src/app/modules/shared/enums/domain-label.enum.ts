export enum DomainLabelEnum {
    HUISSIER = 'HUISSIER',
    AVOCAT = 'AVOCATS'
}
