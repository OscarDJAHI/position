export interface CpnConfig {
    version: string;
    alerteIntervallPooling: number;
    alerteMessagePooling: number;
    rechercheEnable: boolean;
    prefixBalsCanSentViaExchange: string[];
    modalSendMessageEnable: boolean;
    modalDocumentDepositEnable: boolean;
    searchAvocatFromAnuaireEnable: boolean;
}
