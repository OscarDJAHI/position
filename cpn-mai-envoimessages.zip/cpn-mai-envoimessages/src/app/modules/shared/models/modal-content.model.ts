export interface ModalContent {
    title: string;
    message: string;
}
