import { MailboxModel } from "../../mailbox/models/mailbox.model";

/**
 * Représente les informations d'un utilisateur connecté.
 */
export interface UserInfoModel {

    idLdap?: string;
    nom: string;
    prenom?: string;
    idJuridiction?: string;
    bureauIGC?: string;
    roles?: string[];
    permissions?: string[];
    idsJuridictions?: number[];
    igcId?: string;
    bureau?: string;
    mail?: string;
    token?: string;
    parametrage?: UserParameters;
}

export interface UserParameters {
    defaultMailbox?: MailboxModel
}
