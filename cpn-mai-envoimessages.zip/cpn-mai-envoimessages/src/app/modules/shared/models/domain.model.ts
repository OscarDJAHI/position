export interface Domain {
    id?: number;
    label: string;
    value: string;
    selected?: boolean;
    disabled?: boolean;
    canal: string;
    mails: string[];
    editable: boolean;
}
