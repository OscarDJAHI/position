import { NgModule } from '@angular/core';

import { CacheInterceptor } from './services/cache-interceptor';
import { CustomHttpInterceptor } from './services/http-interceptor';
import { TokenInterceptor } from './services/token-interceptor';

@NgModule({
    declarations: [],
    imports: [],
    exports: [],
    providers: [
        CacheInterceptor,
        CustomHttpInterceptor,
        TokenInterceptor
    ],
    entryComponents: []
})
export class InterceptorModule {
}
