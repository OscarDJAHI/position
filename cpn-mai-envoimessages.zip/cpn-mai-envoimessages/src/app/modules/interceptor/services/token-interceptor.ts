import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { ActivatedRoute, Params } from '@angular/router';

import { Observable } from 'rxjs';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {

    private tokenParameterName = 'token';
    private tokenCookieName = 'tkn';

    constructor(private route: ActivatedRoute) {
        this.route.queryParams.subscribe((params: Params) => {
            localStorage.setItem(this.tokenCookieName, params[this.tokenParameterName]);
            console.log('in TokenInterceptor constructor ', params[this.tokenParameterName]);
        });
    }

    /**
     * Interception des URLS de type HTTP.
     * Récupération du JWT et insertion dans les headers de chaque requête http vers les serveurs.
     *
     * @param request , le type de requetes REST à intercepter.
     * @param next , handler pour les requêtes HTTP.
     */
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        // add authorization header with basic auth credentials if available
        const token = localStorage.getItem(this.tokenCookieName);

        if (token) {
            request = request.clone({
                setHeaders: {
                    Authorization: `Bearer eyJjdHkiOiJKV1QiLCJlbmMiOiJBMTI4R0NNIiwiYWxnIjoiZGlyIn0..0C_iRHx8CeVTLq05.N9sYx0V2o1k7LS7pIu4d2IhSTqTiGgh_OhIMNl27VE08F5NTk6W5r0eLa7iFVjWmUqzqBDt0mfA4lER0VLlzTljKgeRj9a9XIu9DDbYd1DJXsSB6mx6xhYLjk5JhcA_0pStrQzL845wAZCV4xmZ3NwcsfMXJyml13WburRnxncgNcIK5TaRERbJtszgFLuZH0hlFkXO9WqCcBXAw5JmC0dyju5Zia5lhGKNjHgkYVaoMGt4exz8OJapREvFAzPCMe5z7xmTVigQv6uH6p2zwl_9o0MQsNQeBumLj_6SZK3wvBJvmH3zyQu8b3WroHHEnx0qO4jJkC-SZK22advgrm3JmA7-tAZQG_SSkgDE7Yf9ribTzsNFus472a9P-MFq5WD6x7MvK8tHD7-ksnqW6zAzi4GUKgch2qso8ULLsKHisbmHc2sGqPe_TXpnPbJ_I3Esh2h0XZdU0vpWLJy19mTvqsKGV_ZGgvARg8NpOLQJi4aaicSjD8dlznQw-BOPAdO7BnKkn_rueCGFn9908RF4XDhe0QhWtWxvaWr7sr6XK1Gx7FAMAV6rXVeDFUqZjDwhwBngNNLv_klyAROXZOipYYxWDA3LN9cJxJ4ghIsf2JYzPq7L77TmINvhlulzRvo1cooCH0xZKFaMNwm0AHpr_cQtapOkNjTnhlc0UBGuTwlQiaqt2x86UWrRu-zbLsW7qK7RgQ4t-gkDHGNZHaR-wuESYiCpLQdVDbmwdccK44pyeuo0BgwOuRg4IbQ_Ak3Cf7Gu9Ejigl0t-P04WZ-JzvfnpteHPqID-ej8ubfW3mxd2IPIhkwqvDG_gqjp4oe85rzx9cH8gfcMqFWff0ibHoGMyb9X81_uBAgsdHUog0HDS2F2Qf4uU5Cl_whrVsfAosjb1bqUtr8hnE_x1jQbAqM9bJqHD-vURNFLIpvpvckJj9aHMu1JOV9rKFQCRhnwpFKcXrU5zVz-b44uN5Z6Akpx168Blq5UVwiEJ3Kp8qEnuEsZzED6t3kd8Obl1fWezL7_ntL10NLVXgeWz9YfEAQRGe0pIfmC0fCGv5OsIWc6F1KS4nWlfrbWofP6fjcnaLiobBLfBBsyRkHSt_mL6I2A.seTKHELtOUdABu70L4UsUQ`
                }
            });
        }

        return next.handle(request);
    }
}
