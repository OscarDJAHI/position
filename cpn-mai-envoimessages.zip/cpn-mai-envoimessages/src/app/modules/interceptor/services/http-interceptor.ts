import { Injectable } from '@angular/core';
import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';

import { ErrorHandlerService } from '../../error/services/error-handler.service';

@Injectable()
export class CustomHttpInterceptor implements HttpInterceptor {

    constructor(private errorHandlerService: ErrorHandlerService) {
    }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(request)
            .pipe(
                retry(0),
                catchError((error: HttpErrorResponse) => {
                    switch (error.status) {
                        case 418:
                            break;
                        case 401:
                            console.log('HttpErrorInterceptor -> ERREUR 401');
                            this.errorHandlerService.redirectLogin();
                            break;
                        case 403:
                            console.log('HttpErrorInterceptor -> ERREUR 403');
                            this.errorHandlerService.redirectForbidden();
                            break;
                        default:
                            console.error('HttpErrorInterceptor -> ', error);
                            break;
                    }
                    return throwError(error);
                })
            );
    }
}
