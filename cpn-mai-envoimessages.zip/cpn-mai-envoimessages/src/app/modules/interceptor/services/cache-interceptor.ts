import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';

import { Observable } from 'rxjs';

@Injectable()
export class CacheInterceptor implements HttpInterceptor {

    /**
     * Interception des URLS de type HTTP.
     * No-cache supported
     *
     * @param request , le type de requetes REST à intercepter.
     * @param next , handler pour les requêtes HTTP.
     */
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        const customRequest = request.clone({
            setHeaders: {
                'catch-control': 'no-cache',
                Pragma: 'no-cache'
            }
        });
        return next.handle(customRequest);
    }
}
