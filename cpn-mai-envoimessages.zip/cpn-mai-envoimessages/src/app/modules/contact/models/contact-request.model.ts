import { Contact } from './contact.model';

export class ContactRequest extends Contact {
    constructor(uid?: string, canal?: string, firstName?: string, lastName?: string, email?: string, domain?: string) {
        super(uid, canal, firstName, lastName, email, domain);
    }
}
