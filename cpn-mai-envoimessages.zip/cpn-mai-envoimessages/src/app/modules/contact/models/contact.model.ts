export class Contact {
    uid: string;
    canal: string;
    firstName: string;
    lastName: string;
    email?: string;
    domain?: string

    constructor(uid?: string, canal?: string, firstName?: string, lastName?: string, email?: string, domain?: string) {
        this.uid = uid || '';
        this.canal = canal || '';
        this.firstName = firstName || '';
        this.lastName = lastName || '';
        this.email = email;
        this.domain = domain || '';
    }
}
