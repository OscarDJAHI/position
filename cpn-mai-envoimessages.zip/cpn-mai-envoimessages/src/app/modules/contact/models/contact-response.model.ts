import { Contact } from './contact.model';

export interface Error {
    type: string;
    code: string;
    message: string;
}

export interface ContactResponse {
    contacts: Array<Contact>;
    erreurs: Array<Error>
}
