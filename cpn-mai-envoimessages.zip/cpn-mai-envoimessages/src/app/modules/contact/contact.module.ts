import { NgModule } from '@angular/core';

import { ContactService } from './services/contact.service';

@NgModule({
    declarations: [],
    imports: [],
    exports: [],
    providers: [
        ContactService
    ],
    entryComponents: []
})
export class ContactModule {
}
