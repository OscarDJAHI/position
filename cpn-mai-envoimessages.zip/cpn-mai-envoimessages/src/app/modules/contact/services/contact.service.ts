import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { ContactRequest } from '../models/contact-request.model';
import { DomainLabelEnum } from '../../shared/enums/domain-label.enum';
import { CpnConfigService } from '../../shared/services/cpn-config.service';

@Injectable()
export class ContactService {

    constructor(protected http: HttpClient,
                private cpnConfigService: CpnConfigService) {
    }

    checkContact(canal: string, emails: string) {
        return this.http.get<any>(environment.REST_URL_CONTACT_ANNUAIRE_CHECK,
            {
                params: {
                    canal,
                    emails
                }
            });
    }

    searchContacts(searchRequest: ContactRequest): Observable<any> {
        const searchAvocatFromAnuaireEnable: boolean = this.cpnConfigService.cpnConfig.searchAvocatFromAnuaireEnable;
        if (DomainLabelEnum.AVOCAT === searchRequest.domain && searchAvocatFromAnuaireEnable) {
            return this.searchAvocat(searchRequest);
        }

        return this.searchContactsViaPlinePlex(searchRequest);
    }

    private searchContactsViaPlinePlex(searchRequest: ContactRequest): Observable<any> {
        return this.http.get<any>(environment.REST_URL_CONTACT_ANNUAIRE,
            {
                params: this.buildSearchParams(searchRequest)
            });
    }

    private searchAvocat(searchRequest: ContactRequest): Observable<any> {
        return this.http.get<any>(environment.REST_URL_CONTACT_AVOCAT_ANNUAIRE,
            {
                params: this.buildSearchParams(searchRequest)
            });
    }

    private buildSearchParams(searchRequest: ContactRequest) {
        return {
            canal: searchRequest.canal,
            firstName: searchRequest.firstName,
            lastName: searchRequest.lastName,
            email: searchRequest.email
        };
    }
}
