export enum MessageAttachmentPlugin {
    CROSS,
    SELECT,
    CLIP,
    DESKTOP,
    BPN
}
