import { MessageRecipient } from './message-detail.model';

export interface Message {
    id: number;
    type: null;
    subject: string;
    editableSubject: boolean;
    mandatorySubject: boolean;
    comment: string;
    editableComment: boolean;
    mandatoryComment: boolean;
    date: string;
    lifetime: number;
    encrypted: number;
    signed: number;
    status: string;
    sender: {
        id: number,
        firstName: string,
        lastName: string,
        email: string,
        userId: string,
        codeSrj: string,
        emailBoiteStructurelle: string
    };
    nbTry: number;
    appName: string;
    misc: string;
    addFileFromPc: boolean;
    recipients: MessageRecipient[];
    fichierMessages: {
        id: number;
        nom: string;
        type: string;
        idSps: string;
    }[];
    messageStatuts: [];
}
