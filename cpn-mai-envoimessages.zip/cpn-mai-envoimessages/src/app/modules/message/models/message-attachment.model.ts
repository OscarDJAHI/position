export interface MessageAttachment {
    id: string;
    externalId: string;
    name: string;
    type: string;
    size: number;
}
