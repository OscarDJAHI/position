import { Domain } from '../../shared/models/domain.model';

export class MessageSender {
    recipients: MessageRecipient [];
    subject: string;
    comment: string;
    encrypted: number;
    lifetime: number;
    emailBoiteStructurelle: string;
}

export interface MessageRecipient {
    id?: number;
    domain: string;
    canal: string;
    email: string;
    emailChecked?: MessageChecked[];
}

export interface MessageObject {
    sender: string;
    recipientRows: [{
        domains: Domain[];
        recipients: string[];
        recipientsChecked: MessageChecked[];
        addButton: boolean;
        deleteButton: boolean;
    }];
    subject: string;
    body: string;
    files: MessageFile[];
    expiration: { expirationList: any[], selectedValue: number };
    sendButton: boolean;
    multipartFileArray: File[];
}

export interface MessageFile {
    id?: number;
    idSps: string;
    nom: string;
    type: string;
    level?: number;
    size?: string;
}

export interface MessageBody {
    comment: string;
    encrypted: number;
    files: MessageFile[];
    lifetime: string;
    recipients: MessageRecipient[];
    sender: {
        email: string;
        userId: string;
    };
    signed: number;
    subject: string;
}

export interface MessageChecked {
    email: string;
    exist: boolean;
}
