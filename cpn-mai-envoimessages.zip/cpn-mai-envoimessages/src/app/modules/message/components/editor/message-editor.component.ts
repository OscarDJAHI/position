import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CKEditor4 } from 'ckeditor4-angular';

@Component({
    selector: 'app-message-editor',
    styleUrls: ['./message-editor.component.scss'],
    template: `
		           <ckeditor editorUrl="assets/scripts/ckeditor-4/ckeditor.js"
		                     type="divarea"
		                     [disabled]="disabled"
		                     [(ngModel)]="data"
		                     (change)="onChange($event)">
		           </ckeditor>`
})
export class MessageEditorComponent implements OnInit {

    @Input() data: string;
    @Input() disabled: boolean;

    @Output() dataChanged = new EventEmitter<string>();

    constructor() {
    }

    ngOnInit() {
    }

    onChange(event: CKEditor4.EventInfo) {
        this.dataChanged.emit(event.editor.getData());
    }
}
