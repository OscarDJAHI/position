import { Component, ElementRef, EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { FormControl, FormGroup } from '@angular/forms';

import * as moment from 'moment';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { NgbActiveModal, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

import { concatAll, concatMap, map, take, tap } from 'rxjs/operators';
import { concat, interval, Observable, Subscription } from 'rxjs';

import { MessageConstants } from '../../constants/message.constants';
import { ContactRequest } from '../../../contact/models/contact-request.model';

import { DomainService } from '../../../shared/services/domain.service';
import { DataService } from '../../../shared/services/data.service';
import { ModalService } from '../../../shared/services/modal.service';
import { ContactService } from '../../../contact/services/contact.service';

import { MailboxService } from '../../../mailbox/services/mailbox.service';
import { ConfirmModalComponent } from '../../../shared/modals/confirm-modal/confirm-modal.component';
import { AddMailboxComponent } from '../../../mailbox/components/add/add-mailbox.component';
import { DeleteMailboxComponent } from '../../../mailbox/components/delete/delete-mailbox.component';
import { Contact } from '../../../contact/models/contact.model';

import { Message } from '../../models/message.model';
import { MessageChecked, MessageFile, MessageObject, MessageRecipient } from '../../models/message-detail.model';
import { Domain } from '../../../shared/models/domain.model';
import { UtilsService } from '../../../shared/services/utils.service';
import { MessageService } from '../../services/message.service';
import { MessageAttachmentPlugin } from '../../models/message-attachment-plugin.model';
import { MessageNotidocModalComponent } from '../notidoc-modal/message-notidoc-modal.component';
import { DomainLabelEnum } from 'src/app/modules/shared/enums/domain-label.enum';
import { MailboxManageDefaultComponent } from 'src/app/modules/mailbox/components/manage-default/mailbox-manage-default.component';
import { UserService } from 'src/app/modules/shared/services/user.service';
import { UserInfoModel } from 'src/app/modules/shared/models/user-info.model';
import { MailboxModel } from 'src/app/modules/mailbox/models/mailbox.model';

declare var $: any;

@Component({
    selector: 'app-message-write',
    templateUrl: './message-write.component.html',
    styleUrls: ['./message-write.component.scss']
})
export class MessageWriteComponent implements OnInit, OnDestroy {

    /**
     * Envoi une requete d'annulation
     */
    @Output() cancelActionEmitter: EventEmitter<boolean> = new EventEmitter();

    newMessageForm: FormGroup;

    user: UserInfoModel;

    recipientFilteredByDomain: { uid: '', email: '', lastName: '', firstName: '' }[][];
    autoCompleteSpinner = [];
    recipientSelectedSpinner = [];

    attachmentPlugins = [
        MessageAttachmentPlugin.CLIP,
        MessageAttachmentPlugin.CROSS
    ];

    loadDataReady: boolean = false;

    disableSendButton = true;
    showTooltipElt = false;

    mailboxes: Array<MailboxModel>;
    selectedMailbox = '';
    msgExpiration: string;

    message: MessageObject;
    sendMessageRequest: Message;

    isBtnMyMailBoxesParamEnabled: boolean;

    private sendBtnAutoEnableInterval$: Observable<any>;
    private sendBtnAutoEnableSubcription: Subscription;
    private msgToSend: any;
    private errorNpp = '';
    private currentRecipientsIndex;
    private disableSendButtonTemporarily = false;
    private idDemande: number;
    private domains: Domain[];
    private elementAttributes = {
        request: 'idDemande',
        value: 'value',
        style: 'style'
    };

    constructor(
        private contactService: ContactService,
        private dataService: DataService,
        private domainService: DomainService,
        private mailboxService: MailboxService,
        private messageService: MessageService,
        private alertModalService: ModalService,
        private ngxUiLoaderService: NgxUiLoaderService,
        public activeModal: NgbActiveModal,
        private modalService: NgbModal,
        private route: ActivatedRoute,
        private userService: UserService
    ) {
        this.user = this.userService.userInfo;
    }

    private static getRecipientsElement(index: any) {
        return $('#ul-' + index);
    }

    private static enableSelectedDomainByDOMelement() {
        document.querySelectorAll('.domain-select-list').forEach((elt: ElementRef['nativeElement']) => {
            for (const opt of elt.options) {
                opt.removeAttribute('disabled');
            }
        });
    }

    ngOnInit() {
        this.ngxUiLoaderService.startLoader('loader-write-new-mail');

        this.route.queryParams.subscribe((params: Params) => {
            this.idDemande = params[this.elementAttributes.request];
        });

        this.message = this.messageService.newMessage();
        this.sendMessageRequest = this.messageService.newSendMessageRequest();

        this.recipientFilteredByDomain = [];

        this.newMessageForm = new FormGroup({
            subject: new FormControl(''),
            body: new FormControl(''),
            file: new FormControl('')
        });

        this.selectedMailbox = this.user.mail;

        this.msgExpiration = moment().locale('fr')
            .add(8, 'days')
            .format('LL');

        this.initMailboxes();
        this.clickOutAutoCompletion();
    }

    ngOnDestroy() {
        this.sendBtnAutoEnableSubcription.unsubscribe();
    }

    selectSender(email: string) {
        this.selectedMailbox = email;
        this.newMessageForm.patchValue({ sender: email });
    }

    selectDomain(e: any, index: any) {
        if (e.target.value.length === 0) {
            this.disableSelectedDomainByDOMelement();
        }

        if (e.target.value === DomainLabelEnum.HUISSIER) {
            this.openNotidocModal();
        }

        if (e.target.value.length > 0) {
            // Set selected domain
            this.message.recipientRows[index].domains.filter(r => {
                if (r.value === e.target.value) {
                    r.selected = true;

                    if (r.mails.length) {
                        const rc: MessageChecked[] = [];
                        r.mails.forEach(v => rc.push({ email: v, exist: true }));

                        this.message.recipientRows[index].recipientsChecked = rc;
                        this.message.recipientRows[index].recipients = r.mails;

                        // disable input
                        if (!r.editable) {
                            document.querySelector('#recipient-input-' + index).setAttribute('disabled', 'disabled');
                        } else {
                            document.querySelector('#recipient-input-' + index).removeAttribute('disabled');
                        }
                    } else {
                        document.querySelector('#recipient-input-' + index).removeAttribute('disabled');
                        this.message.recipientRows[index].recipientsChecked = [];
                        this.message.recipientRows[index].recipients = [];
                    }
                } else {
                    r.selected = false;
                }
            });

            // Disable for each row selected domain (select options)
            this.disableSelectedDomainByDOMelement();
        } else {
            // Set selected domain
            this.message.recipientRows[index].domains.filter(r => {
                r.selected = false;
            });
        }
    }

    autocompleteRecipientList(e: any, index: any) {
        this.disableSendButtonTemporarily = true;

        const inputTextValue = e.target.value.toLowerCase();

        // get selected option
        const el = document.getElementById(e.target.className);

        // get selected option value
        const optionValue = el[this.elementAttributes.value];

        // get selected option innerText
        if (optionValue.length === 0) {
            document.querySelector('.title').classList.add('title-error');
            return;
        }

        const canal = this.getCanalByDomain(optionValue);

        if (inputTextValue.length >= 3) {
            this.autoCompleteSpinner[index] = true;
            const ulElement = document.getElementById('ul-' + index);
            this.contactService.searchContacts(new ContactRequest('', canal, '', '', inputTextValue, optionValue)).subscribe(
                contactResponse => {
                    this.autoCompleteSpinner[index] = false;

                    this.recipientFilteredByDomain[index] = this.recipientsByDomain(contactResponse.contacts);

                    if (this.recipientFilteredByDomain[index] !== null && this.recipientFilteredByDomain[index].length >= 1) {
                        document.getElementById('ul-' + index).style.boxShadow = '-2px 7px 16px 11px #1c1a1a26';
                        ulElement.style.display = 'block';
                    } else {
                        document.querySelector('.ul-list')[this.elementAttributes.style].display = 'none';
                        ulElement.style.display = 'none';
                    }
                },
                error => {
                    this.autoCompleteSpinner[index] = false;
                    console.log('Sorry ! Something went wrong when trying to get contacts:', error);
                }
            );
        } else {
            const ulElement = document.getElementById('ul-' + index);
            ulElement.style.display = 'none';
        }
    }

    selectRecipient(email: string, index: any) {
        const emails = this.message.recipientRows[index].recipients;

        if (!emails.filter(r => r === email).length) {
            emails.push(email);
        }

        if (emails.length) {
            this.recipientSelectedSpinner[index] = true;

            // get selected domain
            const domain = document.getElementById('id-domain-select-' + index)[this.elementAttributes.value];
            const canal = this.getCanalByDomain(domain);

            this.contactService.checkContact(canal, emails.join())
                .pipe(
                    tap(() => {
                        this.disableSendButtonTemporarily = true;
                    }))
                .subscribe(
                    done => {
                        this.disableSendButtonTemporarily = false;
                        this.recipientSelectedSpinner[index] = false;
                        this.message.recipientRows[index].recipientsChecked = done;
                    },
                    fail => {
                        this.disableSendButtonTemporarily = false;
                        this.recipientSelectedSpinner[index] = false;
                        console.log(fail);
                    });
        }

        // empty
        this.recipientFilteredByDomain[index] = [];

        const el = document.getElementById('recipient-input-' + index);
        el[this.elementAttributes.value] = '';
        el.focus();
    }

    showCustomTooltip(e, id) {
        const elt = document.querySelector('#email-error-' + id);
        const tooltipElt: HTMLElement = document.querySelector('.cpn-tooltip-email-error');
        const elRec = elt.getBoundingClientRect();

        tooltipElt.style.top = String(elRec.top + elRec.height + 6) + 'px';
        tooltipElt.style.left = String(elt.getBoundingClientRect().left) + 'px';

        this.showTooltipElt = true;
    }

    hideCustomTooltip() {
        this.showTooltipElt = false;
    }

    checkEmail($event: any, index: any) {
        const recipients = MessageWriteComponent.getRecipientsElement(index);
        if (recipients.is(':visible')) {
            return;
        }

        const inputTextValue = $event.target.value.trim();
        if (MessageConstants.EMAIL_PATTERN.test(inputTextValue)) {
            this.selectRecipient(inputTextValue, index);
        } else {
            this.disableSendButtonTemporarily = false;
        }

        $event.target.value = '';
    }

    removeRecipient(email: string, index: any) {
        if (this.isSelectedDomainNotEditable(this.message.recipientRows[index].domains)) {
            return;
        }

        this.showTooltipElt = false;
        const idx = this.message.recipientRows[index].recipients.findIndex(rslt => rslt === email);
        const edx = this.message.recipientRows[index].recipientsChecked.findIndex(e => e.email === email);

        this.message.recipientRows[index].recipients.splice(idx, 1);
        this.message.recipientRows[index].recipientsChecked.splice(edx, 1);
    }

    verif(index: any) {
        // Hide and show autocomplete recipient list by domain row
        const ulList = document.querySelectorAll('.ul-list');
        ulList.forEach((v: HTMLElement) => {
            v.style.display = 'none';
        });

        this.currentRecipientsIndex = index;
        document.getElementById('ul-' + index).style.boxShadow = '';
    }

    addNewRecipientRow($event: any, index: any) {
        const newDomains = this.toDomains();
        const checkDomain = document.getElementById('id-domain-select-' + index)[this.elementAttributes.value];

        if (checkDomain.length === 0) {
            document.querySelector('.title').classList.add('title-error');
            return;
        }

        if (this.message.recipientRows.length < this.domains.length) {
            // disable all selected domain
            newDomains.forEach(d => {
                this.message.recipientRows.forEach(rw => {
                    rw.domains.forEach(dm => {
                        if (dm.selected === true && dm.value === d.value) {
                            dm.disabled = true;
                            d.disabled = true;
                        }
                    });
                });
            });

            this.message.recipientRows.push({
                domains: newDomains,
                recipients: [],
                recipientsChecked: [],
                addButton: true,
                deleteButton: true
            });
        }

        // Set dynamically z-index
        setTimeout(() => {
            document.querySelectorAll('.recipient-row').forEach((v, i) => {
                v[this.elementAttributes.style] = `z-index:${this.domains.length - i}`;
            });
        }, 500);

        // Hide all recipient row addButton, and display the last one
        setTimeout(() => {
            this.hideAndShowActionButton();
        }, 20);
    }

    removeRecipientRow($event: any, index: any) {
        // remove domain and recipient row
        if (this.message.recipientRows.length > 1) {
            this.message.recipientRows.splice(index, 1);
        }

        setTimeout(() => {
            // Hide all recipient row addButton, and display the last one
            this.hideAndShowActionButton();

            // enable selected domain
            if (this.message.recipientRows.length === 1) {
                MessageWriteComponent.enableSelectedDomainByDOMelement();
            }
        }, 50);
    }

    selectExpiration($event: any) {
        if ($event.target.value.length > 0) {
            this.message.expiration.selectedValue = $event.target.value;
            this.msgExpiration = moment().locale('fr').add($event.target.value, 'days').format('LL');
        }
    }

    cancel() {
        const config = { windowClass: 'cpn-confirm-modal', centered: true };
        const confirmModal = this.modalService.open(ConfirmModalComponent, config);
        confirmModal.componentInstance.name = 'ConfirmModalComponent';
        confirmModal.componentInstance.title = 'Confirmation de fermeture';
        confirmModal.componentInstance.message = 'Voulez-vous annuler l\'envoi du message ?';
        confirmModal.result.then(
            close => {
                window.close();
            }
        );
    }

    sendMessage() {
        this.ngxUiLoaderService.startLoader('loader-write-new-mail');

        this.msgToSend = this.getMessageToSend();

        this.messageService.updateSendMessageRequest(this.msgToSend).subscribe(
            success => {
                this.ngxUiLoaderService.stopLoader('loader-write-new-mail');

                this.dataService.openTinyWindowRequest.emit(false);

                this.alertModalService.openSuccessModal({
                    title: MessageConstants.DEMANDE_ENVOI_MESSAGE_TITLE,
                    message: '<p>Votre message a bien été envoyé.</p>'
                });
            },
            fail => {
                this.ngxUiLoaderService.stopLoader('loader-write-new-mail');

                this.errorNpp = UtilsService.toMessage(fail);
                this.alertModalService.openErrorModal({
                    title: MessageConstants.DEMANDE_ENVOI_MESSAGE_TITLE,
                    message: `<p>L'envoie du message a échoué</p><p>${this.errorNpp}</p>`
                });
            }
        );
    }

    addMailbox() {
        const config = { size: 'None', centered: true, windowClass: 'cpn-add-boite-structurelle' };
        const modalRef = this.modalService.open(AddMailboxComponent, config);
        modalRef.componentInstance.name = 'World';
    }

    deleteMailbox() {
        const config = { size: 'None', centered: true, windowClass: 'cpn-delete-boite-structurelle' };
        const modalRef = this.modalService.open(DeleteMailboxComponent, config);
        modalRef.componentInstance.name = 'World';
    }

    checkMaiboxesButtonAvailability() {
        this.userService.userMailboxes$
            .pipe(take(1), map((data: MailboxModel[]) => {
                if (data) {
                    return data.filter((boxe: MailboxModel) => !boxe.nominative);
                }
                return data;
            }))
            .subscribe((data: MailboxModel[]) => {
                this.isBtnMyMailBoxesParamEnabled = data != null && data?.length > 0;
            });
    }

    openManageDefaultMailBoxModal(previousChoice: MailboxModel = undefined) {
        const config = { size: 'md', centered: true, windowClass: 'cpn-manage-default-mail-box' };
        const modalRef = this.modalService.open(MailboxManageDefaultComponent, config);
        modalRef.componentInstance.name = 'manage messagerie';
        modalRef.componentInstance.previousChoice = previousChoice;
        modalRef.result.then(
            (chosenBox: MailboxModel) => {
                this.confirmChoiceDefaultMail(chosenBox);
            },
            () => {
                console.log('complete!')
            });
    }

    confirmChoiceDefaultMail(defaultMailSelected: MailboxModel) {
        const message: string = `<p>Vous &ecirc;tes sur le point de choisir la boite de reception :</p>
        <p>${defaultMailSelected.email}</p>
        <p>&Ecirc;tes-vous s&ucirc;r ?</p>`;

        const modal: NgbModalRef = this.alertModalService.openValidationModal({
            title: "",
            message: message
        });

        modal.result.then(
            () => {
                this.getUserMailBoxListAndUpdateDefaultOne(defaultMailSelected);
            },
            () => {
                this.openManageDefaultMailBoxModal(defaultMailSelected);
            });
    }

    getUserMailBoxListAndUpdateDefaultOne(defaultBoxMailChosen: MailboxModel) {
        this.userService.userMailboxes$
            .pipe(take(1), map((data: MailboxModel[]) => {
                data.forEach((el: MailboxModel) => {
                    el.defaultBox = el.email === defaultBoxMailChosen.email;
                });
                return data;
            }))
            .subscribe((data: MailboxModel[]) => {
                this.sendUpdatedBoxListToBackAndUpdateDefaultBoxMail(data);
            });
    }

    sendUpdatedBoxListToBackAndUpdateDefaultBoxMail(mailBoxes: MailboxModel[]) {
        this.mailboxService.updateMailBoxes(mailBoxes).subscribe(
            (data: MailboxModel[]) => {
                this.userService.updateOrCreateUserParametersWithDefaultMailbox(data);
                this.userService.updateUserCepMails(data);
                this.selectedMailbox = data.find(m => m.defaultBox === true).email;
            },
            error => {
                this.alertModalService.openGenericErrorModal();
            }
        );
    }

    showAttachments() {
        return this.sendMessageRequest && (this.sendMessageRequest.fichierMessages || this.sendMessageRequest.addFileFromPc);
    }

    updateAttachments($event: MessageFile[]) {
        this.message.files = $event;
    }

    openNotidocModal() {
        const config = { size: 'lg', windowClass: 'cpn-notidoc-modal', centered: true };
        const modalRef = this.modalService.open(MessageNotidocModalComponent, config);
        modalRef.componentInstance.name = ' NotidocModalComponent';
    }

    isSelectedDomainNotEditable(domains: Domain[]) {
        const selectedDomain = domains.filter(d => d.selected);
        return selectedDomain.length === 1 && !selectedDomain[0].editable;
    }

    private getCanalByDomain(domain: string) {
        return this.domains.filter(d => d.value === domain)[0].canal;
    }

    private initSendMessageRequest() {
        this.messageService.getSendMessageRequest(this.idDemande).subscribe(
            data => {
                this.sendMessageRequest = data;

                this.selectedMailbox = this.userService.hasDefaultMailbox()
                    ? this.userService.userInfo.parametrage.defaultMailbox.email
                    : this.sendMessageRequest.sender.email;

                this.initMailHeader();
            },
            error => {
                UtilsService.printMessage(error, 'to initialize the modale.');
                this.ngxUiLoaderService.stopLoader('loader-write-new-mail');
            }
        );
    }

    private initMailHeader() {
        this.domainService.getDomains(this.sendMessageRequest.appName).subscribe(
            data => {
                this.domains = data;
                const domains = this.toDomains();

                this.message = {
                    sender: this.sendMessageRequest.sender.email,
                    recipientRows: [{
                        domains,
                        recipients: [],
                        recipientsChecked: [],
                        addButton: true,
                        deleteButton: true
                    }],
                    subject: this.sendMessageRequest.subject,
                    body: this.sendMessageRequest.comment,
                    files: this.sendMessageRequest.fichierMessages,
                    expiration: { expirationList: MessageConstants.EXPIRATION_LIST, selectedValue: 8 },
                    sendButton: false,
                    multipartFileArray: [],
                };

                this.newMessageForm.setValue({
                    subject: this.sendMessageRequest.subject,
                    body: this.sendMessageRequest.comment,
                    file: null
                });

                if (this.isBoiteStructurelle()) {
                    this.message.sender = this.selectedMailbox;
                }

                // set default selected and value
                this.message.expiration.expirationList.find(elt => elt.value === 8).selected = true;

                this.autoEnableSendButton();

                this.loadDataReady = true;
                this.ngxUiLoaderService.stopLoader('loader-write-new-mail');
            },
            error => {
                UtilsService.printMessage(error, 'Initialize message content.');
                this.ngxUiLoaderService.stopLoader('loader-write-new-mail');
            }
        );
    }

    private isBoiteStructurelle(): boolean {
        return this.user.mail !== this.selectedMailbox;
    }

    private toDomains(): Domain[] {
        const result: Domain[] = [];
        this.domains.forEach(elt => {
            result.push({
                label: elt.label,
                value: elt.value,
                selected: false,
                disabled: false,
                canal: elt.canal,
                mails: elt.mails,
                editable: elt.editable
            });
        });

        return result;
    }

    private hideAndShowActionButton() {
        this.message.recipientRows.forEach(rw => rw.addButton = false);
        this.message.recipientRows[this.message.recipientRows.length - 1].addButton = true;
    }

    private disableSelectedDomainByDOMelement() {
        MessageWriteComponent.enableSelectedDomainByDOMelement();
        const eltValue = [];
        document.querySelectorAll('.domain-select-list').forEach((elt: ElementRef['nativeElement']) => {
            eltValue.push(elt.value);
        });

        document.querySelectorAll('.domain-select-list').forEach((elt: ElementRef['nativeElement']) => {
            for (const opt of elt.options) {
                eltValue.forEach(ev => {
                    if (ev.length !== 0 && ev === opt.value) {
                        opt.setAttribute('disabled', 'disabled');
                    }
                });
            }
        });
    }

    private getRecipients(): MessageRecipient[] {
        const destinataire: MessageRecipient[] = [];
        this.message.recipientRows.forEach((elt) => {
            let domain = '';
            let canal = '';

            for (const d of elt.domains) {
                if (d.selected === true) {
                    domain = d.value;
                    canal = d.canal;
                }
            }

            if (canal) {
                elt.recipients.forEach(recipient => destinataire.push({
                    domain,
                    canal,
                    email: recipient,
                    emailChecked: elt.recipientsChecked
                }));
            }
        });

        return destinataire;
    }

    private enableSendButton() {
        const recipients: any[] = [];
        const recipientsChecked: any[] = [];
        const recipientEmails: any[] = [];
        let invalidEmails: any[] = [];

        this.message.recipientRows.forEach((r, i) => {
            recipients[i] = r.recipients;
            recipientsChecked[i] = r.recipientsChecked;
        });

        recipientsChecked.forEach(e => {
            e.forEach(t => {
                recipientEmails.push(t);
            });
        });

        invalidEmails = recipientEmails.filter(e => e.exist === false);

        const domains = [];
        document.querySelectorAll('.domain-select-list').forEach((elt: ElementRef['nativeElement']) => {
            domains.push(elt.value);
        });

        /* Bouton 'Envoyer' actif si :
         * 1- Règle générale, au moins :
         *                  - Un 'Domaine' est sélectionné
         *                  - Un destinataire valide est saisi
         *                  - Une PJ est uploadée
         * *                - Tous les champs marqués comme obligatoires renseignés
         *
         * 2- Pour les boites CEP, au moins :
         *                  - Un 'Domaine' <Avocat> est sélectionné
         */
        const emptyRecipient = [];
        domains.forEach((ev, i) => {
            if (recipients[i].length === 0) {
                emptyRecipient.push(true);
            }
            this.disableSendButton = emptyRecipient.length > 0 || invalidEmails.length > 0 || !this.isAllMandatoryFilled() || this.disableSendButtonTemporarily;
            this.disableSendButton = this.disableSendButton ||
                (this.selectedMailbox && this.selectedMailbox.toLocaleLowerCase().match('cep-') ? !domains.includes('AVOCATS')
                    : domains.includes('') || this.message.files.length === 0);
        });
    }

    private autoEnableSendButton() {
        this.sendBtnAutoEnableInterval$ = interval(100);
        this.sendBtnAutoEnableSubcription = this.sendBtnAutoEnableInterval$.subscribe(r => {
            this.enableSendButton();
        });
    }

    private clickOutAutoCompletion() {
        window.addEventListener('click', (e: any) => {
            if (document.querySelector('.ul-list') !== null && !document.querySelector('.ul-list').contains(e.target)) {
                const ul = MessageWriteComponent.getRecipientsElement(this.currentRecipientsIndex);
                if (this.currentRecipientsIndex != null && ul != null && ul.is(':visible')) {
                    const inputMail: HTMLElement = document.querySelector('#recipient-input-' + this.currentRecipientsIndex);
                    inputMail.focus();
                    inputMail.blur();
                }

                document.querySelector('.ul-list')[this.elementAttributes.style].display = 'none';
            }
        });
    }

    private getMessageToSend() {
        this.message.sender = this.selectedMailbox;
        this.message.subject = this.newMessageForm.get('subject').value;
        this.message.body = this.newMessageForm.get('body').value;
        const emailBoiteStructurelle = this.isBoiteStructurelle() ? this.message.sender : null;

        return {
            id: this.idDemande,
            appName: this.sendMessageRequest.appName,
            comment: this.message.body,
            encrypted: 0,
            fichierMessages: this.message.files,
            lifetime: this.message.expiration.selectedValue,
            messageDestinataires: this.getRecipients(),
            sender: {
                email: this.user.mail,
                userId: this.user.idLdap,
                emailBoiteStructurelle
            },
            signed: 0,
            subject: this.message.subject
        };
    }

    private initMailboxes() {
        this.mailboxService.all().subscribe(
            data => {
                if (data) {
                    this.mailboxes = data.filter((box: MailboxModel) => !box.nominative);
                }
                this.userService.updateOrCreateUserParametersWithDefaultMailbox(data);
                this.userService.updateUserCepMails(data);

                this.initSendMessageRequest();
            },
            error => {
                UtilsService.printMessage(error, 'to get mailboxes');
            }
        );
    }

    private recipientsByDomain(contacts: Array<Contact>) {
        const recipients = [];
        contacts.forEach(contact => recipients.push({
            uid: contact.uid,
            email: contact.email,
            lastName: contact.lastName,
            firstName: contact.firstName
        }));
        return recipients;
    }

    private isAllMandatoryFilled() {
        if (!this.sendMessageRequest) {
            return false;
        }

        if (this.sendMessageRequest.mandatorySubject && UtilsService.isStringEmpty(this.newMessageForm.get('subject').value)) {
            return false;
        }

        return !(this.sendMessageRequest.mandatoryComment && UtilsService.isStringEmpty(this.newMessageForm.get('body').value));
    }
}
