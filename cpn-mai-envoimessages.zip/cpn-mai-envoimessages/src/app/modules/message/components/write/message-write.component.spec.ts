import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';

import { NgbActiveModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderModule, NgxUiLoaderService } from 'ngx-ui-loader';

import { DataService } from '../../../shared/services/data.service';
import { MessageWriteComponent } from './message-write.component';

describe('WriteNewMailComponent', () => {
    let component: MessageWriteComponent;
    let fixture: ComponentFixture<MessageWriteComponent>;
    let componentElt: any;

    let dataServiceStub: Partial<DataService>;

    beforeEach(waitForAsync(() => {
        dataServiceStub = {
        };

        TestBed.configureTestingModule({
            declarations: [
                MessageWriteComponent
            ],
            imports: [
                FormsModule,
                ReactiveFormsModule,
                NgxUiLoaderModule,
                NgbModule,
                RouterTestingModule,
                HttpClientModule
            ],
            providers: [
                { provide: DataService, useValue: dataServiceStub },
                NgxUiLoaderService,
                NgbActiveModal,
            ]
        }).compileComponents();
    }));

    beforeEach(() => {
        jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(MessageWriteComponent);
        component = fixture.componentInstance;
        componentElt = fixture.debugElement.nativeElement;
        component.message = {
            sender: '',
            recipientRows: [{
                domains: [],
                recipients: [],
                recipientsChecked: [],
                addButton: false,
                deleteButton: false,
            }],
            subject: '',
            body: '',
            files: [],
            expiration: { expirationList: [], selectedValue: 0 },
            sendButton: false,
            multipartFileArray: []
        };
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    xit('should activate message send button', () => {
        let recipientrow = {
            domains: [{
                label: 'Avocats',
                value: 'AVOCATS',
                selected: true,
                disabled: true,
                canal: 'PLEX',
                mails: [''],
                editable: true
            }],
            recipients: ['test-email@mj.gouv.fr'],
            recipientsChecked: [{
                email: 'test-email@mj.gouv.fr',
                exist: true
            }],
            addButton: true,
            deleteButton: true
        };

        component.disableSendButton = true;
        component.message.recipientRows.push(recipientrow);

        expect(component.disableSendButton).toBe(false);
    });

    xit('should not activate message send button', () => {
        const recipientrow = {
            domains: [{
                label: 'Avocats',
                value: 'AVOCATS',
                selected: true,
                disabled: true,
                canal: 'PLEX',
                mails: [''],
                editable: true
            }],
            recipients: [],
            recipientsChecked: [],
            addButton: true,
            deleteButton: true
        };

        component.disableSendButton = true;
        component.message.recipientRows.push(recipientrow);

        expect(component.disableSendButton).toBe(true);
    });
});
