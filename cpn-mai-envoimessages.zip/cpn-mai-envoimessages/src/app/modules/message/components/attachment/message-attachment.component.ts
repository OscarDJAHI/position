import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

import { MessageFile } from '../../models/message-detail.model';
import { MessageAttachmentPlugin } from '../../models/message-attachment-plugin.model';
import { UtilsService } from '../../../shared/services/utils.service';

@Component({
    selector: 'app-message-attachment',
    templateUrl: './message-attachment.component.html',
    styleUrls: ['./message-attachment.component.scss']
})
export class MessageAttachmentComponent implements OnInit {

    @Input() attachments: MessageFile[];
    @Input() plugins: MessageAttachmentPlugin[];

    @Output() dataChanged = new EventEmitter<MessageFile[]>();

    private finalAttachment: MessageFile[] = [];

    constructor() {
    }

    ngOnInit() {
    }

    isAttachmentsEmpty() {
        return !this.attachments || !this.attachments.length;
    }

    showClip() {
        return this.contains(MessageAttachmentPlugin.CLIP);
    }

    showCross() {
        return this.contains(MessageAttachmentPlugin.CROSS);
    }

    showSelect() {
        return this.contains(MessageAttachmentPlugin.SELECT);
    }

    removeFile(attachment: MessageFile) {
        if (!this.isAttachmentsEmpty()) {
            const index = this.attachments.findIndex(i => i.nom === attachment.nom);
            this.attachments.splice(index, 1);
        }

        this.dataChanged.emit([...this.attachments]);
    }

    selectFile(attachment: MessageFile) {
        this.finalAttachment.push(this.attachments.filter(file => file.nom === attachment.nom)[0]);
        this.dataChanged.emit(this.finalAttachment);
    }

    unselectFile(attachment: MessageFile) {
        const index = this.finalAttachment.findIndex(file => file.nom === attachment.nom);
        this.finalAttachment.splice(index, 1);

        this.dataChanged.emit(this.finalAttachment);
    }

    private contains(messageAttachmentPlugin: MessageAttachmentPlugin) {
        return !UtilsService.isListEmpty(this.plugins) && this.plugins.filter(plugin => plugin === messageAttachmentPlugin).length;
    }
}
