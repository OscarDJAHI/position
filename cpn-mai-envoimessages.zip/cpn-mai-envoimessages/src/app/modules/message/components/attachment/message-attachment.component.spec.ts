import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { MessageAttachmentComponent } from './message-attachment.component';

describe('MessageAttachementComponent', () => {
    let component: MessageAttachmentComponent;
    let fixture: ComponentFixture<MessageAttachmentComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [MessageAttachmentComponent]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(MessageAttachmentComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
