import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { MessageNotidocModalComponent } from './message-notidoc-modal.component';

describe('NotidocModalComponent', () => {
    let component: MessageNotidocModalComponent;
    let fixture: ComponentFixture<MessageNotidocModalComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [MessageNotidocModalComponent]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(MessageNotidocModalComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
