import { Component, ElementRef, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { DomainLabelEnum } from 'src/app/modules/shared/enums/domain-label.enum';
import { DomainService } from 'src/app/modules/shared/services/domain.service';
import { UtilsService } from '../../../shared/services/utils.service';

@Component({
    selector: 'app-message-notidoc-modal',
    templateUrl: './message-notidoc-modal.component.html',
    styleUrls: ['./message-notidoc-modal.component.scss']
})
export class MessageNotidocModalComponent implements OnInit {

    urlNotidoc: string;

    @Input() title;
    @Input() message;

    constructor(
        public activeModal: NgbActiveModal,
        private domaineService: DomainService,
    ) {
    }

    ngOnInit() {
        this.domaineService.getUrlNotidoc().subscribe(
            done => {
                this.urlNotidoc = done;
            },
            error => UtilsService.printMessage(error, 'Get Notidoc URL')
        );
    }

    closeModal() {
        window.close();
    }

    closeNotidocModal() {
        document.querySelectorAll('.domain-select-list').forEach((elt: ElementRef['nativeElement']) => {
            if (elt.value === DomainLabelEnum.HUISSIER) {
                elt.options[elt.selectedIndex].disabled = false;
                elt.options[0].selected = true;
            }
        });

        this.activeModal.dismiss('Modale fermée manuellement');
    }
}
