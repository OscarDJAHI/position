export abstract class MessageConstants {

    static readonly EMAIL_PATTERN = /^[a-zA-Z0-9._-]+@[a-zA-Z_-]+?\.[a-zA-Z.]{2,}$/;

    static readonly DEMANDE_ENVOI_MESSAGE_TITLE = 'Envoyer message';

    static readonly EXPIRATION_LIST = [
        { label: '1', value: 1, selected: false },
        { label: '2', value: 2, selected: false },
        { label: '3', value: 3, selected: false },
        { label: '8', value: 8, selected: false },
        { label: '10', value: 10, selected: false },
        { label: '15', value: 15, selected: false }
    ];
}
