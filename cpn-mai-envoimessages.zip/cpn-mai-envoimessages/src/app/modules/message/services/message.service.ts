import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

import { environment } from '../../../../environments/environment';

import { MessageObject } from '../models/message-detail.model';
import { Message } from '../models/message.model';
import { MessageConstants } from '../constants/message.constants';

@Injectable()
export class MessageService {

    constructor(private http: HttpClient) {
    }

    newMessage(): MessageObject {
        return {
            sender: '',
            recipientRows: [{
                domains: [],
                recipients: [],
                recipientsChecked: [],
                addButton: true,
                deleteButton: true
            }],
            subject: '',
            body: '',
            files: [],
            expiration: { expirationList: MessageConstants.EXPIRATION_LIST, selectedValue: 8 },
            sendButton: false,
            multipartFileArray: [],
        };
    }

    newSendMessageRequest(): Message {
        return {
            id: null,
            type: null,
            subject: '',
            editableSubject: false,
            mandatorySubject: false,
            comment: '',
            editableComment: false,
            mandatoryComment: false,
            date: '',
            lifetime: null,
            encrypted: null,
            signed: null,
            status: '',
            sender: {
                id: null,
                firstName: '',
                lastName: '',
                email: '',
                userId: '',
                codeSrj: '',
                emailBoiteStructurelle: ''
            },
            nbTry: null,
            appName: '',
            misc: '',
            addFileFromPc: false,
            recipients: [],
            fichierMessages: [],
            messageStatuts: []
        };
    }

    getSendMessageRequest(id: number): Observable<any> {
        return this.http.get(`${ environment.REST_URL_CPN_MESSAGES_LEGACY }/id/${ id }`);
    }

    updateSendMessageRequest(documents: any): Observable<any> {
        return this.http.put<any>(environment.REST_URL_CPN_MESSAGES, documents);
    }
}
