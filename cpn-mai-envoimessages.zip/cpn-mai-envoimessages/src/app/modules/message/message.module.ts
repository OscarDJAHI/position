import { NgModule } from '@angular/core';

import { CKEditorModule } from 'ckeditor4-angular';

import { SharedModule } from '../shared/shared.module';
import { ContactModule } from '../contact/contact.module';
import { MailboxModule } from '../mailbox/mailbox.module';
import { MessageRoutingModule } from './message-routing.module';

import { MessageAttachmentComponent } from './components/attachment/message-attachment.component';
import { MessageEditorComponent } from './components/editor/message-editor.component';
import { MessageWriteComponent } from './components/write/message-write.component';

import { MessageService } from './services/message.service';
import { MessageNotidocModalComponent } from './components/notidoc-modal/message-notidoc-modal.component';

@NgModule({
    declarations: [
        MessageAttachmentComponent,
        MessageEditorComponent,
        MessageWriteComponent,
        MessageNotidocModalComponent
    ],
    exports: [],
    imports: [
        CKEditorModule,
        ContactModule,
        MailboxModule,
        MessageRoutingModule,
        SharedModule
    ],
    providers: [
        MessageService
    ],
    entryComponents: [
        MessageNotidocModalComponent
    ]
})
export class MessageModule {
}
