import { HttpClientModule } from '@angular/common/http';
import { TestBed, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { NgbModalConfig, NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';
import { MailboxService } from '../../modules/mailbox/services/mailbox.service';
import { DomainService } from '../../modules/shared/services/domain.service';
import { DataService } from '../../modules/shared/services/data.service';
import { UtilsService } from '../../modules/shared/services/utils.service';

describe('AppComponent', () => {
    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [
                AppComponent
            ],
            imports: [
                RouterTestingModule,
                NgbModule,
                HttpClientModule,
            ],
            providers: [
                MailboxService,
                DomainService,
                DataService,
                UtilsService,
                NgbModalConfig,
            ]
        }).compileComponents();
    }));

    it('should create the app', () => {
        const fixture = TestBed.createComponent(AppComponent);
        const app = fixture.debugElement.componentInstance;
        expect(app).toBeTruthy();
    });

    it(`should have as title 'bpn-mai'`, () => {
        const fixture = TestBed.createComponent(AppComponent);
        const app = fixture.debugElement.componentInstance;
        expect(app.title).toEqual('bpn-mai');
    });
});
