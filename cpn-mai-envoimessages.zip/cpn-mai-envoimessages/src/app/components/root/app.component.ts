import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { CpnConfig } from 'src/app/modules/shared/models/cpn-config.model';
import { CpnConfigService } from 'src/app/modules/shared/services/cpn-config.service';
import { UserService } from 'src/app/modules/shared/services/user.service';
import { AuthenticationService } from '../../modules/shared/services/authentication.service';

@Component({
    selector: 'app-root',
    template: `
        <div class="main-content"
             *ngIf="configLoaded && userLogged">
            <router-outlet></router-outlet>
        </div>
    `,
    styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

    userLogged = false;
    configLoaded = false;

    constructor(
        private userService: UserService,
        private authenticationService: AuthenticationService,
        private route: ActivatedRoute,
        private cpnConfigService: CpnConfigService
    ) { }

    ngOnInit() {
        this.route.queryParams.subscribe((params: Params) => {
            if (params) {
                this.authenticationService.authenticate(params['token']);
            }
        });

        this.authenticationService.user().subscribe(user => {
            this.userService.userInfo = user;
            this.userLogged = !!user;
        });

        this.cpnConfigService.getCpnConfig().subscribe((data: CpnConfig) => {
            this.cpnConfigService.cpnConfig = data;
            this.configLoaded = !!data;
        });
    }
}
