import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { MessageWriteComponent } from './modules/message/components/write/message-write.component';

const routes: Routes = [
    {
        path: '',
        component: MessageWriteComponent
    }
];

@NgModule({
    imports: [
        RouterModule.forRoot(routes, {relativeLinkResolution: 'legacy'})
    ],
    exports: [RouterModule]
})
export class AppRoutingModule {
}
