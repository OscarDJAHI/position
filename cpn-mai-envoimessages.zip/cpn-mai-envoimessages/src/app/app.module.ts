import { ErrorHandler, NgModule } from '@angular/core';
import { DatePipe, DecimalPipe } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { DataService } from './modules/shared/services/data.service';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './components/root/app.component';
import { MessageModule } from './modules/message/message.module';
import { ErrorModule } from './modules/error/error.module';
import { GlobalErrorHandlerService } from './modules/error/services/global-error-handler.service';
import { InterceptorModule } from './modules/interceptor/interceptor.module';


@NgModule({
    declarations: [
        AppComponent
    ],
    imports: [
        AppRoutingModule,
        BrowserModule,
        BrowserAnimationsModule,
        ErrorModule,
        InterceptorModule,
        MessageModule
    ],
    providers: [
        NgbActiveModal,
        {
            provide: ErrorHandler,
            useClass: GlobalErrorHandlerService
        },
        DatePipe,
        DataService,
        DecimalPipe
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
}
