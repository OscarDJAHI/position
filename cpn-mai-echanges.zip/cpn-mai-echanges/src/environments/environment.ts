// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

const URL_BPN = '/api';
const URL_CPN_MAS_ECHANGE = '/api/mas-echanges';
const URL_CPN_MAS_INTERFACE_PLINE_PLEX = '/api/mas-interface-pline-plex';
const URL_CPN_MAS_JDR = '/api/mas-jdr';
const URL_CPN_MAS_ANNUAIRE = '/api/mas-annuaires';
const URL_HABILITATION = '/api/habilitation';

export const environment = {

    production: false,

    /**
     * URL de l'API BPN
     */
    REST_URL_BPN: URL_BPN,
    REST_URL_BPN_VIEW_DOC: URL_BPN + '/view/',
    REST_URL_BPN_VIEW_ODT: URL_BPN + '/viewOdt/',
    REST_URL_BPN_VIEW_IMAGE: URL_BPN + '/viewImage/',
    REST_URL_BPN_GET_FILE: URL_BPN + '/getFile/',
    REST_URL_BPN_POCHETTE_CREATE: URL_BPN + '/node/create/pochette',
    REST_URL_BPN_NODE_CREATE: URL_BPN + '/node/create',
    REST_URL_BPN_NODE_UPDATE: URL_BPN + '/node/update',
    REST_URL_BPN_NODE_DELETE: URL_BPN + '/node/trash',
    REST_URL_BPN_NODE_RESTORE: URL_BPN + '/node/restore',
    REST_URL_BPN_NODE_DELETE_DEFINITIVE: URL_BPN + '/node/delete',
    REST_URL_BPN_NODE_RENAME: URL_BPN + '/node/rename',
    REST_URL_BPN_NODE_LOAD: URL_BPN + '/node/load',
    REST_URL_BPN_NODE_MOVE: URL_BPN + '/node/move',
    REST_URL_BPN_INFO_UTILISATEUR: URL_BPN + '/utilisateur',
    REST_URL_BPN_HABILITATION: URL_BPN + '/habilitation',
    REST_URL_BPN_TRASH_LOAD: URL_BPN + '/node/trash/load',
    REST_URL_BPN_QUICK_SIGN_LOAD: URL_BPN + '/node/quicksign/load',
    REST_URL_BPN_QUICK_SIGN_GET_NODE: URL_BPN + '/node/load/quicksign',
    REST_URL_BPN_NODE_GET_ALL_IDS_DOCUMENTS_FROM_NODE: URL_BPN + '/node/getallidsdocumentsfromnode',
    REST_URL_BPN_NODE_GET_ALL_DOCUMENTS_FROM_POCHETTE: URL_BPN + '/node/getalldocumentsfrompochette',
    REST_URL_BPN_ADD_COMMENT: URL_BPN + '/node/comment',
    REST_URL_BPN_NODE_USER_ROOT_NAME: URL_BPN + '/node/user/root/{{NAME}}',
    REST_URL_CHECK_USER_BOX_EMAIL: URL_BPN + '/boiteStructurelle/checkBoxEmail/{email}',
    REST_URL_CHECK_USER_BOX_NAME: URL_BPN + '/boiteStructurelle/checkBoxName/{boxName}',
    REST_URL_DOWNLOAD: URL_BPN + '/download',
    REST_URL_CONVERT_ODT: URL_BPN + '/convert/odtToPdf',
    REST_SHOW_EMPLACEMENT_NPP: URL_BPN + '/getParamsWithKey?key=SHOW_EMPLACEMENT_NPP',

    /**
     * URL HABILITATION
     */
    REST_URL_HABILITATION_GET_USERS: URL_HABILITATION + '/ldap/searchUsersSameJuridiction/{{USERNAME}}',

    /**
     * URL d envoi vers npp
     */
    REST_URL_SEND_NPP: URL_BPN + '/sendToNPP',
    REST_URL_LOCATION_NPP: URL_BPN + '/locationNPP',
    REST_URL_SHARE: URL_BPN + '/share',
    REST_URL_UNSHARE: URL_BPN + '/unshare',


    /**
     * Demande Envoi Message resources
     */
    REST_URL_CPN_SEND_MESSAGE: URL_CPN_MAS_ECHANGE + '/demandesEnvoiMessages',
    REST_URL_CPN_SEND_MESSAGE_MIXTE: URL_CPN_MAS_ECHANGE + '/messages/envoimixte',

    /**
     * AR resources
     */
    REST_URL_SEND_AR_E_BARREAU: URL_CPN_MAS_ECHANGE + '/sendAr',
    REST_URL_POST_SEND_AR_INTO_BPN: URL_CPN_MAS_ECHANGE + '/sendArToBpn',
    REST_URL_POST_SAVE_AR: URL_CPN_MAS_ECHANGE + '/saveAr',
    REST_URL_POST_DEMANDE_AR: URL_CPN_MAS_ECHANGE + '/telechargementAr',

    /**
     * Mailbox resources
     */
    REST_URL_MAILBOX: URL_CPN_MAS_ECHANGE + '/boiteStructurelle',

    REST_URL_USER_MAIL_BOX_LIST: URL_CPN_MAS_ECHANGE + '/boiteStructurelle/access',
    REST_URL_CHECK_BOITE_STRUCTURELLE: URL_CPN_MAS_ECHANGE + '/boiteStructurelle/check',
    REST_URL_CHECK_NOM_BOITE_STRUCTURELLE: URL_CPN_MAS_ECHANGE + '/boiteStructurelle/name',
    REST_URL_CHECK_MAIL_BOITE_STRUCTURELLE: URL_CPN_MAS_ECHANGE + '/boiteStructExistence',
    REST_URL_UPDATE_BOITES_STRUCTURELLES: URL_CPN_MAS_ECHANGE + '/boiteStructurelles',

    /**
     * Message resources
     */
    REST_URL_CPN_NOTIFICATION: URL_CPN_MAS_ECHANGE + '/messages/alert',
    REST_URL_CPN_ACTION_MESSAGE: URL_CPN_MAS_ECHANGE + '/messages/action/{typeAction}',
    REST_URL_GET_MESSAGES_SENT: URL_CPN_MAS_ECHANGE + '/allMessageSent',
    REST_URL_GET_ALL_MESSAGES: URL_CPN_MAS_ECHANGE + '/messages/',
    REST_URL_CPN_GET_MESSAGE: URL_CPN_MAS_ECHANGE + '/messages/id/',
    REST_URL_CPN_LIST_DELETED_MESSAGE: URL_CPN_MAS_ECHANGE + '/messages/deleted',
    REST_URL_GET_TELECHARGEMENT_PJ_EXCHANGE: URL_CPN_MAS_ECHANGE + '/downloadPj',
    REST_URL_GET_PREVIEW_PJ: URL_CPN_MAS_ECHANGE + '/previewPj',

    /**
     * Signature resources
     */
    REST_URL_API_SIGNATURE: URL_CPN_MAS_ECHANGE + '/signatures',

    /**
     * Setting resources
     */
    REST_URL_GET_CPN_CONFIG: URL_CPN_MAS_ECHANGE + '/settings/config',
    REST_URL_APPLICATION_DOMAIN_LIST: URL_CPN_MAS_ECHANGE + '/application/domaines',
    REST_URL_APPLICATION_NOTIDOC: URL_CPN_MAS_ECHANGE + '/application/notidoc/url',

    /**
     * URLs INDICATEUR LOG
     */
    REST_URL_POST_INDICATEUR: URL_CPN_MAS_ECHANGE + '/logIndicateur',


    REST_URL_CPN_SEND_MESSAGE_SYNCHRONE: URL_CPN_MAS_INTERFACE_PLINE_PLEX + '/sendMessageSynchrone',
    REST_URL_CPN_SEND_DEMANDE_DOCUMENT_INTO_NPP: URL_CPN_MAS_INTERFACE_PLINE_PLEX + '/demandeEnvoiDocumentDansNPP',
    REST_URL_CPN_SEND_DEMANDE_DOCUMENT_INTO_BPN: URL_CPN_MAS_INTERFACE_PLINE_PLEX + '/demandeEnvoiDocumentBpn',
    REST_URL_GET_TELECHARGEMENT_PJ: URL_CPN_MAS_INTERFACE_PLINE_PLEX + '/telechargementPj',
    REST_URL_GET_TELECHARGEMENT_ZIP: URL_CPN_MAS_INTERFACE_PLINE_PLEX + '/telechargementZip',

    /**
     * JDR resources
     */
    REST_URL_CPN_PROCEDURE_NOTIFICATION: URL_CPN_MAS_JDR + '/procedures/numberOfNewProcedures',
    REST_URL_GET_PROCEDURE: URL_CPN_MAS_JDR + '/procedures/search',
    REST_URL_GET_PROCEDURE_STATUS_BY_IDS: URL_CPN_MAS_JDR + '/procedures/listStatutProcedure',
    REST_URL_GET_PROCEDURE_BY_ID: URL_CPN_MAS_JDR + '/procedures',
    REST_URL_GET_FILES_BY_PROCEDURE_ID: URL_CPN_MAS_JDR + '/procedure-fichiers',
    REST_URL_GET_PREVIEW_PROCEDURE_FILE: URL_CPN_MAS_JDR + '/procedure-fichiers/previewFile',
    REST_URL_DOWNLOAD_PROCEDURE: URL_CPN_MAS_JDR + '/procedures/{id}/downloadZip',
    REST_URL_BOOK_PROCEDURE: URL_CPN_MAS_JDR + '/procedures/book',
    REST_URL_PUT_PROCEDURE_COMMENTARY: URL_CPN_MAS_JDR + '/procedures/{id}/update-commentary',

    REST_URL_GET_ALL_SERVICES: URL_CPN_MAS_JDR + '/services/codeSrj',

    REST_URL_SOUS_SERVICES: URL_CPN_MAS_JDR + '/sous-services',
    REST_URL_GET_ALL_SOUS_SERVICES_BY_SERVICE: URL_CPN_MAS_JDR + '/sous-services/service',
    REST_URL_GET_ALL_SOUS_SERVICES_BY_CODE_SRJ: URL_CPN_MAS_JDR + '/sous-services/code-srj',

    REST_URL_GET_ALL_ORIENTATIONS: URL_CPN_MAS_JDR + '/orientations/code-srj',
    REST_URL_GET_ALL_ORIENTATIONS_FROM_SPP: URL_CPN_MAS_JDR + '/referentiel/orientationsPenales',
    REST_URL_CREATE_UPDATE_ORIENTATION: URL_CPN_MAS_JDR + '/orientations',

    REST_URL_COLORS: URL_CPN_MAS_JDR + '/couleurs',
    REST_URL_GET_COLORS: URL_CPN_MAS_JDR + '/couleurs/code-srj',
    REST_URL_IS_LIBELLE_COLOR: URL_CPN_MAS_JDR + '/couleurs/label',

    /**
     *  ANNUAIRE
     */
    REST_URL_CONTACT_MAS_ANNUAIRES: URL_CPN_MAS_ANNUAIRE + '/contacts',
    REST_URL_CONTACT_MAS_ANNUAIRES_CHECK: URL_CPN_MAS_ANNUAIRE + '/contacts/check',

    /**
     * URLs SPS
     */
    REST_URL_SPS_INIT_MODAL: URL_BPN + '/initCallModale',
    REST_URL_SPS_GESTION_AFFAIRE_MODAL: URL_BPN + '/initCallModaleReceptionProcedure'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
