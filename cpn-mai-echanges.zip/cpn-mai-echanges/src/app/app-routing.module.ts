import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './core/helpers/auth.guard';
import { UserAction } from './core/models/user-action.model';
import { MessagingModule } from './messaging/messaging.module';
import { ProceduresModule } from './procedures/procedures.module';

const routes: Routes = [
    {
        path: '',
        redirectTo: 'messages',
        pathMatch: 'full',
    },
    {
        path: 'messages',
        loadChildren: () => import('./messaging/messaging.module').then(m => m.MessagingModule)
    },
    {
        path: 'procedures',
        canActivate: [AuthGuard],
        data: {roles: [UserAction.ACESS_PAGE_PROCEDURE]},
        loadChildren: () => import('./procedures/procedures.module').then(m => m.ProceduresModule)
    }
];

@NgModule({
    imports: [
        RouterModule.forRoot(routes, {relativeLinkResolution: 'legacy'}),
        MessagingModule,
        ProceduresModule
    ],
    exports: [RouterModule]
})
export class AppRoutingModule {
}
