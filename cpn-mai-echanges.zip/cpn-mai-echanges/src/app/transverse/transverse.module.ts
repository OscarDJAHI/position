import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DisplayIfHasPermissionDirective } from './directives/display-if-has-permission.directive';

@NgModule({
    declarations: [
        DisplayIfHasPermissionDirective,
    ],
    imports: [
        CommonModule
    ],
    exports: [
        DisplayIfHasPermissionDirective,
    ]
})
export class TransverseModule {
}
