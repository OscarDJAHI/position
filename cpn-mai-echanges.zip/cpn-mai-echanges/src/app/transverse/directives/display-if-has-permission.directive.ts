import { Directive, Input, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import { PermissionService } from 'src/app/core/services/permissions/permission.service';

@Directive({
    selector: '[displayIfHasPermission]'
})
export class DisplayIfHasPermissionDirective implements OnInit {
    @Input('displayIfHasPermission') permissions: string[];

    constructor(
        private templateRef: TemplateRef<any>,
        private viewContainer: ViewContainerRef,
        private permissionService: PermissionService
    ) {
    }

    ngOnInit() {
        if (!this.permissionService.hasPermission(this.permissions)) {
            this.viewContainer.clear();
        } else {
            this.viewContainer.createEmbeddedView(this.templateRef);
        }
    }
}
