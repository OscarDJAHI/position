export interface MessageAttachment {
    id?: number;
    idSps: string;
    uri: string;
    nom: string;
    type: string;
    level?: number;
    size?: number;
    source?: string;
}
