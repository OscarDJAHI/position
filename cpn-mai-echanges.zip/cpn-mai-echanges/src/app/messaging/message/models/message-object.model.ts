import { Domain } from '../../contact/models/domain.model';
import { EmailChecked } from './email-checked.model';
import { MessageAttachment } from './message-attachment.model';

export interface MessageObject {
    sender: string;
    recipientRow: [{
        domainList: Domain[];
        recipients: string[];
        recipientsChecked: EmailChecked[];
        addButton: boolean;
        deleteButton: boolean;
    }];
    mailSubject: string;
    mailBody: string;
    mailFiles: MessageAttachment[];
    mailExpieration: { expirationList: any[], selectedValue: number };
    sendMailButton: boolean;
    multipartFileArray: File[];
}
