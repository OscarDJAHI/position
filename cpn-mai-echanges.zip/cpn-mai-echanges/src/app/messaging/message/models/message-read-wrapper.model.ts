import { Message, MessageRead } from './message.model';

export class MessageReadWrapper {
    messageList: Message;
    message: MessageRead;
    boxEmail: string;
    deleted: boolean;
    nominativeBox: boolean;
}
