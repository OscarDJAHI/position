export interface Message {
    id: string;
    idExterne: string;
    isAvocat: boolean;
    originMessage: string;
    subject: string;
    comment?: string;
    creation_date: string;
    expiration_date: string;
    project: string;
    project_id: string;
    sender: string;
    recipients: string[];
    nb_files: number;
    viewed: number;
    sent: number;
    traite: string;
    arEbarreauSent: boolean;
    deleted: boolean;
    deletedBy: String;
    deletedDate: Date;
    emailBoite: string;
}

export interface MessageRead {
    id: number;
    type: string;
    subject: string;
    comment: string;
    sender: {
        index: number,
        email: string,
        uid: string,
        domain: string,
        type: string
    };
    recipients: {
        index: number,
        email: string,
        uid: string,
        domain: string,
        type: string
    }[];
    date: string;
    expiration_date: string;
    encrypted: number;
    signed: number;
    pre_archiving_status: string;
    files: MessageReadFile[];
    download_url: string;
    access_url: string;
    size: number;
    email: string;
    audit: Audit;
    originMessage: string;
    idExterne: string;
    deleted: boolean;
}

export interface Audit {
    viewed: AttachmentAudit[];
    downloaded: AttachmentAudit[];
}

export interface AttachmentAudit {
    user_index: number;
    file_index: number;
    date: Date;
}

export interface MessageReadFile {
    index: number;
    name: string;
    size: number;
    download_url: string;
    digest: string;
    content: string;
    contentType: string;
}
