import { MessageRecipient } from './message-recipient.model';

export class MessageParamSender {
    recipients: MessageRecipient[];
    subject: string;
    comment: string;
    encrypted: number;
    lifetime: number;
    emailBoiteStructurelle?: string;
}
