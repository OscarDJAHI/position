export interface EmailChecked {
    email: string;
    exist: boolean;
}
