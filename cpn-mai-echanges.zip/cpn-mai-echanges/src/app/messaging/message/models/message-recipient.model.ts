import { EmailChecked } from './email-checked.model';

export interface MessageRecipient {
    domain: string;
    canal: string;
    email: string;
    emailChecked?: EmailChecked[];
}
