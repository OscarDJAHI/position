export interface Signature {
    userUid: string;
    content: string;
    creationDate?: Date;
}
