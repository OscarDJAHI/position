import { Message } from './message.model';

export interface MessageParams {
    typeBox?: string;
    isNomitativeBox?: string;
    boxMail?: string;
    boxMails?: string[];
    page?: string;
    sort?: string;
    numberPerPage?: string;
    term?: string;
    orderBy?: string;
    currentMessageReadId?: number;
    currentMessageRead?: Message;
    deleted?: string;
}
