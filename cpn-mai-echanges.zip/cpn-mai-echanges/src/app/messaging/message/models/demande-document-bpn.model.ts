export class DemandeDocumentBpn {
    id: number;
    idMessage: number;
    idNoeud: string;
    originMessage: string;
    idExterne: string;
    userMail: string;
    codeSrj: string;
    idLdap: string;
    emailBs: string;
    demandeEnvoiDocumentBpnFiles: DemandeDocumentBpnFile[];
}

export class DemandeDocumentBpnFile {
    id: number;
    name: string;
    externalId: string;
}
