import { MessageAttachment } from './message-attachment.model';
import { MessageRecipient } from './message-recipient.model';

export interface MessageToSend {
    comment: string;
    encrypted: number;
    fichierMessages: MessageAttachment[];
    lifetime: string;
    messageDestinataires: MessageRecipient[];
    sender: {
        email: string;
        userId: string;
    };
    signed: number;
    subject: string;
}
