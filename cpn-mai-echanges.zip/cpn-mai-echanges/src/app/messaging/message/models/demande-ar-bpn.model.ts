export class DemandeArBpn {
    idMessage: number;
    idNoeud: string;
    userMail: string;
    codeSrj: string;
    idLdap: string;
}
