import { TabElement } from '../../shared/models/tabs.model';
import { Message } from './message.model';

export class MessageListWrapper {
    typeBox: string;
    boxEmail: string;
    isNominativeBox: string;
    currentPage: string;
    messages: any;
    currentMessageReadId: number;
    lastOpenedMessageList: Message;
    term: string;
    searchMode?: boolean;
    tabs?: TabElement[];
}
