import { NgModule } from '@angular/core';

import { ContactModule } from '../contact/contact.module';
import { SharedModule } from '../shared/shared.module';

import { AttachmentDisplayComponent } from './components/attachment-display/attachment-display.component';
import { MessageAuditComponent } from './components/audit/message-audit.component';
import { MessageAuditModalComponent } from './components/audit-modal/message-audit-modal.component';
import { MessageDetailComponent } from './components/detail/message-detail.component';
import { MessageFlagComponent } from './components/flag/message-flag.component';
import { MessageListComponent } from './components/list/message-list.component';
import { MessageWriteComponent } from './components/write/message-write.component';
import { MessageWriteModalComponent } from './components/write-modal/message-write-modal.component';
import { MessageWriteModalRestoreComponent } from './components/write-modal-restore/message-write-modal-restore.component';
import { MessageSearchService } from './services/message-search.service';
import { CpnMasEchangeService } from './services/cpn-mas-echange.service';
import { CpnMasInterfaceService } from './services/cpn-mas-interface.service';
import { MessagesListService } from './services/messages-list.service';
import { MessageSearchTabService } from './services/message-search-tab.service';
import { NotidocModalComponent } from './components/notidoc-modal/notidoc-modal.component';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { SignatureComponent } from './components/signature/signature.component';
import { NgxUiLoaderModule } from 'ngx-ui-loader';
import { TransverseModule } from 'src/app/transverse/transverse.module';
import { DisplayExpirationRemainTime } from './directives/expiration-time-remaining.directive';

@NgModule({
    declarations: [
        AttachmentDisplayComponent,
        MessageAuditComponent,
        MessageAuditModalComponent,
        MessageDetailComponent,
        MessageFlagComponent,
        MessageListComponent,
        MessageWriteComponent,
        MessageWriteModalComponent,
        MessageWriteModalRestoreComponent,
        NotidocModalComponent,
        SignatureComponent,
        DisplayExpirationRemainTime
    ],
    imports: [
        ContactModule,
        SharedModule,
        ReactiveFormsModule,
        CommonModule,
        NgxUiLoaderModule,
        TransverseModule
    ],
    exports: [
        MessageWriteModalRestoreComponent,
        MessageListComponent,
        MessageDetailComponent,
    ],
    entryComponents: [
        AttachmentDisplayComponent,
        MessageAuditModalComponent,
        MessageWriteModalComponent,
        NotidocModalComponent,
        SignatureComponent,
    ],
    providers: [
        CpnMasEchangeService,
        CpnMasInterfaceService,
        MessagesListService,
        MessageSearchService,
        MessageSearchTabService,
    ]
})
export class MessageModule {
}
