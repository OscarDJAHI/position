import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Signature } from '../models/signature.model';

@Injectable({
    providedIn: 'root'
})
export class SignatureService {

    constructor(private http: HttpClient) {
    }

    getSignature(userUid: string): Observable<Signature> {
        return this.http.get<Signature>(`${ environment.REST_URL_API_SIGNATURE }/${ userUid }`);
    }

    create(signature: Signature): Observable<any> {
        return this.http.post<any>(environment.REST_URL_API_SIGNATURE, signature);
    }

    update(signature: Signature): Observable<any> {
        return this.http.put<any>(environment.REST_URL_API_SIGNATURE, signature);
    }
}
