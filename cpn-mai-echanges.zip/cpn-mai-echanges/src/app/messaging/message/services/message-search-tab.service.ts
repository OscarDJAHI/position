import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { NgxUiLoaderService } from 'ngx-ui-loader';

import { BoxType } from 'src/app/core/models/enums/box-type.enum';

import { TAB_ITEM_LIST } from '../../shared/constants/constants';
import { TabElement } from '../../shared/models/tabs.model';
import { DataService } from '../../shared/services/data.service';

import { MessageListWrapper } from '../models/message-list-wrapper.model';
import { MessageParams } from '../models/message-params.model';

import { CpnMasEchangeService } from './cpn-mas-echange.service';

@Injectable()
export class MessageSearchTabService {
    tabItemList: TabElement[];
    searchMode: boolean;

    constructor(
        private masEchangeService: CpnMasEchangeService,
        private ngxService: NgxUiLoaderService,
        private dataService: DataService,
        private http: HttpClient
    ) {
    }

    initTabs(activeElmlt: TabElement, countInbox: number, countSent: number) {
        this.tabItemList = TAB_ITEM_LIST;

        this.tabItemList.find(r => r.typeBox === BoxType.INBOX).count = countInbox;
        this.tabItemList.find(r => r.typeBox === BoxType.SENT).count = countSent;

        if (activeElmlt === null) {
            this.tabItemList.find(r => r.typeBox === BoxType.INBOX).active = true;
        } else {
            this.tabItemList.forEach(r => {
                r.active = r.label === activeElmlt.label;
            });
        }

        return this.tabItemList;
    }

    searchMessages(params: MessageParams, activeElmlt: TabElement) {
        this.customUiLoader();

        if (params.numberPerPage == null) {
            params.numberPerPage = '10';
        }
        if (params.orderBy == null) {
            params.orderBy = 'desc';
        }
        if (params.sort == null) {
            params.sort = '';
        }
        if (params.page == null) {
            params.page = '1';
        }

        this.dataService.currentBoxEmail = String(this.dataService.newUserInfo.mail);

        const wrapper = new MessageListWrapper();

        this.masEchangeService.searchMessages(params.typeBox, params.numberPerPage, params.orderBy, params.page, params.sort,
                params.isNomitativeBox, params.boxMails, params.term)
            .subscribe(
                data => {
                    wrapper.boxEmail = params.boxMail;
                    wrapper.currentPage = params.page;
                    wrapper.isNominativeBox = params.isNomitativeBox;
                    wrapper.typeBox = params.typeBox;
                    wrapper.messages = data;
                    wrapper.currentMessageReadId = params.currentMessageReadId;
                    wrapper.lastOpenedMessageList = params.currentMessageRead;

                    wrapper.searchMode = true;
                    wrapper.term = params.term;
                    wrapper.tabs = this.initTabs(activeElmlt, data.countInbox, data.countSent);

                    this.dataService.listMessagesEmitter.next(wrapper);
                },
                error => {
                    console.error('erreur pendant la recup message : ', error);
                    this.ngxService.stopLoader('searchLoader');
                },
                () => {
                    this.dataService.isScroll = false;
                    this.ngxService.stopLoader('searchLoader');
                });
    }


    searchMessages$(params: MessageParams, activeElmlt: TabElement) {
        this.customUiLoader();

        if (params.numberPerPage == null) {
            params.numberPerPage = '10';
        }
        if (params.orderBy == null) {
            params.orderBy = 'desc';
        }
        if (params.sort == null) {
            params.sort = '';
        }
        if (params.page == null) {
            params.page = '1';
        }

        const wrapper = new MessageListWrapper();
        wrapper.currentPage = params.page;

        return this.masEchangeService.searchMessages(params.typeBox, params.numberPerPage, params.orderBy, params.page, params.sort,
            params.isNomitativeBox, params.boxMails, params.term)
    }

    private customUiLoader() {
        this.ngxService.startLoader('searchLoader');
        document.querySelector('.cpn-loader .ngx-overlay').classList.remove('ngx-position-absolute');
        document.querySelector('.cpn-loader .ngx-foreground-spinner')['style']['width'] = '224px';
    }
}
