import { Injectable } from '@angular/core';

import { Observable, Subject } from 'rxjs';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { BoxType } from 'src/app/core/models/enums/box-type.enum';

import { TAB_ITEM_LIST } from '../../shared/constants/constants';
import { TabElement } from '../../shared/models/tabs.model';
import { CpnMasEchangeService } from './cpn-mas-echange.service';
import { DataService } from '../../shared/services/data.service';

import { MessageListWrapper } from '../models/message-list-wrapper.model';
import { MessageParams } from '../models/message-params.model';

@Injectable()
export class MessageSearchService {
    tabItemList: TabElement[];
    searchMode: boolean;

    private headerSearchAction = new Subject<string>();

    constructor(
        private masEchangeService: CpnMasEchangeService,
        private ngxService: NgxUiLoaderService,
        private dataService: DataService
    ) {
    }

    initTabs(countInbox: number, countSent: number) {
        this.tabItemList = TAB_ITEM_LIST;

        this.tabItemList.find(r => r.typeBox === BoxType.INBOX).active = true;
        this.tabItemList.find(r => r.typeBox === BoxType.INBOX).count = countInbox;

        this.tabItemList.find(r => r.typeBox === BoxType.SENT).count = countSent;
        this.tabItemList.find(r => r.typeBox === BoxType.SENT).active = false;

        return this.tabItemList;
    }

    searchMessages(params: MessageParams) {
        this.customUiLoader();

        if (params.numberPerPage == null) {
            params.numberPerPage = '10';
        }

        if (params.orderBy == null) {
            params.orderBy = 'desc';
        }

        if (params.sort == null) {
            params.sort = '';
        }

        if (params.page == null) {
            params.page = '1';
        }

        this.dataService.currentBoxEmail = String(this.dataService.newUserInfo.mail);

        this.masEchangeService.searchMessages(params.typeBox, params.numberPerPage, params.orderBy, params.page, params.sort,
                params.isNomitativeBox, params.boxMails, params.term)
            .subscribe(
                data => {
                    const wrapper = new MessageListWrapper();
                    wrapper.boxEmail = params.boxMail;
                    wrapper.currentPage = params.page;
                    wrapper.isNominativeBox = params.isNomitativeBox;
                    wrapper.typeBox = params.typeBox;
                    wrapper.messages = data;
                    wrapper.currentMessageReadId = params.currentMessageReadId;
                    wrapper.lastOpenedMessageList = params.currentMessageRead;
                    wrapper.currentPage = params.page;
                    wrapper.term = params.term;
                    wrapper.tabs = this.initTabs(data.countInbox, data.countSent);
                    wrapper.searchMode = true;

                    this.dataService.listMessagesEmitter.next(wrapper);
                },
                error => {
                    console.error('erreur pendant la recup message : ', error);
                    this.ngxService.stopLoader('searchLoader');
                },
                () => {
                    this.ngxService.stopLoader('searchLoader');
                }
            );
    }

    getSearchHeaderOsb(): Observable<string> {
        return this.headerSearchAction.asObservable();
    }

    notifyHeaderSearchLaunched(message: string): void {
        this.headerSearchAction.next(message);
    }

    private customUiLoader() {
        this.ngxService.startLoader('searchLoader');
        document.querySelector('.cpn-loader .ngx-overlay').classList.remove('ngx-position-absolute');
        document.querySelector('.cpn-loader .ngx-foreground-spinner')['style']['width'] = '224px';
    }
}
