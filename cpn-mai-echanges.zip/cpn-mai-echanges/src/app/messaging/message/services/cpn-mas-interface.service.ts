import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { DemandeDocumentBpn as DemandeDocumentBpn } from '../models/demande-document-bpn.model';

@Injectable()
export class CpnMasInterfaceService {

    constructor(private http: HttpClient) {
    }

    /**
     * Envoi de message avec pièces jointes au masInterfacePlinePlex
     */
    public sendMessageSynchrone(form: FormData): Observable<any> {
        return this.http.post<any>(environment.REST_URL_CPN_SEND_MESSAGE_SYNCHRONE, form);
    }

    /**
     * Envoi d'une demande de dépôt de pièces jointes dans NPP au masInterfacePlinePlex
     */
    public sendDemandeDocumentIntoNPP(data: any): Observable<any> {
        return this.http.post<any>(environment.REST_URL_CPN_SEND_DEMANDE_DOCUMENT_INTO_NPP, data);
    }

    /**
     * Envoi d'une demande de dépôt de pièces jointes dans BPN au masInterfacePlinePlex
     */
    public sendDemandeDocumentIntoBPN(data: DemandeDocumentBpn): Observable<any> {
        return this.http.post<DemandeDocumentBpn>(environment.REST_URL_CPN_SEND_DEMANDE_DOCUMENT_INTO_BPN, data);
    }
}
