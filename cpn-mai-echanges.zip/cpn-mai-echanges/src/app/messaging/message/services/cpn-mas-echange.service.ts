import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { MessageRead } from '../models/message.model';
import { Domain } from '../../contact/models/domain.model';

@Injectable()
export class CpnMasEchangeService {

    constructor(private http: HttpClient) {
    }

    /**
     * Envoi de message avec pièces jointes depuis le pc de l'utilisateur et de bepuis BPN au masEchangeCPN
     */
    public sendMessageMixte(form: FormData): Observable<any> {
        return this.http.post<any>(environment.REST_URL_CPN_SEND_MESSAGE_MIXTE, form);
    }

    /**
     * Envoi de message avec pièces jointe au masEchangeCPN
     */
    sendMessage(documents: any): Observable<any> {
        return this.http.post<any>(environment.REST_URL_CPN_SEND_MESSAGE, documents);
    }

    readMessage(id: number, typeBox: string): Observable<MessageRead> {
        return this.http.get<MessageRead>(environment.REST_URL_CPN_GET_MESSAGE + id + "/" + typeBox);
    }

    getMessages(
        msgType: string,
        sze: string,
        ord: string,
        pg: string,
        srt: string,
        nominativeBox: string,
        cepBox: string,
        trm: string
    ): Observable<any> {
        return this.http.get(`${ environment.REST_URL_GET_ALL_MESSAGES }${ msgType }`,
            {
                params: {
                    size: sze,
                    order: ord,
                    page: pg,
                    sort: srt,
                    boiteNominative: nominativeBox,
                    boitesStructurelles: cepBox,
                    term: trm
                }
            });
    }

    searchMessages(
        msgType: string,
        sze: string,
        ord: string,
        pg: string,
        srt: string,
        nominativeBox: string,
        cepBox: string[],
        trm: string
    ): Observable<any> {
        return this.http.get(`${ environment.REST_URL_GET_ALL_MESSAGES }${ msgType }/filtres`,
            {
                params: {
                    size: sze,
                    order: ord,
                    page: pg,
                    sort: srt,
                    boiteNominative: nominativeBox,
                    boitesStructurelles: cepBox,
                    term: trm
                }
            });
    }

    actionOnMessage(messageIds: string[], typeAction: string): Observable<any> {
        const url = environment.REST_URL_CPN_ACTION_MESSAGE.replace('{typeAction}', typeAction);
        return this.http.put(url, messageIds);
    }

    sendArEbarreau(body: MessageRead): Observable<any> {
        const url = environment.REST_URL_SEND_AR_E_BARREAU;
        return this.http.post(url, body);
    }

    getCpnConfig(): Observable<any> {
        return this.http.get(environment.REST_URL_GET_CPN_CONFIG);
    }

    getDeletedMessages(
        deleted: string,
        emailBox: string,
        pg: string,
        sze: string,
        srt: string,
        ord: string,
    ): Observable<any> {
        return this.http.get(`${ environment.REST_URL_CPN_LIST_DELETED_MESSAGE }/${ deleted }`, {
            params: {
                size: sze,
                order: ord,
                page: pg,
                sort: srt,
                emailBox: emailBox
            }
        });
    }

    getDomainList(appName: string): Observable<Domain[]> {
        return this.http.get<Domain[]>(`${ environment.REST_URL_APPLICATION_DOMAIN_LIST }/${ appName }`);
    }

    getUrlNotidoc(): Observable<any> {
        return this.http.get(environment.REST_URL_APPLICATION_NOTIDOC, { responseType: 'text' });
    }
}
