import { Injectable } from '@angular/core';

import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Observable } from 'rxjs';

import { CpnMasEchangeService } from './cpn-mas-echange.service';
import { DataService } from '../../shared/services/data.service';
import { Pagination } from '../../shared/constants/paginationConstants';
import { MessageListWrapper } from '../models/message-list-wrapper.model';
import { MessageParams } from '../models/message-params.model';

@Injectable()
export class MessagesListService {

    constructor(
        private masEchangeService: CpnMasEchangeService,
        private ngxService: NgxUiLoaderService,
        private dataService: DataService
    ) {
    }

    getMessages(params: MessageParams) {
        this.ngxService.startLoader('loader-message-list');

        if (params.numberPerPage == null) {
            params.numberPerPage = Pagination.DEFAULT.NUMBER_PER_PAGE;
        }

        if (params.orderBy == null) {
            params.orderBy = Pagination.DEFAULT.ORDER_BY;
        }

        if (params.sort == null) {
            params.sort = Pagination.DEFAULT.SORT;
        }

        if (params.term == null) {
            params.term = Pagination.DEFAULT.TERM;
        }

        if (params.page == null) {
            params.page = Pagination.DEFAULT.PAGE;
        }

        this.dataService.currentBoxEmail = params.boxMail;

        this.masEchangeService.getMessages(params.typeBox, params.numberPerPage, params.orderBy, params.page, params.sort,
            params.isNomitativeBox, params.boxMail, params.term)
            .subscribe(
                data => {
                    const wrapper = new MessageListWrapper();
                    wrapper.boxEmail = params.boxMail;
                    wrapper.currentPage = params.page;
                    wrapper.isNominativeBox = params.isNomitativeBox;
                    wrapper.typeBox = params.typeBox;
                    wrapper.messages = data;
                    wrapper.currentMessageReadId = params.currentMessageReadId;
                    wrapper.lastOpenedMessageList = params.currentMessageRead;
                    wrapper.searchMode = false;
                    this.dataService.currentBoxEmail = params.boxMail;
                    this.dataService.listMessagesEmitter.next(wrapper);

                    const readMsgWrapper = {
                        messageList: data.messagesFiltered.content,
                        message: null,
                        boxEmail: params.boxMail,
                        deleted: false,
                        nominativeBox: !!(params.isNomitativeBox)
                    };

                    this.dataService.updatedMessageEmitter.emit(readMsgWrapper);
                },
                error => {
                    console.error('erreur pendant la recup message : ', error);
                    this.ngxService.stopLoader('loader-message-list');
                }, () => {
                    this.ngxService.stopLoader('loader-message-list');
                });
    }

    getDeletedMessages(params: MessageParams) {
        this.ngxService.startLoader('loader-message-list');

        if (params.numberPerPage == null) {
            params.numberPerPage = Pagination.DEFAULT.NUMBER_PER_PAGE;
        }

        if (params.orderBy == null) {
            params.orderBy = Pagination.DEFAULT.ORDER_BY;
        }

        if (params.sort == null) {
            params.sort = Pagination.DEFAULT.SORT;
        }

        if (params.page == null) {
            params.page = Pagination.DEFAULT.PAGE;
        }

        this.masEchangeService.getDeletedMessages(
            params.deleted,
            params.boxMail,
            params.page,
            params.numberPerPage,
            params.sort,
            params.orderBy,
        ).subscribe(
            data => {
                const wrapper = new MessageListWrapper();
                wrapper.boxEmail = params.boxMail;
                wrapper.currentPage = params.page;
                wrapper.isNominativeBox = params.isNomitativeBox;
                wrapper.typeBox = params.typeBox;
                wrapper.messages = data;
                wrapper.searchMode = false;

                this.dataService.listMessagesEmitter.next(wrapper);

                const readMsgWrapper = {
                    messageList: data.messagesFiltered.content,
                    message: null,
                    boxEmail: params.boxMail,
                    deleted: true,
                    nominativeBox: !!(params.isNomitativeBox)
                };

                this.dataService.updatedMessageEmitter.emit(readMsgWrapper);
            },
            error => {
                console.error('erreur pendant la recup message : ', error);
                this.ngxService.stopLoader('loader-message-list');
            }, () => {
                this.ngxService.stopLoader('loader-message-list');
            });
    }

    getDeletedMessages$(params: MessageParams): Observable<any> {
        this.ngxService.startLoader('loader-message-list');

        if (params.numberPerPage == null) {
            params.numberPerPage = Pagination.DEFAULT.NUMBER_PER_PAGE;
        }

        if (params.orderBy == null) {
            params.orderBy = Pagination.DEFAULT.ORDER_BY;
        }

        if (params.sort == null) {
            params.sort = Pagination.DEFAULT.SORT;
        }

        if (params.page == null) {
            params.page = Pagination.DEFAULT.PAGE;
        }

        return this.masEchangeService.getDeletedMessages(
            params.deleted,
            params.boxMail,
            params.page,
            params.numberPerPage,
            params.sort,
            params.orderBy,
        );
    }

    getMessages$(params: MessageParams): Observable<any> {
        if (params.numberPerPage == null) {
            params.numberPerPage = Pagination.DEFAULT.NUMBER_PER_PAGE;
        }

        if (params.orderBy == null) {
            params.orderBy = Pagination.DEFAULT.ORDER_BY;
        }

        if (params.sort == null) {
            params.sort = Pagination.DEFAULT.SORT;
        }

        if (params.page == null) {
            params.page = Pagination.DEFAULT.PAGE;
        }

        return this.masEchangeService.getMessages(params.typeBox, params.numberPerPage, params.orderBy, params.page, params.sort,
            params.isNomitativeBox, params.boxMail, params.term);
    }

    searchMessages(params: MessageParams) {
        this.ngxService.start();

        if (params.numberPerPage == null) {
            params.numberPerPage = Pagination.DEFAULT.NUMBER_PER_PAGE;
        }

        if (params.orderBy == null) {
            params.orderBy = Pagination.DEFAULT.ORDER_BY;
        }

        if (params.sort == null) {
            params.sort = Pagination.DEFAULT.SORT;
        }

        if (params.page == null) {
            params.page = Pagination.DEFAULT.PAGE;
        }

        this.dataService.currentBoxEmail = params.boxMail;  // TODO à conserver pour la recherche?

        this.masEchangeService.searchMessages(params.typeBox, params.numberPerPage, params.orderBy, params.page, params.sort,
            params.isNomitativeBox, params.boxMails, params.term)
            .subscribe(
                data => {
                    const wrapper = new MessageListWrapper();
                    wrapper.boxEmail = params.boxMail;
                    wrapper.currentPage = params.page;
                    wrapper.isNominativeBox = params.isNomitativeBox;
                    wrapper.typeBox = params.typeBox;
                    wrapper.messages = data;
                    wrapper.currentMessageReadId = params.currentMessageReadId;
                    wrapper.lastOpenedMessageList = params.currentMessageRead;
                    wrapper.term = params.term;
                    // TODO rajouter les nouveaux attributs count...
                    this.dataService.listMessagesEmitter.next(wrapper);
                },
                error => {
                    console.error('erreur pendant la recup message : ', error);
                    this.ngxService.stop();
                }, () => {
                    this.ngxService.stop();
                });
    }
}
