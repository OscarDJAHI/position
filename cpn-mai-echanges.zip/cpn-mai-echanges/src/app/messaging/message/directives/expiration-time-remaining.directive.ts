import { Directive, ElementRef, Input, OnChanges } from '@angular/core';

@Directive({
    selector: '[displayExpirationRemainTime]'
})
export class DisplayExpirationRemainTime implements OnChanges {
    @Input('displayExpirationRemainTime') expirationDate = '';

    constructor(private el: ElementRef) {
    }

    ngOnChanges() {
        this.computeExpirationRemainTime();
    }

    private computeExpirationRemainTime() {
        this.el.nativeElement.innerHTML = '';

        const currentDate = new Date();
        const expirationDate = new Date(this.expirationDate);

        if (currentDate.toDateString() === expirationDate.toDateString()) {
            const remainTimeInMilliseconds = expirationDate.getTime() - currentDate.getTime();
            this.el.nativeElement.innerHTML = this.dispalyRemainTime(this.millisecondToTime(remainTimeInMilliseconds));
        }
    }

    private millisecondToTime(milliseconds: number) {
        const second = 1000;
        const minute = second * 60;
        const hour = minute * 60;

        const hours = Math.floor(milliseconds / hour % 24);
        const minutes = Math.floor(milliseconds / minute % 60);

        return { hr: hours, mm: minutes };
    }

    private dispalyRemainTime(time: { hr: number, mm: number }) {
        let hoursMsg = '';
        let minutesMsg = '';
        let s = '';

        if (time.hr) {
            s = time.hr > 1 ? 's' : '';
            hoursMsg = `<b>${time.hr} heure${s}</b>`;
        }

        if (time.mm) {
            s = time.mm > 1 ? 's' : '';
            minutesMsg = `<b>${time.mm} minute${s}</b>`;
        }

        return `Expire dans ${hoursMsg} ${minutesMsg}`;
    }
}
