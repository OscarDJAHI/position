import { Component, Input, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';

import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

import * as fileSaver from 'file-saver';
import { Arborescence } from 'src/app/core/models/arborescence.model';
import { BoxType } from 'src/app/core/models/enums/box-type.enum';

import { Message, MessageRead, MessageReadFile } from 'src/app/messaging/message/models/message.model';
import { UtilsService } from 'src/app/messaging/shared/services/utils.service';
import { CpnMasEchangeService } from 'src/app/messaging/message/services/cpn-mas-echange.service';
import { AttachmentService } from 'src/app/messaging/shared/services/attachment.service';

import {
    DEMANDE_DOCUMENT_INTO_BPN_ERROR_MESSAGE,
    DEMANDE_DOCUMENT_INTO_BPN_ERROR_TITLE,
    DEMANDE_DOCUMENT_INTO_BPN_SUCCESS_MESSAGE,
    DEMANDE_DOCUMENT_INTO_BPN_SUCCESS_TITLE,
    MODAL_ARBO_BPN_DL_FILE_TITLE,
    MODAL_ARBO_BPN_DL_FILE_VALIDATE_BTN,
    OriginMessage
} from '../../../shared/constants/constants';
import { SendToNppComponent } from '../../../shared/modals/send-to-npp/send-to-npp.component';
import { DocExplorerComponent } from '../../../shared/components/doc-explorer/doc-explorer.component';
import { AlertesModalService } from '../../../shared/services/alertes-modal.service';
import { DataService } from '../../../shared/services/data.service';
import { StorageService } from '../../../shared/services/storage.service';

import { DemandeDocumentBpn, DemandeDocumentBpnFile } from '../../models/demande-document-bpn.model';
import { MessageReadWrapper } from '../../models/message-read-wrapper.model';
import { CpnMasInterfaceService } from '../../services/cpn-mas-interface.service';

import { AttachmentDisplayComponent } from '../attachment-display/attachment-display.component';
import { MessageWriteModalComponent } from '../write-modal/message-write-modal.component';
import { StringUtils } from '../../../shared/utils/string.utils';
import { SpsService } from '../../../../core/services/sps/sps.service';
import { IndicatorLogService } from 'src/app/core/services/indicators/indicator-log.service';
import { UserAction } from 'src/app/core/models/user-action.model';
import { ConfigurationService } from 'src/app/core/services/configuration/configuration.service';

@Component({
    selector: 'app-message-detail',
    templateUrl: './message-detail.component.html',
    styleUrls: ['./message-detail.component.scss']
})
export class MessageDetailComponent implements OnInit {

    messageMapping = {
        '=0': 'Aucun fichier n\'a été téléchargé',
        '=1': '1 fichier a été téléchargé',
        other: '# fichiers ont été téléchargés'
    };

    message: MessageRead;
    messageList: Message;
    boxEmail: string;
    nominativeBox: boolean;
    alreadyDeletedMessage: boolean;

    messageID: number;
    isDownloadArButtonDisabled = true;
    isSent = false;

    isPjSelected = false;
    fileCheckedList = [];
    fileForm: FormGroup;
    sentAr = false;

    node: Arborescence[];

    btnDlNppDisabled = true;
    btnDlNppShowInformation = false;

    btnDlBpnDisabled = true;
    btnDownloadBpnShowInformation = false;

    showDefaultPage = true;
    dateDuJour: Date;
    isMessageExpired = false;

    userAction = UserAction;

    @Input() typeBox;
    boxType = BoxType;

    constructor(
        public cpnMasEchangeService: CpnMasEchangeService,
        private utilsService: UtilsService,
        private modalService: NgbModal,
        private dataService: DataService,
        private storageService: StorageService,
        private alertModalService: AlertesModalService,
        public activeModal: NgbActiveModal,
        private datePipe: DatePipe,
        private ffb: FormBuilder,
        private attachmentService: AttachmentService,
        private masInterfaceService: CpnMasInterfaceService,
        private spsService: SpsService,
        private indicateurService: IndicatorLogService,
        private configurationService: ConfigurationService
    ) {
        this.fileForm = this.ffb.group({
            checkArray: this.ffb.array([])
        });
    }

    private static toNode(file: any): Arborescence {
        return {
            id: file.index,
            level: 0,
            text: file.name,
            format: file.name.substr(file.name.lastIndexOf('.')),
            path: file.url
        };
    }

    ngOnInit() {
        // Toutes les variables qui doivent être réinitialisé lors d'un changement de message, doivent être réinit içi.
        this.dataService.updatedMessageEmitter.subscribe((wrapper: MessageReadWrapper) => {
            this.initProperties(wrapper);
        });
    }

    formatageRecipientsObject(r: any) {
        return this.utilsService.formatageRecipientsObject(r);
    }

    userInitial(value: any) {
        return this.utilsService.userInitial(value);
    }

    initProperties(wrapper: MessageReadWrapper) {
        this.messageList = wrapper.messageList;
        this.message = wrapper.message;

        if (this.message) {
            this.message.files.forEach(attachment => {
                const type = attachment.contentType || attachment.name.substr(attachment.name.lastIndexOf('.') + 1);
                attachment.contentType = type.toLowerCase();
            });

            this.checkOnDateExpiration(this.message.expiration_date);
            this.alreadyDeletedMessage = wrapper.deleted;

            if (this.alreadyDeletedMessage) {
                this.message = null;
                return;
            }

            this.nominativeBox = wrapper.nominativeBox;
            this.boxEmail = wrapper.boxEmail;
            this.messageID = this.message.id;
            this.isDownloadArButtonDisabled = this.isArButtonToDisable();
            this.sendArEbarreau();
            this.showDefaultPage = this.message.id == null;
        }

        this.fileCheckedList = [];
        this.isPjSelected = false;
        this.sentAr = this.messageList.arEbarreauSent;
        this.isSent = 1 == this.messageList.sent;
        this.fileForm = this.ffb.group({
            checkArray: this.ffb.array([])
        });

        this.btnDlNppDisabled = true;
        this.btnDlNppShowInformation = false;
        this.btnDlBpnDisabled = true;
        this.btnDownloadBpnShowInformation = false;
    }

    isArButtonToDisable(): boolean {
        const audit = this.message.audit;
        if (audit === undefined) {
            return true;
        }

        return (!(audit.viewed != null || audit.downloaded != null)) || !(audit.viewed.length > 0 || audit.downloaded.length > 0);
    }

    isPlinePlexMessage(): boolean {
        return this.message.originMessage !== OriginMessage.EXCHANGE;
    }

    openMessageReponseModal() {
        this.dataService.openTinyWindowRequest.emit(false);
        const writeNewMessageType = { newMsg: false, msgReponse: true };
        this.storageService.destroyStoredMailObject();

        const config = { size: 'xl', windowClass: 'cpn-write-new-mail-modal', centered: true };
        const modalRef = this.modalService.open(MessageWriteModalComponent, config);
        modalRef.componentInstance.name = 'WriteNewMailComponent';
        modalRef.componentInstance.writeNewMessageState = writeNewMessageType;
        modalRef.componentInstance.boxEmail = this.boxEmail;

        localStorage.setItem('writeNewMessageType', JSON.stringify(writeNewMessageType));

        modalRef.componentInstance.previousMessageData = this.formatMessageReponse();
        modalRef.componentInstance.previousMessageSender = this.message.sender.email;
    }

    onCheckboxChange(event: any) {
        const checkArray: FormArray = this.fileForm.get('checkArray') as FormArray;
        if (event.target.checked) {
            checkArray.push(new FormControl(event.target.value));
            this.fileCheckedList.push({
                index: event.target.id,
                name: event.target.name,
                object: this.message.subject,
                url: event.target.value,
                checked: event.target.checked,
                size: event.target.size
            });
        } else {
            let i = 0;
            checkArray.controls.forEach((item: FormControl) => {
                if (item.value == event.target.value) {
                    checkArray.removeAt(i);
                    this.fileCheckedList.splice(i, 1);
                    return;
                }

                i++;
            });
        }

        this.enableOrDisableNppDlBtn();
        this.enableOrDisableBpnDownloadBtn();
    }

    enableOrDisableNppDlBtn() {
        const extValid = ['txt', 'odt', 'docx', 'doc', 'png', 'pdf', 'jpg', 'bmp'];
        const somethingIsFishy = this.utilsService.isNotValidExtension(this.fileCheckedList, extValid);

        this.btnDlNppDisabled = somethingIsFishy;
        this.btnDlNppShowInformation = somethingIsFishy && this.fileCheckedList.length > 0;
    }

    enableOrDisableBpnDownloadBtn() {
        const extValid = ['pdf', 'odt', 'rtf', 'docx', 'ods', 'xls', 'jpg', 'bmp'];
        const somethingIsFishy = this.utilsService.isNotValidExtension(this.fileCheckedList, extValid);

        this.btnDlBpnDisabled = somethingIsFishy;
        this.btnDownloadBpnShowInformation = somethingIsFishy && this.fileCheckedList.length > 0;
    }

    download() {
        if (this.isPlinePlexMessage()) {
            this.downloadFromPlinePlex();
        } else {
            this.downloadFromExchange();
        }
    }

    downloadFromPlinePlex() {
        const mailBS = this.dataService.currentBoxEmail != this.dataService.newUserInfo.mail ? this.dataService.currentBoxEmail : '';
        const object = this.fileCheckedList[0].object;
        const nbFiles = this.fileCheckedList.length;
        if (nbFiles === 1) {
            const name = this.fileCheckedList[0].name;
            const url = this.fileCheckedList[0].url;

            this.attachmentService.downloadFile(this.message.originMessage, mailBS, name, url).subscribe(
                response => {
                    const blob: any = new Blob([response], { type: 'text/json; charset=utf-8' });
                    fileSaver.saveAs(blob, name);
                },
                error => console.log('Error downloading the file'),
                () => console.log('File downloaded successfully'));
        } else if (nbFiles > 1) {
            const urls = [];

            this.fileCheckedList.forEach(file => urls.push(file.url + '&filename=' + file.name));

            this.attachmentService.downloadZipFile(this.message.originMessage, mailBS, object, urls).subscribe(
                response => {
                    const blob: any = new Blob([response], { type: 'text/json; charset=utf-8' });
                    fileSaver.saveAs(blob, object + '.zip');
                },
                error => console.log('Error downloading the file -> ', error),
                () => console.log('ZipFile downloaded successfully'));
        }
    }

    openSendNodesToNppTooltip() {
        if (this.configurationService.cpnConfigMap.modalDocumentDepositEnable) {
            this.openSendNodesToNppWindow();
        } else {
            this.openSendNodesToNppModal();
        }
    }

    downloadFromExchange() {
        const zipName = (this.message.subject != null) ? this.message.subject : (this.fileCheckedList[0].name).split('.', 1);
        const name = (this.fileCheckedList.length === 1) ? this.fileCheckedList[0].name : zipName;
        const attachments = [];
        const nbFiles = this.fileCheckedList.length;
        this.fileCheckedList.forEach(attachment => {
            attachments.push(attachment.url);
        });

        this.attachmentService.downloadPj(this.message.id, name, attachments).subscribe(
            response => {
                const blob: any = new Blob([response], { type: 'text/json; charset=utf-8' });
                fileSaver.saveAs(blob, name + (nbFiles === 1 ? '' : '.zip'));
            },
            error => console.log('Error downloading the file : ', error),
            () => console.log('File downloaded successfully'));
    }

    sendArEbarreau(): void {
        if (this.messageList != null) {
            if (this.messageList.isAvocat && !this.messageList.arEbarreauSent) {
                this.cpnMasEchangeService.sendArEbarreau(this.message).subscribe(
                    data => {
                        this.messageList.arEbarreauSent = true;
                        this.sentAr = true;
                    },
                    error => {
                        console.error('Problème lors de l\'envoie de l\'AR', error);
                    },
                    () => {
                        this.setViewed();
                    }
                );
            } else {
                this.setViewed();
            }
        }
    }

    setViewed() {
        this.messageList.viewed = 1;
    }

    openBpnArborescence() {
        const config = { size: 'lg', windowClass: 'cpn-doc-explorer-modal', centered: true };
        const modalRef = this.modalService.open(DocExplorerComponent, config);
        modalRef.componentInstance.name = 'DocExplorerComponent';
        modalRef.componentInstance.isPochetteOnly = true;
        modalRef.componentInstance.componentTitle = MODAL_ARBO_BPN_DL_FILE_TITLE;
        modalRef.componentInstance.validateBtnLabel = MODAL_ARBO_BPN_DL_FILE_VALIDATE_BTN;
        modalRef.result.then(
            (result) => {
                this.sendDemandeDocumentBpn();
            }, (reason) => {
                // fermeture manuel pas de requête a faire
            });
    }

    sendDemandeDocumentBpn() {
        const demande = new DemandeDocumentBpn();
        const user = this.dataService.newUserInfo;

        demande.userMail = String(user.mail);
        demande.codeSrj = String(user.idJuridiction);
        demande.idLdap = String(user.idLdap);
        demande.originMessage = this.messageList.originMessage;
        demande.idNoeud = this.dataService.idNodeChecked;
        demande.idExterne = this.messageList.idExterne;
        demande.idMessage = this.messageID;
        demande.emailBs = String(this.boxEmail) !== String(user.mail) ? this.boxEmail : null;
        demande.demandeEnvoiDocumentBpnFiles = [];

        this.fileCheckedList.forEach(f => {
            const file = new DemandeDocumentBpnFile();
            file.externalId = f.url;
            file.name = f.name;
            demande.demandeEnvoiDocumentBpnFiles.push(file);
        });

        this.masInterfaceService.sendDemandeDocumentIntoBPN(demande).subscribe(
            data => {
                if (data.id == null) {
                    this.alertModalService.openErrorModal({
                        title: DEMANDE_DOCUMENT_INTO_BPN_ERROR_TITLE,
                        message: DEMANDE_DOCUMENT_INTO_BPN_ERROR_MESSAGE
                    });
                } else {
                    this.alertModalService.openSuccessModal({
                        title: DEMANDE_DOCUMENT_INTO_BPN_SUCCESS_TITLE,
                        message: DEMANDE_DOCUMENT_INTO_BPN_SUCCESS_MESSAGE
                    });
                }
            }, error => {
                this.alertModalService.openErrorModal({
                    title: DEMANDE_DOCUMENT_INTO_BPN_ERROR_TITLE,
                    message: DEMANDE_DOCUMENT_INTO_BPN_ERROR_MESSAGE
                });
                console.error(error);
            }, () => {
                this.dataService.idNodeChecked = null;
            });
    }

    checkOnDateExpiration(dateExpiration: string) {
        this.dateDuJour = new Date();
        const expirationDate = new Date(dateExpiration);

        this.isMessageExpired = expirationDate < this.dateDuJour;
    }

    openPreview(file: MessageReadFile) {
        if (this.isMessageExpired) {
            return false;
        }

        const name = file.name;
        const url = file.download_url;
        const mailBS = this.dataService.currentBoxEmail != this.dataService.newUserInfo.mail ? this.dataService.currentBoxEmail : '';

        const options = { centered: true, size: 'xl', windowClass: 'cpn-preview-modal' };
        const urlPreview = this.attachmentService.getPreviewPjUrl(this.message.originMessage, mailBS, name, url, this.message.id);
        const modal = this.modalService.open(AttachmentDisplayComponent, options);
        modal.componentInstance.data = urlPreview;
        modal.componentInstance.fileName = name;
        modal.componentInstance.contentType = file.contentType;
    }

    isFileNotClickable(file: MessageReadFile) {
        return this.isMessageExpired
            || (!this.isMessageExpired && file.contentType === 'xlsx')
            || (!this.isMessageExpired && file.contentType === 'xls')
            || (!this.isMessageExpired && file.contentType === 'ppt')
            || (!this.isMessageExpired && file.contentType === 'pptx')
            || (!this.isMessageExpired && file.contentType === '7zip')
            || (!this.isMessageExpired && file.contentType === 'rar')
            || (!this.isMessageExpired && file.contentType === 'zip')
            || (!this.isMessageExpired && file.contentType === 'csv');
    }

    private changeExtension(fileCheckedList: any[]) {
        const fileCheckedListTemp = fileCheckedList;
        fileCheckedListTemp.forEach(f => {
            const array = f.name.split('.');
            f.name = array[0] + '.pdf';
        });
        return fileCheckedListTemp;
    }

    private formatMessageReponse() {
        const date = this.utilsService.formatDate(this.message.date);
        const formattedDate = this.datePipe.transform(date, 'EEEE d MMMM y à HH:mm', '', 'fr_FR');

        return `<div id="msgReponse" contentEditable="true">&nbsp;</div>
				<hr style="border-top: 1px solid #ccc; margin-top:40px"/>
				<div>
					<div>
						<b>De: </b><span>${this.message.sender.email}</span>
					</div>
					<div>
						<b>Envoyé: </b><span>Le ${formattedDate}</span>
					</div>
					<div>
						<b>A: </b><span>${this.formatageRecipientsObject(this.message.recipients)}</span>
					</div>
					<div>
						<b>Objet: </b><span>${this.message.subject}</span>
					</div>
					<br />
					<span>${this.message.comment}</span>
				</div>`;
    }

    private openSendNodesToNppWindow() {
        const files = [];
        const fileCheckedListTemp = this.changeExtension(this.fileCheckedList);

        fileCheckedListTemp.forEach(file => {
            files.push({
                idFichier: file.url,
                nom: file.name,
                type: file.name.substr(file.name.lastIndexOf('.')),
                storeType: 'CPN',
                taille: file.size
            });
        });

        const complement = {
            idExterne: this.isPlinePlexMessage() ? this.message.idExterne : this.messageID,
            emailPrimaire: StringUtils.toString(this.dataService.newUserInfo.mail),
            emailSecondaire: this.nominativeBox ? null : this.boxEmail,
            repository: this.message.originMessage
        };

        this.spsService.openDepositModal('CPN', files, complement);
    }

    private openSendNodesToNppModal() {
        const options = { size: 'lg', windowClass: 'cpn-send-pj-to-npp-modal', centered: true };
        const modalRef = this.modalService.open(SendToNppComponent, options);
        const fileCheckedListTemp = this.changeExtension(this.fileCheckedList);
        modalRef.componentInstance.nodes = fileCheckedListTemp.map(MessageDetailComponent.toNode);
        modalRef.componentInstance.idExterne = this.isPlinePlexMessage() ? this.message.idExterne : this.messageID;
        modalRef.componentInstance.originMessage = this.message.originMessage;
        modalRef.componentInstance.emailBs = this.nominativeBox ? null : this.boxEmail;
    }
}
