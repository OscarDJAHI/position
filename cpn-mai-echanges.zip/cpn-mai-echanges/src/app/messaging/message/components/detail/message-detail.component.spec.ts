import { DatePipe } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { NgbActiveModal, NgbModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderModule } from 'ngx-ui-loader';
import { Observable } from 'rxjs';
import { MaterialModule } from 'src/app/core/modules/material/material.module';
import { AuthentificationService } from 'src/app/core/services/authentification/authentification.service';
import { FormateDate } from '../../../shared/pipes/format-date.pipe';
import { AlertesModalService } from '../../../shared/services/alertes-modal.service';
import { CpnMasEchangeService } from '../../services/cpn-mas-echange.service';
import { CpnNotificationService } from '../../../shared/services/cpn-notification.service';
import { DataService } from '../../../shared/services/data.service';
import { DemandeArService } from '../../../shared/services/demande-ar.service';
import { StorageService } from '../../../shared/services/storage.service';
import { UtilsService } from '../../../shared/services/utils.service';
import { MessageDetailComponent } from './message-detail.component';
//import { FileService } from 'src/app/file.service';

// export class DateFormatPipeMock {
//   transform() {
//     return '29.06.2018 15:12';
//   }
// }

class CpnMasEchangServiceMock {
    sendArEbarreau() {
        return Observable.of("OK");
    }
}

describe('DetailMessageComponent', () => {
    let component: MessageDetailComponent;
    let fixture: ComponentFixture<MessageDetailComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [
                MessageDetailComponent,
                FormateDate,
                //  FileService
            ],
            imports: [
                MaterialModule,
                NgxUiLoaderModule,
                FormsModule,
                NgbModule,
                ReactiveFormsModule,
                RouterTestingModule,
                HttpClientModule,
                // FileService
                // DatePipe
            ],
            providers: [
                NgbActiveModal,
                DataService,
                CpnNotificationService,
                // CpnMasEchangeService,
                UtilsService,
                NgbModal,
                DemandeArService,
                AuthentificationService,
                StorageService,
                AlertesModalService,
                DatePipe,
                {provide: CpnMasEchangeService, useValue: CpnMasEchangServiceMock},
                // {
                //   provide: ActivatedRoute,
                //   useValue:
                //   {
                //     snapshot:
                //     {
                //       url: [{ path: 1 }, { path: 2 }]
                //     }
                //   }
                // },
                {
                    provide: ActivatedRoute,
                    useValue: {
                        parent: {
                            parent: {
                                params: {
                                    subscribe: function () {
                                        return;
                                    }
                                }
                            },
                            snapshot: {
                                params: {
                                    subscribe: function () {
                                        return;
                                    }
                                },
                                paramMap: {
                                    get: () => 1, // represents the bookId
                                },
                            },
                        },
                        snapshot: {
                            paramMap: {
                                get: () => 1, // represents the bookId
                            },
                        },
                    }
                }
            ]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(MessageDetailComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    // it('should check selected file', () => {

    // })
    it('should not send AR mail if mail is not Avocat', () => {
        component.messageList = {
            id: "",
            idExterne: "",
            isAvocat: false,
            originMessage: "",
            subject: "subject",
            creation_date: "",
            expiration_date: "",
            project: "",
            project_id: "",
            sender: "",
            recipients: ["mock.mail@mock.mock"],
            nb_files: 3,
            viewed: 0,
            sent: 0,
            traite: "",
            arEbarreauSent: false
        };
        expect(component.cpnMasEchangeService).not.toHaveBeenCalledTimes(1);

    });
});
