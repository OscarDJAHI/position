import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { NgbActiveModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderModule } from 'ngx-ui-loader';
import { MaterialModule } from 'src/app/core/modules/material/material.module';
import { CpnSidebarComponent } from '../../../shared/components/sidebar/cpn-sidebar.component';
import { FormateDate } from '../../../shared/pipes/format-date.pipe';
import { DataService } from '../../../shared/services/data.service';
import { MessageListComponent } from './message-list.component';
import { MessageFlagComponent } from '../flag/message-flag.component';
import { EventEmitter } from '@angular/core';
import { CountNotReadMails } from '../../../shared/components/count-not-read-mails/count-not-read-mails.component';
import { SimplebarAngularModule } from 'simplebar-angular';
import { UtilsService } from '../../../shared/services/utils.service';
import { StorageService } from '../../../shared/services/storage.service';
import { BehaviorSubject, Observable } from 'rxjs';
import { BoxType } from 'src/app/core/models/enums/box-type.enum';

describe('GestionMessagesComponent', () => {
    let component: MessageListComponent;
    let fixture: ComponentFixture<MessageListComponent>;
    let element;

    let dataServiceStub: Partial<DataService>;
    let utilsServiceStub: Partial<UtilsService>;
    let storageServiceStub: Partial<StorageService>;

    beforeEach(waitForAsync(() => {

        dataServiceStub = {
            userInfo: new BehaviorSubject<any>({nom: '', prenom: '', mail: ''}),
            newUserInfo: {nom: '', prenom: '', mail: ''},
            cpnSpsLoadEmitter: new EventEmitter(),
        };
        dataServiceStub.userInfo.next({nom: '', prenom: '', mail: ''});
        dataServiceStub.userCepMails$ = new Observable();

        storageServiceStub = {
            storeMailBox(mail: string) {
                localStorage.setItem('mail_box', mail);
            },
            storeNewMailObject(data: string) {
                localStorage.setItem('mail_object', JSON.stringify(data));
            },
            restoreWindow() {
                if (localStorage.getItem('mail_object') !== null) {
                    this.dataService.openTinyWindowRequest.emit(true);
                }
            },
            destroyStoredMailObject() {
                if (localStorage.getItem('mail_object') !== null) {
                    localStorage.removeItem('mail_object');
                }
            }
        };

        utilsServiceStub = {};

        TestBed.configureTestingModule({
                declarations: [
                    MessageListComponent,
                    CpnSidebarComponent,
                    MessageFlagComponent,
                    FormateDate,
                    CountNotReadMails
                ],
                imports: [
                    MaterialModule,
                    NgxUiLoaderModule,
                    FormsModule,
                    NgbModule,
                    RouterTestingModule,
                    HttpClientModule,
                    SimplebarAngularModule
                ],
                providers: [
                    NgbActiveModal,
                    // CpnMasEchangeService,
                    {provide: DataService, useValue: dataServiceStub},
                    {provide: UtilsService, useValue: utilsServiceStub},
                    {provide: StorageService, useValue: storageServiceStub},
                ]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(MessageListComponent);
        component = fixture.componentInstance;
        element = fixture.nativeElement;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it(`should have a typeBox 'INBOX'`, waitForAsync(() => {
        component.typeBox = BoxType.INBOX
        expect(component.typeBox).toEqual(BoxType.INBOX);
    }));

});
