import { Component, ElementRef, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';

import { PaginationInstance } from 'ngx-pagination/dist/ngx-pagination.module';
import { map } from 'rxjs/operators';

import { NgxUiLoaderService } from 'ngx-ui-loader';

import { Message, MessageRead } from '../../models/message.model';
import { UtilsService } from '../../../shared/services/utils.service';
import { CpnMasEchangeService } from '../../services/cpn-mas-echange.service';

import { UserInfoModel } from 'src/app/core/models/user-info.model';
import { BoxType } from 'src/app/core/models/enums/box-type.enum';
import { ActionType } from 'src/app/core/models/enums/action-type.enum';

import { StorageService } from '../../../shared/services/storage.service';
import { CepMailModel, DataService } from '../../../shared/services/data.service';
import { MessagesListService } from '../../services/messages-list.service';
import { CpnNotificationService } from '../../../shared/services/cpn-notification.service';
import { MessageSearchService } from '../../services/message-search.service';
import { MessageSearchTabService } from '../../services/message-search-tab.service';

import { MessageListWrapper } from '../../models/message-list-wrapper.model';
import { TabElement } from '../../../shared/models/tabs.model';

import { Pagination } from '../../../shared/constants/paginationConstants';
@Component({
    selector: 'app-message-list',
    templateUrl: './message-list.component.html',
    styleUrls: ['./message-list.component.scss'],
})
export class MessageListComponent implements OnInit {

    srt = true;

    public listMessages: Message[] = [];

    pagingConfig: PaginationInstance = {
        id: 'pg-id-custom',
        itemsPerPage: 10,
        currentPage: 0,
        totalItems: 0
    };

    showSpinner = false;
    showPagination = false;

    noData = false;
    nbrInboxMails: number;
    nominativeBox = 'sandra.ramier@externes.justice.gouv.fr';

    userInfo: UserInfoModel;
    typeBox: string;
    boxEmail: string;
    isNominativeBox: string;
    currentPage = 0;
    totalPages: number;

    previousUrl: string = null;
    urlPathName: string;

    previousEmailbox: string = null;
    currentEmailbox: string = null;
    messageList: Message = null;
    currentReadMessageId: number = null;

    isTypeSent = false;
    boxType = BoxType;
    actionType = ActionType;
    viewedMsgLoaded = false;

    TAB_ITEM_LIST: TabElement[];
    searchMode = false;
    searchTerm: string;
    totalElement: any;

    notEmptyPost = true;
    reloadListMessageAfterRemove = false;
    renewListMessage = false;
    viewedMessageDeleted = false;

    @ViewChild('messagesContainer') divMessages: ElementRef;
    countInboxMessage: number;
    countSentMessage: number;

    listElm: any;
    selectedMessages: Message[] = [];

    @ViewChildren('messageEl') domSelectedMessage: QueryList<ElementRef>;

    constructor(
        private cpnMasEchangeService: CpnMasEchangeService,
        public utilsService: UtilsService,
        private storageService: StorageService,
        public dataService: DataService,
        private messageListService: MessagesListService,
        private ngxService: NgxUiLoaderService,
        private tabsService: MessageSearchTabService,
        private searchService: MessageSearchService,
        private notificationService: CpnNotificationService
    ) {
    }

    ngOnInit() {
        this.listElm = document.querySelector('#infinite-list');
        this.showSpinner = true;
        this.userInfo = this.dataService.newUserInfo;
        this.reloadListMessageAfterRemove = false;

        this.dataService.listMessagesEmitter.subscribe(
            (data: MessageListWrapper) => {
                // Si un message avait déjà été ouvert on réinitialise à vide.
                this.messageList = null;

                // Si on change de boite
                this.divMessages.nativeElement.scrollTop = 0;
                this.selectedMessages = [];

                this.listMessages = data.messages.messagesFiltered.content;

                this.storageService.storeMailBox(this.nominativeBox);
                this.typeBox = data.typeBox;
                this.boxEmail = data.boxEmail;
                this.isNominativeBox = data.isNominativeBox;
                this.isTypeSent = BoxType.INBOX !== this.typeBox;
                this.showSpinner = false;
                this.showPagination = true;
                this.noData = this.listMessages.length === 0;
                this.countInboxMessage = data.messages.countInbox;
                this.countSentMessage = data.messages.countSent;
                this.nbrInboxMails = data.messages.nbNewInboxMessage;
                this.totalPages = data.messages.messagesFiltered.totalPages;

                this.currentPage = data.currentPage === null ? 1 : Number(data.currentPage);
                this.pagingConfig.currentPage = Number(data.currentPage);

                this.pagingConfig.totalItems = data.messages.messagesFiltered.totalElements;
                this.previousEmailbox = this.currentEmailbox;
                this.currentEmailbox = this.boxEmail;
                this.TAB_ITEM_LIST = data.tabs;
                this.searchTerm = data.term;
                this.searchMode = data.searchMode;

                if (data.lastOpenedMessageList != null) {
                    this.readMessage(data.lastOpenedMessageList);
                }

                // à la fin de la récupération de la liste on désactive le mode reload suite delete
                this.reloadListMessageAfterRemove = false;
                this.renewListMessage = false;
            },
            (error: any) => {
                this.showSpinner = false;
                console.error('Problème dans MessageExplorerComponent lors de la récupération des messages.', error);
            });

        this.urlPathName = location.pathname;
        this.searchService.getSearchHeaderOsb().subscribe(text => {
            this.reinitParam();
            this.searchMode = true;
        });
    }

    toggleTabs(activeElmlt: TabElement) {
        if (!activeElmlt.active) {
            this.tabsService.searchMessages({
                typeBox: activeElmlt.typeBox,
                isNomitativeBox: 'false',
                boxMails: this.mailboxes().split(','),
                term: this.searchTerm
            },
                activeElmlt
            );
        }
    }

    searchInboxResultEmpty() {
        return this.searchMode && this.TAB_ITEM_LIST && this.TAB_ITEM_LIST[1].count > 0 && this.TAB_ITEM_LIST[0].count === 0 && this.TAB_ITEM_LIST[0].active;
    }

    searchSentResultEmpty() {
        return this.searchMode && this.TAB_ITEM_LIST && this.TAB_ITEM_LIST[0].count > 0 && this.TAB_ITEM_LIST[1].count === 0 && this.TAB_ITEM_LIST[1].active;
    }

    searchBothTabResultEmpty() {
        return this.searchMode && this.TAB_ITEM_LIST && this.TAB_ITEM_LIST[0].count === 0 && this.TAB_ITEM_LIST[1].count === 0;
    }

    formatageRecipient(r: any[]) {
        return this.utilsService.formatageRecipient(r);
    }

    userInitial(value: any) {
        return this.utilsService.userInitial(value);
    }

    sortBykey(array: any[], key: string) {
        return array.sort((a: { [x: string]: any; }, b: { [x: string]: any; }) => {
            const x = a[key];
            const y = b[key];
            return ((x < y) ? -1 : ((x > y) ? 1 : 0));
        });
    }

    unSortByKey(array: any[], key: string) {
        return array.reverse();
    }

    sortMessage() {
        if (this.srt) {
            this.listMessages = this.sortBykey(this.listMessages, 'sender');
            this.srt = false;
        } else {
            this.listMessages = this.unSortByKey(this.listMessages, 'sender');
            this.srt = true;
        }
    }

    sortMessageV2() {
        if (this.srt) {
            this.listMessages = this.listMessages.sort((a, b) => {
                return a.sender.localeCompare(b.sender);
            });
            this.srt = false;
        } else {
            this.listMessages = this.listMessages.reverse();
            this.srt = true;
        }
    }

    setToRead(message: { viewed: number; }) {
        message.viewed = 1;
    }

    computeMessageListheight() {
        const style = 'style';
        const height = 'height';

        const windowHeight = window.innerHeight;
        const headerHeight = document.querySelector('.cpn-header').getBoundingClientRect().height;
        const sortHeight = document.querySelector('.sort-sent-message').getBoundingClientRect().height;
        const tabSearchHeight = document.querySelector('.tab-search-result').getBoundingClientRect().height;

        if (window.devicePixelRatio === 1 && sortHeight > 0) {
            document.querySelector('.ff-scrollbar')[style][height] = `${windowHeight - headerHeight - sortHeight - 40}px`;
        }

        if (window.devicePixelRatio === 1 && tabSearchHeight > 0) {
            document.querySelector('.ff-scrollbar')[style][height] = `${windowHeight - headerHeight - tabSearchHeight - 40}px`;
        }

        if (window.devicePixelRatio === 1.5 && sortHeight > 0) {
            document.querySelector('.ff-scrollbar')[style][height] = `${windowHeight - headerHeight - sortHeight - 30}px`;
        }

        if (window.devicePixelRatio === 1.5 && tabSearchHeight > 0) {
            document.querySelector('.ff-scrollbar')[style][height] = `${windowHeight - headerHeight - tabSearchHeight - 30}px`;
        }
    }

    private readMessage(message: Message) {
        const unreadMessage = message.viewed === 0;

        this.ngxService.startLoader('loader-message-detail');
        this.messageList = message;
        this.messageList.viewed = 1;
        this.currentReadMessageId = Number(message.id);
        this.cpnMasEchangeService.readMessage(Number(message.id), this.typeBox).pipe(
            map((messageRead: MessageRead) => {
                if (!messageRead.deleted) {
                    messageRead.expiration_date = messageRead.expiration_date == null ? messageRead.expiration_date = '' : messageRead.expiration_date;
                }

                this.viewedMessageDeleted = messageRead.deleted;

                return messageRead;
            })
        ).subscribe(
            (messageRead: MessageRead) => {
                const wrapper = {
                    messageList: message,
                    message: messageRead,
                    boxEmail: this.boxEmail,
                    deleted: messageRead.deleted,
                    nominativeBox: this.utilsService.parseBoolean(this.isNominativeBox)
                };

                this.dataService.updatedMessageEmitter.emit(wrapper);
                this.updateUnreadEmailNotification(unreadMessage, message, '');

                this.ngxService.stopLoader('loader-message-detail');
            },
            error => {
                this.ngxService.stopLoader('loader-message-detail');
                console.log('Error:', error);
            }
        );
    }

    messageClickEventModifier(event: any, el: HTMLElement, message: Message) {
        if (!event.ctrlKey) {
            this.readMessage(message);
            this.unselectAll();
        }

        this.bulkSelectMessage(el, message);
    }

    findAnchor(element: { tagName: string; parentElement: any; }) {
        return ('A' !== element.tagName) ? this.findAnchor(element.parentElement) : element;
    }

    /**
     * Cette fonction permet de réinitialiser les variables : currentPage, listMessages..
     * le but c'est d'éviter toute interférence entre les listes: resultatRecherche et listeMessageMailBox
     * Elle est appelée au moment du clique sur une boite ou bien au lancement de la recherche
     * ... à garder en attendant la factorisation de la page "gestion messages" en plusieurs components
     */
    reinitParam() {
        if (this.divMessages) {
            this.divMessages.nativeElement.scrollTop = 0;
        }

        this.currentPage = 1;
        this.renewListMessage = true;
        this.currentReadMessageId = null;
        this.messageList = null;
        this.viewedMsgLoaded = false;
        this.searchMode = false;
        this.reloadListMessageAfterRemove = false;
        this.searchTerm = '';
    }

    onScrollDown() {
        const scrollLogiq = this.listElm.scrollTop + this.listElm.clientHeight >= this.listElm.scrollHeight;

        if (scrollLogiq && this.listMessages.length < this.pagingConfig.totalItems) {
            this.currentPage = this.currentPage + 1;
            if (this.searchMode) {
                this.getPageSearchResult(String(this.currentPage), this.pagingConfig.itemsPerPage, false);
            } else {
                this.getPageMessageBox(String(this.currentPage), this.pagingConfig.itemsPerPage, false);
            }
        }
    }

    getPageSearchResult(pageIndex: string, numberMessageToLoad: number, withCheckIfViewedMessageLoaded: boolean) {
        this.tabsService.searchMessages$(
            {
                typeBox: this.TAB_ITEM_LIST.find(r => r.active === true).typeBox,
                isNomitativeBox: 'false',
                boxMails: this.mailboxes().split(','),
                page: pageIndex,
                numberPerPage: String(numberMessageToLoad),
                term: this.searchTerm
            },
            this.TAB_ITEM_LIST.find(r => r.active === true)
        ).subscribe(
            result => {
                if (result.messagesFiltered.content.length === 0) {
                    this.notEmptyPost = false;
                }

                if (this.listMessages !== null) {
                    this.listMessages = this.listMessages.concat(result.messagesFiltered.content);
                } else {
                    this.pagingConfig.totalItems = result.messagesFiltered.totalElements;
                    this.listMessages = result.messagesFiltered.content;
                }
            },
            error => {
                console.log(error);
            },
            () => {
                this.ngxService.stopLoader('searchLoader');
            }
        );

        if (withCheckIfViewedMessageLoaded) {
            this.checkIfViewedMessageLoaded();
        }
    }

    getPageMessageBox(pageIndex: string, numberElementACharger: number, withCheckIfViewedMessageLoaded: boolean) {
        // INBOX scrolled list
        if (this.typeBox === BoxType.INBOX) {
            this.messageListService.getMessages$(
                {
                    typeBox: this.typeBox,
                    page: pageIndex,
                    numberPerPage: String(numberElementACharger),
                    isNomitativeBox: this.isNominativeBox,
                    boxMail: this.boxEmail
                }).subscribe(
                    result => {
                        if (result.messagesFiltered.content.length === 0) {
                            this.notEmptyPost = false;
                        }
                        if (this.listMessages !== null) {
                            this.listMessages = this.listMessages.concat(result.messagesFiltered.content);
                        } else {
                            this.pagingConfig.totalItems = result.messagesFiltered.totalElements;
                            this.listMessages = result.messagesFiltered.content;
                        }
                    },
                    error => {
                        this.ngxService.stopLoader('loader-message-list');
                    },
                    () => {
                        this.ngxService.stopLoader('loader-message-list');
                    }
                );

            this.isTypeSent = BoxType.INBOX !== this.typeBox;
        }

        // SENT scrolled list
        if (this.typeBox === BoxType.SENT) {
            this.messageListService.getMessages$(
                {
                    typeBox: this.typeBox,
                    page: pageIndex,
                    numberPerPage: String(this.pagingConfig.itemsPerPage),
                    isNomitativeBox: this.isNominativeBox,
                    boxMail: this.boxEmail
                }).subscribe(
                    result => {
                        if (result.messagesFiltered.content.length === 0) {
                            this.notEmptyPost = false;
                        }
                        if (this.listMessages !== null) {
                            this.listMessages = this.listMessages.concat(result.messagesFiltered.content);
                        } else {
                            this.pagingConfig.totalItems = result.messagesFiltered.totalElements;
                            this.listMessages = result.messagesFiltered.content;
                        }
                    },
                    error => {
                        this.ngxService.stopLoader('loader-message-list');
                    },
                    () => {
                        this.ngxService.stopLoader('loader-message-list');
                    }
                );

            this.isTypeSent = BoxType.SENT !== this.typeBox;
        }

        // Corbeille scrolled list
        if (this.typeBox === BoxType.TRASH) {
            this.messageListService.getDeletedMessages$(
                {
                    page: String(this.currentPage),
                    isNomitativeBox: 'false',
                    deleted: 'true',
                    boxMail: this.mailboxes(),
                    numberPerPage: Pagination.DEFAULT.NUMBER_PER_PAGE
                }).subscribe(
                    result => {
                        if (result.messagesFiltered.content.length === 0) {
                            this.notEmptyPost = false;
                        }
                        if (this.listMessages !== null) {
                            this.listMessages = this.listMessages.concat(result.messagesFiltered.content);
                        } else {
                            this.pagingConfig.totalItems = result.messagesFiltered.totalElements;
                            this.listMessages = result.messagesFiltered.content;
                        }
                    },
                    error => {
                        this.ngxService.stopLoader('loader-message-list');
                    },
                    () => {
                        this.ngxService.stopLoader('loader-message-list');
                    }
                );
        }

        if (withCheckIfViewedMessageLoaded) {
            this.checkIfViewedMessageLoaded();
        }
    }

    deleteAndRestoreMessage(message: Message, el: HTMLElement, typeAction: string, index: number) {

        // Do nothing for the moment : Waiting for the permanent deletion
        if ((this.typeBox === BoxType.TRASH) && (typeAction === ActionType.SUPPRIME)) {
            return;
        }

        if (!el.classList.contains('active-row')) {
            this.selectedMessages = [];
            this.selectedMessages.push(message);
        }

        this.ngxService.startLoader('loader-message-list');

        if (this.selectedMessages.length) {
            this.selectedMessages.forEach((msg) => {
                this.updateUnreadEmailNotification(msg.viewed === 0, msg, typeAction);
            });
        } else {
            this.updateUnreadEmailNotification(true, message, typeAction);
        }

        this.cpnMasEchangeService.actionOnMessage(this.selectedMessages.map(msg => msg.id), typeAction).subscribe(
            () => {

                let totalPageAfterDelete = Math.floor(this.listMessages.length / this.pagingConfig.itemsPerPage);
                if ((this.listMessages.length % this.pagingConfig.itemsPerPage) !== 0) {
                    totalPageAfterDelete = totalPageAfterDelete + 1;
                }

                // si suite à la suppression on a un déphasage avec le currentPage alors on reinitialise le currentPage
                if (totalPageAfterDelete < this.currentPage) {
                    this.currentPage = totalPageAfterDelete;
                }

                this.listMessages.splice(index, 1);

                // Rafraichir la liste des messages de la premiere page jusqu'à la page en cours
                this.reloadListMessageAfterRemove = true;
                const nombreElementACharger = this.currentPage * this.pagingConfig.itemsPerPage;

                if (this.searchMode) {
                    this.listMessages = null;
                    this.getPageSearchResult('1', nombreElementACharger, true);
                } else {
                    this.listMessages = null;
                    this.getPageMessageBox('1', nombreElementACharger, true);
                }

                this.selectedMessages.forEach(msg => {
                    /**
                     * Si il y a un message déjà lu et qui est différent de celui qui est affiché
                     * on regarde s'il est chargé sinon on scroll jusqu'à ce qu'il soit chargé
                     * (pour traiter les cas des messages qui arrivent au moment de la suppression) */
                    if (!this.viewedMessageDeleted && (this.currentReadMessageId != null) && (this.currentReadMessageId !== Number(msg.id))) {
                        while (!this.viewedMsgLoaded && !this.noData) {
                            this.currentPage = this.currentPage + 1;
                            if (this.searchMode) {
                                this.getPageSearchResult(String(this.currentPage), this.pagingConfig.itemsPerPage, true);
                            } else {
                                this.getPageMessageBox(String(this.currentPage), this.pagingConfig.itemsPerPage, true);
                            }
                        }
                    }

                    /**
                     * Si le message à supprimer est celui qui est affiché au moment de la suppression alors on le relit
                     * pour afficher le panneau "message dans la corbeille"
                     * si non on ne fait rien */

                    if (Number(message.id) === this.currentReadMessageId) {
                        this.readMessage(message);
                    }
                });
            },
            error => {
                console.log(error);
                this.ngxService.stopLoader('loader-message-list');
            }, () => {
                this.ngxService.stopLoader('loader-message-list');
            });

        this.selectedMessages = [];
    }

    private updateUnreadEmailNotification(unreadMessage: boolean, message: Message, typeAction: string) {
        if (unreadMessage) {
            this.notificationService.updateNotificationsAfterMessageRead(message, typeAction);
        }
    }

    private mailboxes() {
        const mailboxes: string[] = [];
        this.getCepMailboxes().forEach(mailbox => {
            mailboxes.push(mailbox.email);
        });

        mailboxes.push(String(this.userInfo.mail));

        return mailboxes.join();
    }

    private getCepMailboxes() {
        let mailboxes: CepMailModel[];

        this.dataService.userCepMails$.subscribe(
            data => {
                mailboxes = data;
            },
            error => {
                console.error('Error:', error);
            }
        );

        return mailboxes ? mailboxes : [];
    }

    private checkIfViewedMessageLoaded() {
        if (this.listMessages) {
            for (const msg of this.listMessages) {
                if (Number(msg.id) === this.currentReadMessageId) {
                    this.viewedMsgLoaded = true;
                    break;
                }
            }
        }
    }

    private bulkSelectMessage(el: HTMLElement, message: Message): void {
        if (el.classList.contains('active-row')) {
            el.classList.remove('active-row');

            if (this.selectedMessages.length > 0) {
                const index = this.selectedMessages.findIndex(m => Number(m.id) === Number(el.dataset.messageId));
                this.selectedMessages.splice(index, 1);
            }
        } else {
            el.classList.add('active-row');
            this.selectedMessages.push(message);
        }
    }

    private unselectAll() {
        this.selectedMessages = [];
        this.domSelectedMessage.forEach(row => {
            row.nativeElement.classList.remove('active-row');
        });
    }
}
