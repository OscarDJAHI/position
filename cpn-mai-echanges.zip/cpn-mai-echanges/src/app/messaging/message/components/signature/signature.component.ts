import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { NgxUiLoaderService } from 'ngx-ui-loader';

import { Signature } from 'src/app/messaging/message/models/signature.model';
import { AlertModalContent } from 'src/app/messaging/shared/models/alerte-modal-content.model';
import { SignatureService } from 'src/app/messaging/message/services/signature.service';
import { AlertesModalService } from 'src/app/messaging/shared/services/alertes-modal.service';
import { DataService } from '../../../shared/services/data.service';

@Component({
    selector: 'app-signature',
    templateUrl: './signature.component.html',
    styleUrls: ['./signature.component.scss']
})
export class SignatureComponent implements OnInit {

    formSignature: FormGroup;

    formState = {
        isValid: false,
        signature: {
            createSuccess: false,
            isLengthValid: true,
            errorMsg: 'Signature trop longue. Veuillez ne pas dépasser 255 caractères.',
            successMsg: 'Votre signature a bien été enregistrée !'
        }
    };

    postMethod = 'PUT';
    modalTilte = 'Ma signature';

    alertModalContent: AlertModalContent;

    userSignature: Signature;
    countSignatureChar = 0;
    MAX_SIGNATURE_CHAR_LENGTH = 255;

    constructor(
        public activeModal: NgbActiveModal,
        private dataService: DataService,
        private signatureService: SignatureService,
        private ngxService: NgxUiLoaderService,
        private alertModalService: AlertesModalService
    ) {
    }

    ngOnInit() {
        this.userSignature = {userUid: '', content: ''};
        this.alertModalContent = {title: '', message: ''};

        this.formSignature = new FormGroup({
            signatureText: new FormControl(''),
        });

        this.initUserSignature();
    }

    countChar() {
        this.countSignatureChar = this.formSignature.controls.signatureText.value.length;
    }

    checkAndSubmitForm() {
        this.userSignature.content = this.formSignature.controls.signatureText.value;

        if (this.userSignature.content.length > this.MAX_SIGNATURE_CHAR_LENGTH) {
            this.formState.signature.isLengthValid = false;
            return;
        }

        this.formState.signature.isLengthValid = true;
        this.formState.isValid = true;
        this.createOrUpdateSignature(this.postMethod);
    }

    checkInput() {
        this.userSignature.content = this.formSignature.controls.signatureText.value;
        if (this.userSignature.content.length > this.MAX_SIGNATURE_CHAR_LENGTH) {
            this.formState.signature.isLengthValid = false;
            this.formState.isValid = false;
        } else {
            this.formState.signature.isLengthValid = true;
            this.formState.isValid = true;
        }
    }

    createOrUpdateSignature(postMethod: string) {
        if (this.formState.isValid) {
            this.ngxService.startLoader('signature-loader');
            this.userSignature.userUid = String(this.dataService.newUserInfo.idLdap);
            this.userSignature.content = this.formSignature.controls.signatureText.value;

            if (postMethod === 'PUT') {
                this.signatureService.update(this.userSignature).subscribe(
                    () => {
                        this.handleSuccess();
                    },
                    error => {
                        this.handleError(error);
                    }
                );
            } else {
                this.signatureService.create(this.userSignature).subscribe(
                    () => {
                        this.handleSuccess();
                    },
                    error => {
                        this.handleError(error);
                    }
                );
            }
        }
    }

    private initUserSignature() {
        this.signatureService.getSignature(String(this.dataService.newUserInfo.idLdap)).subscribe(
            data => {
                this.userSignature = data as Signature;

                if (this.userSignature.userUid === null && this.userSignature.content === null) {
                    this.postMethod = 'POST';
                }

                if (this.userSignature.content !== null) {
                    this.formSignature.patchValue({signatureText: this.userSignature.content});
                    this.countSignatureChar = this.formSignature.controls.signatureText.value.length;
                    this.formState.isValid = true;
                }
            },
            error => {
                this.handleError(error);
            }
        );
    }

    private handleSuccess() {
        this.ngxService.stopLoader('signature-loader');
        this.activeModal.close();

        this.formState.signature.createSuccess = true;
        this.alertModalContent.message = this.formState.signature.successMsg;
        this.alertModalService.openSuccessModal(this.alertModalContent);
    }

    private handleError(error: any) {
        this.ngxService.stopLoader('signature-loader');
        console.error(error);

        this.activeModal.close();
        this.alertModalService.openGenericErrorModal();
    }
}
