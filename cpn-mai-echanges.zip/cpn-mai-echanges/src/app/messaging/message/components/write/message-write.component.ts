import { Component, ElementRef, EventEmitter, Injector, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

import { tap } from 'rxjs/operators';
import { interval, Observable, Subscription } from 'rxjs';
import * as _ from 'lodash';
import * as moment from 'moment';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { UserInfoModel } from 'src/app/core/models/user-info.model';
import { Arborescence } from 'src/app/core/models/arborescence.model';
import { AppNameEnum } from 'src/app/core/models/enums/app-name.enum';
import {
    DEMANDE_ENVOI_MESSAGE_TITLE,
    EMAIL_PATTERN,
    MAIL_EXPIRATION_LIST,
    MODAL_ARBO_BPN_WRITE_MAIL_TITLE,
    MODAL_ARBO_BPN_WRITE_MAIL_VALIDATE_BTN
} from '../../../shared/constants/constants';
import { DocExplorerComponent, FichierMessages } from '../../../shared/components/doc-explorer/doc-explorer.component';
import { CepMailModel, DataService } from '../../../shared/services/data.service';
import { StorageService } from '../../../shared/services/storage.service';
import { AlertesModalService } from '../../../shared/services/alertes-modal.service';
import { UtilsService } from '../../../shared/services/utils.service';
import { Domain } from '../../../contact/models/domain.model';
import { ContactService } from '../../../contact/services/contact.service';
import { SearchRequest } from '../../../contact/models/search-request.model';
import { MessageRead } from '../../models/message.model';
import { MessageAttachment } from '../../models/message-attachment.model';
import { MessageObject } from '../../models/message-object.model';
import { EmailChecked } from '../../models/email-checked.model';
import { MessageToSend } from '../../models/message-to-send.model';
import { MessageRecipient } from '../../models/message-recipient.model';
import { CpnMasEchangeService } from '../../services/cpn-mas-echange.service';
import { NotidocModalComponent } from '../notidoc-modal/notidoc-modal.component';
import { DomainLabelEnum } from 'src/app/core/models/enums/domain-label.enum';
import { SignatureService } from 'src/app/messaging/message/services/signature.service';
import { PermissionService } from 'src/app/core/services/permissions/permission.service';
import { UserAction } from 'src/app/core/models/user-action.model';
import { UtilisateurService } from 'src/app/core/services/utilisateur/utilisateur.service';
import { ConfigurationService } from 'src/app/core/services/configuration/configuration.service';

declare var $: any;

@Component({
    selector: 'app-message-write',
    templateUrl: './message-write.component.html',
    styleUrls: ['./message-write.component.scss']
})
export class MessageWriteComponent implements OnInit, OnDestroy {

    NEW_LINE = String.fromCharCode(13, 10);

    mailAutoSaveInterval$: Observable<any>;
    mailAutoSaveSubcription: Subscription;

    sendBtnAutoEnableInterval$: Observable<any>;
    sendBtnAutoEnableSubcription: Subscription;

    newMailForm: FormGroup;

    user: UserInfoModel;

    recipientFilteredByDomain: { uid: '', email: '', last_name: '', first_name: '' }[][];

    msgExpiration: string;

    cpnModal: boolean;
    cpnMsgModal: boolean;
    failModal: boolean;

    msgToSend: any;
    disableSendButton: boolean;

    fileSelected: Arborescence[];
    fileToSend: MessageAttachment[];
    multipartFileToSend: File[] = [];

    @Input() mailType: string;
    @Input() cntx: string;
    @Input() closeReason: string;

    /**
     * Envoi une requete d'annulation
     */
    @Output() cancelActionEmitter: EventEmitter<boolean> = new EventEmitter();

    /**
     * Envoi une requete de traitement
     */
    @Output() doneActionEmitter: EventEmitter<boolean> = new EventEmitter();

    @Output() newMailBox: EventEmitter<String> = new EventEmitter();

    @Input() cpnMailBox: string;

    errorNpp = '';

    /**
     * Liste des noeuds selectionnes à envoyer cpn
     */
    @Input() nodes: Arborescence[] = [];

    /**
     * Liste des noeuds reelement utilises à envoyer cpn
     */
    public nodesUse: Arborescence[] = [];

    cepMails: CepMailModel[];
    cepSenderMail: string;

    userDocs: any[] = [];
    mailObject: MessageObject;

    @Input() writeNewMessageType: { newMsg: boolean, msgReponse: boolean };

    @Input() previousMessageData: MessageRead;

    @Input() previousMessageSender: string;

    @Input() domainFromSearchResult: string;
    @Input() emailFromSearchResult: string;

    currentRecipientsIndex;

    autoCompleteSpinner = [];
    recipientSelectedSpinner = [];

    disableSendButtonTemporarily = false;
    showTooltipElt = false;
    domains: Domain[] = [];
    initReady = false;

    preventRecipientEmailDeletion: boolean[] = [];
    disableAutoCompletionInput: boolean[] = [];
    signature = '';
    fichierMessagesDto: FichierMessages[];
    senderDefaultBoxEmail: string;

    private contactService: ContactService;
    private dataService: DataService;
    private cpnMasEchangeService: CpnMasEchangeService;
    private ngxService: NgxUiLoaderService;
    private alertesModalService: AlertesModalService;
    public activeModal: NgbActiveModal;
    private storageService: StorageService;
    private modalService: NgbModal;
    private signatureService: SignatureService;
    private permissionService: PermissionService;
    private userService: UtilisateurService;
    private configurationService: ConfigurationService;

    constructor(private injector: Injector) {
        this.contactService = this.injector.get<ContactService>(ContactService);
        this.dataService = this.injector.get<DataService>(DataService);
        this.cpnMasEchangeService = this.injector.get<CpnMasEchangeService>(CpnMasEchangeService);
        this.ngxService = this.injector.get<NgxUiLoaderService>(NgxUiLoaderService);
        this.alertesModalService = this.injector.get<AlertesModalService>(AlertesModalService);
        this.activeModal = this.injector.get<NgbActiveModal>(NgbActiveModal);
        this.storageService = this.injector.get<StorageService>(StorageService);
        this.modalService = this.injector.get<NgbModal>(NgbModal);
        this.signatureService = this.injector.get<SignatureService>(SignatureService);
        this.permissionService = this.injector.get<PermissionService>(PermissionService);
        this.userService = this.injector.get<UtilisateurService>(UtilisateurService);
        this.configurationService = this.injector.get<ConfigurationService>(ConfigurationService);
    }

    ngOnInit() {
        this.cepSenderMail = localStorage.getItem('mail_box');
        this.nodesUse = this.nodes;
        this.fileToSend = [];
        this.newMailForm = new FormGroup({
            sender: new FormControl({ value: '', disabled: true }),
            mailSubject: new FormControl(''),
            mailBody: new FormControl(''),
            file: new FormControl(''),
        });

        this.user = this.userService.userInfo;
        let senderDefaultMailBox = this.user.mail;

        if (this.dataService.currentBoxEmail) {
            senderDefaultMailBox = this.dataService.currentBoxEmail;
        }

        if (this.userService.hasDefaultBox()) {
            senderDefaultMailBox = this.user.parametrage.defaultMailBox.email;
        }

        this.newMailForm.patchValue({ sender: senderDefaultMailBox });

        this.cpnModal = false;
        this.cpnMsgModal = false;
        this.disableSendButton = true;
        this.msgExpiration = moment().locale('fr').add(8, 'days').format('LL');

        this.recipientFilteredByDomain = [];
        this.fileSelected = [];

        this.clickOutAutoCompleation();
        this.initMailHeader();
        this.initBoiteStructurelleList();
        this.initSignature(this.user.idLdap);
    }

    initSignature(userUid) {
        this.signatureService.getSignature(userUid).subscribe(res => {
            this.signature = res.content;
        });
    }

    addSignature() {
        this.newMailForm.get('mailBody').setValue(this.mailObject.mailBody + this.NEW_LINE + this.NEW_LINE + this.signature);
    }

    isBoiteNominative() {
        return this.user.mail == this.newMailForm.get('sender').value;
    }

    ngOnDestroy() {
        this.storageService.restoreWindow();
        this.mailAutoSaveSubcription.unsubscribe();
        this.sendBtnAutoEnableSubcription.unsubscribe();
    }

    selectSender(email: String) {
        this.newMailForm.patchValue({ sender: email });
        this.newMailBox.emit(email);
    }

    initBoiteStructurelleList() {
        this.dataService.userCepMails$.subscribe(
            data => {
                this.cepMails = data.filter(box => !box.nominative);
            },
            error => {
                console.error(error);
            }
        );
    }

    alertsClass(node: Arborescence) {
        return node.format === 'pdf' ? 'secondary' : 'secondary';
    }

    removeCpnNode(node: Arborescence) {
        this.nodesUse.forEach((item, index) => {
            if (node.id === item.id) {
                this.nodesUse.splice(index, 1);
            }
        });

        if (this.nodesUse.length === 0) {
            this.cancelActionEmitter.emit(true);
        }
    }

    selectDomain(e: any, index: any) {
        if (e.target.value.length === 0) {
            this.disableSelectedDomainByDOMelement();
        }

        if (e.target.value === DomainLabelEnum.HUISSIER) {
            this.openNotidocModal();
        }

        if (e.target.value.length) {
            // Set selected domain
            this.mailObject.recipientRow[index].domainList.filter(r => {
                if (r.value === e.target.value) {
                    r.selected = true;

                    if (r.mails.length) {
                        const rc: EmailChecked[] = [];
                        r.mails.forEach(v => rc.push({ email: v, exist: true }));

                        this.mailObject.recipientRow[index].recipientsChecked = rc;
                        this.mailObject.recipientRow[index].recipients = r.mails;

                        // disable input
                        if (!r.editable) {
                            this.preventRecipientEmailDeletion[index] = true;
                            this.disableAutoCompletionInput[index] = true;
                        } else {
                            this.preventRecipientEmailDeletion[index] = false;
                            this.disableAutoCompletionInput[index] = false;
                        }
                    } else {
                        this.disableAutoCompletionInput[index] = false;
                        this.mailObject.recipientRow[index].recipientsChecked = [];
                        this.mailObject.recipientRow[index].recipients = [];
                    }
                } else {
                    r.selected = false;
                }
            });

            // Disable for each row selected domain (select options)
            this.disableSelectedDomainByDOMelement();
        } else {
            // Set selected domain
            this.mailObject.recipientRow[index].domainList.filter(r => {
                r.selected = false;
            });
        }
    }

    autocompleteRecipientList(e: any, index: any) {
        this.disableSendButtonTemporarily = true;

        const inputTextValue = e.target.value.toLowerCase();

        // get selected option
        const el = document.getElementById(e.target.className);

        // get selected option value
        const optionValue = el['value'];

        // get selected option innerText
        if (optionValue.length === 0) {
            document.querySelector('.title').classList.add('title-error');
            return;
        }

        const canal = this.getCanalByDomain(optionValue);
        const referentiel = this.getReferentielByDomain(optionValue);

        if (inputTextValue.length >= 3) {
            this.autoCompleteSpinner[index] = true;
            const ulEl = document.getElementById('ul-' + index);
            this.contactService.searchContacts(new SearchRequest('', canal, '', '', inputTextValue, optionValue, referentiel)).subscribe(
                data => {
                    this.autoCompleteSpinner[index] = false;
                    this.recipientFilteredByDomain[index] = data['contacts'];
                    if (this.recipientFilteredByDomain[index] !== null && this.recipientFilteredByDomain[index].length >= 1) {
                        document.getElementById('ul-' + index).style.boxShadow = '-2px 7px 16px 11px #1c1a1a26';
                        ulEl.style.display = 'block';
                    } else {
                        document.querySelector('.ul-list')['style'].display = 'none';
                        ulEl.style.display = 'none';
                    }
                },
                error => {
                    this.autoCompleteSpinner[index] = false;
                    console.error('annuaire error:', error);
                }
            );
        } else {
            const ulEl = document.getElementById('ul-' + index);
            ulEl.style.display = 'none';
        }
    }

    autocompleteSelectRecipient(email: string, index: any) {
        const emails = this.mailObject.recipientRow[index].recipients;

        if (!emails.filter(r => r === email).length) {
            emails.push(email);
        }

        if (emails.length) {
            this.recipientSelectedSpinner[index] = true;

            // get selected domain
            const domain = document.getElementById('id-domain-select-' + index)['value'];
            const canal = this.getCanalByDomain(domain);
            const referentiel = this.getReferentielByDomain(domain);

            this.contactService.checkContact(new SearchRequest('', canal, '', '', emails.join(), domain, referentiel))
                .pipe(
                    tap(() => {
                        this.disableSendButtonTemporarily = true;
                    }))
                .subscribe(
                    done => {
                        this.disableSendButtonTemporarily = false;
                        this.recipientSelectedSpinner[index] = false;
                        this.mailObject.recipientRow[index].recipientsChecked = done;
                    },
                    fail => {
                        this.disableSendButtonTemporarily = false;
                        this.recipientSelectedSpinner[index] = false;
                        console.error(fail);
                    });
        }

        // empty
        this.recipientFilteredByDomain[index] = [];

        const el = document.getElementById('recipient-input-' + index);
        el['value'] = '';
        el.focus();

        // stored mail object
        this.storeMailObject();
    }

    showCustomTooltip(e, id) {
        const elt = document.querySelector('#email-error-' + id);
        const tooltipElt: HTMLElement = document.querySelector('.cpn-tooltip-email-error');
        const elRec = elt.getBoundingClientRect();

        tooltipElt.style.top = String(elRec.top + elRec.height + 6) + 'px';
        tooltipElt.style.left = String(elt.getBoundingClientRect().left) + 'px';

        this.showTooltipElt = true;
    }

    hideCustomTooltip() {
        this.showTooltipElt = false;
    }

    checkEmail(e: any, index: any) {
        const recipients = this.getRecipientsElement(index);
        if (recipients.is(':visible')) {
            return;
        }

        const inputTextValue = e.target.value.trim();
        if (EMAIL_PATTERN.test(inputTextValue)) {
            this.autocompleteSelectRecipient(inputTextValue, index);
        } else {
            this.disableSendButtonTemporarily = false;
        }

        e.target.value = '';
    }

    isSelectedDomainEditable(domains: Domain[]) {
        const selectedDomain = domains.filter(d => d.selected);
        return selectedDomain.length === 1 && selectedDomain[0].editable;
    }

    removeSelectedRecipient(email: string, index: any) {

        if (!this.isSelectedDomainEditable(this.mailObject.recipientRow[index].domainList)) {
            return;
        }

        this.showTooltipElt = false;
        const idx = this.mailObject.recipientRow[index].recipients.findIndex(rslt => rslt === email);
        const edx = this.mailObject.recipientRow[index].recipientsChecked.findIndex(e => e.email === email);

        this.mailObject.recipientRow[index].recipients.splice(idx, 1);
        this.mailObject.recipientRow[index].recipientsChecked.splice(edx, 1);

        const cnd = (this.mailObject.recipientRow[index].recipients.length === 0 || this.mailObject.recipientRow[index].recipientsChecked.length === 0) &&
            document.querySelector('#recipient-input-' + index).getAttribute('disabled') !== null;
        if (cnd) {
            document.querySelector('#recipient-input-' + index).removeAttribute('disabled');
        }
    }

    verif(index: any) {
        // Hide and show autocomplete recipient list by domain row
        const ulList = document.querySelectorAll('.ul-list');
        ulList.forEach((v: HTMLElement) => {
            v.style.display = 'none';
        });
        this.currentRecipientsIndex = index;
        document.getElementById('ul-' + index).style.boxShadow = '';
    }

    addNewRecipientRow(e: any, index: any) {
        const newDomains = this.PPNDomainListInit(this.domains);
        const checkDomain = document.getElementById('id-domain-select-' + index)['value'];

        if (checkDomain.length === 0) {
            document.querySelector('.title').classList.add('title-error');
            return;
        }

        if (this.mailObject.recipientRow.length < this.domains.length) {
            // disable all selected domain
            newDomains.forEach(d => {
                this.mailObject.recipientRow.forEach(rw => {
                    rw.domainList.forEach(dm => {
                        if (dm.selected === true && dm.value === d.value) {
                            dm.disabled = true;
                            d.disabled = true;
                        }
                    });
                });
            });

            this.mailObject.recipientRow.push({
                domainList: newDomains,
                recipients: [],
                recipientsChecked: [],
                addButton: true,
                deleteButton: true
            });
        }

        // Set dynamically z-index
        setTimeout(() => {
            document.querySelectorAll('.recipient-row').forEach((v, i) => {
                v['style'] = `z-index:${this.domains.length - 1 - i}`;
            });
        }, 500);

        // Hide all recipient row addButton, and display the last one
        setTimeout(() => {
            this.hideAndShowActionButton();
        }, 20);
    }

    removeRecipientRow(e: any, index: any) {
        // remove domain and recipient row
        if (this.mailObject.recipientRow.length > 1) {
            this.preventRecipientEmailDeletion[index] = false;
            this.disableAutoCompletionInput[index] = false;
            this.mailObject.recipientRow.splice(index, 1);
        }

        setTimeout(() => {
            // Hide all recipient row addButton, and display the last one
            this.hideAndShowActionButton();

            // enable selected domain
            if (this.mailObject.recipientRow.length === 1) {
                this.enableSelectedDomainByDOMelement();
            }
        }, 50);
    }

    removeSelectedFile(f: MessageAttachment) {
        const idx = this.mailObject.mailFiles.findIndex(i => i.nom === f.nom);
        this.mailObject.mailFiles.splice(idx, 1);

        const fileIdx = this.multipartFileToSend.findIndex(i => i.name === f.nom);
        this.multipartFileToSend.splice(fileIdx, 1);

        const dataFileIdx = this.dataService.multipartFileUpload.findIndex(i => i.name === f.nom);
        this.dataService.multipartFileUpload.splice(dataFileIdx, 1);

        const indx = this.dataService.arboNodeChecked.findIndex(n => n.path === f.uri);
        this.dataService.arboNodeChecked.splice(indx, 1);
    }

    addSelectedFiles(event) {
        const files: MessageAttachment[] = [];

        for (const file of event.target.files) {
            files.push({
                idSps: '',
                uri: '',
                nom: file.name,
                type: file.name.substr(file.name.lastIndexOf('.') + 1).toLowerCase(),
                size: file.size,
                source: ''
            });

            this.multipartFileToSend.push(file);
        }

        if (this.mailObject.mailFiles.length > 0) {
            this.dataService.updateUserDocs(this.mailObject.mailFiles.concat(_.differenceBy(files, this.mailObject.mailFiles, 'nom')));
        } else {
            this.dataService.updateUserDocs(files);
        }

        // The multiple attribute is not working for adding the same file twice
        event.target.value = null;
    }

    openAttachmentModal() {
        const config = { size: 'lg', windowClass: 'cpn-doc-explorer-modal', centered: true };
        const modalRef = this.modalService.open(DocExplorerComponent, config);
        modalRef.componentInstance.name = 'DocExplorerComponent';
        modalRef.componentInstance.userDocsFromDB = this.userDocs;
        modalRef.componentInstance.isPochetteOnly = false;
        modalRef.componentInstance.componentTitle = MODAL_ARBO_BPN_WRITE_MAIL_TITLE;
        modalRef.componentInstance.validateBtnLabel = MODAL_ARBO_BPN_WRITE_MAIL_VALIDATE_BTN;
        modalRef.componentInstance.userDocsSelected = this.mailObject.mailFiles;
    }

    msgExpirationSelect(e: any) {
        if (e.target.value.length > 0) {
            this.mailObject.mailExpieration.selectedValue = e.target.value;
            this.msgExpiration = moment().locale('fr').add(e.target.value, 'days').format('LL');
        }
    }

    cancelNewMailModal() {
        this.dataService.arboNodeChecked = [];
        this.storageService.destroyStoredMailObject();
    }

    sendMessage() {
        this.ngxService.startLoader('loader-write-new-mail');
        this.msgToSend = this.getMailObjectData();

        if (this.multipartFileToSend.length !== 0) {
            this.sendMessageMixte();
        } else {
            this.sendMessageArchitectureCible();
        }

        return this.msgToSend;
    }

    enableSendBtn() {
        const recipients: any[] = [];
        const recipientsChecked: any[] = [];
        const recipientEmails: any[] = [];
        let invalidEmails: any[] = [];

        this.mailObject.recipientRow.forEach((r, i) => {
            recipients[i] = r.recipients;
            recipientsChecked[i] = r.recipientsChecked;
        });

        recipientsChecked.forEach(e => {
            e.forEach(t => {
                recipientEmails.push(t);
            });
        });

        invalidEmails = recipientEmails.filter(e => e.exist === false);

        const domains = [];
        document.querySelectorAll('.domain-select-list').forEach((elt: ElementRef['nativeElement']) => {
            domains.push(elt.value);
        });

        /* Bouton 'Envoyer' actif si :
         * 1- Règle générale, au moins :
         *                  - Un 'Domaine' est sélectionné
         *                  - Un destinataire valide est saisi
         *                  - Une PJ est uploadée
         *
         * 2- Pour les boites CEP, au moins :
         *                  - Un 'Domaine' <Avocat> est sélectionné
         *                  - Un destinataire valide est saisi
     *                  - Avoir le role CPN_TITULAIRE (ou a minima, ne pas avoir CPN_STORE)
         */
        const isAnyRecipientEmpty = [];
        const noFileToSent: boolean = this.mailObject.mailFiles.length === 0;
        const selectedMailbox = this.newMailForm.get('sender').value;

        domains.forEach((domain, i) => {
            if (recipients[i].length === 0) {
                isAnyRecipientEmpty.push(true);
            }
            const immutableCondition = isAnyRecipientEmpty.length > 0 || invalidEmails.length > 0 || this.disableSendButtonTemporarily;
            this.disableSendButton =
                immutableCondition
                || (noFileToSent && this.cannotSendViaExchange(selectedMailbox))
                || (noFileToSent && this.canSentViaExchange(selectedMailbox) && this.domainAvocatIsNotInRecipientDomain(domains))
                || (noFileToSent && !this.permissionService.hasPermission(UserAction.SEND_MAIL_VIA_EXCHANGE));
        });
    }

    domainAvocatIsNotInRecipientDomain(domains: string[]) {
        return !domains.includes('AVOCATS');
    }

    openNotidocModal() {
        const config = { size: 'lg', windowClass: 'cpn-notidoc-modal', centered: true };
        const modalRef = this.modalService.open(NotidocModalComponent, config);
        modalRef.componentInstance.name = ' NotidocModalComponent';
    }

    private sendMessageMixte() {

        const form: FormData = new FormData();
        this.fichierMessagesDto = this.msgToSend.fichierMessages.filter(f => f.uri);
        const jsonParametres = {
            id: null,
            type: null,
            subject: this.msgToSend.subject,
            comment: this.msgToSend.comment,
            date: null,
            lifetime: this.msgToSend.lifetime,
            encrypted: this.msgToSend.encrypted,
            signed: this.msgToSend.signed,
            status: null,
            sender: this.msgToSend.sender,
            nbTry: null,
            editableSubject: true,
            editableComment: true,
            appName: null,
            misc: null,
            addFileFromPc: false,
            messageDestinataires: this.msgToSend.messageDestinataires as MessageRecipient[],
            fichierMessages: this.fichierMessagesDto,
            messageStatuts: []
        };


        jsonParametres.fichierMessages.forEach(m => {
            delete m.size;
        });

        jsonParametres.messageDestinataires.forEach(m => {
            delete m.emailChecked;
        });

        form.append('parametres', JSON.stringify(jsonParametres));
        this.multipartFileToSend.forEach(file => form.append('file', file));

        this.cpnMasEchangeService.sendMessageMixte(form).subscribe(
            success => {
                this.ngxService.stopLoader('loader-write-new-mail');
                this.activeModal.close();

                this.dataService.openTinyWindowRequest.emit(false);
                this.storageService.destroyStoredMailObject();
                this.initMailHeader();

                const txt = 'Votre message a bien été envoyé.';
                this.alertesModalService.openSuccessModal({
                    title: DEMANDE_ENVOI_MESSAGE_TITLE,
                    message: txt
                });
            },
            fail => {
                this.ngxService.stopLoader('loader-write-new-mail');
                this.activeModal.close();

                this.dataService.openTinyWindowRequest.emit(false);
                this.storageService.destroyStoredMailObject();
                this.initMailHeader();

                this.errorNpp = UtilsService.toMessage(fail);
                this.alertesModalService.openErrorModal({
                    title: DEMANDE_ENVOI_MESSAGE_TITLE,
                    message: `<p>L'envoie du message a échoué</p><p>${this.errorNpp}</p>`
                });
            }
        );
    }

    private sendMessageArchitectureCible() {
        this.cpnMasEchangeService.sendMessage(this.msgToSend).subscribe(
            data => {
                this.ngxService.stopLoader('loader-write-new-mail');
                this.activeModal.close();

                this.dataService.openTinyWindowRequest.emit(false);
                this.storageService.destroyStoredMailObject();
                this.initMailHeader();

                this.alertesModalService.openSuccessModal({
                    title: DEMANDE_ENVOI_MESSAGE_TITLE,
                    message: '<p>Votre message a bien été envoyé.</p>'
                });
            },
            fail => {
                this.ngxService.stopLoader('loader-write-new-mail');
                this.activeModal.close();

                this.errorNpp = UtilsService.toMessage(fail);
                this.alertesModalService.openErrorModal({
                    title: DEMANDE_ENVOI_MESSAGE_TITLE,
                    message: `<p>L'envoie du message a échoué</p><p>${this.errorNpp}</p>`
                });
            }
        );
    }

    private getRecipientsElement(index: any) {
        return $('#ul-' + index);
    }

    private initMailHeader() {
        this.cpnMasEchangeService.getDomainList(AppNameEnum.CEPN).subscribe(
            reslt => {
                this.domains = reslt;
                this.mailObject = {
                    sender: '',
                    recipientRow: [{
                        domainList: this.PPNDomainListInit(this.domains),
                        recipients: [],
                        recipientsChecked: [],
                        addButton: true,
                        deleteButton: true
                    }],
                    mailSubject: '',
                    mailBody: '',
                    mailFiles: [],
                    mailExpieration: { expirationList: MAIL_EXPIRATION_LIST, selectedValue: 8 },
                    sendMailButton: false,
                    multipartFileArray: [],
                };

                if (this.isBalCep()) {
                    this.mailObject.sender = this.newMailForm.get('sender').value;
                    this.mailObject.recipientRow[0].domainList.find(d => d.label === 'Avocats').selected = true;
                } else {
                    this.mailObject.recipientRow[0].domainList.find(d => d.label === 'Avocats').selected = false;
                }

                if (this.domainFromSearchResult && this.emailFromSearchResult) {
                    if (this.domainFromSearchResult.length && this.emailFromSearchResult.length) {
                        this.mailObject.recipientRow[0].domainList.find(d => d.value === this.domainFromSearchResult).selected = true;
                        this.mailObject.recipientRow[0].recipients.push(this.emailFromSearchResult);
                        this.mailObject.recipientRow[0].recipientsChecked.push({
                            email: this.emailFromSearchResult,
                            exist: true
                        });
                    }
                }

                if (this.writeNewMessageType.msgReponse) {
                    this.mailObject.recipientRow[0].domainList.find(d => d.label === 'Avocats').selected = true;
                    this.mailObject.recipientRow[0].recipients.push(this.previousMessageSender);
                    this.newMailForm.patchValue({ mailBody: this.previousMessageData });

                    if (localStorage.getItem('mail_object') === null) {
                        this.recipientSelectedSpinner[0] = true;	// TODO modifier
                        this.contactService.checkContact(new SearchRequest('', this.mailObject.recipientRow[0].domainList.find(d => d.label === 'Avocats').value, '', '', this.previousMessageSender, ''))
                            .pipe(
                                tap(() => {
                                    this.disableSendButtonTemporarily = true;
                                })
                            ).subscribe(
                                done => {
                                    this.disableSendButtonTemporarily = false;
                                    this.recipientSelectedSpinner[0] = false;
                                    this.mailObject.recipientRow[0].recipientsChecked = done;
                                },
                                fail => {
                                    this.disableSendButtonTemporarily = false;
                                    this.recipientSelectedSpinner[0] = false;
                                    console.error(fail);
                                }
                            );
                    }
                }

                // get and set selected files broadcasted from doc-explorer.component through dataService.ts
                this.dataService.fichierMessages$.subscribe(
                    data => {
                        this.mailObject.mailFiles = data as MessageAttachment[];
                        this.dataService.messageAttachment = this.mailObject.mailFiles;
                    }
                );

                this.dataService.updateUserDocs([]);
                this.multipartFileToSend = this.dataService.multipartFileUpload;

                // set default selected and value
                this.mailObject.mailExpieration.expirationList.find(elt => elt.value === 8).selected = true;

                if (localStorage.getItem('mail_object') !== null) {
                    const mailobj = JSON.parse(localStorage.getItem('mail_object')) as MessageToSend;
                    this.mailObject.recipientRow.splice(0, 1);

                    this.mailObject.sender = mailobj.sender.email;
                    this.cepSenderMail = this.mailObject.sender;
                    this.mailObject.mailSubject = mailobj.subject;
                    this.mailObject.mailBody = mailobj.comment;

                    this.newMailForm.setValue({
                        sender: mailobj.sender.email,
                        mailSubject: mailobj.subject,
                        mailBody: mailobj.comment,
                        file: null
                    });

                    this.dataService.updateUserDocs(mailobj.fichierMessages);
                    this.dataService.arboNodeChecked = [];
                    mailobj.fichierMessages.forEach(r => {
                        this.dataService.arboNodeChecked.push({
                            id: null,
                            path: r.uri,
                            text: r.nom,
                            type: r.type,
                            level: null
                        });
                    });

                    this.mailObject.mailExpieration = {
                        expirationList: MAIL_EXPIRATION_LIST,
                        selectedValue: Number(mailobj.lifetime)
                    };

                    // set default selected and value
                    this.mailObject.mailExpieration.expirationList.find(elt => elt.value === Number(mailobj.lifetime)).selected = true;

                    mailobj.messageDestinataires.forEach((r, i) => {
                        let emails = [];
                        let checkedEmails: EmailChecked[] = [];
                        let domains: Domain[] = [];
                        let domain: Domain = {
                            label: '',
                            value: '',
                            selected: false,
                            disabled: false,
                            mails: [],
                            canal: '',
                            editable: true,
                            referentiel: ''
                        };
                        domains = this.PPNDomainListInit(this.domains);
                        domain = domains.find(d => d.value === r.domain);

                        if (r.domain === domain.value) {
                            domain.selected = true;
                            emails = r.email.length > 0 ? r.email.split(',') : emails;
                            checkedEmails = r.emailChecked;

                            if (!domain.editable) {
                                this.preventRecipientEmailDeletion[i] = true;
                                this.disableAutoCompletionInput[i] = true;
                            } else {
                                this.preventRecipientEmailDeletion[i] = false;
                                this.disableAutoCompletionInput[i] = false;
                            }
                        }

                        this.mailObject.recipientRow.push({
                            domainList: domains,
                            recipients: emails,
                            recipientsChecked: checkedEmails,
                            addButton: false,
                            deleteButton: true
                        });
                    });

                    this.mailObject.recipientRow[this.mailObject.recipientRow.length - 1].addButton = true;

                    // Set dynamically z-index
                    setTimeout(() => {
                        document.querySelectorAll('.recipient-row').forEach((v, i) => {
                            v['style'] = `z-index:${this.domains.length - 1 - i}`;
                        });
                    }, 500);
                }

                // Auto save writing mail
                this.autoStoreMailObject();

                // Enable and Disable send button
                this.autoEnableSendBtn();

                this.initReady = true;
            },
            error => {
            });

    }

    private isBalCep(): boolean {
        return this.dataService.newUserInfo.mail !== this.dataService.currentBoxEmail;
    }

    private PPNDomainListInit(PPN_DOMAINS_LIST: Domain[]) {
        const domain: Domain[] = [];
        PPN_DOMAINS_LIST.forEach(elt => {
            domain.push({
                label: elt.label,
                value: elt.value,
                selected: false,
                disabled: false,
                mails: elt.mails,
                canal: elt.canal,
                editable: elt.editable,
                referentiel: elt.referentiel
            });
        });

        return domain;
    }

    private getCanalByDomain(domain: string) {
        return this.domains.filter(d => d.value === domain)[0].canal;
    }

    private getReferentielByDomain(domain: string) {
        return this.domains.filter(d => d.value === domain)[0].referentiel;
    }

    private hideAndShowActionButton() {
        this.mailObject.recipientRow.forEach(rw => rw.addButton = false);
        this.mailObject.recipientRow[this.mailObject.recipientRow.length - 1].addButton = true;
    }

    private disableSelectedDomainByDOMelement() {
        this.enableSelectedDomainByDOMelement();
        const eltValue = [];
        document.querySelectorAll('.domain-select-list').forEach((elt: ElementRef['nativeElement']) => {
            eltValue.push(elt.value);
        });

        document.querySelectorAll('.domain-select-list').forEach((elt: ElementRef['nativeElement']) => {
            for (const opt of elt.options) {
                eltValue.forEach(ev => {
                    if (ev.length !== 0 && ev === opt.value) {
                        opt.setAttribute('disabled', 'disabled')
                    }
                });
            }
        });
    }

    private enableSelectedDomainByDOMelement() {
        document.querySelectorAll('.domain-select-list').forEach((elt: ElementRef['nativeElement']) => {
            for (const opt of elt.options) {
                opt.removeAttribute('disabled');
            }
        });
    }

    private storeMailObject() {
        const data = this.getMailObjectData();
        if (data.messageDestinataires.length !== 0) {
            localStorage.setItem('mail_object', JSON.stringify(data));
        }
    }

    private autoStoreMailObject() {
        this.mailAutoSaveInterval$ = interval(2000);
        this.mailAutoSaveSubcription = this.mailAutoSaveInterval$.subscribe(r => {
            const data = this.getMailObjectData();
            if (data.messageDestinataires.length !== 0) {
                localStorage.setItem('mail_object', JSON.stringify(data));
            }
        });
    }

    private canSentViaExchange(selectedMailbox: string) {
        if (selectedMailbox) {
            return this.configurationService.cpnConfigMap.prefixBalsCanSentViaExchange.filter(e => selectedMailbox.toLocaleLowerCase().startsWith(e.toLocaleLowerCase())).length > 0;
        } else {
            return false;
        }
    }

    private cannotSendViaExchange(selectedMailbox: string) {
        return !this.canSentViaExchange(selectedMailbox);
    }

    private autoEnableSendBtn() {
        this.sendBtnAutoEnableInterval$ = interval(100);
        this.sendBtnAutoEnableSubcription = this.sendBtnAutoEnableInterval$.subscribe(r => {
            this.enableSendBtn();
        });
    }

    private clickOutAutoCompleation() {
        window.addEventListener('click', (e: any) => {
            if (document.querySelector('.ul-list') !== null && !document.querySelector('.ul-list').contains(e.target)) {
                const ul = this.getRecipientsElement(this.currentRecipientsIndex);
                if (this.currentRecipientsIndex != null
                    && ul != null
                    && ul.is(':visible')) {
                    const inputMail: HTMLElement = document.querySelector('#recipient-input-' + this.currentRecipientsIndex);
                    inputMail.focus();
                    inputMail.blur();
                }

                document.querySelector('.ul-list')['style'].display = 'none';
            }
        });
    }

    private getMailObjectData() {
        this.mailObject.sender = this.newMailForm.get('sender').value;
        this.mailObject.mailSubject = this.newMailForm.get('mailSubject').value;
        this.mailObject.mailBody = this.newMailForm.get('mailBody').value;

        const boiteStructurelleMail = this.newMailForm.get('sender').value === this.user.mail ? '' : this.newMailForm.get('sender').value;

        return {
            comment: this.mailObject.mailBody,
            encrypted: 0,
            fichierMessages: this.mailObject.mailFiles,
            lifetime: this.mailObject.mailExpieration.selectedValue,
            messageDestinataires: this.getRecipientsByDomain(),
            sender: {
                email: this.mailObject.sender,
                userId: this.user.idLdap,
                codeSrj: this.user.idJuridiction,
                emailBoiteStructurelle: boiteStructurelleMail,
            },
            signed: 0,
            subject: this.mailObject.mailSubject
        };
    }

    private getRecipientsByDomain(): MessageRecipient[] {
        const recipients: MessageRecipient[] = [];

        this.mailObject.recipientRow.forEach((elt) => {
            let domain = '';
            let canal = '';

            for (const d of elt.domainList) {
                if (d.selected === true) {
                    domain = d.value;
                    canal = d.canal;
                }
            }

            if (canal) {
                elt.recipients.forEach(recipient => recipients.push({
                    domain,
                    canal,
                    email: recipient,
                    emailChecked: elt.recipientsChecked
                }));
            }
        });

        return recipients;
    }
}
