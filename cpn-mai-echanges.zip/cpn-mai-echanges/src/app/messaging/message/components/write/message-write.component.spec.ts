import { HttpClientModule } from '@angular/common/http';
import { EventEmitter } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { NgbActiveModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderModule, NgxUiLoaderService } from 'ngx-ui-loader';
import { BehaviorSubject, Observable } from 'rxjs';
import { MaterialModule } from 'src/app/core/modules/material/material.module';
import { FormateDate } from '../../../shared/pipes/format-date.pipe';
import { CpnNotificationService } from '../../../shared/services/cpn-notification.service';
import { DataService } from '../../../shared/services/data.service';
import { StorageService } from '../../../shared/services/storage.service';
import { MessageWriteComponent } from './message-write.component';

describe('WriteNewMailComponent', () => {
    let component: MessageWriteComponent;
    let fixture: ComponentFixture<MessageWriteComponent>;
    let componentElt: any;

    let dataServiceStub: Partial<DataService>;
    let storageServiceStub: Partial<StorageService>;
    let cpnNotificationServiceStub: Partial<CpnNotificationService>;

    beforeEach(waitForAsync(() => {
        dataServiceStub = {
            userInfo: new BehaviorSubject<any>({nom: '', prenom: '', mail: ''}),
            newUserInfo: {nom: '', prenom: '', mail: ''},
            cpnSpsLoadEmitter: new EventEmitter(),
            updateUserDocs() {
            }
        };

        dataServiceStub.userInfo.next({nom: '', prenom: '', mail: ''});
        dataServiceStub.fichierMessages$ = new Observable();

        storageServiceStub = {
            storeMailBox(mail: string) {
                localStorage.setItem('mail_box', mail);
            },
            storeNewMailObject(data: string) {
                localStorage.setItem('mail_object', JSON.stringify(data));
            },
            restoreWindow() {
                if (localStorage.getItem('mail_object') !== null) {
                    this.dataService.openTinyWindowRequest.emit(true);
                }
            },
            destroyStoredMailObject() {
                if (localStorage.getItem('mail_object') !== null) {
                    localStorage.removeItem('mail_object');
                }
            }
        };
        cpnNotificationServiceStub = {};

        TestBed.configureTestingModule({
            declarations: [
                MessageWriteComponent,
                FormateDate
            ],
            imports: [
                FormsModule,
                ReactiveFormsModule,
                NgxUiLoaderModule,
                NgbModule,
                MaterialModule,
                RouterTestingModule,
                HttpClientModule
            ],
            providers: [
                {provide: DataService, useValue: dataServiceStub},
                {provide: StorageService, useValue: storageServiceStub},
                {provide: CpnNotificationService, useValue: cpnNotificationServiceStub},
                NgxUiLoaderService,
                NgbActiveModal,
            ]
        }).compileComponents();
    }));

    beforeEach(function () {
        jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(MessageWriteComponent);
        component = fixture.componentInstance;
        componentElt = fixture.debugElement.nativeElement;
        component.writeNewMessageType = {newMsg: true, msgReponse: false};
        component.mailObject = {
            sender: '',
            recipientRow: [{
                domainList: [],
                recipients: [],
                recipientsChecked: [],
                addButton: false,
                deleteButton: false,
            }],
            mailSubject: '',
            mailBody: '',
            mailFiles: [],
            mailExpieration: {expirationList: [], selectedValue: 0},
            sendMailButton: false,
            multipartFileArray: []
        };
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    xit('should activate message send button', () => {
        let recipientrow = {
            domainList: [],
            recipients: [],
            recipientsChecked: [],
            addButton: true,
            deleteButton: true
        };

        component.disableSendButton = true;
        component.mailObject.recipientRow.push(recipientrow);
        component.enableSendBtn();

        expect(component.disableSendButton).toBe(false);
    });

    xit('should not activate message send button', () => {
        let recipientrow = {
            domainList: [],
            recipients: [],
            recipientsChecked: [],
            addButton: true,
            deleteButton: true
        };
        component.disableSendButton = true;
        component.mailObject.recipientRow.push(recipientrow);
        component.enableSendBtn();

        expect(component.disableSendButton).toBe(true);
    });
});
