import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { MessageAuditModalComponent } from './message-audit-modal.component';

describe('DownlodedFilesModalComponent', () => {
    let component: MessageAuditModalComponent;
    let fixture: ComponentFixture<MessageAuditModalComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [MessageAuditModalComponent]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(MessageAuditModalComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
