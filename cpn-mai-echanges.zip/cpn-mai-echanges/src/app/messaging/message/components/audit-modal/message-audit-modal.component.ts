import { Component, Input, OnInit } from '@angular/core';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { AttachmentAudit, MessageRead } from 'src/app/messaging/message/models/message.model';

@Component({
    selector: 'app-message-audit-modal',
    templateUrl: './message-audit-modal.component.html',
    styleUrls: ['./message-audit-modal.component.scss']
})
export class MessageAuditModalComponent implements OnInit {

    @Input() message: MessageRead;
    @Input() userIndex: number;

    attachmentMetadata: AttachmentAudit[];

    constructor(public activeModal: NgbActiveModal) {
    }

    ngOnInit() {
        this.attachmentMetadata = this.message.audit.downloaded.filter(v => v.user_index === this.userIndex);
    }

    getFileName(attachmentMetadata: AttachmentAudit) {
        return this.message.files.filter(f => f.index === attachmentMetadata.file_index)[0].name;
    }
}
