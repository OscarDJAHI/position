import { Component, Input } from '@angular/core';
import { ActionType } from 'src/app/core/models/enums/action-type.enum';
import { CpnMasEchangeService } from 'src/app/messaging/message/services/cpn-mas-echange.service';

@Component({
    selector: 'app-message-flag',
    templateUrl: './message-flag.component.html',
    styleUrls: ['./message-flag.component.scss'],
})
export class MessageFlagComponent {

    @Input() msgId = '';
    @Input() msgState = '';

    actionType = ActionType;

    constructor(private cpnMasEchangeService: CpnMasEchangeService) {
    }

    updateFlagTraite(id: any, etat: string) {
        const ids = [];
        ids.push(id);

        this.cpnMasEchangeService.actionOnMessage(ids, etat).subscribe(
            () => {
                this.msgState = etat;
            },
            error => {
                console.log(error);
            }
        );
    }
}
