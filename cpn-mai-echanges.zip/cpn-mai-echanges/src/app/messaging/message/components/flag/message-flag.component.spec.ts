import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CpnMasEchangeService } from '../../services/cpn-mas-echange.service';
import { CpnNotificationService } from '../../../shared/services/cpn-notification.service';
import { DataService } from '../../../shared/services/data.service';
import { MessageFlagComponent } from './message-flag.component';

describe('PopoverMessageTraiteComponent', () => {
    let component: MessageFlagComponent;
    let fixture: ComponentFixture<MessageFlagComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [MessageFlagComponent],
                imports: [
                    NgbModule,
                    RouterTestingModule,
                    HttpClientModule
                ],
                providers: [
                    DataService,
                    CpnMasEchangeService,
                    CpnNotificationService
                ]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(MessageFlagComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
