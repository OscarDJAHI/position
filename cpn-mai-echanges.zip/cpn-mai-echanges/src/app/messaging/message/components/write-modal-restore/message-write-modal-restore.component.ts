import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { DataService } from '../../../shared/services/data.service';
import { MessageWriteModalComponent } from '../write-modal/message-write-modal.component';

@Component({
    selector: 'app-message-write-modal-restore',
    templateUrl: './message-write-modal-restore.component.html',
    styleUrls: ['./message-write-modal-restore.component.scss'],
})
export class MessageWriteModalRestoreComponent implements OnInit {

    @Input() displayNotifNewMsg: number;
    @Input() displayAlertNewMsg: boolean;
    @Input() closeWindowState = true;

    constructor(
        private router: Router,
        private dataService: DataService,
        private modalService: NgbModal,
    ) {
    }

    ngOnInit() {
    }

    restoreClosedWindow() {
        this.dataService.openTinyWindowRequest.emit(false);
        const config = {size: 'xl', windowClass: 'cpn-write-new-mail-modal', centered: true};
        const modalRef = this.modalService.open(MessageWriteModalComponent, config);

        if (localStorage.getItem('writeNewMessageType') !== undefined) {
            modalRef.componentInstance.writeNewMessageState = JSON.parse(localStorage.getItem('writeNewMessageType'));
        }
    }
}
