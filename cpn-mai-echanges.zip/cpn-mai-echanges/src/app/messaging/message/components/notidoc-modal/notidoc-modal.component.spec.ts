import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { NotidocModalComponent } from './notidoc-modal.component';

describe('NotidocModalComponent', () => {
    let component: NotidocModalComponent;
    let fixture: ComponentFixture<NotidocModalComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [NotidocModalComponent]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(NotidocModalComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
