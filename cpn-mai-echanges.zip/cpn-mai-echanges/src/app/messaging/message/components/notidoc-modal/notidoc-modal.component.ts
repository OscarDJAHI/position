import { Component, ElementRef, Input, OnInit } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DomainLabelEnum } from 'src/app/core/models/enums/domain-label.enum';
import { IndicatorId } from 'src/app/core/services/indicators/indicator-id.enum';
import { IndicatorLogService } from 'src/app/core/services/indicators/indicator-log.service';
import { CpnMasEchangeService } from '../../services/cpn-mas-echange.service';

@Component({
    selector: 'app-notidoc-modal',
    templateUrl: './notidoc-modal.component.html',
    styleUrls: ['./notidoc-modal.component.scss']
})
export class NotidocModalComponent implements OnInit {

    urlNotidoc: string;

    @Input() title;
    @Input() message;

    constructor(
        public activeModal: NgbActiveModal,
        private modalService: NgbModal,
        private cpnMasEchangeService: CpnMasEchangeService,
        private indicatorService: IndicatorLogService
    ) {
    }

    ngOnInit() {
        this.cpnMasEchangeService.getUrlNotidoc().subscribe(
            done => {
                this.urlNotidoc = done;
            }
        );
    }

    doActionNotidocModal() {
        this.indicatorService.log(IndicatorId.CPN06).subscribe();
        this.modalService.dismissAll();
    }

    cancelActionNotidocModal() {
        document.querySelectorAll('.domain-select-list').forEach((elt: ElementRef['nativeElement']) => {
            if (elt.value === DomainLabelEnum.HUISSIER) {
                elt.options[elt.selectedIndex].disabled = false
                elt.options[0].selected = true;
            }
        });
    }
}
