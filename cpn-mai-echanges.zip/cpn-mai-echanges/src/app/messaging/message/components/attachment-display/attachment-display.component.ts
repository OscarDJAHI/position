import { Component, Input, OnInit } from '@angular/core';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { NgxUiLoaderService } from 'ngx-ui-loader';

@Component({
    selector: 'app-attachment-display',
    templateUrl: './attachment-display.component.html',
    styleUrls: ['./attachment-display.component.scss']
})
export class AttachmentDisplayComponent implements OnInit {

    @Input() data: any;
    @Input() fileName: string;
    @Input() contentType: string;

    constructor(
        public activeModal: NgbActiveModal,
        private ngxUiLoaderService: NgxUiLoaderService) {
    }

    ngOnInit() {
        this.ngxUiLoaderService.startLoader('preview-loading');
    }

    stopLoader() {
        this.ngxUiLoaderService.stopLoader('preview-loading');
    }
}
