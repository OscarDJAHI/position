import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { AttachmentDisplayComponent } from './attachment-display.component';

describe('VisionneuseComponent', () => {
    let component: AttachmentDisplayComponent;
    let fixture: ComponentFixture<AttachmentDisplayComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [AttachmentDisplayComponent]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AttachmentDisplayComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
