import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { MessageRead } from '../../models/message.model';
import { DataService } from '../../../shared/services/data.service';
import { StorageService } from '../../../shared/services/storage.service';
import { UtilisateurService } from 'src/app/core/services/utilisateur/utilisateur.service';

@Component({
    selector: 'app-message-write-modal',
    templateUrl: './message-write-modal.component.html',
    styleUrls: ['./message-write-modal.component.scss'],
})
export class MessageWriteModalComponent implements OnInit {

    @Input() displayNotifNewMsg: number;
    @Input() displayAlertNewMsg: boolean;
    @Input() writeNewMessageState: { newMsg: boolean, msgReponse: boolean };
    @Input() previousMessageData: MessageRead;
    @Input() previousMessageSender: string;
    @Input() domainFromSearchResult: string;
    @Input() emailFromSearchResult: string;

    mailBoxType = 'nominativeBox';
    mailCntx = 'cpn';
    closeReason = 'Cross click';
    boxEmail: string;

    constructor(
        config: NgbModalConfig,
        public activeModal: NgbActiveModal,
        private storageService: StorageService,
        private dataService: DataService,
        private userService: UtilisateurService,
    ) {
        // customize default values of modals used by this component tree
        config.windowClass = 'cpn-write-new-mail-modal';
        config.size = 'xl';
        config.centered = true;
    }

    ngOnInit() {
        this.boxEmail = this.dataService.currentBoxEmail;

        if (this.userService.hasDefaultBox()) {
            this.boxEmail = this.userService.userInfo.parametrage.defaultMailBox.email;
        }
    }

    reduceMailModal() {
        this.activeModal.close();
        return this.closeReason;
    }

    closeMailModal() {
        this.storageService.destroyStoredMailObject();
        this.activeModal.close();
    }

    updateBoxMail(newBoxMail: string) {
        this.boxEmail = newBoxMail;
    }
}
