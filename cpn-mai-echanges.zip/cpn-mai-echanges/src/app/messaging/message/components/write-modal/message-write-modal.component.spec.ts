import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { NgbActiveModal, NgbModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderModule, NgxUiLoaderService } from 'ngx-ui-loader';
import { MaterialModule } from 'src/app/core/modules/material/material.module';
import { ArborescenceService } from 'src/app/core/services/arborescence/arborescence.service';
import { PochetteService } from 'src/app/core/services/pochette/pochette.service';
import { MessageWriteComponent } from '../write/message-write.component';
import { ContactService } from '../../../contact/services/contact.service';
import { MailboxService } from '../../../mailbox/services/mailbox.service';
import { CpnMasEchangeService } from '../../services/cpn-mas-echange.service';
import { CpnNotificationService } from '../../../shared/services/cpn-notification.service';
import { DataService } from '../../../shared/services/data.service';
import { StorageService } from '../../../shared/services/storage.service';

import { MessageWriteModalComponent } from './message-write-modal.component';

xdescribe('WindowOpenComponent', () => {
    let component: MessageWriteModalComponent;
    let fixture: ComponentFixture<MessageWriteModalComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [MessageWriteModalComponent, MessageWriteComponent],
                imports: [
                    MaterialModule,
                    NgxUiLoaderModule,
                    FormsModule,
                    NgbModule,
                    RouterTestingModule,
                    ReactiveFormsModule,
                    HttpClientModule
                ],
                providers: [
                    NgbActiveModal,
                    DataService,
                    CpnNotificationService,
                    ContactService,
                    PochetteService,
                    ArborescenceService,
                    CpnMasEchangeService,
                    MailboxService,
                    NgxUiLoaderService,
                    NgbActiveModal,
                    StorageService,
                    NgbModal,
                ]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(MessageWriteModalComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
