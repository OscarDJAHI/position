import { Component, Input, OnChanges } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import * as fileSaver from 'file-saver';

import { BoxType } from 'src/app/core/models/enums/box-type.enum';
import { DocExplorerComponent } from 'src/app/messaging/shared/components/doc-explorer/doc-explorer.component';

import { UserInfoModel } from '../../../../core/models/user-info.model';

import {
    DEMANDE_AR_ERROR_MESSAGE,
    DEMANDE_AR_ERROR_TITLE,
    DEMANDE_AR_INTO_BPN_ERROR_MESSAGE,
    DEMANDE_AR_INTO_BPN_ERROR_TITLE,
    DEMANDE_AR_INTO_BPN_SUCCESS_MESSAGE,
    DEMANDE_AR_INTO_BPN_SUCCESS_TITLE,
    MODAL_ARBO_BPN_DL_FILE_TITLE,
    MODAL_ARBO_BPN_DL_FILE_VALIDATE_BTN
} from '../../../shared/constants/constants';
import { DataService } from '../../../shared/services/data.service';
import { AlertesModalService } from '../../../shared/services/alertes-modal.service';
import { DemandeArService } from '../../../shared/services/demande-ar.service';
import { DownloadArComponent } from '../../../shared/modals/download-ar/download-ar.component';
import { DemandeAr } from '../../../shared/models/demande-ar.model';

import { MessageAuditModalComponent } from '../audit-modal/message-audit-modal.component';

import { DemandeArBpn } from '../../models/demande-ar-bpn.model';
import { MessageRead } from '../../models/message.model';
import { SpsService } from '../../../../core/services/sps/sps.service';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { UserAction } from 'src/app/core/models/user-action.model';
import { ConfigurationService } from 'src/app/core/services/configuration/configuration.service';
import { FileModel } from '../../../../core/models/attachment-deposit.model';

@Component({
    selector: 'app-message-audit',
    templateUrl: './message-audit.component.html',
    styleUrls: ['./message-audit.component.scss']
})
export class MessageAuditComponent implements OnChanges {

    @Input() message: MessageRead;
    @Input() mailbox: string;
    @Input() typeBox: string;

    messageMapping: any;

    disable = true;

    userAction = UserAction;

    constructor(
        private modalService: NgbModal,
        private dataService: DataService,
        private alertModalService: AlertesModalService,
        private demandeArService: DemandeArService,
        private spsService: SpsService,
        private ngxService: NgxUiLoaderService,
        private configurationService: ConfigurationService) {
    }

    ngOnChanges() {
        const audit = this.message.audit;
        this.disable = !audit || !audit.viewed || !audit.viewed.length || this.typeBox === BoxType.TRASH;
        this.messageMapping = {
            '=-1': 'Tous les fichiers ont été téléchargés',
            '=0': 'Aucun fichier téléchargé',
            '=1': '1 fichier a été téléchargé sur ' + this.message.files.length,
            other: '# fichiers ont été téléchargés sur ' + this.message.files.length
        };
    }

    downloadedFiles(recipientIndex: number): number {
        const dfCount = this.message.audit.downloaded.filter(v => v.user_index === recipientIndex).length;
        return dfCount === this.message.files.length ? -1 : dfCount;
    }

    openSendArToNppTooltip() {
        if (this.configurationService.cpnConfigMap.modalDocumentDepositEnable) {
            this.openSendArToNppWindow();
        } else {
            this.openSendArToNppModal();
        }
    }

    openDownloadedFilesModal(userIndex: number) {
        const config = { centered: true, windowClass: 'downloded-files-modal' };
        const modal = this.modalService.open(MessageAuditModalComponent, config);
        modal.componentInstance.message = this.message;
        modal.componentInstance.userIndex = userIndex;
    }

    viewDate(recipientIndex: number): Date {
        const viewed = this.message.audit.viewed.filter(v => v.user_index === recipientIndex);
        return viewed.length ? viewed[0].date : null;
    }

    saveARLocally() {
        this.demandeArService.saveAr(this.message.id).subscribe(
            response => {
                const blob: any = new Blob([response.body], { type: 'application/pdf' });
                fileSaver.saveAs(blob, response.headers.get('filename'));
            },
            error => console.log('Error downloading the ar'),
            () => console.log('File downloaded successfully')
        );
    }

    openBpnArborescence() {
        const config = { size: 'lg', windowClass: 'cpn-doc-explorer-modal', centered: true };
        const modalRef = this.modalService.open(DocExplorerComponent, config);
        modalRef.componentInstance.name = 'DocExplorerComponent';
        modalRef.componentInstance.isPochetteOnly = true;
        modalRef.componentInstance.componentTitle = MODAL_ARBO_BPN_DL_FILE_TITLE;
        modalRef.componentInstance.validateBtnLabel = MODAL_ARBO_BPN_DL_FILE_VALIDATE_BTN;
        modalRef.result.then(
            (result) => {
                this.sendArBpn();
            }, (reason) => {
                // fermeture manuel pas de requête a faire
            });
    }

    private sendArBpn() {
        const demande = new DemandeArBpn();
        const user = this.dataService.newUserInfo;

        demande.userMail = String(user.mail);
        demande.codeSrj = String(user.idJuridiction);
        demande.idLdap = String(user.idLdap);
        demande.idNoeud = this.dataService.idNodeChecked;
        demande.idMessage = this.message.id;

        this.demandeArService.sendArIntoBPN(demande).subscribe(
            data => {
                this.alertModalService.openSuccessModal({
                    title: DEMANDE_AR_INTO_BPN_SUCCESS_TITLE,
                    message: DEMANDE_AR_INTO_BPN_SUCCESS_MESSAGE
                });
            }, error => {
                this.alertModalService.openErrorModal({
                    title: DEMANDE_AR_INTO_BPN_ERROR_TITLE,
                    message: DEMANDE_AR_INTO_BPN_ERROR_MESSAGE
                });
                console.error(error);
            }, () => {
                this.dataService.idNodeChecked = null;
            });
    }

    private openSendArToNppWindow() {
        this.ngxService.start();

        const emailBs = String(this.mailbox) !== String(this.dataService.newUserInfo.mail) ? this.mailbox : null;

        const files: FileModel[] = [{
            idFichier: 'AR_TO_GENERATE',
            nom: 'ar_to_generate.pdf',
            type: 'pdf',
            taille: '1024',
            storeType: 'CPN'
        }];

        const complement = {
            idExterne: this.message.idExterne,
            emailPrimaire: this.dataService.newUserInfo.mail,
            emailSecondaire: this.dataService.newUserInfo.mail ? null : emailBs,
            repository: this.message.originMessage
        };

        this.spsService.openDepositModal('CPN', files, complement);
    }

    private openSendArToNppModal() {
        const config = { centered: true, windowClass: 'cpn-demande-ar-modal', size: 'none' };
        const modal = this.modalService.open(DownloadArComponent, config);
        modal.componentInstance.message = this.message;
        modal.componentInstance.boxEmail = this.mailbox;
        modal.result.then(
            result => this.sendDemandeAr(result),
            error => console.log('Sorry ! Something went wrong xx', error)
        );
    }

    private sendDemandeAr(demandeAr: DemandeAr) {
        this.dataService.userInfo$.subscribe(data => {
            const user = data as UserInfoModel;
            demandeAr.codeSrj = String(user.idJuridiction);
            demandeAr.emailMessage = String(user.mail);
            demandeAr.emailBs = String(this.mailbox) !== String(user.mail) ? this.mailbox : null;
            demandeAr.idMessage = String(this.message.id);

            this.demandeArService.createRequest(demandeAr).subscribe(
                response => {
                    if (response.id == null) {
                        this.alertModalService.openErrorModal({
                            title: DEMANDE_AR_ERROR_TITLE,
                            message: DEMANDE_AR_ERROR_MESSAGE
                        });
                    }
                }, error => {
                    this.alertModalService.openErrorModal({
                        title: DEMANDE_AR_ERROR_TITLE,
                        message: DEMANDE_AR_ERROR_MESSAGE
                    });
                    console.error(error);
                });
        });
    }
}
