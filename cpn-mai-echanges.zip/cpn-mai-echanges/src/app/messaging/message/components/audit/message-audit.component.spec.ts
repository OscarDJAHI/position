import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { MessageAuditComponent } from './message-audit.component';

describe('MessageArComponent', () => {
    let component: MessageAuditComponent;
    let fixture: ComponentFixture<MessageAuditComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [MessageAuditComponent]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(MessageAuditComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
