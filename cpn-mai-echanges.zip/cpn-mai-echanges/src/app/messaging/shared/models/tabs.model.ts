export interface TabElement {
    label: string;
    active: boolean;
    count: number;
    typeBox: string;
}
