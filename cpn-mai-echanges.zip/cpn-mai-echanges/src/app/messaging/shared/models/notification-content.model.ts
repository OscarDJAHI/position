export interface NotificationContent {
    boiteNominative: boolean;
    mailBoxMail: string;
    nbNewMessage: number;
}