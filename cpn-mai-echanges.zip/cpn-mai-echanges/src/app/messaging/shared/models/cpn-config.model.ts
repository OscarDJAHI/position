export interface CpnConfig {
    version: string;
    alerteIntervallPooling: number;
    alerteMessagePooling: number;
    rechercheEnable: boolean;
    prefixBalsCanSentViaExchange: string[];
    modalSendMessageEnable: boolean;
    modalDocumentDepositEnable: boolean;
    environnementDisplayMessage: string
    codeSrjJuridictionsActive: string[];
}
