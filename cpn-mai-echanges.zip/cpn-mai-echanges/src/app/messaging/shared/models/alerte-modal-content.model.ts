export interface AlertModalContent {
    title: string;
    message: string;
}
