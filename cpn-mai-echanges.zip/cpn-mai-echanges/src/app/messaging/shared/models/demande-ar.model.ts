export interface DemandeAr {
    id?: any;
    idMessage: string;
    idj: string;
    codeSrj: string;
    emailMessage: string;
    emailBs: string;
    originMessage: string;
}
