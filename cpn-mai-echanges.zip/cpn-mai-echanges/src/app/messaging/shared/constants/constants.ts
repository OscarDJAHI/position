export const EMAIL_PATTERN = /^[a-zA-Z0-9._-]+@[a-zA-Z_-]+?\.[a-zA-Z.]{2,}$/;

export const IDJ_PATTERN = '[0-9]{10}[A,B,C,D,E,F,G,H,J,K,M,N,P,Q,R,S,T,U,V,W,X,Y,Z]{1}';

export const IDJ_PATTERN_BPN = /^([0-9]{10}[A,B,C,D,E,F,G,H,J,K,M,N,P,Q,R,S,T,U,V,W,X,Y,Z]{1})$/;
export const APPI_PATTERN = /^([0-9]{12}[T]{0,1})$/;

export const GENERIC_ERROR_TITLE = 'Demande non enregistrée';
export const GENERIC_ERROR_MESSAGE = 'Un problème est survenue lors de votre requête, veuillez réessayer plus tard. Si le problème persiste, contactez le service informatique.';

export const DEMANDE_AR_ERROR_TITLE = GENERIC_ERROR_TITLE;
export const DEMANDE_AR_ERROR_MESSAGE = GENERIC_ERROR_MESSAGE;

export const DEMANDE_DOCUMENT_INTO_BPN_ERROR_TITLE = GENERIC_ERROR_TITLE;
export const DEMANDE_DOCUMENT_INTO_BPN_SUCCESS_TITLE = 'Demande enregistrée';
export const DEMANDE_DOCUMENT_INTO_BPN_ERROR_MESSAGE = GENERIC_ERROR_MESSAGE;
export const DEMANDE_DOCUMENT_INTO_BPN_SUCCESS_MESSAGE = 'La demande a été créée.';

export const DEMANDE_AR_INTO_BPN_ERROR_TITLE = 'Document AR non enregistré';
export const DEMANDE_AR_INTO_BPN_SUCCESS_TITLE = 'Document AR enregistré';
export const DEMANDE_AR_INTO_BPN_ERROR_MESSAGE = GENERIC_ERROR_MESSAGE;
export const DEMANDE_AR_INTO_BPN_SUCCESS_MESSAGE = 'Le document AR a été crée et envoyé vers BPN.';

export const DEMANDE_DOCUMENT_INTO_SUCCESS_TITLE = 'Demande bien enregistrée';
export const DEMANDE_DOCUMENT_INTO_ERROR_TITLE = GENERIC_ERROR_TITLE;

export const DEMANDE_ENVOI_MESSAGE_TITLE = 'Envoyer message';

export const MODAL_ARBO_BPN_WRITE_MAIL_TITLE = 'Insérer depuis BPN';
export const MODAL_ARBO_BPN_WRITE_MAIL_VALIDATE_BTN = 'Insérer';
export const MODAL_ARBO_BPN_DL_FILE_TITLE = 'Envoi vers BPN';
export const MODAL_ARBO_BPN_DL_FILE_VALIDATE_BTN = 'Valider';



export const MAIL_EXPIRATION_LIST = [
    {label: '1', value: 1, selected: false},
    {label: '2', value: 2, selected: false},
    {label: '3', value: 3, selected: false},
    {label: '8', value: 8, selected: false},
    {label: '10', value: 10, selected: false},
    {label: '15', value: 15, selected: false}
];

export const POLLING_INTERVAL = 60000;

export const OriginMessage = {
    PLINE: 'PLINE',
    PLEX: 'PLEX',
    EXCHANGE: 'EXCHANGE_CEP'
};

export const TAB_ITEM_LIST = [
    {
        typeBox: 'INBOX',
        label: 'Messages reçus',
        count: 0,
        active: true
    }, {
        typeBox: 'SENT',
        label: 'Messages envoyés',
        count: 0,
        active: false
    }
];
