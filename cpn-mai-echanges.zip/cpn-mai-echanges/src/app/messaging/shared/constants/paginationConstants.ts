export const Pagination = {
    DEFAULT: {
        NUMBER_PER_PAGE: '10',
        ORDER_BY: 'desc',
        SORT: '',
        PAGE: '1',
        TERM: ''
    }
}
