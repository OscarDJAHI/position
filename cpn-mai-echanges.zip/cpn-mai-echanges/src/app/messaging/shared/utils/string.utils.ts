export class StringUtils {

    static isEmpty(value: string): boolean {
        return !value || !value.length;
    }

    static toString(value: String): string {
        return value ? value.toString() : '';
    }

    static toArrayString(values: String[]): string[] {
        return values ? values.map(value => StringUtils.toString(value)) : [];
    }
}
