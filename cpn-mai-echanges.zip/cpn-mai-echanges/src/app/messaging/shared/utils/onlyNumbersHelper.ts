/**
 * empeche la saisie des caractères alpha
 * @param event
 */
export function onlyNumbers(event: any) {
    let charCode = (event.which) ? event.which : event.keyCode;
    //pour ff52, il faut autoriser explicitement <-, ->, backspace et suppr
    if ((charCode < 48 || charCode > 57) && charCode !== 37 && charCode !== 39 && charCode !== 8 && charCode !== 46) {
        event.preventDefault();
        return false;
    } else {
        return true;
    }
}
