/**
 * empeche la saisie des espaces
 * @param event
 */
export function noSpace(event: any) {
    let charCode = (event.which) ? event.which : event.keyCode;

    if (charCode == 32) {
        event.preventDefault();
        return false;
    } else {
        return true;
    }
}

