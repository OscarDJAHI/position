/**
 * aide à la saisie pour les champs dates
 * @param event
 */
export function maskedDate(event: any) {
    let v: string = event.target.value;
    let charCode = (event.which) ? event.which : event.keyCode;

    // keyCode = 8 backspace
    if (event.keyCode !== 8) {
        if (v.match(/^\d{2}$/) !== null) {
            event.target.value = v + '/';
        } else if (v.match(/^\d{2}\/\d{2}$/) !== null) {
            event.target.value = v + '/';
        }
        // qd on supprime le /, on supprime le chiffre avant
        // sinon le mask va le rajouter systematiquement
    } else {
        if (v.match(/^\d{2}$/) !== null) {
            event.target.value = v.substring(0, v.length - 1);
        } else if (v.match(/^\d{2}\/\d{2}$/) !== null) {
            event.target.value = v.substring(0, v.length - 1);
        }
    }

}
