import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderService } from 'ngx-ui-loader';

import { AlertesModalService } from '../../services/alertes-modal.service';
import { DataService } from "../../services/data.service";
import { CpnMasInterfaceService } from "../../../message/services/cpn-mas-interface.service";

import {
    APPI_PATTERN,
    DEMANDE_DOCUMENT_INTO_ERROR_TITLE,
    DEMANDE_DOCUMENT_INTO_SUCCESS_TITLE,
    IDJ_PATTERN_BPN
} from "../../constants/constants";
import { UserInfoModel } from "../../../../core/models/user-info.model";
import { Arborescence } from 'src/app/core/models/arborescence.model';

declare var $: any;

@Component({
    selector: 'app-send-to-npp',
    templateUrl: './send-to-npp.component.html',
    styleUrls: ['./send-to-npp.component.scss']
})
export class SendToNppComponent implements OnInit {

    @Input() nodes: Arborescence[] = [];
    @Input() idExterne;
    @Input() originMessage;
    @Input() emailBs;

    idjId = '';
    appiId = '';
    errorNpp = ' ';
    errorDossier = ' ';
    disabledCursor = false;
    user: UserInfoModel;

    constructor(
        public activeModal: NgbActiveModal,
        private ngxService: NgxUiLoaderService,
        private dataService: DataService,
        private alertesModalService: AlertesModalService,
        private cpnMasInterfaceService: CpnMasInterfaceService) {
    }

    private static toFile(node: Arborescence) {
        return {
            name: node.text,
            externalId: node.path
        }
    }

    private static toMessage(fail: any) {
        if (typeof (fail.error) == 'object') {
            return fail.error.hasOwnProperty('response') ? fail.error.response : fail.message;
        }

        return fail.error;
    }

    ngOnInit() {
        this.user = this.dataService.newUserInfo;
    }

    selectIdj() {
        this.appiId = '';
        $('#radioIdj').prop('checked', true);
        this.reset();
    }

    selectAppi() {
        this.idjId = '';
        $('#radioAppi').prop('checked', true);
        this.reset();
    }

    focusOutIdj() {
        this.errorNpp = '';
        this.errorDossier = '';

        if (this.idjId && !IDJ_PATTERN_BPN.test(this.idjId)) {
            this.errorIdj();
        } else {
            this.cleanIdj();
        }
    }

    focusOutAppi() {
        this.errorNpp = '';
        this.errorDossier = '';

        if (this.appiId && !APPI_PATTERN.test(this.appiId)) {
            this.errorAppi();
        } else {
            this.cleanAppi();
        }
    }

    removeNode(node: Arborescence) {
        this.nodes.forEach((item, index) => {
            if (node.id === item.id) {
                this.nodes.splice(index, 1);
            }
        });

        if (this.nodes.length === 0) {
            this.activeModal.close('Close click');
        }
    }

    checkBtnFormatIdentifiantDossier() {
        let isValid = true;

        const idjChecked = $('#radioIdj').is(':checked');
        const appiChecked = $('#radioAppi').is(':checked');

        if (!idjChecked && !appiChecked) {
            if (this.idjId == '' && this.appiId == '') {
                this.errorIdj();
                this.errorAppi();
            } else {
                this.errorDossier = 'Veuillez ne conserver qu\'un seul numéro IDJ ou APPI en cochant le dossier voulu.';
            }

            isValid = false;
        } else if (idjChecked && !IDJ_PATTERN_BPN.test(this.idjId)) {
            this.errorIdj();
            isValid = false;
        } else if (appiChecked && !APPI_PATTERN.test(this.appiId)) {
            this.errorAppi();
            isValid = false;
        }

        return isValid;
    }

    isPdf(item: Arborescence) {
        return item.format === '.pdf';
    }

    checkForm() {
        if (!this.checkBtnFormatIdentifiantDossier()) {
            return true;
        }

        return !this.checkExistPdfDocument();
    }

    mouseenterSubmit() {
        this.disabledCursor = this.checkForm();
    }

    submit() {
        if (this.disabledCursor) {
            return;
        }

        const data = {
            idj: this.idjId,
            codeAppi: this.appiId,
            idExterne: this.idExterne,
            originMessage: this.originMessage,
            codeSrj: this.user.idJuridiction,
            email: this.user.mail,
            emailBs: this.emailBs,
            files: this.nodes.filter(this.isPdf).map(SendToNppComponent.toFile)
        };

        this.ngxService.startLoader('send-to-npp');
        this.cpnMasInterfaceService.sendDemandeDocumentIntoNPP(data).subscribe(
            () => {
                this.ngxService.stopLoader('send-to-npp');
                this.activeModal.close('Close click');
                this.alertesModalService.openSuccessModal({
                    title: DEMANDE_DOCUMENT_INTO_SUCCESS_TITLE,
                    message: 'Envoi avec succès d\'une demande de dépôt de pièces jointes dans NPP.'
                });
            },
            fail => {
                this.alertesModalService.openErrorModal({
                    title: DEMANDE_DOCUMENT_INTO_ERROR_TITLE,
                    message: SendToNppComponent.toMessage(fail)
                });
                this.ngxService.stopLoader('send-to-npp');
            }
        );
    }

    private reset() {
        this.errorNpp = ' ';

        this.cleanIdj();
        this.cleanAppi();
    }

    private errorIdj() {
        $('#idj_id_input').addClass('is-invalid');
        $('#idj_id').addClass('text-danger');
    }

    private cleanIdj() {
        $('#idj_id_input').removeClass('is-invalid');
        $('#idj_id').removeClass('text-danger');
    }

    private errorAppi() {
        $('#appi_id_input').addClass('is-invalid');
        $('#appi_id').addClass('text-danger');
    }

    private cleanAppi() {
        $('#appi_id_input').removeClass('is-invalid');
        $('#appi_id').removeClass('text-danger');
    }

    private checkExistPdfDocument() {
        const hasPdfs = this.nodes.filter(this.isPdf).length > 0;
        if (!hasPdfs) {
            this.errorNpp = 'Le format du document n\'est pas supporté';
        }

        return hasPdfs;
    }
}
