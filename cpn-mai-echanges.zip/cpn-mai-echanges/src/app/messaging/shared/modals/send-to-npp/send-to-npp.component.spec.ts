import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { SendToNppComponent } from './send-to-npp.component';

describe('SendToNppComponent', () => {
    let component: SendToNppComponent;
    let fixture: ComponentFixture<SendToNppComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [SendToNppComponent]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(SendToNppComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
