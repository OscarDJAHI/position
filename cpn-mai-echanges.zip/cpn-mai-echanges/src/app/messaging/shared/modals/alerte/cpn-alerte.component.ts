import { Component, OnInit } from '@angular/core';
import { UserInfoModel } from 'src/app/core/models/user-info.model';
import { DataService } from '../../services/data.service';
import { CpnNotificationService } from '../../services/cpn-notification.service';
import { ConfigurationService } from 'src/app/core/services/configuration/configuration.service';

@Component({
    selector: 'cpn-app-alerte',
    templateUrl: './cpn-alerte.component.html',
    styleUrls: ['./cpn-alerte.component.scss'],
})
export class CpnAlerteComponent implements OnInit {

    notificationsCount: number;
    newProcedureNotificationsCount: number = 0;
    notificationsMessagesNonLus: number = 0;
    notificationsDemandeAvocats: number = 0;

    hasJdrAccess: boolean;

    userInfo: UserInfoModel;

    constructor(
        private dataService: DataService,
        private notificationService: CpnNotificationService,
        private configurationService: ConfigurationService
    ) { }

    ngOnInit() {
        this.userInfo = this.dataService.newUserInfo;
        this.updateUnreadEmailNotifications();
        this.updateNewProcedureNotifications();
        this.hasJdrAccess = this.configurationService.hasJdrAccess(this.dataService.newUserInfo.idJuridiction);
    }

    public getCEPUnreadNotifications(notifications: any): any {
        return notifications.filter(x => x.mailBoxMail.includes(
            this.configurationService.cpnConfigMap.prefixBalsCanSentViaExchange[0] ||
            this.configurationService.cpnConfigMap.prefixBalsCanSentViaExchange[1]));
    }

    private updateUnreadEmailNotifications() {
        this.notificationService.unreadEmailNotifications$.subscribe(
            notifications => {
                const unreadEmailNotifications = notifications ? notifications : [];
                this.notificationsCount = this.nbrOfUnreadMails(unreadEmailNotifications);
                this.notificationsDemandeAvocats = this.nbrOfUnreadMails(this.getCEPUnreadNotifications(unreadEmailNotifications));
                this.notificationsMessagesNonLus = this.notificationsCount - this.notificationsDemandeAvocats;
            },
            error => console.error('Sorry ! Something went wrong when trying to fetch not read emails count', error)
        );
    }

    private updateNewProcedureNotifications() {
        this.notificationService.newProcedureNotifications$.subscribe(
            res => {
                this.newProcedureNotificationsCount = res;
            },
            error => {
                this.newProcedureNotificationsCount = 0;
                console.error('Sorry ! Something went wrong when trying to fetch new procedures notifications', error);
            }
        )
    }

    private nbrOfUnreadMails(cepMails: any) {
        let cepCount = 0;
        cepMails.forEach(cepMail => cepCount += cepMail.nbNewMessage);
        return cepCount;
    }

    toggleSideBarNav() {
        this.dataService.toggleSideBar.emit(true);
    }
}
