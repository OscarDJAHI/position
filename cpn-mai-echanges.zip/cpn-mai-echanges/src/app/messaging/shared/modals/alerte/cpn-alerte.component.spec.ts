import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderModule } from 'ngx-ui-loader';
import { MaterialModule } from 'src/app/core/modules/material/material.module';
import { CpnNotificationService } from '../../services/cpn-notification.service';
import { DataService } from '../../services/data.service';

import { CpnAlerteComponent } from './cpn-alerte.component';

xdescribe('CpnAlerteComponent', () => {
    let component: CpnAlerteComponent;
    let fixture: ComponentFixture<CpnAlerteComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [CpnAlerteComponent],
            imports: [
                MaterialModule,
                NgxUiLoaderModule,
                FormsModule,
                NgbModule,
                ReactiveFormsModule,
                RouterTestingModule,
                HttpClientModule
            ],
            providers: [
                DataService,
                CpnNotificationService
            ]
        }).compileComponents();

        fixture = TestBed.createComponent(CpnAlerteComponent);
        component = fixture.componentInstance;
        // fixture.detectChanges();
    }));

    // beforeEach(() => {
    //   fixture = TestBed.createComponent(CpnAlerteComponent);
    //   component = fixture.componentInstance;
    //   fixture.detectChanges();
    // });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
