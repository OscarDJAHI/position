import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { registerLocaleData } from '@angular/common';
import localeFr from '@angular/common/locales/fr';

import { NgxUiLoaderService } from 'ngx-ui-loader';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { UserInfoModel } from '../../../../core/models/user-info.model';

import { MessageRead } from '../../../message/models/message.model';

import { DemandeAr } from '../../models/demande-ar.model';
import {
    DEMANDE_AR_ERROR_MESSAGE,
    DEMANDE_AR_ERROR_TITLE,
    DEMANDE_DOCUMENT_INTO_SUCCESS_TITLE,
    IDJ_PATTERN
} from '../../constants/constants';

import { DataService } from '../../services/data.service';
import { AlertesModalService } from '../../services/alertes-modal.service';

import { DemandeArService } from '../../services/demande-ar.service';


registerLocaleData(localeFr, 'fr');

@Component({
    selector: 'app-download-ar',
    templateUrl: './download-ar.component.html',
    styleUrls: ['./download-ar.component.scss']
})
export class DownloadArComponent implements OnInit {

    @Input() message: MessageRead;
    @Input() boxEmail: string;

    form: FormGroup;
    downloadDate: number;

    constructor(
        public activeModal: NgbActiveModal,
        private formBuilder: FormBuilder,
        private dataService: DataService,
        private demandeArService: DemandeArService,
        private alertModalService: AlertesModalService,
        private ngxUiLoaderService: NgxUiLoaderService
    ) {
    }

    ngOnInit() {
        this.downloadDate = Date.now();
        this.form = this.formBuilder.group({
            idj: new FormControl('', {
                validators: [
                    Validators.required,
                    Validators.minLength(11),
                    Validators.maxLength(11),
                    Validators.pattern(IDJ_PATTERN)
                ],
            })
        });
    }

    isInputInvalid(fieldName): boolean {
        return this.form.controls[fieldName].invalid &&
            (this.form.controls[fieldName].dirty || this.form.controls[fieldName].touched);
    }

    submitForm() {
        this.dataService.userInfo$.subscribe(data => {
            this.ngxUiLoaderService.startLoader('download-ar');

            const demandeAr = this.toDemandeAr(data as UserInfoModel);

            this.demandeArService.createRequest(demandeAr).subscribe(
                result => {
                    this.closeActiveModal();

                    if (result.id == null) {
                        this.openErrorModal();
                    } else {
                        this.alertModalService.openSuccessModal({
                            title: DEMANDE_DOCUMENT_INTO_SUCCESS_TITLE,
                            message: 'Envoi avec succès d\'une demande de dépôt de l\'AR dans NPP.'
                        });
                    }
                }, error => {
                    console.error(error);
                    this.closeActiveModal();
                    this.openErrorModal();
                });
        });
    }

    private toDemandeAr(user: UserInfoModel): DemandeAr {
        return {
            idj: this.form.get('idj').value,
            idMessage: String(this.message.id),
            codeSrj: String(user.idJuridiction),
            emailMessage: String(user.mail),
            emailBs: String(this.boxEmail) !== String(user.mail) ? this.boxEmail : null,
            originMessage: this.message.originMessage
        };
    }

    private closeActiveModal() {
        this.ngxUiLoaderService.stopLoader('download-ar');
        this.activeModal.close('Close click');
    }

    private openErrorModal() {
        this.alertModalService.openErrorModal({
            title: DEMANDE_AR_ERROR_TITLE,
            message: DEMANDE_AR_ERROR_MESSAGE
        });
    }
}
