import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbActiveModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderModule } from 'ngx-ui-loader';
import { MaterialModule } from 'src/app/core/modules/material/material.module';

import { DownloadArComponent } from './download-ar.component';

describe('DownloadArComponent', () => {
    let component: DownloadArComponent;
    let fixture: ComponentFixture<DownloadArComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [DownloadArComponent],
                imports: [
                    MaterialModule,
                    NgxUiLoaderModule,
                    FormsModule,
                    ReactiveFormsModule,
                    NgbModule
                ],
                providers: [
                    NgbActiveModal
                ]
            })
            .compileComponents();
    }));

    beforeEach(function () {
        jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(DownloadArComponent);
        component = fixture.componentInstance;
        // fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
