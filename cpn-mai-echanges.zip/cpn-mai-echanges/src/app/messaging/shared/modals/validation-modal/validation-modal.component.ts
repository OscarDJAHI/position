import { Component, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
    selector: 'app-validation-modal',
    templateUrl: './validation-modal.component.html',
    styleUrls: ['./validation-modal.component.scss']
})
export class ValidationModalComponent {

    @Input() title: string;
    @Input() message: string;

    constructor(public activeModal: NgbActiveModal) {
    }
}
