import { FormateDate } from './format-date.pipe';

describe('FormateDate', () => {

    const eltDate = new FormateDate();

    const dateFull = new Date('2021-02-02 10:21:00');

    it('transforms "02/02/2021 10:21:00" to "01/02/2021 10:21:00"', () => {
        expect(eltDate.transform('02/02/2021 10:21:00')).toEqual(dateFull);
    });

    const date = new Date('2021-02-02');
    it('transforms date without time "02/02/2021" to "2021-02-02" +GTM01', () => {
        expect(eltDate.transform('02/02/2021 01:00:00')).toEqual(date);
    });
});
