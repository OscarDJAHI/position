import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'shortenString'})
export class ShortenStringPipe implements PipeTransform {

    transform(value: string, endStringIndex?: number): string {
        if (!value) {
            return '...';
        }

        if (value.length <= endStringIndex || endStringIndex === undefined) {
            return value;
        }

        value = value.substring(0, endStringIndex);

        return value + '...';
    }
}
