import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'formateDate' })
export class FormateDate implements PipeTransform {

    transform(value: number): Date {
        return String(value).length ? new Date(value) : new Date();
    }
}
