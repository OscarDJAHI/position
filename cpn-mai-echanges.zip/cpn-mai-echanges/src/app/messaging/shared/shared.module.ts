import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { NgxUiLoaderModule } from 'ngx-ui-loader';

import { NgbModalConfig, NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { ContenteditableValueAccessorModule } from '@tinkoff/angular-contenteditable-accessor';

import { CepnUiSpinnerModule } from './components/cepn-ui-spinner/cepn-ui-spinner.module';
import { MaterialModule } from '../../core/modules/material/material.module';

import { CountNotReadMails } from './components/count-not-read-mails/count-not-read-mails.component';
import { DocExplorerComponent } from './components/doc-explorer/doc-explorer.component';
import { ArboLiPochetteComponent } from './components/doc-explorer/arbo-li-pochette/arbo-li-pochette.component';
import { ArboExplorerComponent } from './components/doc-explorer/arbo-explorer/arbo-explorer.component';
import { ArboFolderComponent } from './components/doc-explorer/arbo-folder/arbo-folder.component';
import { ArboFileComponent } from './components/doc-explorer/arbo-file/arbo-file.component';

import { DownloadArComponent } from './modals/download-ar/download-ar.component';
import { ErrorModalComponent } from './modals/error-modal/error-modal.component';
import { SuccessModalComponent } from './modals/success-modal/success-modal.component';
import { SendToNppComponent } from './modals/send-to-npp/send-to-npp.component';

import { FormateDate } from './pipes/format-date.pipe';
import { ShortenStringPipe } from './pipes/shorten-string.pipe';

import { CpnNotificationService } from './services/cpn-notification.service';
import { DataService } from './services/data.service';
import { UtilsService } from './services/utils.service';
import { DemandeArService } from './services/demande-ar.service';
import { StorageService } from './services/storage.service';
import { AttachmentService } from './services/attachment.service';
import { CpnAlerteComponent } from './modals/alerte/cpn-alerte.component';
import { RouterModule } from '@angular/router';
import { SignatureService } from '../message/services/signature.service';
import { ValidationModalComponent } from './modals/validation-modal/validation-modal.component';

@NgModule({
    declarations: [
        CountNotReadMails,
        DownloadArComponent,
        ErrorModalComponent,
        SuccessModalComponent,
        FormateDate,
        DocExplorerComponent,
        SendToNppComponent,
        ShortenStringPipe,
        ArboLiPochetteComponent,
        ArboExplorerComponent,
        ArboFolderComponent,
        ArboFileComponent,
        CpnAlerteComponent,
        ValidationModalComponent
    ],
    imports: [
        CommonModule,
        CepnUiSpinnerModule,
        ReactiveFormsModule,
        FormsModule,
        MaterialModule,
        NgxUiLoaderModule,
        NgbModule,
        ContenteditableValueAccessorModule,
        RouterModule
    ],
    exports: [
        CepnUiSpinnerModule,
        NgxUiLoaderModule,
        NgbModule,
        ContenteditableValueAccessorModule,
        CountNotReadMails,
        DownloadArComponent,
        ErrorModalComponent,
        SuccessModalComponent,
        FormateDate,
        DocExplorerComponent,
        SendToNppComponent,
        ShortenStringPipe,
        ArboLiPochetteComponent,
        ArboExplorerComponent,
        ArboFolderComponent,
        ArboFileComponent,
        CpnAlerteComponent
    ],
    entryComponents: [
        DownloadArComponent,
        ErrorModalComponent,
        SuccessModalComponent,
        CountNotReadMails,
        DocExplorerComponent,
        SendToNppComponent
    ],
    providers: [
        CpnNotificationService,
        DataService,
        UtilsService,
        NgbModalConfig,
        DemandeArService,
        StorageService,
        FormateDate,
        AttachmentService,
        SignatureService
    ]
})
export class SharedModule {
}
