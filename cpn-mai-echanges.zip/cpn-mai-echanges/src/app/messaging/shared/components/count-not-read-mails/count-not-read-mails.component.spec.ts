import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { NgbActiveModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderModule } from 'ngx-ui-loader';
import { MaterialModule } from 'src/app/core/modules/material/material.module';
import { ContactService } from '../../../contact/services/contact.service';
import { CpnNotificationService } from '../../services/cpn-notification.service';
import { DataService } from '../../services/data.service';
import { CountNotReadMails } from './count-not-read-mails.component';

describe('CountNotReadMails', () => {
    let component: CountNotReadMails;
    let fixture: ComponentFixture<CountNotReadMails>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [CountNotReadMails],
                imports: [
                    MaterialModule,
                    NgxUiLoaderModule,
                    FormsModule,
                    NgbModule,
                    ReactiveFormsModule,
                    RouterTestingModule,
                    HttpClientModule
                ],
                providers: [
                    NgbActiveModal,
                    DataService,
                    CpnNotificationService,
                    ContactService
                ]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CountNotReadMails);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
