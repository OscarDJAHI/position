import { Component, Input, OnInit } from '@angular/core';
import { CpnNotificationService } from '../../services/cpn-notification.service';
import { DataService } from '../../services/data.service';

@Component({
    selector: 'app-count-not-read-mails',
    styleUrls: ['./count-not-read-mails.component.scss'],
    template: `<span *ngIf="notReadEmailsCount" class="msg-count-notif {{ countClass }}">
					<span class="number">{{ notReadEmailsCount }}</span>
            	</span>`
})

export class CountNotReadMails implements OnInit {

    @Input() countClass = '';
    @Input() mailbox = '';

    notReadEmailsCount = 0;
    toggleMini: string;

    constructor(
        private notificationService: CpnNotificationService,
        private dataService: DataService
    ) {
    }

    ngOnInit() {
        this.notificationService.unreadEmailNotifications$.subscribe(
            notifications => {
                const unreadEmailNotifications = notifications ? notifications : [];

                if (this.mailbox === 'TOTAL_SUM') {
                    this.notReadEmailsCount = 0;
                    unreadEmailNotifications.forEach(notification => this.notReadEmailsCount += notification.nbNewMessage);
                } else {
                    const unreadEmailNotificationsByMailbox = unreadEmailNotifications.filter(notification => notification.mailBoxMail === this.mailbox);
                    this.notReadEmailsCount = unreadEmailNotificationsByMailbox.length ? unreadEmailNotificationsByMailbox[0].nbNewMessage : 0;
                }
            },
            error => console.error('Sorry ! Something went wrong when trying to fetch not read emails count', error)
        );

        this.dataService.toggleSideBar.subscribe(
            data => {
                this.toggleMini = data ? 'mini' : '';
            }
        );
    }
}
