import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { ArboLiPochetteComponent } from './arbo-li-pochette.component';
import { RouterTestingModule } from '@angular/router/testing';
import { MessagingModule } from 'src/app/messaging/messaging.module';

describe('ArboLiPochetteComponent', () => {
    let component: ArboLiPochetteComponent;
    let fixture: ComponentFixture<ArboLiPochetteComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                imports: [MessagingModule, RouterTestingModule]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ArboLiPochetteComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
