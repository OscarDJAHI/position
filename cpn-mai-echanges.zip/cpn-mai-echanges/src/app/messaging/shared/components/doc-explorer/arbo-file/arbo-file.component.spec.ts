import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { RouterTestingModule } from '@angular/router/testing';
import { MessagingModule } from 'src/app/messaging/messaging.module';
import { ArboFileComponent } from './arbo-file.component';

describe('ArboFileComponent', () => {
    let component: ArboFileComponent;
    let fixture: ComponentFixture<ArboFileComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                imports: [MessagingModule, RouterTestingModule]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ArboFileComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
