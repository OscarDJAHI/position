import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { ArboFolderComponent } from './arbo-folder.component';
import { RouterTestingModule } from '@angular/router/testing';
import { MessagingModule } from 'src/app/messaging/messaging.module';

describe('ArboFolderComponent', () => {
    let component: ArboFolderComponent;
    let fixture: ComponentFixture<ArboFolderComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                imports: [MessagingModule, RouterTestingModule]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ArboFolderComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
