import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { ArboExplorerComponent } from './arbo-explorer.component';
import { RouterTestingModule } from '@angular/router/testing';
import { Arborescence } from 'src/app/core/models/arborescence.model';
import { MessagingModule } from 'src/app/messaging/messaging.module';

const pochette: Arborescence = {
    id: 3,
    text: "Pochette",
    children: [{
        id: 5,
        text: "OSC___",
        children: [
            {
                id: 15,
                text: "fichier-1.pdf",
                children: [],
                icon: "fa-file",
                type: "file",
                parent: "5",
                level: 0,
                kind: "",
                format: "pdf"
            }
        ],
        type: "folder",
        parent: "3",
        level: 4,
        kind: "pochette",
    }],
    type: "folder",
    parent: null,
    level: 3,
    kind: "pochette",
};
const nodeSelected: Arborescence = {
    id: 5,
    text: "OSC___",
    children: [
        {
            id: 15,
            text: "fichier-1.pdf",
            children: [],
            icon: "fa-file",
            type: "file",
            parent: "5",
            level: 0,
            kind: "",
            format: "pdf"
        }
    ],
    type: "folder",
    parent: "3",
    level: 4,
    kind: "pochette",
};

describe('ArboExplorerComponent', () => {
    let component: ArboExplorerComponent;
    let fixture: ComponentFixture<ArboExplorerComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                imports: [MessagingModule, RouterTestingModule]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ArboExplorerComponent);
        component = fixture.componentInstance;
        component.node = pochette;
        component.nodeSelected = nodeSelected;

        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('When subfolder opened, close it', () => {
        const compiled = fixture.debugElement.nativeElement;
        expect(compiled.querySelector('.node-container')).not.toHaveClass('hide');

    });
});
