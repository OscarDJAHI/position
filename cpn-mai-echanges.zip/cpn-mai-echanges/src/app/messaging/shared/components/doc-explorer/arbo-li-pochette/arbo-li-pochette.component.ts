import { Component, ElementRef, EventEmitter, Input, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { Pochette } from 'src/app/core/models/pochette.model';
import { ArborescenceService } from 'src/app/core/services/arborescence/arborescence.service';
import { Arborescence } from 'src/app/core/models/arborescence.model';
import { DatePipe } from '@angular/common';
import { FileService } from 'src/app/core/services/file/file.service';
import { AuthentificationService } from 'src/app/core/services/authentification/authentification.service';
import { Subject } from 'rxjs';
import { ArboExplorerComponent } from '../arbo-explorer/arbo-explorer.component';
import { DataService } from '../../../services/data.service';

@Component({
    selector: 'app-arbo-li-pochette',
    templateUrl: './arbo-li-pochette.component.html',
    styleUrls: ['./arbo-li-pochette.component.scss'],
})
export class ArboLiPochetteComponent implements OnInit {

    @ViewChild('fileEditorContainer', {static: true}) public fileEditorContainer: ElementRef;
    @Input() public pochette: Pochette = {text: 'Sans titre', id: null, level: null};
    @Input() public currentPochette: Pochette = {text: 'Sans titre', id: null, level: null};
    @Output() nodeToggleEmitter: EventEmitter<Pochette> = new EventEmitter();
    @Output() nodeDeleteEmitter: EventEmitter<any> = new EventEmitter();
    @Output() renameFileEmitter: EventEmitter<Pochette> = new EventEmitter();
    @Output() deleteEmitter: EventEmitter<any> = new EventEmitter();
    /**
     * Liste de toutes les pochettes racines
     */
    @Input() pochettes: Pochette[];
    public currentNode: Arborescence;
    public firstLevelTargetMode: String = 'sub';
    public isShareModalOpened: boolean = false;
    public isNppModalOpened: boolean = false;
    public isCpnModalOpened: boolean = false;
    public isTrashModalOpened: boolean = false;
    public nodeToOpenRequested: any;
    public firstName: any;
    public node: any;
    public htmlIdPochette: String;
    public resultDialog: any;
    public nodesChecked: Arborescence[] = [];
    public isAllowFolderCreation: Boolean = true;
    public currentFolderOpen: Arborescence = null;
    /**
     * @var displayExplorer Mode d'affichage de l'explorer présent dans la <li>
     */
    public displayExplorer: String = 'list';
    /**
     * Noeuds a traiter
     */
    public trtNodes: Arborescence[] = [];
    public isBpn = false;
    public isCpn = false;
    public typePochette = 'pochette';
    public currentContent: Arborescence;
    /**
     * Evenement qui sera envoyé à l'enfant lors de la demande de suppression des noeuds
     */
    public deleteNodesSubject: Subject<void> = new Subject<void>();
    /**
     * Evenement qui sera envoyé à l'enfant lors de la demande de rafraichissement des noeuds
     */
    public callRefreshChildSubject: Subject<void> = new Subject<void>();
    @Input() public isPochetteOnly: boolean;
    @ViewChild(ArboExplorerComponent, {static: true}) private explorer: ArboExplorerComponent;

    constructor(
        private arborescenceService: ArborescenceService,
        public datepipe: DatePipe,
        private fileService: FileService,
        private authentificationService: AuthentificationService,
        private dataService: DataService
    ) {
    }

    ngOnInit() {
        this.currentNode = this.pochette;
        this.htmlIdPochette = this.pochette.owner === true ?
            "pochette_" + this.pochette.id :
            "pochette_" + this.pochette.id + "_shared";
        const that = this;
        this.authentificationService.getUser$().subscribe(user => {
            if (user != null && user.roles != null) {
                user.roles.forEach(role => {
                    if (role.indexOf('BPN:BPN') > -1 || role.indexOf('BPN:UTILISATEUR') > -1) {
                        that.isBpn = true;
                    }
                    if (role.indexOf('BPN:CPN') > -1) {
                        that.isCpn = true;
                    }
                });
            }
        });
    }

    ngOnChanges(changes: SimpleChanges) {
        this.currentPochette = changes.currentPochette ? changes.currentPochette.currentValue : this.currentPochette;
        if (changes.currentPochette && this.currentPochette != null && this.currentPochette.text != 'Documents partagés') {
            if (this.pochette && this.currentPochette && this.currentPochette.id == this.pochette.id) {
                this.getChildren();
            }
        }
    }

    /**
     * L'action toggle va porter les actions suivante :
     *  - Définir si le toggle est ouverte
     *  - Récupérer les enfants du noeud
     */
    public toggle(): void {
        if (this.pochette != null && this.pochette.type == 'file') {
            this.fileService.openFile(this.pochette, this.fileEditorContainer);
            return;
        }
        this.nodesChecked = [];
        this.currentPochette = !this.currentPochette ? this.pochette : null;
        this.getChildren();

        this.nodeToggleEmitter.emit(this.pochette);
    }

    checkPochette() {
        this.pochette.checked = !this.pochette.checked;
        if (this.pochette.checked) {
            this.dataService.idNodeChecked = this.pochette.id;
            this.dataService.checkedNodeEmitter.emit(false);
        } else {
            this.dataService.idNodeChecked = null;
            this.dataService.checkedNodeEmitter.emit(true);
        }
        this.uncheckAll(this.pochettes);
    }


    uncheckAll(nodes: Arborescence[]) {
        if (nodes != null) {
            nodes.forEach(node => {
                if (node.id !== this.dataService.idNodeChecked) {
                    node.checked = false;
                }
                if (node.children != null && node.children.length > 0) {
                    this.uncheckAll(node.children);
                }
            })
        }
    }

    /**
     * Récupére les informations enfants du noeud
     *  cas particuliers pour les documents partagés qui ont une arborescence non conforme
     */
    public getChildren(): void {
        this.arborescenceService.getNode(this.pochette.id).subscribe(datas => {
            if (this.isPochetteOnly) {
                this.pochette.children = datas.filter(p => p.type == 'folder');
            } else {
                this.pochette.children = datas
            }
        });
    }

    /**
     * Ajouter un noeud de la liste des noeuds cochés
     * @param node : noeud à ajouter
     */
    public addNodeChecked(node: Arborescence): void {
        if (!this.nodesChecked.filter(n => n.id === node.id)) {
            this.nodesChecked.push(node);
        }
    }

    /**
     * Supprimer un noeud de la liste des noeuds cochés
     * @param node : noeud à supprimer
     */
    public removeNodeChecked(node: Arborescence): void {
        this.nodesChecked.push(node);
        this.nodesChecked = this.nodesChecked.filter(n => n.id != node.id);
        console.log('litgl unnodesChecked:', this.nodesChecked);
    }

    public isOpened() {
        if (this.pochette && this.currentPochette && this.currentPochette.id == this.pochette.id) {
            return true;
        }
        return false;
    }

    /**
     * Met à jour le node courant de l'explorateur
     * @param node
     */
    public setCurrentNode(node: Arborescence): void {
        this.currentNode = this.firstLevelTargetMode == 'sub' ? this.pochette : node;
    }

    /**
     * Autorise la création de sous pochette si le level est inférieur a 5
     * @param node
     */
    public setNodeFolderOpen(node: Arborescence): void {
        if (node) {
            this.isAllowFolderCreation = (node.level >= 5) ? false : true;
            this.currentFolderOpen = node;
        } else {
            this.isAllowFolderCreation = true;
            this.currentFolderOpen = null;
        }
    }

    /**
     *
     * @param node Récupére le type de noeud, en se basant sur son nom..
     */
    public getCurrentNodeType(node: Arborescence): string {
        if (node.level == 2) {
            switch (node.text) {
                case 'Dossier de restauration':
                    return 'restored';
                case 'Documents partagés':
                    return 'shared';
                case 'Éditions CASSIOPÉE':
                    return 'cassiopee';
                default:
                    return node.kind;
            }
        } else {
            return node.kind;
        }
    }

    /**
     * Vérifie si la pochette doit être affichée
     * @todo devrait être traité au niveau back....
     */
    public showPochette(): boolean {
        if (this.pochette.text == 'Documents partagés') {
            return true;
        }
        return true;
    }
}
