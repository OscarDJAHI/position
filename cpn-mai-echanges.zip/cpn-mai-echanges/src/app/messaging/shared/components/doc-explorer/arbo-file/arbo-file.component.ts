import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { Arborescence } from 'src/app/core/models/arborescence.model';
import { MatDialog } from '@angular/material';
import { FileService } from 'src/app/core/services/file/file.service';
import { DataService } from '../../../services/data.service';

declare var $: any;

@Component({
    selector: 'app-arbo-file',
    templateUrl: './arbo-file.component.html',
    styleUrls: ['./arbo-file.component.scss']
})
export class ArboFileComponent implements OnInit {

    @Input() parent: Arborescence;
    @Input() node: Arborescence = {text: 'Sans titre', id: null, level: null, checked: false};
    @Input() display = 'big-icon';
    @Input() checkAllChecked = false;
    @Input() contenteditable = false;
    @Input() nodesChecked: Arborescence[];

    @Output() checkEmitter: EventEmitter<Arborescence> = new EventEmitter();
    @Output() uncheckEmitter: EventEmitter<Arborescence> = new EventEmitter();

    @Output() clickRightEmitter: EventEmitter<Arborescence> = new EventEmitter();

    constructor(
        public dialog: MatDialog,
        private dataService: DataService,
        private fileService: FileService) {
    }

    ngOnInit() {
        this.dataService.fichierMessages$.subscribe(
            data => {
                if (data.length > 0) {
                    data.find(n => n.uri === this.node.path) ? this.node.checked = true : this.node.checked = false;
                }
                data.forEach(n => {
                    if (!this.dataService.arboNodeChecked.find(r => r.path === n.uri)) {
                        this.dataService.arboNodeChecked.push({
                            id: null,
                            path: n.uri,
                            text: n.nom,
                            type: n.type,
                            format: n.type,
                            level: null
                        });
                    }
                });
            }
        );

        if (this.dataService.arboNodeChecked.length > 0) {
            this.dataService.arboNodeChecked.find(n => n.path === this.node.path) ? this.node.checked = true : this.node.checked = false;
        }
    }

    ngOnChanges(changes: SimpleChanges) {
        this.node = changes.node ? changes.node.currentValue : this.node;
    }

    openFile(content: any) {
        this.fileService.openFile(this.node, content);
    }

    check(event, node: Arborescence) {
        node.checked = !this.node.checked;

        if (node.checked) {
            this.node.checked = true;
            this.checkEmitter.emit(this.node);

            if (!this.dataService.arboNodeChecked.find(n => n.path === this.node.path)) {
                this.dataService.arboNodeChecked.push(this.node);
            }
            this.dataService.checkedFilesEmitter.emit(this.dataService.arboNodeChecked);
        } else {
            this.node.checked = false;
            this.uncheckEmitter.emit(this.node);

            const indx = this.dataService.arboNodeChecked.findIndex(n => n.path === this.node.path);
            this.dataService.arboNodeChecked.splice(indx, 1);

            this.dataService.checkedFilesEmitter.emit(this.dataService.arboNodeChecked);
        }
    }
}
