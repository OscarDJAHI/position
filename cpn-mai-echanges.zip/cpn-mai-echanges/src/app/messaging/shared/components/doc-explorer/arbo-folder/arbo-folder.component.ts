import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Arborescence } from 'src/app/core/models/arborescence.model';
import { DataService } from '../../../services/data.service';

@Component({
    selector: 'app-arbo-folder',
    templateUrl: './arbo-folder.component.html',
    styleUrls: ['./arbo-folder.component.scss']
})
export class ArboFolderComponent implements OnInit {

    @Input() node: Arborescence = {text: 'Sans titre', id: null, level: null, checked: false};
    @Input() nodes: Arborescence[];
    @Output() clickEmitter: EventEmitter<Arborescence> = new EventEmitter();
    @Output() uncheckEmitter: EventEmitter<number> = new EventEmitter();

    @Input() idx;
    @Input() isPochetteOnly: boolean;

    @Input()
    toggleChevron = [];

    constructor(private dataService: DataService) {
    }

    ngOnInit() {
        if (this.isPochetteOnly) {
            if (this.dataService.idNodeChecked != null && this.dataService.idNodeChecked === this.node.id) {
                this.node.checked = true;
            }
        }
    }

    click(idx): void {
        this.toggleChevron[idx] = !this.toggleChevron[idx];
        this.clickEmitter.emit(this.node);
    }

    check(event) {
        this.node.checked = !this.node.checked;
        if (this.node.checked) {
            this.dataService.idNodeChecked = this.node.id;
            this.dataService.checkedNodeEmitter.emit(false);
        } else {
            this.dataService.idNodeChecked = null;
            this.dataService.checkedNodeEmitter.emit(true);
        }
        this.uncheckEmitter.emit(this.node.id);
    }
}
