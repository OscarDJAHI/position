import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { Arborescence } from 'src/app/core/models/arborescence.model';
import { ArborescenceService } from 'src/app/core/services/arborescence/arborescence.service';
import { Observable, Subject, Subscription } from 'rxjs';
import { DataService } from 'src/app/messaging/shared/services/data.service';
import { AuthentificationService } from 'src/app/core/services/authentification/authentification.service';
import { NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

declare var $: any;

@Component({
    selector: 'app-arbo-explorer',
    templateUrl: './arbo-explorer.component.html',
    styleUrls: ['./arbo-explorer.component.scss']
})
export class ArboExplorerComponent implements OnInit {

    /**
     * Element de paramètrage, nombre de colonne a affiché par ligne
     */
    @Input() elementsPerRow: number = 6;

    /**
     * Noeud parent
     */
    @Input() node: Arborescence;

    /**
     * Element de paramètrage, affiche ou non l'arbre jstree
     */
    @Input() showTree: boolean = false;

    /**
     * Element de paramètrage, affiche ou non le selectionner tout
     */
    @Input() showCheckAllBtn = false;

    /**
     * Element de paramètrage, affiche ou non les checkbox des noeuds
     */
    @Input() showCheckbox;

    /**
     * Element de paramètrage, la manière dont on ouvre un dossier après l'avoir sélectionné
     */
    @Input() openTargetMode: String = 'sub';

    /**
     * Noeud que l'on souhaite ouvrir dans l'explorateur
     */
    @Input() nodeToOpenRequested: Arborescence = null;

    /**
     * Noeud courant selectionné
     */
    @Input() public nodeSelected: Arborescence;

    /**
     * Noeud parent selectionné
     */
    @Input() public parentNode: Arborescence;

    @Input() checkAllChecked = false;

    /**
     * Envoi un appel au parent pour le prévenir du souhaite de fermer l'explorateur
     */
    @Output() closeEmitter: EventEmitter<boolean> = new EventEmitter();

    /**
     * Envoi un appel au parent pour lui indiquer qu'un noeud a été selectionné
     */
    @Output() selectNodeEmitter: EventEmitter<Arborescence> = new EventEmitter();

    /**
     * Envoi les données à l'explorer parent, qu'un noeud a été selectionné
     */
    @Output() checkEmitter: EventEmitter<Arborescence> = new EventEmitter();

    /**
     * Envoi les données à l'explorer parent, qu'un noeud a été déselectionné
     */
    @Output() uncheckEmitter: EventEmitter<Arborescence> = new EventEmitter();

    /**
     * Envoi la demande de création d'un noeud de type "folder" à créer
     */
    @Output() requestCreateFolderEmitter: EventEmitter<any> = new EventEmitter();

    /**
     * Indique si l'on autorise ou non la création d'une sous pochette
     */
    @Output() nodeFolderOpenEmitter: EventEmitter<any> = new EventEmitter();

    /**
     * folder (??????)
     */
    public folder: any;

    /**
     * Noeuds cochés
     */
    public nodesChecked: Arborescence[] = [];

    /**
     * Noeuds a traiter
     */
    public trtNodes: Arborescence[] = [];

    /**
     * Sous-noeud si existant : ne devrait fonctionner que si @openTargetMode = 'sub'
     */
    public subNode: Arborescence;

    /**
     * le noeud active à griser
     */
    public activeNode: Arborescence;

    /**
     * premier noeud appelé : ne devrait fonctionner que si @openTargetMode = 'sub'
     */
    public firstLevelNode: Arborescence;

    /**
     * Liste de noeuds parents à partir d'un node
     */
    public nodesParentsFromNode: Arborescence[] = [];

    /**
     * sous-noeud de level n+1 par rapport au noeud que l'on souhaite ouvrir
     */
    public nodeSup: Arborescence;

    /**
     * Référence au modal
     */
    public modal: NgbModalRef;
    /**
     * Evenement de rafraîchissemnt de noeuds enfants lié à la subscription @callRefreshChildEventSubscription
     */
    @Input() public callRefreshChildEvent: Observable<void>;
    @Input() public isPochetteOnly: boolean;
    /**
     * Liste de toutes les pochettes
     */
    @Input() public nodes: Arborescence[];
    /**
     * Remonte les informations d'appel au refraichissement des enfants au composants enfants
     */
    public callRefreshChildSubject: Subject<void> = new Subject<void>();
    public isCpn: boolean = false;
    public isBpn: boolean = false;
    toggleChevron = [];
    nodeEmpty: boolean;
    /**
     * Souscription à un évenement envoyé par le parent pour le rafraîchissement des noeuds enfants
     */
    private callRefreshChildEventSubscription: Subscription;

    constructor(
        private arborescenceService: ArborescenceService,
        private authentificationService: AuthentificationService,
        private dataService: DataService,
    ) {
    }

    ngOnDestroy() {
        if (this.callRefreshChildEventSubscription) {
            this.callRefreshChildEventSubscription.unsubscribe();
        }
    }

    ngOnInit() {

        this.nodeEmpty = this.isEmpty();
        if (this.callRefreshChildEvent) {
            this.callRefreshChildEventSubscription = this.callRefreshChildEvent.subscribe(() => {
                this.refreshNodeChildren();
            });
        }

        //@TODO : le jstree est affiché seulement au 1er niveau, sinon jstree sur tous les niveaux
        this.showTree = this.showTree && this.node.level < 4;
        this.nodeSelected = this.node;

        const that = this;
        this.authentificationService.getUser$().subscribe(user => {
            if (user != null && user.roles != null) {
                user.roles.forEach(role => {
                    if (role.indexOf('BPN:BPN') > -1 || role.indexOf('BPN:UTILISATEUR') > -1) {
                        that.isBpn = true;
                    }
                    if (role.indexOf('BPN:CPN') > -1) {
                        that.isCpn = true;
                    }
                });
            }
        });

        this.dataService.isCpnProfile$.subscribe(data => {
            this.isCpn = data;
        });

        this.dataService.isBpnProfile$.subscribe(data => {
            this.isBpn = data;
        });
    }

    ngOnChanges(changes: SimpleChanges) {
        this.node = changes.node ? changes.node.currentValue : this.node;
    }

    /**
     * Permet d'ouvrir (ou de fermer) le conteneur contenant la liste des sous fichiers :
     *  - Enregistre le noeud selectionné
     *  - Récupère la liste des enfants du noeud
     *  - Déplace le block 'liste des fichiers/dossiers' en dessous du noeud
     *
     * @param node
     */
    public openFolderFiles(node: Arborescence, idx): void {

        this.node.children.forEach((n, i) => {
            if (idx !== i) {
                this.toggleChevron[i] = false;
                this.node.checked = false;
            }
        })

        /**
         * Si le @node est déjà ouvert, on le ferme
         */
        if (this.nodeSelected === node) {
            this.nodeFolderOpenEmitter.emit(this.parentNode)
            this.closeFilesListOfSubFolder(true);
        } else if (this.nodeSelected && this.nodeSelected.parent && this.subNode == node) {
            this.closeFilesListOfSubFolder(true);
            this.nodeFolderOpenEmitter.emit(this.parentNode)
        }

        /**
         * Si le @node qu'on souhaite ouvrir n'est pas le même que celui déjà ouvert,
         *  on ouvre un explorer correspondant (dans l'explorateur courant OU imbriqué)
         */
        else {
            /**
             * La position du sub-explorer sera placé diffément selon le type d'affichage
             */
            let pos: String = 'after-node';
            this.nodeFolderOpenEmitter.emit(node);
            this.nodesChecked = [];
            this.nodeSelected = node;
            this.refreshWithNodeChildren(node);
            this.moveNodeChildrenBlock(pos);
        }
        this.selectNodeEmitter.emit(node);
        this.activeNode = node;
    }

    public refreshNodeChildren(): void {
        this.arborescenceService.getChildren(this.node).subscribe(child => {
            this.node.children = child;
            this.openFolderFiles(this.firstLevelNode, null);
        })
    }

    /**
     * Permet de fermer le conteneur contenant la liste des sous fichiers
     *
     * @param closeRequested
     */
    public closeFilesListOfSubFolder(closeRequested: boolean): void {
        if (closeRequested) {
            this.nodeSelected = this.node;
            this.subNode = null;
            this.firstLevelNode = null;
            this.nodesChecked = [];
        }
    }

    /**
     * On appel l'API pour rafraîchir la liste des childrens du noeud
     *  passé en paramètre
     *
     * @param node
     */
    public refreshWithNodeChildren(node: Arborescence): void {
        this.arborescenceService.getChildren(node).subscribe(data => {
            let d = data;
            if (this.isPochetteOnly) {
                d = data.filter(p => p.type == 'folder');
            }
            if (this.openTargetMode == 'inner') {
                this.node.children = d;
            } else {
                this.setfirstLevelNode(this.nodeSelected);
                this.setSubNode(this.nodeSelected ? this.nodeSelected : this.node, d);
            }
        });
    }

    /**
     * Déplace le block sub-explorer-container à l'endroit défini @pos
     *
     * @param node
     * @param pos : after-last-col-of-row, after-node
     */
    public moveNodeChildrenBlock(pos: String = 'after-last-col-of-row'): void {
        /**
         * Correspond à l'id DOM du sub-explorer
         *  (chaque node explorer à le sien, et est basé sur l'id)
         */
        let idSource: String = '#sub-explorer-container_' + this.node.id;

        switch (pos) {
            /**
             * On souhaite le déplacer à la dernière colonne de la ligne
             *  où se trouve le node selectionné
             */
            case 'after-last-col-of-row': {
                let idCurrentNode: String = '#node-wrapper_' + this.node.id;
                let indexCurrentNode: number = $(idCurrentNode).index();
                let indexOfLastColumnOfCurrentNodeRow: number = this.getLastColumn(indexCurrentNode, this.elementsPerRow, this.node.children.length);
                let idDestination = $(idCurrentNode).parent().find('li').eq(indexOfLastColumnOfCurrentNodeRow);

                $(idSource).insertAfter(idDestination);
                break;
            }

            /**
             * On souhaite le déplacer après le node sélectionné
             */
            case 'after-node': {
                let idDestination: String = '#node-wrapper_' + this.nodeSelected.id;
                $(idSource).insertAfter(idDestination);
                break;
            }
        }
    }

    /**
     * Calcule la position du dernier élément d'une colonne dans
     *  un tableau en 3 dimension
     *
     * @param currentPos
     * @param elementsPerRow
     * @param maxElements
     * @author yannick.roussel
     */
    public getLastColumn(
        currentPos: number,
        elementsPerRow: number,
        maxElements: number): number {
        elementsPerRow = elementsPerRow - 1;
        let position: number = Math.floor(currentPos / elementsPerRow);

        position += 1;
        position *= elementsPerRow;
        position = position >= maxElements ? maxElements : position;

        return position;
    }

    public setSubNode(node: Arborescence, children: Arborescence[]): ArboExplorerComponent {
        if (this.openTargetMode == 'sub') {
            this.subNode = node;
            this.subNode.children = children;
        }
        return this;
    }

    public setfirstLevelNode(node: Arborescence): ArboExplorerComponent {
        if (this.openTargetMode == 'sub') {
            this.firstLevelNode = node;
        }
        return this;
    }

    /**
     * Ajouter un noeud de la liste des noeuds cochés
     * @param node : noeud à ajouter
     */
    public addNodeChecked(node: Arborescence): void {
        this.nodesChecked.push(node);
        this.checkEmitter.emit(node);
    }

    /**
     * Supprimer un noeud de la liste des noeuds cochés
     * @param node : noeud à supprimer
     */
    public removeNodeChecked(node: Arborescence): void {
        this.nodesChecked.push(node);
        this.nodesChecked = this.nodesChecked.filter(n => n.id != node.id);
        this.uncheckEmitter.emit(node);
    }

    /**
     * Action d'ouverture d'un fichier
     */
    public openNode(e: any): void {
        e.item.openFile()
    }

    /**
     * Ajoute un enfant au noeud de l'explorateur courant
     *
     * @param node
     */
    public addChildren(nodes: Arborescence[]): void {
        this.node.children = nodes;
    }

    isEmpty() {
        if (this.isPochetteOnly && this.node.children.length > 0) {
            this.node.children.forEach(n => {

            });
            return true;
        }

        return this.node.children.length > 0;
    }

    uncheckAll(nodes: Arborescence[]) {
        if (nodes != null) {
            nodes.forEach(node => {
                if (node.id !== this.dataService.idNodeChecked) {
                    node.checked = false;
                }
                if (node.children != null && node.children.length > 0) {
                    this.uncheckAll(node.children);
                }
            })
        }
    }

}
