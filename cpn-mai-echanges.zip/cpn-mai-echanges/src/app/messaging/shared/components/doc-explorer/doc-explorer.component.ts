import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import * as _ from 'lodash';

import { Arborescence } from 'src/app/core/models/arborescence.model';
import { Pochette } from 'src/app/core/models/pochette.model';
import { MessageService } from 'src/app/core/services/message/message.service';
import { PochetteService } from 'src/app/core/services/pochette/pochette.service';

import { DataService } from '../../services/data.service';

export interface ModalUserDoc {
    label: string;
    value: string;
    checked: boolean;
}

export interface FichierMessages {
    idSps: string;
    uri: string;
    nom: string;
    type: string;
    size?: number;
    source?: string;
}

@Component({
    selector: 'app-doc-explorer',
    templateUrl: './doc-explorer.component.html',
    styleUrls: ['./doc-explorer.component.scss']
})
export class DocExplorerComponent implements OnInit, OnDestroy {

    userDocsForm: FormGroup;

    @Input()
    userDocsFromDB: Arborescence[];

    @Input()
    userDocsSelected: FichierMessages[];

    modalUserDocList: ModalUserDoc[];

    @Input()
    pochettes: Pochette[];

    @Input()
    currentPochette: Pochette;

    @Input()
    node: Arborescence;

    @Input()
    isPochetteOnly: boolean;

    @Input()
    componentTitle: string;

    @Input()
    validateBtnLabel: string;

    disableSendButton = true;

    @Output() checkEmitter: EventEmitter<Arborescence> = new EventEmitter();

    pochetteLoader = false;

    constructor(
        private dataService: DataService,
        public activeModal: NgbActiveModal,
        private pochetteService: PochetteService,
        private messageService: MessageService
    ) {
    }

    ngOnInit() {

        if (!this.isPochetteOnly) {
            this.userDocsFromDB.forEach(elt => {
                const chk = this.userDocsSelected.find(el => el.nom.toLowerCase() === elt.text.toLowerCase()) ? true : false;
                this.modalUserDocList.push({label: elt.text, value: elt.text, checked: chk});
            });
        }

        this.load();

        if (!this.isPochetteOnly) {
            this.dataService.checkedFilesEmitter.subscribe(r => {
                this.disableSendButton = r.length <= 0;
            });

            this.dataService.fichierMessages.subscribe(r => {
                this.disableSendButton = r.length <= 0;
            });
        } else {
            this.dataService.checkedNodeEmitter.subscribe(r => {
                this.disableSendButton = r;
            });
        }
    }

    /**
     * Récupère les informations de l'arborescence "pochette" (niveau2) l'utilisateur courant
     *  puis récupère les pochettes contenus dans cette arborescence.
     */
    public load(): void {
        this.pochetteLoader = true;

        // On récupère dans un premier les informations du noeud pochette de niveau 2
        this.pochetteService.getUserRootNode('pochettes').subscribe(node => {
            // on affecte les informations récupéré à l'attribut this.node
            this.node = node;

            // puis on récupére et charge les pochettes
            this.pochetteService.getNode().subscribe(data => {
                this.pochetteLoader = false;
                this.pochettes = data;
            });
        });

        this.messageService.getPochettes().subscribe(data => {
            this.pochetteLoader = false;
            this.pochettes = data;
        });
    }

    submitForm() {
        if (!this.isPochetteOnly) {
            const docSelected = [];
            this.dataService.arboNodeChecked.forEach(n => {
                docSelected.push({
                    idSps: n.path,
                    uri: n.id,
                    nom: n.text,
                    type: n.format,
                    size: 0,
                    source: 'BPN'
                });
            });

            if (this.dataService.messageAttachment.length > 0) {
                this.dataService.updateUserDocs(this.dataService.messageAttachment.concat(_.differenceBy(docSelected, this.dataService.messageAttachment, 'nom')));
            } else {
                this.dataService.updateUserDocs(docSelected);
            }
        }
    }

    ngOnDestroy() {
        this.dataService.arboNodeChecked = [];
    }
}
