import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CepnUiSpinnerComponent } from './cepn-ui-spinner.component';

@NgModule({
    declarations: [CepnUiSpinnerComponent],
    exports: [
        CepnUiSpinnerComponent
    ],
    imports: [
        CommonModule
    ],

})
export class CepnUiSpinnerModule {
}
