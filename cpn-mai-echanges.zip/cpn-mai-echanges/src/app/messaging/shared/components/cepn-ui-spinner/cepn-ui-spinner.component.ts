import { Component, HostListener, OnInit } from '@angular/core';

@Component({
    selector: 'app-cepn-ui-spinner',
    templateUrl: './cepn-ui-spinner.component.html',
    styleUrls: ['./cepn-ui-spinner.component.scss']
})
export class CepnUiSpinnerComponent implements OnInit {

    constructor() {
    }

    ngOnInit() {
        this.computeCenteredPosition();
    }

    @HostListener('window:resize', ['$event'])
    onResize(event: any) {
        this.computeCenteredPosition();
    }

    computeCenteredPosition() {
        let cepnUiSpinnerWrapper: HTMLElement = document.querySelector('.cpn-loader');
        let cepnUiSpinner: HTMLElement = document.querySelector('.icon-wrapper');
        let browserHeight = window.innerHeight;
        let pageHeight = window.document.documentElement.scrollHeight;

        cepnUiSpinnerWrapper.style.bottom = `${ browserHeight - pageHeight }px`;
        cepnUiSpinner.style.top = `${ (browserHeight - Number(cepnUiSpinner.offsetHeight)) / 2 }px`;
    }

}
