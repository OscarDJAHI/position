import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { CepnUiSpinnerComponent } from './cepn-ui-spinner.component';

describe('CepnUiSpinnerComponent', () => {
    let component: CepnUiSpinnerComponent;
    let fixture: ComponentFixture<CepnUiSpinnerComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [CepnUiSpinnerComponent]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CepnUiSpinnerComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
