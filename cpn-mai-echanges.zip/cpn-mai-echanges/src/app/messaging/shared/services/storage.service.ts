import { Injectable } from '@angular/core';

import { DataService } from './data.service';

@Injectable()
export class StorageService {

    constructor(
        private dataService: DataService
    ) {
    }

    storeMailBox(mail: string) {
        localStorage.setItem('mail_box', mail);
    }

    storeNewMailObject(data: string) {
        localStorage.setItem('mail_object', JSON.stringify(data));
    }

    restoreWindow() {
        if (localStorage.getItem('mail_object') !== null) {
            this.dataService.openTinyWindowRequest.emit(true);
        }
    }

    destroyStoredMailObject() {
        if (localStorage.getItem('mail_object') !== null) {
            this.dataService.multipartFileUpload = [];
            localStorage.removeItem('mail_object');
        }
    }
}
