import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';

import { DemandeAr } from '../models/demande-ar.model';

import { DemandeArBpn } from '../../message/models/demande-ar-bpn.model';
import { DocumentModel } from '../../../core/models/document.model';

@Injectable()
export class DemandeArService {

    constructor(private http: HttpClient) {
    }

    createRequest(demandeAr: DemandeAr) {
        return this.http.post<DemandeAr>(environment.REST_URL_POST_DEMANDE_AR, demandeAr);
    }

    saveAr(id: number): Observable<any> {
        return this.http.post(environment.REST_URL_POST_SAVE_AR + '/' + id, null, {
            responseType: 'blob',
            observe: 'response'
        });
    }

    sendArIntoBPN(data: DemandeArBpn): Observable<any> {
        return this.http.post(environment.REST_URL_POST_SEND_AR_INTO_BPN, data);
    }
}
