import { EventEmitter, Injectable } from '@angular/core';

import { BehaviorSubject } from 'rxjs';

import { Arborescence } from 'src/app/core/models/arborescence.model';
import { UserInfoModel } from 'src/app/core/models/user-info.model';
import { Procedure, ServiceMJ } from 'src/app/procedures/journal/models/journal.model';
import { MessageAttachment } from '../../message/models/message-attachment.model';
import { MessageListWrapper } from '../../message/models/message-list-wrapper.model';
import { MessageReadWrapper } from '../../message/models/message-read-wrapper.model';
import { CpnMasEchangeService } from '../../message/services/cpn-mas-echange.service';

export interface CepMailModel {
    name: string;
    email: string;
    userId: string;
    id: string;
    defaultBox?: boolean;
    nominative?: boolean;
}

interface FichierMessages {
    id?: number;
    idSps: string;
    uri: string;
    nom: string;
    text?: string;
    type: string;
    level?: number;
    source?: string;
}

@Injectable()
export class DataService {

    // Broadcast user docs in file explorer to all components
    fichierMessages = new BehaviorSubject<FichierMessages[]>([]);
    fichierMessages$ = this.fichierMessages.asObservable();

    // Broadcast user structural mail box to all components
    userCepMails = new BehaviorSubject<CepMailModel[]>(null);
    userCepMails$ = this.userCepMails.asObservable();

    // use to share the state of the user profile in all modules
    isCpnProfile = new BehaviorSubject<boolean>(false);
    isCpnProfile$ = this.isCpnProfile.asObservable();

    // use to share the state of the user profile in all modules
    isBpnProfile = new BehaviorSubject<boolean>(false);
    isBpnProfile$ = this.isBpnProfile.asObservable();

    isSpsProfile = new BehaviorSubject<boolean>(false);
    isSpsProfile$ = this.isSpsProfile.asObservable();
    // use to share connected user info
    userInfo = new BehaviorSubject<any>('');
    userInfo$ = this.userInfo.asObservable();

    newUserInfo: UserInfoModel;
    currentBoxEmail: string;
    isCpnLoaded: boolean;

    // use to emit true when the cpn module is loaded and false when it destroy
    cpnSpsLoadEmitter: EventEmitter<string> = new EventEmitter();

    // use to emit true when the write new mail modal component is destroy
    openTinyWindowRequest: EventEmitter<boolean> = new EventEmitter();

    multipartFileUpload: File[] = [];
    messageAttachment: MessageAttachment[] = [];

    arboNodeChecked: Arborescence[] = [];
    checkedFilesEmitter: EventEmitter<Arborescence[]> = new EventEmitter();
    checkedNodeEmitter: EventEmitter<boolean> = new EventEmitter();

    listMessagesEmitter: EventEmitter<MessageListWrapper> = new EventEmitter();
    updatedMessageEmitter: EventEmitter<MessageReadWrapper> = new EventEmitter();
    idNodeChecked: any;

    isScroll = false;

    toggleSideBar: EventEmitter<boolean> = new EventEmitter();
    hideSideBar: EventEmitter<boolean> = new EventEmitter();

    procedureList = new BehaviorSubject<Procedure[]>([]);
    procedureList$ = this.procedureList.asObservable();

    procedure = new BehaviorSubject<any>('');
    procedure$ = this.procedure.asObservable();

    listServiceMJ: ServiceMJ[] = [];

    constructor(
        private cpnMasEchangeService: CpnMasEchangeService
    ) { }

    updateUserDocs(docs: FichierMessages[]) {
        this.fichierMessages.next(docs);
    }

    updateUserCepMails(mails: CepMailModel[]) {
        this.userCepMails.next(mails);
    }

    updateCpnProfileState(b: boolean) {
        this.isCpnProfile.next(b);
    }


    // Gestion du profil SPS
    updateSpsProfileState(b: boolean) {
        this.isSpsProfile.next(b);
    }

    updateBpnProfileState(b: boolean) {
        this.isBpnProfile.next(b);
    }

    updateUserInfoState(user: UserInfoModel) {
        this.userInfo.next(user);
    }

    getCpnConfig$() {
        return this.cpnMasEchangeService.getCpnConfig();
    }
}
