import { Injectable } from '@angular/core';

@Injectable()
export class UtilsService {

    constructor() {
    }

    static toMessage(fail: any) {
        if (typeof (fail.error) === 'object') {
            return fail.error.hasOwnProperty('response') ? fail.error.response : fail.message;
        }

        return fail.error;
    }

    formatageRecipient(r: any[]) {
        return r !== null ? r.join(';') : '(vide)';
    }

    formatageRecipientsObject(r: any) {
        const emails = [];
        let val = '(vide)';
        if (r !== null) {
            r.forEach(recipient => {
                emails.push(recipient.email);
            });

            val = emails.join(', ');
        }

        return val;
    }

    userInitial(value: any) {
        let username = '';

        if (value != null && value.length !== 0 && typeof value === 'object') {
            username = value[0].split('.')[0].charAt(0).toUpperCase() + value[0].split('.')[1].charAt(0).toUpperCase();
        }

        if (value != null && value.length !== 0 && typeof value === 'string') {
            username = value.split('.')[0].charAt(0).toUpperCase() + value.split('.')[1].charAt(0).toUpperCase();
        }

        return username;
    }

    formatDate(value: string): Date {
        return value.length > 0 ? new Date(value) : new Date();
    }

    parseBoolean(value: string): boolean {
        return value ? Boolean(JSON.parse(value)) : false;
    }

    isNotValidExtension(fileCheckedList: any[], extValid: string[]): boolean {
        let isNotValidExtension = false;
        if (fileCheckedList.length === 0) {
            isNotValidExtension = true;
        }
        fileCheckedList.forEach(f => {
            const array = f.name.split('.');
            const extension: string = array[array.length - 1];
            const ext = extension.toLowerCase();
            if (!extValid.includes(ext)) {
                isNotValidExtension = true;
            }
        });
        return isNotValidExtension;
    }
}
