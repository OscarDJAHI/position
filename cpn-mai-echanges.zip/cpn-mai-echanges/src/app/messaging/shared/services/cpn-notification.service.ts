import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';

import { BehaviorSubject, Subscription } from 'rxjs';
import { concatMap } from 'rxjs/operators';

import { environment } from '../../../../environments/environment';

import { BoiteStructurelle } from '../../mailbox/components/delete/mailbox-delete.component';

import { Message } from '../../message/models/message.model';
import { NotificationContent } from '../models/notification-content.model';
import { DataService } from './data.service';
import { ActionType } from '../../../core/models/enums/action-type.enum';

@Injectable()
export class CpnNotificationService {

    private unreadEmailNotifications = new BehaviorSubject<NotificationContent[]>(null);
    unreadEmailNotifications$ = this.unreadEmailNotifications.asObservable();
    private newProcedureNotifications = new BehaviorSubject<number>(null);
    newProcedureNotifications$ = this.newProcedureNotifications.asObservable();

    private updateUnreadEmailSubscription: Subscription;
    private updateProcedureSubscription: Subscription;

    constructor(private http: HttpClient, private dataService: DataService) {
    }

    updateNotificationsAfterMessageRead(message: Message, typeAction: string) {
        const currentUnreadEmailNotifications = this.unreadEmailNotifications.getValue() || [];

        currentUnreadEmailNotifications.forEach(notification => {
            if (typeAction === ActionType.SUPPRIME) {
                if (notification.mailBoxMail === message.emailBoite && !message.deleted && message.viewed === 0) {
                    --notification.nbNewMessage;
                }
            } else if (typeAction === ActionType.RESTAURE) {
                if (notification.mailBoxMail === message.emailBoite && message.deleted && message.viewed === 0) {
                    ++notification.nbNewMessage;
                }
            } else {
                if (notification.mailBoxMail === message.emailBoite) {
                    --notification.nbNewMessage;
                }
            }
        });

        this.unreadEmailNotifications.next(currentUnreadEmailNotifications);
    }

    updateNotificationsAfterMailboxRemove(mailbox: BoiteStructurelle) {
        const currentUnreadEmailNotifications = this.unreadEmailNotifications.getValue() || [];
        this.unreadEmailNotifications.next(currentUnreadEmailNotifications.filter(notification => notification.mailBoxMail !== mailbox.email));
    }

    updateUnreadEmailNotifications() {
        if (this.updateUnreadEmailSubscription !== undefined) {
            this.updateUnreadEmailSubscription.unsubscribe();
        }
        this.updateUnreadEmailSubscription = this.dataService.userCepMails$
            .pipe(
                concatMap(mailboxes => {
                    return this.http.get<NotificationContent[]>(environment.REST_URL_CPN_NOTIFICATION,
                        {
                            params: new HttpParams().append('mailBoxMail', mailboxes.map(m => m.email).join())
                        });
                })
            )
            .subscribe(
                notifications => {
                    this.unreadEmailNotifications.next(notifications);
                },
                error => {
                    console.error('Sorry ! Something went wrong when trying to fetch unread Emails notifications', error);
                    this.unreadEmailNotifications.error(error);
                },
                () => this.unreadEmailNotifications.complete()
            );
    }

    updateNewProcedureNotifications() {
        if (this.updateProcedureSubscription !== undefined) {
            this.updateProcedureSubscription.unsubscribe();
        }
        this.updateProcedureSubscription = this.dataService.userCepMails$
            .pipe(
                concatMap(() => {
                    return this.http.get<number>(environment.REST_URL_CPN_PROCEDURE_NOTIFICATION);
                })
            )
            .subscribe(
                newProcedures => {
                    this.newProcedureNotifications.next(newProcedures);
                },
                error => {
                    console.error('Sorry ! Something went wrong when trying to fetch new procedures notifications', error);
                    this.newProcedureNotifications.error(error);
                },
                () => this.newProcedureNotifications.complete()
            );
    }
}
