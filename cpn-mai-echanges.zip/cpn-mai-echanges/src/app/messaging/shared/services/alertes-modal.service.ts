import { Injectable } from '@angular/core';

import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

import { ErrorModalComponent } from '../modals/error-modal/error-modal.component';
import { SuccessModalComponent } from '../modals/success-modal/success-modal.component';
import { AlertModalContent } from '../models/alerte-modal-content.model';
import { GENERIC_ERROR_MESSAGE, GENERIC_ERROR_TITLE } from '../constants/constants';
import { ValidationModalComponent } from '../modals/validation-modal/validation-modal.component';

@Injectable({
    providedIn: 'root'
})
export class AlertesModalService {

    constructor(private modalService: NgbModal) {
    }

    openGenericErrorModal() {
        this.openErrorModal({title: GENERIC_ERROR_TITLE, message: GENERIC_ERROR_MESSAGE});
    }

    openGenericValidationModal() {
        this.openErrorModal({title: GENERIC_ERROR_TITLE, message: GENERIC_ERROR_MESSAGE});
    }

    openErrorModal(object: AlertModalContent) {
        const options = {centered: true, windowClass: 'cpn-error-modal', size: 'none'};
        const modal = this.modalService.open(ErrorModalComponent, options);
        modal.componentInstance.title = object.title;
        modal.componentInstance.message = object.message;
    }

    openSuccessModal(object: AlertModalContent) {
        const options = {centered: true, windowClass: 'cpn-succes-modal', size: 'none'};
        const modal = this.modalService.open(SuccessModalComponent, options);
        modal.componentInstance.title = object.title;
        modal.componentInstance.message = object.message;
    }

    openValidationModal(object: AlertModalContent): NgbModalRef {
        const options = {centered: true, windowClass: 'cpn-succes-modal', size: 'none'};
        const modal = this.modalService.open(ValidationModalComponent, options);
        modal.componentInstance.title = object.title;
        modal.componentInstance.message = object.message;

        return modal;
    }
}
