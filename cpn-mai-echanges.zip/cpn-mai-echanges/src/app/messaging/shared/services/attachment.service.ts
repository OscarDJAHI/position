import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';

@Injectable()
export class AttachmentService {

    constructor(private http: HttpClient, private sanitizer: DomSanitizer) {
    }

    downloadFile(originMsg: any, mailBS: string, name: string, url: any): Observable<any> {
        return this.http.get(environment.REST_URL_GET_TELECHARGEMENT_PJ, {
            params: {
                originMessage: originMsg.toString(),
                mailBS,
                name,
                url
            },
            responseType: 'blob'
        });
    }

    downloadZipFile(originMsg: any, mailBS: string, subject: string, urls: string[]): Observable<any> {
        return this.http.get(environment.REST_URL_GET_TELECHARGEMENT_ZIP,
            {
                params: {
                    originMessage: originMsg.toString(),
                    mailBS,
                    subject,
                    urls: urls.map(u => encodeURIComponent(u)).join()
                },
                responseType: 'blob'
            });
    }

    downloadPj(messageId: number, name: string, attachments: string[]): Observable<any> {
        return this.http.get(environment.REST_URL_GET_TELECHARGEMENT_PJ_EXCHANGE,
            {
                params: {
                    messageId: messageId.toString(),
                    name,
                    attachments: attachments.map(a => encodeURIComponent(a)).join()
                },
                responseType: 'blob'
            });
    }

    getPreviewPjUrl(originMsg: any, mailBS: string, name: string, durl: any, messageId: number) {
        return this.sanitizer.bypassSecurityTrustResourceUrl(
            environment.REST_URL_GET_PREVIEW_PJ
            + '?originMessage=' + originMsg
            + '&mailBs=' + mailBS
            + '&fileName=' + name
            + '&url=' + durl
            + '&messageId=' + messageId
        );
    }
}
