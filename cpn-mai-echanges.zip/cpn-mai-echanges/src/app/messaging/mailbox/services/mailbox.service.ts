import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { CepMailModel, DataService } from '../../shared/services/data.service';

@Injectable()
export class MailboxService {

    constructor(
        private http: HttpClient,
        private dataService: DataService
    ) { }

    all(): Observable<CepMailModel[]> {
        return this.http.get<CepMailModel[]>(environment.REST_URL_MAILBOX);
    }

    checkMailboxAuthorization(emails: any): Observable<any> {
        return this.http.get(environment.REST_URL_CHECK_BOITE_STRUCTURELLE, { params: { mailBoxesMail: emails } });
    }

    checkMailboxByEmail(email: any): Observable<any> {
        return this.http.get(environment.REST_URL_CHECK_MAIL_BOITE_STRUCTURELLE, { params: { mailBoxMail: email } });
    }

    checkMailboxByName(name: any): Observable<any> {
        return this.http.get(environment.REST_URL_CHECK_NOM_BOITE_STRUCTURELLE, { params: { mailBoxName: name } });
    }

    deleteById(id: any): Observable<any> {
        return this.http.delete(environment.REST_URL_MAILBOX, { params: { id } });
    }

    inscription(boite: any): Observable<any> {
        return this.http.post<any>(environment.REST_URL_MAILBOX, boite);
    }

    updateCepList() {
        this.all().subscribe(
            data => {
                this.dataService.updateUserCepMails(data);
            }
        )
    }

    updateMailBoxes(mailBoxes: CepMailModel[]): Observable<CepMailModel[]> {
        return this.http.put<CepMailModel[]>(environment.REST_URL_UPDATE_BOITES_STRUCTURELLES, mailBoxes);
    }

    updateMailBox(mailBox: CepMailModel): Observable<CepMailModel> {
        return this.http.put<CepMailModel>(environment.REST_URL_MAILBOX, mailBox);
    }
}
