import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';

import { NgxUiLoaderModule } from 'ngx-ui-loader';

import { SharedModule } from '../shared/shared.module';
import { MailboxAddComponent } from './components/add/mailbox-add.component';
import { MailboxDeleteComponent } from './components/delete/mailbox-delete.component';
import { MailboxService } from './services/mailbox.service';
import { MailboxManageDefaultComponent } from './components/manage-default/mailbox-manage-default.component';

@NgModule({
    declarations: [
        MailboxAddComponent,
        MailboxDeleteComponent,
        MailboxManageDefaultComponent
    ],
    imports: [
        SharedModule,
        CommonModule,
        ReactiveFormsModule,
        NgxUiLoaderModule,
    ],
    exports: [
        MailboxAddComponent,
        MailboxDeleteComponent,
        MailboxManageDefaultComponent
    ],
    providers: [
        MailboxService
    ],
    entryComponents: [
        MailboxAddComponent,
        MailboxDeleteComponent,
        MailboxManageDefaultComponent
    ]
})
export class MailboxModule {
}
