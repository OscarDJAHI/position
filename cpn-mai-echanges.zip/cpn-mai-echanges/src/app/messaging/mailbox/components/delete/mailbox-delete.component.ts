import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

import { map } from 'rxjs/operators';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderService } from 'ngx-ui-loader';

import { AuthentificationService } from 'src/app/core/services/authentification/authentification.service';
import { UserInfoModel } from 'src/app/core/models/user-info.model';
import { MailboxService } from 'src/app/messaging/mailbox/services/mailbox.service';
import { CepMailModel, DataService } from 'src/app/messaging/shared/services/data.service';
import { CpnNotificationService } from '../../../shared/services/cpn-notification.service';
import { UtilisateurService } from 'src/app/core/services/utilisateur/utilisateur.service';

export interface User {
    id: String;
    email: String;
}

export interface BoiteStructurelle {
    id: String;
    name: String;
    email: String;
    userId: String;
}

@Component({
    selector: 'app-mailbox-delete',
    templateUrl: './mailbox-delete.component.html',
    styleUrls: ['./mailbox-delete.component.scss']
})
export class MailboxDeleteComponent implements OnInit {

    userInfo: UserInfoModel;
    form: FormGroup;
    boiteStructurelle: BoiteStructurelle;
    boiteStructurelleList: BoiteStructurelle[];

    stepOne = true;
    stepTwo = false;
    stepThree = false;

    emailEmpty = false;
    invalidForm = true;

    constructor(
        public activeModal: NgbActiveModal,
        private authentificationService: AuthentificationService,
        private boiteStructurelleService: MailboxService,
        private ngxService: NgxUiLoaderService,
        private dataService: DataService,
        private notificationService: CpnNotificationService,
        private userService: UtilisateurService
    ) {
    }

    ngOnInit() {
        // Get User Authenticate
        this.authentificationService.getUser$().subscribe(data => {
            this.userInfo = data as UserInfoModel;
        })

        this.form = new FormGroup({
            id: new FormControl(''),
            boxName: new FormControl(''),
            email: new FormControl(''),
        });

        this.boiteStructurelle = { id: '', name: '', email: '', userId: '' };

        this.getBoiteStructurelleList();
    }

    getBoiteStructurelleList() {
        this.dataService.userCepMails$.pipe(
            map((data: CepMailModel[]) => {
                if (data) { return data.filter(el => !el.nominative); }
                return data
            })
        ).subscribe(
            data => {
                this.boiteStructurelleList = data;
            },
            error => {
                console.error('mailBoxList error :', error);
            }
        );
    }

    setBoiteStructurelleName() {
        this.boiteStructurelle = this.boiteStructurelleList.find(r => r.email === this.form.get('email').value);
        this.form.patchValue({ boxName: this.boiteStructurelle.name });
        this.form.patchValue({ id: this.boiteStructurelle.id });

        this.emailEmpty = false;
        this.invalidForm = false;
    }

    deleteConfirmation() {
        if (this.form.get('email').value.length === 0) {
            this.emailEmpty = true;
            this.invalidForm = true;
        } else {
            this.invalidForm = false;
            this.stepOne = false;
            this.stepTwo = true;
        }
    }

    deleteBoiteStructurelle() {
        if (this.form.get('email').value.length === 0) {
            this.emailEmpty = true;
            this.invalidForm = true;
        } else {
            this.emailEmpty = false;
            this.invalidForm = false;
            this.ngxService.startLoader('loader-delete-boite-structurelle');
            const email = String(this.boiteStructurelle.email);
            this.boiteStructurelleService.deleteById(this.boiteStructurelle.id).subscribe(
                () => {
                    this.updateDefaultMailBoxIfDeletedWasDefaultOne(email);
                    this.ngxService.stopLoader('loader-delete-boite-structurelle');
                    this.stepTwo = false;
                    this.stepThree = true;
                    this.boiteStructurelleService.updateCepList();
                    this.notificationService.updateNotificationsAfterMailboxRemove(this.boiteStructurelle);
                },
                () => {
                    this.ngxService.stopLoader('loader-delete-boite-structurelle');
                }
            )
        }
    }

    updateDefaultMailBoxIfDeletedWasDefaultOne(email: string) {
        if (this.userService.hasDefaultBox() &&
            email === this.userService.userInfo.parametrage?.defaultMailBox.email) {
            this.userService.reinitNominativBoxAsDefaultBox();
        }
    }
}
