import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MailboxManageDefaultComponent } from './mailbox-manage-default.component';

describe('MailboxManageDefaultComponent', () => {
  let component: MailboxManageDefaultComponent;
  let fixture: ComponentFixture<MailboxManageDefaultComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MailboxManageDefaultComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MailboxManageDefaultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
