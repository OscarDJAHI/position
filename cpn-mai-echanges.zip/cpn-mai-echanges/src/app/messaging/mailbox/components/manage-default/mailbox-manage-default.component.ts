import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { map } from 'rxjs/operators';

import { UtilisateurService } from 'src/app/core/services/utilisateur/utilisateur.service';
import { CepMailModel, DataService } from 'src/app/messaging/shared/services/data.service';

@Component({
    selector: 'cpn-mailbox-manage-default',
    templateUrl: './mailbox-manage-default.component.html',
    styleUrls: ['./mailbox-manage-default.component.scss']
})
export class MailboxManageDefaultComponent implements OnInit {

    @Input() previousChoice: CepMailModel;

    formGroup: FormGroup;
    mailboxes: CepMailModel[] = [];

    constructor(
        public activeModal: NgbActiveModal,
        private dataService: DataService,
        private userService: UtilisateurService
    ) { }

    ngOnInit(): void {
        let currentDefault: CepMailModel = this.userService.userInfo.parametrage?.defaultMailBox;
        this.formGroup = new FormGroup({
            email: new FormControl('', [Validators.required])
        });

        this.dataService.userCepMails$
            .pipe(map((data: CepMailModel[]) => {
                let mailBoxesFiltered: CepMailModel[] = data;
                if (currentDefault) {
                    mailBoxesFiltered = data.filter(el => el.email !== currentDefault.email);
                }
                let nominativeBox = data.find(el => el.nominative);
                if (currentDefault == null && nominativeBox == null) {
                    const userInfo = this.userService.userInfo;
                    nominativeBox = {
                        id: undefined,
                        userId: userInfo.idLdap,
                        email: userInfo.mail,
                        name: '',
                        defaultBox: false,
                        nominative: true
                    };
                    mailBoxesFiltered.push(nominativeBox);
                }

                return mailBoxesFiltered;
            }))
            .subscribe((data: CepMailModel[]) => {
                this.mailboxes = data;
                if (this.previousChoice) {
                    currentDefault = this.previousChoice;
                }
                const currentDefaultView = data.find(el => el.email === currentDefault?.email);
                this.formGroup.patchValue({ email: currentDefaultView });
            });
    }

    onClose() {
        this.activeModal.dismiss('Cross click');
    }

    onValid() {
        const cepMail: CepMailModel = this.formGroup.get('email').value as CepMailModel;
        this.activeModal.close(cepMail);
    }
}
