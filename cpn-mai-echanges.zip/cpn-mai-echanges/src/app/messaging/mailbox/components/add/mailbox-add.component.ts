import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { AuthentificationService } from 'src/app/core/services/authentification/authentification.service';
import { UserInfoModel } from 'src/app/core/models/user-info.model';
import { FormControl, FormGroup } from '@angular/forms';
import { MailboxService } from 'src/app/messaging/mailbox/services/mailbox.service';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Mailbox } from 'src/app/messaging/mailbox/models/mailbox.model';
import { EMAIL_PATTERN } from '../../../shared/constants/constants';
import { AlertesModalService } from '../../../shared/services/alertes-modal.service';
import { noSpace } from 'src/app/messaging/shared/utils/withoutSpacesHelper';

export interface User {
    id: string;
    email: string;
}

export interface BoiteStructurelle {
    id: string;
    name: string;
    email: string;
    userId: string;
}

export interface AlertModalContent {
    title: string;
    message: string;
}

@Component({
    selector: 'app-mailbox-add',
    templateUrl: './mailbox-add.component.html',
    styleUrls: ['./mailbox-add.component.scss']
})
export class MailboxAddComponent implements OnInit {

    userInfo: UserInfoModel;
    form: FormGroup;
    mailBox: Mailbox;
    boiteStructurelle: BoiteStructurelle;
    alertModalContent: AlertModalContent;
    emailEmpty = false;
    invalidEmail = false;
    emailAlreadyExist = false;
    invalidForm = true;
    isBoxNameAlreadyExist = false;
    isBoiteStructurelleNotExist = false;
    noAccess = false;

    modalTilte = 'Ajouter - Boite structurelle';
    closeForm = false;
    showSuccessMsg = false;

    reqSpinner = false;

    withoutSpaces = noSpace;

    constructor(
        public activeModal: NgbActiveModal,
        private authentificationService: AuthentificationService,
        private boiteStructurelleService: MailboxService,
        private ngxService: NgxUiLoaderService,
        private alertModalService: AlertesModalService
    ) {
    }

    ngOnInit() {
        // Get User Authenticate
        this.authentificationService.getUser$().subscribe(data => {
            this.userInfo = data;
        });

        this.form = new FormGroup({
            boxName: new FormControl(''),
            email: new FormControl(''),
        });

        this.boiteStructurelle = { id: '', name: '', email: '', userId: '' };
        this.alertModalContent = { title: '', message: '' };
    }

    checkInput() {
        const email = this.form.get('email').value.trim().toLocaleLowerCase();
        const emailOk = EMAIL_PATTERN.test(email);

        if (email.length === 0) {
            this.emailEmpty = true;
            this.invalidForm = true;
            this.invalidEmail = false;
        } else if (!emailOk) {
            this.emailEmpty = false;
            this.invalidEmail = true;
            this.invalidForm = true;
        } else {
            this.verificationsSurBoiteStructurelle();
            this.invalidEmail = false;
            this.invalidForm = false;
            this.emailEmpty = false;
        }

        this.emailAlreadyExist = false;
        this.isBoxNameAlreadyExist = false;
        this.isBoiteStructurelleNotExist = false;
        this.noAccess = false
    }

    checkInputBoxName() {
        const boxName = this.form.get('boxName').value.trim();
        if (boxName.length !== 0) {
            this.boiteStructurelleService.checkMailboxByName(boxName).subscribe(
                data => {
                    if (data === null) {
                        this.isBoxNameAlreadyExist = false;
                    } else {
                        this.isBoxNameAlreadyExist = true;
                        this.invalidForm = true;
                    }
                },
                error => {
                    this.ngxService.stopLoader('loader-add-boite-structurelle');
                    this.retourErreurSeverOrNotFound(error);
                }
            );
        }
    }

    verificationsSurBoiteStructurelle() {
        this.reqSpinner = true;

        this.boiteStructurelleService.checkMailboxByEmail(this.form.get('email').value.trim().toLocaleLowerCase()).subscribe(
            data => {
                this.reqSpinner = false;
                if (data === true) {
                    this.isBoiteStructurelleNotExist = false;
                    this.noAccess = false;
                    this.verificationAccesBoiteStructurelle();
                } else {
                    this.ngxService.stopLoader('loader-add-boite-structurelle');
                    this.noAccess = false;
                    this.isBoiteStructurelleNotExist = true;
                    this.invalidForm = true;
                }
            }, error => {
                this.reqSpinner = false;
                this.invalidForm = true;
                this.invalidEmail = true;
                this.ngxService.stopLoader('loader-add-boite-structurelle');
                this.retourErreurSeverOrNotFound(error);
            }
        );
    }

    verificationAccesBoiteStructurelle() {
        this.reqSpinner = true;

        this.boiteStructurelleService.checkMailboxAuthorization(this.form.get('email').value.trim()).subscribe(
            data => {
                this.reqSpinner = false;
                this.mailBox = data[0];
                if (this.mailBox.access === true) {
                    this.ngxService.stopLoader('loader-add-boite-structurelle');
                    this.noAccess = false
                } else {
                    this.ngxService.stopLoader('loader-add-boite-structurelle');
                    this.noAccess = true
                    this.invalidForm = true;
                }
            }, error => {
                this.reqSpinner = false;
                this.ngxService.stopLoader('loader-add-boite-structurelle');
                if (error.includes("LDAP: error code")) {
                    this.alertModalContent.title = 'ERREUR 500';
                    this.alertModalContent.message = 'Serveur AD indisponible';
                    this.invalidForm = true;
                    this.activeModal.close();
                    this.alertModalService.openErrorModal(this.alertModalContent);
                }
                if (error.status === 404) {
                    this.alertModalContent.title = 'ERREUR 404';
                    this.alertModalContent.message = 'Demande non traitée';
                    this.invalidForm = true;
                    this.activeModal.close();
                    this.alertModalService.openErrorModal(this.alertModalContent);
                }
            }
        );
    }

    inscriptionBoiteStructurelle() {
        if (!this.invalidForm) {
            this.emailEmpty = false;
            this.ngxService.startLoader('loader-add-boite-structurelle');
            this.boiteStructurelle.name = this.form.get('boxName').value;
            this.boiteStructurelle.email = this.form.get('email').value.trim().toLocaleLowerCase();
            this.boiteStructurelle.userId = this.userInfo.idLdap;

            this.boiteStructurelleService.inscription(this.boiteStructurelle).subscribe(
                () => {
                    this.ngxService.stopLoader('loader-add-boite-structurelle');
                    this.boiteStructurelleService.updateCepList();
                    this.modalTilte = 'Information';
                    this.closeForm = true;
                    this.showSuccessMsg = true;
                },
                error => {
                    this.ngxService.stopLoader('loader-add-boite-structurelle');
                    if (error.error.includes("cepmail_already_added")) {
                        this.emailAlreadyExist = true;
                        this.invalidForm = true;
                    } else {
                        this.alertModalContent.title = 'Erreur/Serveur';
                        this.alertModalContent.message = 'Votre demande n\'a pas pu aboutir! \nMerci de contacter votre administrateur si le problème persiste.';
                        this.invalidForm = true;
                        this.activeModal.close();
                        this.alertModalService.openErrorModal(this.alertModalContent);
                    }
                }
            );
        } else {
            this.invalidForm = false;
            this.invalidEmail = false;
        }
    }

    retourErreurSeverOrNotFound(error) {
        console.log("Status error : ", error.status);
        console.log("Msg error : ", error.statusText);

        if (error.status === 500) {
            this.alertModalContent.title = 'ERREUR 500';
            this.alertModalContent.message = 'Serveur indisponible';
            this.invalidForm = true;
            this.activeModal.close();
            this.alertModalService.openErrorModal(this.alertModalContent);
        }
        if (error.status === 404) {
            this.alertModalContent.title = 'ERREUR 404';
            this.alertModalContent.message = 'Demande non traitée';
            this.invalidForm = true;
            this.activeModal.close();
            this.alertModalService.openErrorModal(this.alertModalContent);
        }
    }
}
