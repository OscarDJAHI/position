import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { NgbActiveModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderModule } from 'ngx-ui-loader';
import { MaterialModule } from 'src/app/core/modules/material/material.module';
import { CpnNotificationService } from '../../../shared/services/cpn-notification.service';
import { DataService } from '../../../shared/services/data.service';
import { MailboxAddComponent } from './mailbox-add.component';

describe('AddBoiteStructurelleComponent', () => {
    let component: MailboxAddComponent;
    let fixture: ComponentFixture<MailboxAddComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [MailboxAddComponent],
                imports: [
                    MaterialModule,
                    NgxUiLoaderModule,
                    FormsModule,
                    NgbModule,
                    ReactiveFormsModule,
                    RouterTestingModule,
                    HttpClientModule
                ],
                providers: [
                    NgbActiveModal,
                    DataService,
                    CpnNotificationService,
                ]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(MailboxAddComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
