export interface Mailbox {
    mailBoxName: string;
    mailBoxMail: string;
    access: boolean;
}
