import { Component, OnDestroy, OnInit } from '@angular/core';

import { NgxUiLoaderService } from 'ngx-ui-loader';

import { interval, Observable } from 'rxjs';
import { concatMap } from 'rxjs/operators';

import { UserInfoModel } from '../core/models/user-info.model';
import { BoxType } from '../core/models/enums/box-type.enum';

import { POLLING_INTERVAL } from './shared/constants/constants';
import { MessageListWrapper } from './message/models/message-list-wrapper.model';
import { MailboxService } from './mailbox/services/mailbox.service';
import { CpnNotificationService } from './shared/services/cpn-notification.service';
import { CepMailModel, DataService } from './shared/services/data.service';
import { MessagesListService } from './message/services/messages-list.service';
import { StorageService } from './shared/services/storage.service';
import { AuthentificationService } from '../core/services/authentification/authentification.service';
import { UtilisateurService } from '../core/services/utilisateur/utilisateur.service';

@Component({
    selector: 'app-cpn',
    styleUrls: ['./messaging.component.scss'],
    template: `
		<div class="messaging-content" ngxUiLoaderBlurred [loaderId]="'loader-message-list'">
			<app-message-list></app-message-list>
			<app-message-detail class="messaging-detail" [typeBox]="typeBox"></app-message-detail>
        </div>
        <ngx-ui-loader [loaderId]="'loader-message-list'"></ngx-ui-loader>`
})
export class MessagingComponent implements OnInit, OnDestroy {

    userInfo: UserInfoModel;
    typeBox: string;
    intervalObservable$: Observable<any>;
    structuralBoxFetched: boolean = false;

    constructor(
        private boiteStructurelleService: MailboxService,
        public dataService: DataService,
        private storageService: StorageService,
        private notificationService: CpnNotificationService,
        private messageListService: MessagesListService,
        private ngxUiLoaderService: NgxUiLoaderService,
        private authentificationService: AuthentificationService,
        private utilisateurService: UtilisateurService
    ) { }

    ngOnInit() {
        // cpn code snippet
        this.userInfo = this.authentificationService.userInfo;
        this.dataService.cpnSpsLoadEmitter.emit('cpn');
        this.storageService.restoreWindow();

        this.loadCpn();

        this.intervalObservable$ = interval(POLLING_INTERVAL);
        this.poolingSubscription();
    }

    ngOnDestroy() {
        this.dataService.cpnSpsLoadEmitter.emit('');
        this.dataService.openTinyWindowRequest.emit(false);
        this.dataService.isCpnLoaded = false;
    }

    private loadCpn() {
        //on arrete les loaders locaux
        this.ngxUiLoaderService.stopAllLoader('loader-message-list');
        this.ngxUiLoaderService.start();
        let mailBox: CepMailModel = {
            email: String(this.userInfo.mail),
            nominative: true,
            id: undefined,
            defaultBox: false,
            userId: String(this.userInfo.idLdap),
            name: ''
        }
        this.boiteStructurelleService.all()
            .pipe(
                concatMap((mailBoxList: CepMailModel[]) => {
                    this.addNominativeBoxIfNotExists(mailBoxList);
                    this.utilisateurService.updateOrCreateUserParametersWithDefaultBox(mailBoxList);
                    this.dataService.updateUserCepMails(mailBoxList);

                    // Get the notifications the first time before the interval firing
                    this.notificationService.updateUnreadEmailNotifications();
                    this.notificationService.updateNewProcedureNotifications();
                    if (this.utilisateurService.hasDefaultBox()) {
                        mailBox = this.utilisateurService.getDefaultBoxMail();
                    }
                    this.dataService.isCpnLoaded = true;
                    return this.messageListService.getMessages$(this.getParamsMessages(mailBox));
                }))
            .subscribe(
                listMessage => {
                    const params = this.getParamsMessages(mailBox);
                    const wrapper = new MessageListWrapper();
                    wrapper.boxEmail = params.boxMail;
                    wrapper.currentPage = params.page;
                    wrapper.isNominativeBox = params.isNomitativeBox;
                    wrapper.typeBox = params.typeBox;
                    wrapper.messages = listMessage;
                    this.dataService.listMessagesEmitter.next(wrapper);
                    this.dataService.currentBoxEmail = params.boxMail;
                    this.ngxUiLoaderService.stop();
                },
                error => {
                    this.ngxUiLoaderService.stop();
                    console.error("erreur pendant la recup des notifs", error);
                });
    }

    private poolingSubscription() {
        this.intervalObservable$.subscribe(
            () => {
                this.notificationService.updateUnreadEmailNotifications();
                this.notificationService.updateNewProcedureNotifications();
            },
            error => console.error('Sorry ! Something went wrong when trying to update notifications.', error)
        );
    }

    private getParamsMessages(boxMail: CepMailModel) {
        return {
            typeBox: BoxType.INBOX,
            isNomitativeBox: String(boxMail.nominative),
            boxMail: boxMail.email,
            page: '1'
        };
    }

    private addNominativeBoxIfNotExists(mailBoxList: CepMailModel[]) {
        const existingNominativeBox = mailBoxList.find(el => el.nominative);
        if (existingNominativeBox == null) {
            const nominativeBox: CepMailModel = {
                id: undefined,
                userId: String(this.userInfo.idLdap),
                email: String(this.userInfo.mail),
                name: '',
                defaultBox: false,
                nominative: true
            };
            mailBoxList.push(nominativeBox);
        }
    }

}
