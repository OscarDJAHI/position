import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderService } from 'ngx-ui-loader';

import { AppNameEnum } from 'src/app/core/models/enums/app-name.enum';
import { MessageWriteModalComponent } from '../../../message/components/write-modal/message-write-modal.component';
import { DEMANDE_AR_ERROR_MESSAGE } from '../../../shared/constants/constants';
import { DataService } from '../../../shared/services/data.service';
import { StorageService } from '../../../shared/services/storage.service';
import { CpnMasEchangeService } from '../../../message/services/cpn-mas-echange.service';
import { Domain } from '../../models/domain.model';
import { ContactService } from '../../services/contact.service';
import { SearchRequest } from '../../models/search-request.model';
import { SearchResponse } from '../../models/search-response.model';

@Component({
    selector: 'app-contact-search',
    templateUrl: './contact-search.component.html',
    styleUrls: ['./contact-search.component.scss']
})
export class ContactSearchComponent implements OnInit {
    errorMapping = {
        NO_RESULTAT_INFRACTION: 'Aucun r\u00e9sultat ne correspond \u00e0 vos crit\u00e8res de recherche (assurez-vous d\'avoir s\u00e9lectionn\u00e9 le bon domaine)',
        MAX_RESULTAT_INFRACTION: 'La recherche a identifi\u00e9 trop de r\u00e9sultats, merci d\'affiner les crit\u00e8res de votre recherche',
        UNKNOWN: DEMANDE_AR_ERROR_MESSAGE,
        other: ''
    };

    searchForm: FormGroup;
    searchRequest: SearchRequest;
    searchResults: SearchResponse[];

    domains: Domain[] = [];
    isFormInvalid = true;
    errorCode: string;
    isNbKeywordValid = true;
    dataReady: boolean;

    constructor(
        private contactService: ContactService,
        public activeModal: NgbActiveModal,
        private ngxService: NgxUiLoaderService,
        private dataService: DataService,
        private storageService: StorageService,
        private modalService: NgbModal,
        private cpnMasEchangeService: CpnMasEchangeService
    ) {
    }

    ngOnInit() {
        this.searchRequest = new SearchRequest();
        this.searchResults = [new SearchResponse()];

        this.searchForm = new FormGroup({
            domaine: new FormControl(''),
            first_name: new FormControl(''),
            last_name: new FormControl(''),
            email: new FormControl(''),
            keyword: new FormControl(''),
        });
        this.ngxService.start();
        this.cpnMasEchangeService.getDomainList(AppNameEnum.CEPN).subscribe(
            data => {
                this.domains = data;
                this.dataReady = true;
                this.ngxService.stop();
            },
            () => { /* for sonar, silence is golden */
            });
    }

    checkSearchForm() {
        this.cleanErrors();
        let nbKeyword = 0;
        const domain = this.searchForm.get('domaine').value;
        this.searchRequest.canal = this.getCanalByDomain(domain);
        this.searchRequest.referentiel = this.getReferentielByDomain(domain);
        this.searchRequest.domain = domain;
        this.searchRequest.keyword = this.searchForm.get('keyword').value;
        nbKeyword = this.searchRequest.keyword.split('*').length - 1;
        this.searchRequest.lastName = this.searchForm.get('last_name').value;
        this.searchRequest.firstName = this.searchForm.get('first_name').value;

        this.isFormInvalid = !((this.searchRequest.canal.length) &&
            (this.searchRequest.keyword.length || this.searchRequest.firstName.length || this.searchRequest.lastName.length) && nbKeyword < 3);

        this.isNbKeywordValid = nbKeyword <= 2;
    }

    searchContact() {
        this.ngxService.start();
        this.cleanErrors();

        if (this.searchRequest.keyword.length) {
            this.searchRequest.lastName = '';
            this.searchRequest.firstName = '';
        }

        this.contactService.searchContacts(this.searchRequest).subscribe(
            data => {
                this.searchResults = this.toSearchResponses(data['contacts']);
                this.errorCode = data && data['erreurs'] ? data['erreurs'][0].code : '';
                this.isFormInvalid = true;
                this.ngxService.stop();
            },
            error => {
                this.errorCode = 'UNKNOWN';
                console.error('Sorry ! Something went wrong when trying to fetch contacts from server:', error);
                this.ngxService.stop();
            }
        );
    }

    openMessageWriteModal(email: string) {
        this.dataService.openTinyWindowRequest.emit(false);
        const writeNewMessageType = { newMsg: true, msgReponse: false };
        this.storageService.destroyStoredMailObject();

        const config = { size: 'xl', windowClass: 'cpn-write-new-mail-modal', centered: true };
        const modalRef = this.modalService.open(MessageWriteModalComponent, config);
        modalRef.componentInstance.name = 'WriteNewMailComponent';
        modalRef.componentInstance.writeNewMessageState = writeNewMessageType;
        modalRef.componentInstance.domainFromSearchResult = this.searchForm.get('domaine').value;
        modalRef.componentInstance.emailFromSearchResult = email;

        localStorage.setItem('writeNewMessageType', JSON.stringify(writeNewMessageType));
    }

    private cleanErrors() {
        this.errorCode = '';
    }

    private selectedDomain() {
        return this.domains.filter(d => d.value === this.searchForm.get('domaine').value)[0].label;
    }

    private toSearchResponses(data?: any[]): SearchResponse[] {
        if (!data) {
            return [new SearchResponse()];
        }

        const searchResponses: SearchResponse[] = [];

        data.forEach(d => searchResponses.push(new SearchResponse(d.uid, this.selectedDomain(), d.first_name, d.last_name, d.email)));

        return searchResponses;
    }

    private getCanalByDomain(domain: string) {
        return this.domains.filter(d => d.value === domain)[0].canal;
    }

    private getReferentielByDomain(domain: string) {
        return this.domains.filter(d => d.value === domain)[0].referentiel;
    }
}
