import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbActiveModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderModule } from 'ngx-ui-loader';
import { ContactService } from '../../services/contact.service';
import { CpnNotificationService } from '../../../shared/services/cpn-notification.service';
import { DataService } from '../../../shared/services/data.service';
import { ContactSearchComponent } from './contact-search.component';

xdescribe('RechercheContactComponent', () => {
    let component: ContactSearchComponent;
    let fixture: ComponentFixture<ContactSearchComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [ContactSearchComponent],
                imports: [
                    NgxUiLoaderModule,
                    FormsModule,
                    ReactiveFormsModule,
                    NgbModule,
                    HttpClientModule
                ],
                providers: [
                    NgbActiveModal,
                    DataService,
                    CpnNotificationService,
                    ContactService
                ]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ContactSearchComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
