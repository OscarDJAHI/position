import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { SearchRequest } from '../models/search-request.model';

@Injectable()
export class ContactService {

    constructor(protected http: HttpClient) { }

    searchContacts(searchRequest: SearchRequest): Observable<any> {
        return this.http.get<any>(environment.REST_URL_CONTACT_MAS_ANNUAIRES,
            {
                params: {
                    canal: searchRequest.canal,
                    referentiel: searchRequest.referentiel,
                    firstName: searchRequest.firstName,
                    lastName: searchRequest.lastName,
                    email: searchRequest.keyword
                }
            });
    }


    checkContact(searchRequest: SearchRequest): Observable<any> {
        return this.http.get<any>(environment.REST_URL_CONTACT_MAS_ANNUAIRES_CHECK,
            {
                params: {
                    canal: searchRequest.canal,
                    referentiel: searchRequest.referentiel,
                    emails: searchRequest.keyword
                }
            });
    }
}
