export class SearchItem {
    uid: string;
    canal: string;
    firstName: string;
    lastName: string;
    domain: string;
    referentiel: string;

    constructor(uid?: string, canal?: string, firstName?: string, lastName?: string, domain?: string, referentiel?: string) {
        this.uid = uid || '';
        this.canal = canal || '';
        this.firstName = firstName || '';
        this.lastName = lastName || '';
        this.domain = domain || '';
        this.referentiel = referentiel || '';
    }
}
