import { SearchItem } from './search-item';

export class SearchResponse extends SearchItem {
    email: string;

    constructor(uid?: string, domain?: string, firstName?: string, lastName?: string, email?: string) {
        super(uid, domain, firstName, lastName);
        this.email = email || '';
    }
}
