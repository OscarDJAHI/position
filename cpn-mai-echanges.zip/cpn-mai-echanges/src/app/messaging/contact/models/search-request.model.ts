import { SearchItem } from './search-item';

export class SearchRequest extends SearchItem {
    keyword: string;

    constructor(uid?: string, canal?: string, firstName?: string, lastName?: string, keyword?: string, domain?: string, referentiel?: string) {
        super(uid, canal, firstName, lastName, domain, referentiel);
        this.keyword = keyword || '';
    }
}
