import { HttpClientModule } from '@angular/common/http';
import { EventEmitter } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ContenteditableValueAccessorModule } from '@tinkoff/angular-contenteditable-accessor';
import { McBreadcrumbsModule } from 'ngx-breadcrumbs';
import { NgxPaginationModule } from 'ngx-pagination';
import { NgxUiLoaderModule } from 'ngx-ui-loader';
import { BehaviorSubject, Observable } from 'rxjs';
import { SimplebarAngularModule } from 'simplebar-angular';
import { MaterialModule } from '../core/modules/material/material.module';
import { MessagingRoutingModule } from './messaging-routing.module';
import { MessagingComponent } from './messaging.component';
import { MailboxAddComponent } from './mailbox/components/add/mailbox-add.component';
import { MailboxDeleteComponent } from './mailbox/components/delete/mailbox-delete.component';
import { MessageDetailComponent } from './message/components/detail/message-detail.component';
import { MessageListComponent } from './message/components/list/message-list.component';
import { MessageFlagComponent } from './message/components/flag/message-flag.component';
import { ContactSearchComponent } from './contact/components/search/contact-search.component';
import { CountNotReadMails } from './shared/components/count-not-read-mails/count-not-read-mails.component';
import { FormateDate } from './shared/pipes/format-date.pipe';
import { CpnNotificationService } from './shared/services/cpn-notification.service';
import { DataService } from './shared/services/data.service';
import { StorageService } from './shared/services/storage.service';
import { UtilsService } from './shared/services/utils.service';

xdescribe('CpnComponent', () => {
    let component: MessagingComponent;
    let fixture: ComponentFixture<MessagingComponent>;

    let dataServiceStub: Partial<DataService>;
    let storageServiceStub: Partial<StorageService>;
    let cpnNotificationServiceStub: Partial<CpnNotificationService>;

    beforeEach(waitForAsync(() => {
        dataServiceStub = {
            userInfo: new BehaviorSubject<any>({nom: '', prenom: '', mail: ''}),
            newUserInfo: {nom: '', prenom: '', mail: ''},
            cpnSpsLoadEmitter: new EventEmitter(),
        };
        dataServiceStub.userInfo.next({nom: '', prenom: '', mail: ''});
        dataServiceStub.userCepMails$ = new Observable();

        storageServiceStub = {
            storeMailBox(mail: string) {
                localStorage.setItem('mail_box', mail);
            },
            storeNewMailObject(data: string) {
                localStorage.setItem('mail_object', JSON.stringify(data));
            },
            restoreWindow() {
            },
            destroyStoredMailObject() {
            }
        };
        cpnNotificationServiceStub = {};

        TestBed.configureTestingModule({
            declarations: [
                MessagingComponent,
                MailboxAddComponent,
                MailboxDeleteComponent,
                MessageListComponent,
                MessageDetailComponent,
                MessageFlagComponent,
                CountNotReadMails,
                ContactSearchComponent,
                FormateDate
            ],
            imports: [
                MessagingRoutingModule,
                McBreadcrumbsModule,
                ReactiveFormsModule,
                FormsModule,
                NgxPaginationModule,
                MaterialModule,
                NgxUiLoaderModule,
                NgbModule,
                ContenteditableValueAccessorModule,
                SimplebarAngularModule,
                RouterTestingModule,
                HttpClientModule
            ],
            providers: [
                {provide: DataService, useValue: dataServiceStub},
                {provide: StorageService, useValue: storageServiceStub},
                {provide: CpnNotificationService, useValue: cpnNotificationServiceStub},
                UtilsService,
            ]
        }).compileComponents();

        fixture = TestBed.createComponent(MessagingComponent);
        component = fixture.debugElement.componentInstance;
        fixture.detectChanges();
    }));

    beforeEach(() => {
        jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
