import { NgModule } from '@angular/core';

import { MessageModule } from './message/message.module';
import { MailboxModule } from './mailbox/mailbox.module';

import { MessagingComponent } from './messaging.component';

import { MessagingRoutingModule } from './messaging-routing.module';
import { SharedModule } from './shared/shared.module';
import { TransverseModule } from '../transverse/transverse.module';

@NgModule({
    declarations: [
        MessagingComponent,
    ],
    imports: [
        MailboxModule,
        MessageModule,
        MessagingRoutingModule,
        SharedModule,
        TransverseModule
    ],
    exports: [
        MailboxModule,
        MessageModule
    ],
    entryComponents: [],
    providers: []
})
export class MessagingModule {
}
