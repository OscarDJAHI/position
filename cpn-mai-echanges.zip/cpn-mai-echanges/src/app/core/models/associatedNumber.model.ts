export interface AssociatedNumber {
    numero: string,
    type: string
}
