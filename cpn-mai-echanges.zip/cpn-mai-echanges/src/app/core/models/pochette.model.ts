import { Arborescence } from './arborescence.model';

export interface Pochette extends Arborescence {
}
