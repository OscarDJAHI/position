import { Partage } from './partage.model';
import { AssociatedNumber } from './associatedNumber.model';

export interface Arborescence {
    id: number;
    parent?: string;
    type?: string;
    text?: string;
    level: number;
    children?: Arborescence[];
    format?: string;
    countFiles?: number;
    icon?: string;
    kind?: string;
    path?: string;
    signed?: boolean;
    partages?: Partage[];
    owner?: boolean;
    edit?: boolean;
    comments?: any;
    signatures?: any;
    associatedNumbers?: AssociatedNumber[];
    checked?: boolean;
}
