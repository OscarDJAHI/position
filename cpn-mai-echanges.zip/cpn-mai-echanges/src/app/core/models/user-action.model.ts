import { UserRole } from "./enums/user-role.enum";

export const UserAction = {
    DOWNLOAD_DOCUMENT_INTO_NPP: [UserRole.CPN_TITULAIRE],
    DOWNLOAD_AR_INTO_NPP: [UserRole.CPN_TITULAIRE],
    DOWNLOAD_DOCUMENT_INTO_BPN: [UserRole.BPN_TITULAIRE, UserRole.BPN_STORE, UserRole.CPN_TITULAIRE],
    ACESS_PAGE_PROCEDURE: [UserRole.CPN_TITULAIRE],
    SEND_MAIL_VIA_EXCHANGE: [UserRole.CPN_TITULAIRE],
}
