export interface Partage {
    id: number,
    userUid: string,
    date: Date,
    lastName: string,
    firstName: string,
    comment: string,
    checked?: boolean,
    type?: string
}
