export interface AlerteItem {
    content: string;
    read: boolean;
    id: number;
}
