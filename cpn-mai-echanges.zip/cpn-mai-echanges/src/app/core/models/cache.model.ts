export interface Cache {
    key: any;
    value: any;
}
