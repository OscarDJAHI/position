export interface List {
    id?: number;
    name: string;
    value?: string;
    icon?: string;
    path?: string;
    active?: boolean;
    disable?: boolean;
    uuid?: string;
}
