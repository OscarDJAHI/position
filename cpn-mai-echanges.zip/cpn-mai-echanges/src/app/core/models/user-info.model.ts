import { CepMailModel } from "src/app/messaging/shared/services/data.service";

/**
 * Représente les informations d'un utilisateur connecté.
 */
export interface UserInfoModel {

    idLdap?: string;
    nom: string;
    prenom?: string;
    logonId?: string;
    idJuridiction?: string;
    bureauIGC?: string;
    roles?: string[];
    permissions?: string[];
    idsJuridictions?: number[];
    igcId?: string;
    bureau?: string;
    mail?: string;
    token?: string;
    parametrage?: UserParameters;
    siteDescription?: string;
}

export interface UserParameters {
    defaultMailBox?: CepMailModel
}
