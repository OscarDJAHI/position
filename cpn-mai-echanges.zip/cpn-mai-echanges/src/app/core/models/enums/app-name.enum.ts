export enum AppNameEnum {
    CEPN = 'CEPN',
    BPN = 'BPN',
    NPP = 'NPP',
    SPS = 'SPS',
    VIGIE = 'VIGIE'
}