export enum BoxType {
    ALL = 'ALL',
    INBOX = 'INBOX',
    SENT = 'SENT',
    TRASH = 'TRASH',
    PROCEDURE = 'PROCEDURE',
}