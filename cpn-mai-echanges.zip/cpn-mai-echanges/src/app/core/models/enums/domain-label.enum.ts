export enum DomainLabelEnum {
    HUISSIER = 'HUISSIER',
    AVOCAT = 'AVOCATS',
    JUSTICE = 'SERVICES_JUDICIAIRES'
}
