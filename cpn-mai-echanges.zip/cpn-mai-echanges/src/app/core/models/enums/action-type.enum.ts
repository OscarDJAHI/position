export enum ActionType {
    SUPPRIME = 'SUPPRIME',
    RESTAURE = 'RESTAURE',
    TRAITE = 'TRAITE',
    NON_TRAITE = 'NON_TRAITE'
}