import { UserInfoModel } from './user-info.model';

export interface UserModel extends UserInfoModel {
    logonId: string;
    igcid: string;
    droits: string[];
}

export interface DemandeModel {
    origine: string;
    codeUtilisateurNpp: string;
    dossiers: any[];
    fichiers: FileModel[];
    complement: ComplementModel;
}

export interface ComplementModel {
    idExterne: string | number;
    emailPrimaire: string;
    emailSecondaire: string;
    repository: string;
}

export interface FileModel {
    idFichier: string;
    nom?: string;
    type?: string;
    storeType?: string;
    taille? : string;
}

export interface AttachmentDepositModel {
    userDTO: UserModel;
    demandeDTO: DemandeModel;
}

export interface ProcedureModel {
    idFichier: string;
    nomProcedure: string;
    nomDossier: string;
    identifiantDossier: string;
    description: string;
}

export interface AttachmentReceiptProcedureModel {
    userDTO: UserModel;
    demandeDTO: DemandeModel;
    procedureDTOs: ProcedureModel[];
}
