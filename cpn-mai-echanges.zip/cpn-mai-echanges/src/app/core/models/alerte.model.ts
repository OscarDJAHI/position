import { AlerteItem } from './alerte-item.model';
import { Pochette } from './pochette.model';

export interface Alerte {
    indicator: boolean;
    size: number;
    sizeNewItem: number;
    alerteItems: AlerteItem[];
    pochettes: Pochette[];
}
