export interface DocumentModel {
    id: number;
    name: string;
    size: number;
    type: string;
    externalId: string;
}
