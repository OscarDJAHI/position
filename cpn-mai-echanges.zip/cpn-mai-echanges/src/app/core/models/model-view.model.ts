export class ContentTableModelView {
    content: any[];
    last: boolean;
    totalPages: number;
    totalElements: number;
    numberOfElements: number;
    pageable?: any;
    first: boolean;
    number: number;
    size: number;
    sort?: any;
    empty?: boolean;
}
