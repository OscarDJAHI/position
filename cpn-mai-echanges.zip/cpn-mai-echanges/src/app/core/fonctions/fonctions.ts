import { AuthentificationService } from '../services/authentification/authentification.service';

declare const VERSION: string;

export function initName(authentificationService: AuthentificationService) {
    return () => authentificationService.estAuthentifie();
}

export function getStyleColorOfValue(value: String): String {
    return 'text-light-color-' + value.length.toString().charAt(0);

}
