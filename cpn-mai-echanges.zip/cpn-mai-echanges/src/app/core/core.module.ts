import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { CookieService } from 'ngx-cookie-service';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { MaterialModule } from './modules/material/material.module';

import { LayoutModule } from './components/layout/layout.module';
import { UserListComponent } from './components/user/list/list.component';

import { TooltipService } from './services/tooltip/tooltip.service';
import { HttpErrorInterceptor } from './services/interceptors/http-interceptor';
import { SpsService } from './services/sps/sps.service';

@NgModule({
    declarations: [
        UserListComponent,
    ],
    imports: [
        CommonModule,
        LayoutModule,
        MaterialModule,
        HttpClientModule,
        RouterModule,
        NgbModule,
        FormsModule,
        ReactiveFormsModule
    ],
    exports: [
        CommonModule,
        LayoutModule,
        MaterialModule,
        HttpClientModule,
        RouterModule,
        NgbModule,
        FormsModule,
        ReactiveFormsModule,
        UserListComponent,
    ],
    providers: [
        CookieService,
        SpsService,
        TooltipService,
        {provide: HTTP_INTERCEPTORS, useClass: HttpErrorInterceptor, multi: true},
    ]
})
export class CoreModule {
}
