import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing'
import { ShareService } from './share.service';

xdescribe('ShareService', () => {

    let shareService: ShareService;
    let httpMock: HttpTestingController;

    TestBed.configureTestingModule({
        imports: [
            HttpClientTestingModule,
        ],
        providers: [
            shareService
        ],
    });

    // shareService = TestBed.get(ShareService);
    httpMock = TestBed.get(HttpTestingController);

    it('should be created', () => {
        // const service: ShareService = TestBed.get(ShareService);
        expect(shareService).toBeTruthy();
    });
});
