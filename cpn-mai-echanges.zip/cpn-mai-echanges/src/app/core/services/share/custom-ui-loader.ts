import { NgxUiLoaderService } from 'ngx-ui-loader';

export class CustomUiLoader {

    constructor(public ngxService: NgxUiLoaderService) {
    }

    customUiLoader(loaderId: string) {
        this.ngxService.startLoader(loaderId);
        document
            .querySelector('.cpn-loader .ngx-overlay')
            .classList.remove('ngx-position-absolute');
        document.querySelector('.cpn-loader .ngx-foreground-spinner')["style"]["width"] = "224px";
    }
}
