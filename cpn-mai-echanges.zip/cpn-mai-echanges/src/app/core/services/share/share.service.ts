import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserInfoModel } from '../../models/user-info.model';
import { Arborescence } from 'src/app/core/models/arborescence.model';
import { environment } from 'src/environments/environment';

@Injectable({
    providedIn: 'root'
})
export class ShareService {

    constructor(protected http: HttpClient) {
    }

    /**
     * Partager des noeuds avec des utilisateurs
     *
     * @param id
     */
    public shareNodesUsers(users: UserInfoModel[], nodes: Arborescence[], droit: string, comment: string): Observable<any> {
        // On transforme la valeur des enfants par du boolean comme l'exige le back
        nodes.forEach((node, index) => {
            nodes[index].children = null;
        });
        return this.http.post<any>(environment.REST_URL_SHARE, {users, nodes, droit, comment});
    }

    /**
     * d�Partager des utilisateurs
     *
     * @param id
     */
    public unshare(idsPartage: number[]): Observable<any> {
        return this.http.get(environment.REST_URL_UNSHARE + "?idsPartage=" + idsPartage);
    }

    /**
     * d�Partager des utilisateurs
     *
     * @param id
     */
    public unshareNodes(nodes: Arborescence[]): Observable<any> {
        let partagesListId: number[] = [];

        nodes.forEach(n => {
            n.partages.forEach(p => {
                partagesListId.push(p.id);
            });
        });

        return this.http.get(environment.REST_URL_UNSHARE + "?idsPartage=" + partagesListId);
    }
}
