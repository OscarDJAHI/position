import { NgxUiLoaderService } from 'ngx-ui-loader';
import { ContentTableModelView } from '../../models/model-view.model';
import { CustomUiLoader } from './custom-ui-loader';
import { Observable } from 'rxjs';

export class BaseScrollTable {

    customUiLoaderService: CustomUiLoader;
    contentTableModelView: ContentTableModelView;
    listTableWrapper: any;
    page = '0';
    size = '10';

    constructor(public ngxService: NgxUiLoaderService) {
        this.customUiLoaderService = new CustomUiLoader(ngxService);
    }

    initScroll(selector: string) {
        this.contentTableModelView = new ContentTableModelView();
        this.listTableWrapper = document.querySelector(selector);
    }

    scroll(callback: Observable<ContentTableModelView>) {
        this.customUiLoaderService.customUiLoader('cpnLoader');
        callback.subscribe(
            (data) => {
                if (this.contentTableModelView.content.length !== null) {
                    this.contentTableModelView.content = this.contentTableModelView.content.concat(data.content);
                } else {
                    this.contentTableModelView.content = data.content;
                }
            },
            (error) => {
                console.log(error);
                this.ngxService.stopLoader('cpnLoader');
            },
            () => {
                this.ngxService.stopLoader('cpnLoader');
            }
        );
    }
}
