import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
    providedIn: 'root'
})
export class SendService {

    constructor(protected http: HttpClient) {
    }

    /**
     * Envoi des documents avec l idj vers npp
     *
     */
    public sendNpp(documents: string[], identifiantDossier: string, typeDossier: string): Observable<any> {
        return this.http.post<any>(environment.REST_URL_SEND_NPP, {
            documents: documents,
            identifiant: identifiantDossier.split('-').join(''),
            type: typeDossier
        });
    }

    /**
     * Recuperer l'arborescence NPP
     *
     */
    public locationNpp(): Observable<any> {
        return this.http.get<any>(environment.REST_URL_LOCATION_NPP);
    }
}
