import { TestBed } from '@angular/core/testing';

import { CoreModule } from '../../core.module';
import { SendService } from './send.service';

xdescribe('SendService', () => {
    beforeEach(() => TestBed.configureTestingModule({
        imports: [CoreModule]
    }));

    it('should be created', () => {
        const service: SendService = TestBed.get(SendService);
        expect(service).toBeTruthy();
    });
});
