import { Injectable } from '@angular/core';
import { Arborescence } from '../models/arborescence.model';

@Injectable({
    providedIn: 'root'
})
export class TreeService {

    public tree: Arborescence[];

    constructor() {
    }

    public list_to_tree(): Arborescence[] {
        let list: Arborescence[] = this.tree;
        let map: {} = {};
        let node: Arborescence;
        let roots: Arborescence[] = [];
        let i: number;
        for (i = 0; i < list.length; i += 1) {
            map[list[i].id] = i; // initialize the map
            list[i].children = []; // initialize the children
        }
        for (i = 0; i < list.length; i += 1) {
            node = list[i];
            if (node.parent !== "0") {
                // if you have dangling branches check that map[node.parentId] exists
                list[map[node.parent]].children.push(node);
            } else {
                roots.push(node);
            }
        }
        return roots;
    }
}
