import { TestBed } from '@angular/core/testing';

import { PochetteService } from './pochette.service';
import { CoreModule } from '../../core.module';

xdescribe('PochetteService', () => {
    beforeEach(() => TestBed.configureTestingModule({
        imports: [CoreModule]
    }));

    it('should be created', () => {
        const service: PochetteService = TestBed.get(PochetteService);
        expect(service).toBeTruthy();
    });
});
