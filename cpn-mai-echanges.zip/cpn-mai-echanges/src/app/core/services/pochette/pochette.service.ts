import { Injectable } from '@angular/core';
import { Pochette } from '../../models/pochette.model';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ArborescenceService } from '../arborescence/arborescence.service';
import { HttpClient } from '@angular/common/http';
import { AssociatedNumber as AssociatedNumberDto } from '../../models/associatedNumber.model';

@Injectable({
    providedIn: 'root'
})
export class PochetteService extends ArborescenceService {

    constructor(protected http: HttpClient) {
        super(http);
    }

    public getNode(): Observable<Pochette[]> {
        let pUrl = environment.REST_URL_BPN + "/node/load/pochettes";
        return this.http.get<Pochette[]>(pUrl);
    }

    public create(name: string, idParent: number, associatedNumbers: AssociatedNumberDto[]): Observable<any> {
        let url = environment.REST_URL_BPN_POCHETTE_CREATE;
        return this.http.post<any>(url, {name, idParent, associatedNumbers});
    }
}
