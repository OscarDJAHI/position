import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

import { NgxUiLoaderService } from 'ngx-ui-loader';

import { environment } from '../../../../environments/environment';

import { UtilsService } from '../../../messaging/shared/services/utils.service';
import { StringUtils } from '../../../messaging/shared/utils/string.utils';
import { DataService } from '../../../messaging/shared/services/data.service';

import {
    AttachmentDepositModel,
    AttachmentReceiptProcedureModel,
    ComplementModel,
    DemandeModel,
    FileModel,
    UserModel
} from '../../models/attachment-deposit.model';
import { Procedure } from 'src/app/procedures/journal/models/journal.model';


@Injectable()
export class SpsService {

    constructor(private http: HttpClient,
                private dataService: DataService,
                private ngxService: NgxUiLoaderService) {
    }

    openDepositModal(origin: string, files: FileModel[], complement?: ComplementModel) {
        this.ngxService.start();

        const request = this.toAttachmentDepositModel(origin, files, complement);

        this.initAttachmentDepositModal(request).subscribe(
            data => {
                this.openModal(request, data);
            }, error => {
                console.error('Sorry ! Something went wrong :', UtilsService.toMessage(error));
                this.ngxService.stop();
            });
    }

    openModalReceiptProcedure(origin: string, procedures: Procedure[], complement?: ComplementModel) {
        this.ngxService.start();

        const request = this.toAttachmentReceiptProcedureModel(origin, procedures, complement);

        this.initAttachmentReceiptProcedureModal(request).subscribe(
            data => {
                this.openModal(request, data);
            }, error => {
                console.error('Sorry ! Something went wrong :', UtilsService.toMessage(error));
                this.ngxService.stop();
            });
    }

    openModal(request, data) {
        const width = 815;
        const height = screen.height;
        const left = (screen.width - width) / 2;
        const top = (screen.height - height) / 2;

        window.open(data.urlModale + '?numTicket=' + data.idTicket + '&igcid=' + request.userDTO.igcid + '&token=' + data.token,
            '',
            'width=' + width + ', height=' + height + ', top=' + top + ', left=' + left);
        this.ngxService.stop();
    }

    private toAttachmentDepositModel(origine: string, fichiers: FileModel[], complement?: ComplementModel): AttachmentDepositModel {
        return {
            userDTO: this.toUserDTO(),
            demandeDTO: this.toDemandeDTO(origine, fichiers, complement)
        };
    }

    private toAttachmentReceiptProcedureModel(origine: string, procedures: Procedure[], complement?: ComplementModel): AttachmentReceiptProcedureModel {
        return {
            userDTO: this.toUserDTO(),
            demandeDTO: this.toDemandeDTO(origine, procedures.map(p => {return {idFichier: p.uri}}), complement),
            procedureDTOs: this.toProcedureDTOs(procedures),
        };
    }

    private initAttachmentDepositModal(request: AttachmentDepositModel): Observable<any> {
        return this.http.post<AttachmentDepositModel>(environment.REST_URL_SPS_INIT_MODAL, request);
    }

    private initAttachmentReceiptProcedureModal(request: AttachmentReceiptProcedureModel): Observable<any> {
        return this.http.post<AttachmentReceiptProcedureModel>(environment.REST_URL_SPS_GESTION_AFFAIRE_MODAL, request);
    }

    private toUserDTO(): UserModel {
        const user = this.dataService.newUserInfo;
        return {
            logonId: StringUtils.toString(user.idLdap),
            nom: StringUtils.toString(user.nom),
            roles: StringUtils.toArrayString(user.roles),
            igcid: StringUtils.toString(user.idLdap),
            idJuridiction: StringUtils.toString(user.idJuridiction),
            droits: StringUtils.toArrayString(user.permissions)
        };
    }

    private toDemandeDTO(origine: string, fichiers: FileModel[], complement?: ComplementModel): DemandeModel {
        const user = this.dataService.newUserInfo;
        return {
            origine,
            codeUtilisateurNpp: user.logonId? user.logonId: StringUtils.toString(user.prenom) + '.' + StringUtils.toString(user.nom),
            dossiers: [],
            fichiers,
            complement
        };
    }

    private toProcedureDTOs(procedures: Procedure[]) {
        return procedures.map(p => {
            return {
                idFichier: StringUtils.toString(p.uri),
                nomProcedure: StringUtils.toString(p.numeroProcedure),
                nomDossier: StringUtils.toString(p.nomDossier),
                identifiantDossier: StringUtils.toString(p.idj),
                description: StringUtils.toString(p.commentaire)
            }
        })
    }
}
