import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { TooltipService } from './tooltip.service';

xdescribe('TooltipService', () => {

    let tooltipService: TooltipService;
    let httpMock: HttpTestingController;

    TestBed.configureTestingModule({
        imports: [
            HttpClientTestingModule,
        ],
        providers: [
            tooltipService
        ],
    });

    // tooltipService = TestBed.get(TooltipService);
    httpMock = TestBed.get(HttpTestingController);

    it('should be created', () => {
        // const service: TooltipService = TestBed.get(TooltipService);
        expect(tooltipService).toBeTruthy();
    });
});
