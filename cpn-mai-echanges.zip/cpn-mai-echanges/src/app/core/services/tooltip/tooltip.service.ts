import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Arborescence } from '../../models/arborescence.model';

export interface TooltipDatas {
    name: string;
    nodes?: Arborescence[];
}

@Injectable({
    providedIn: 'root'
})
export class TooltipService {

    private display: BehaviorSubject<TooltipDatas> = new BehaviorSubject(this.defaultDatas());
    private closeEnabled: BehaviorSubject<true | false> = new BehaviorSubject(true);

    constructor() {
    }

    public watch(): Observable<TooltipDatas> {
        return this.display.asObservable();
    }

    public canClose(): Observable<boolean> {
        return this.closeEnabled.asObservable();
    }

    public open(datas: TooltipDatas) {
        this.display.next(datas);
    }

    public close(): boolean {
        if (this.closeEnabled.value) {
            this.display.next(this.defaultDatas());
            return true;
        }
        return false;
    }

    public enableCloseAction(isEnable: boolean): void {
        this.closeEnabled.next(isEnable);
    }

    private defaultDatas(): TooltipDatas {
        return {"name": ""};
    }
}
