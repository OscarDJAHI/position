import { Injectable } from '@angular/core';
import { UserInfoModel } from '../../models/user-info.model';
import { AuthentificationService } from '../authentification/authentification.service';

@Injectable({
    providedIn: 'root'
})
export class PermissionService {

    constructor(private authentificationService: AuthentificationService) {
    }

    /**
     * Define for a given action if the connected user has the permission
     *
     * @param acceptedRoles
     * @returns true if user has permission, otherwise, return false
     */
    hasPermission(acceptedRoles: string[]): boolean {
        const user: UserInfoModel = this.authentificationService.userInfo;
        let hasPermission = false;

        user.roles.forEach(role => {
            acceptedRoles.forEach(acceptedRole => {
                if (role.includes(acceptedRole)) {
                    hasPermission = true;
                }
            })
        });

        return hasPermission;
    }
}
