import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { BehaviorSubject, Observable } from 'rxjs';
import { filter, take, tap } from 'rxjs/operators';

import { environment } from '../../../../environments/environment';

import { UserInfoModel } from '../../models/user-info.model';
import { IndicatorId } from '../indicators/indicator-id.enum';
import { IndicatorLogService } from '../indicators/indicator-log.service';

@Injectable({ providedIn: 'root' })
export class AuthentificationService {

    public enAttenteDeUnlock = new BehaviorSubject(false);

    /**
     * Un Behaviorsubject qui permet de récupérer les informations sur l'utilisateur.
     */
    private _userInfo$ = new BehaviorSubject<UserInfoModel>(null);

    constructor(private httpClient: HttpClient,
                private router: Router,
                private indicatorService: IndicatorLogService) {
    }

    get userInfo(): UserInfoModel {
        return JSON.parse(localStorage.getItem('userInfo'));
    }

    /**
     * Retourne un Observable qui contient l'utilisateur actif pour cette session.
     * @returns un observable de userInfo.
     */
    getUser$(): Observable<UserInfoModel> {
        return this._userInfo$.asObservable();
    }

    // Met à jour le BehaviorSubject lié à l'utilisateur
    setUser$(user: UserInfoModel): void {
        this._userInfo$.next(user);
    }

    /**
     * Retourne un observable qui permet de savoir si l'utilisateur est connecté avec les bon droits ou non.
     * @param forcerRedirection true si l'utilisateur veut aller à sa page d'accueil
     */
    estAuthentifie(forcerRedirection = false) {
        const urlGetInformationsUtilisateur = environment.REST_URL_BPN_INFO_UTILISATEUR;

        return this.httpClient.get(urlGetInformationsUtilisateur)
            .pipe(
                filter(Boolean),
                take(1),
                tap((userInfo: UserInfoModel) => {
                    userInfo.roles = AuthentificationService.removeRoleCpnTitulaireIfCpnStoreExist(userInfo.roles);
                    localStorage.setItem('userInfo', JSON.stringify(userInfo));
                    this.setUser$(userInfo);
                })
            )
            .subscribe(() => {
                this.indicatorService.log(IndicatorId.CPN07).subscribe();
            });
    }

    /**
     * Permet de déconnecter l'utilisateur de l'application
     */
    deconnexion(): void {
        // windows.location kill l'application avant que les OnDestroy ait fini de travailler.
        // Pour temporiser, si on attent un delock on redirige vers une page vide pour déclencher
        // le unloock et on kill l'application après.
        // Si on est pas en attente d'un delock, on kill l'application directement
        if (this.enAttenteDeUnlock.value) {
            this.router.navigate(['/deconnexion']).then(() => {
                this.enAttenteDeUnlock
                    .pipe(filter(lock => !lock))
                    .subscribe(lock => {
                        localStorage.removeItem('userInfo');
                        window.location.href = '/saml/logout';
                    });
            });
        } else {
            localStorage.removeItem('userInfo');
            window.location.href = '/saml/logout';
        }
    }

    /**
     * PPN-8527 - Profile CPN_STORE prime sur CPN_TITULAIRE
     */
    private static removeRoleCpnTitulaireIfCpnStoreExist(roles: string[]): string[] {
        const roleCPNStore = roles.filter(role => role.indexOf('CPN_STORE') !== -1);

        return roleCPNStore.length ? roles.filter(role => role.indexOf('CPN_TITULAIRE') === -1) : roles;
    }
}
