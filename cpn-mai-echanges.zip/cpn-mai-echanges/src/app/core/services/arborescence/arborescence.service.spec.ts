import { TestBed } from '@angular/core/testing';

import { ArborescenceService } from './arborescence.service';
import { CoreModule } from '../../core.module';

xdescribe('ArborescenceService', () => {
    beforeEach(() => TestBed.configureTestingModule({
        imports: [CoreModule]
    }));

    it('should be created', () => {
        const service: ArborescenceService = TestBed.get(ArborescenceService);
        expect(service).toBeTruthy();
    });
});
