import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Arborescence } from '../../models/arborescence.model';
import { environment } from 'src/environments/environment';
import { AssociatedNumber } from '../../models/associatedNumber.model';

declare var $: any;

@Injectable({
    providedIn: 'root'
})
export class ArborescenceService {

    constructor(protected http: HttpClient) {
    }

    /**
     * Récupére les informations d'un noeud
     *
     * @param id
     */
    public getNode(id: number,): Observable<Arborescence[]> {
        const pUrl = environment.REST_URL_BPN_NODE_LOAD + '?idPochette=' + id;
        return this.http.get<Arborescence[]>(pUrl);
    }

    /**
     * Récupère les informations d'un noeud racine de l'utilisateur (niveau 2)
     *
     * @param text: nom du noeud à récupérer
     */
    public getUserRootNode(text: String): Observable<Arborescence> {
        let url = environment.REST_URL_BPN_NODE_USER_ROOT_NAME;
        url = url.replace("{{NAME}}", text.toString());

        return this.http.get<Arborescence>(url);
    }

    /**
     * Récupére la liste des @node enfants affectée au parent @node
     *
     * @param node: Noeud où l'on souhaite récupérer les enfants
     */
    public getChildren(node: Arborescence): Observable<Arborescence[]> {
        return this.http.get<Arborescence[]>(environment.REST_URL_BPN_NODE_LOAD + "?idPochette=&idNode=" + node.id);
    }

    public rename(node: Arborescence): Observable<any> {
        return this.http.get(environment.REST_URL_BPN_NODE_RENAME + "?idNode=" + node.id + "&newName=" + node.text);
    }

    public create(name: string, idParent: number, associatedNumbers: AssociatedNumber[]): Observable<any> {
        return this.http.post<any>(environment.REST_URL_BPN_NODE_CREATE, {name, idParent, associatedNumbers});
        // return this.http.post(environment.REST_URL_BPN_NODE_CREATE + "?idParent=" + node.parent + "&name=" + node.text + "&associatedNumbers=" );
    }

    public update(name: string, idParent: number, associatedNumbers: AssociatedNumber[]): Observable<any> {
        return this.http.post<any>(environment.REST_URL_BPN_NODE_UPDATE, {name, idParent, associatedNumbers});
    }

    public restore(nodes: Arborescence[]): Observable<any> {
        let nodesListId: Number[] = [];
        $.each(nodes, function (k, node: Arborescence) {
            nodesListId.push(node.id);
        });
        return this.http.get(environment.REST_URL_BPN_NODE_RESTORE + "?idsNodes=" + nodesListId);
    }

    public delete(nodes: Arborescence[]): Observable<any> {
        let nodesListId: Number[] = [];
        $.each(nodes, function (k, node: Arborescence) {
            nodesListId.push(node.id);
        });
        return this.http.get(environment.REST_URL_BPN_NODE_DELETE + "?idsNodes=" + nodesListId);
    }

    public move(nodes: Arborescence[], parent: Arborescence): Observable<any> {
        let nodesListId: Number[] = [];
        $.each(nodes, function (k, node: Arborescence) {
            nodesListId.push(node.id);
        });
        return this.http.get(environment.REST_URL_BPN_NODE_MOVE + "?idsNodes=" + nodesListId + "&idParent=" + parent.id);
    }

    public deleteDefinitive(nodes: Arborescence[])//: Observable<any>
    {
        let nodesListId: Number[] = [];
        $.each(nodes, function (k, node: Arborescence) {
            nodesListId.push(node.id);
        });
        return this.http.get(environment.REST_URL_BPN_NODE_DELETE_DEFINITIVE + "?idsNodes=" + nodesListId);
    }

    public getTrash(): Observable<Arborescence[]> {
        return this.http.get<Arborescence[]>(environment.REST_URL_BPN_TRASH_LOAD);
    }


    public getQuickSign(): Observable<Arborescence[]> {
        return this.http.get<Arborescence[]>(environment.REST_URL_BPN_QUICK_SIGN_LOAD);
    }

    public getNodeQuickSign(): Observable<Arborescence> {
        return this.http.get<Arborescence>(environment.REST_URL_BPN_QUICK_SIGN_GET_NODE);
    }

    /**
     * Récupérer arborescences parentes d'un node donné
     */
    public getParentsFromNode(node: Arborescence) {
        if (node.id) {
            return this.http.get<Arborescence[]>(environment.REST_URL_BPN_NODE_LOAD + "/nodesparentsfromnode?idNode=" + node.id);
        }
    }

    /**
     * Récupérer ids de tous les documents d'une pochette
     * @param id idPochette
     */
    public getIdsAllDocuments(id: number) {
        return this.http.get<number[]>(environment.REST_URL_BPN_NODE_GET_ALL_IDS_DOCUMENTS_FROM_NODE + '?idNode=' + id);
    }

    /**
     * Récupérer ids de tous les documents d'une pochette
     * @param id idPochette
     */
    public getAllDocumentsFromPochette(id: number): Observable<Arborescence[]> {
        return this.http.get<Arborescence[]>(environment.REST_URL_BPN_NODE_GET_ALL_DOCUMENTS_FROM_POCHETTE + '?idNode=' + id);
    }

    public addComment(text: string, id: number): Observable<any> {
        return this.http.get(environment.REST_URL_BPN_ADD_COMMENT + "?idDoc=" + id + "&comment=" + text);
    }

    public convertOdtToPdf(node: Arborescence): Observable<any> {
        let httpParams = new HttpParams().set("idDoc", node.id.toString());
        return this.http.post<any>(environment.REST_URL_CONVERT_ODT, httpParams);
    }
}
