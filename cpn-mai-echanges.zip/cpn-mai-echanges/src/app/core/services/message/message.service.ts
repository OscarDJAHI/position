import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { Pochette } from '../../models/pochette.model';

@Injectable({
    providedIn: 'root'
})
export class MessageService {

    private subject = new Subject();

    constructor() {
    }

    addPochettes(pochettes: Pochette[]) {
        this.subject.next(pochettes);
    }

    getPochettes(): Observable<any> {
        return this.subject.asObservable();
    }
}
