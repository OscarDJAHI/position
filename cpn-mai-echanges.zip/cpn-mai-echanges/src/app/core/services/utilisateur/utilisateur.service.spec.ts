import { TestBed } from '@angular/core/testing';

import { UtilisateurService } from './utilisateur.service';
import { CoreModule } from '../../core.module';

xdescribe('UtilisateurService', () => {
    beforeEach(() => TestBed.configureTestingModule({
        imports: [CoreModule]
    }));

    it('should be created', () => {
        const service: UtilisateurService = TestBed.get(UtilisateurService);
        expect(service).toBeTruthy();
    });
});
