import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { take } from 'rxjs/operators';

import { CepMailModel, DataService } from 'src/app/messaging/shared/services/data.service';
import { AuthentificationService } from '../authentification/authentification.service';
import { MailboxService } from 'src/app/messaging/mailbox/services/mailbox.service';
import { UserInfoModel } from '../../models/user-info.model';
import { environment } from 'src/environments/environment';

@Injectable({
    providedIn: 'root'
})
export class UtilisateurService {

    constructor(
        protected http: HttpClient,
        private authentificationService: AuthentificationService,
        private dataService: DataService,
        private mailBoxServices: MailboxService) {
    }

    get userInfo(): UserInfoModel {
        return JSON.parse(localStorage.getItem("userInfo"));
    }

    set userInfo(userInfo: UserInfoModel) {
        localStorage.setItem("userInfo", JSON.stringify(userInfo));
    }

    /**
     * Récupére les informations d'un noeud
     *
     * @param id
     */
    getUsersByUsername(username: string): Observable<UserInfoModel[]> {
        let url = environment.REST_URL_HABILITATION_GET_USERS;
        url = url.replace("{{USERNAME}}", username);

        return this.http.get<UserInfoModel[]>(url);
    }

    updateOrCreateUserParametersWithDefaultBox(mailBoxes: CepMailModel[]) {
        const defaultCepMail: CepMailModel = mailBoxes.find(el => el.defaultBox);
        const userInfo = this.authentificationService.userInfo;
        if (userInfo.parametrage) {
            userInfo.parametrage.defaultMailBox = defaultCepMail;
        } else {
            userInfo.parametrage = { defaultMailBox: defaultCepMail };
        }

        this.userInfo = userInfo;
    }

    reinitNominativBoxAsDefaultBox() {
        this.dataService.userCepMails$
            .pipe(take(1))
            .subscribe((data: CepMailModel[]) => {
                if (data && data.length > 0) {
                    const nominativeBox = data.find(boxe => boxe.nominative);
                    if (nominativeBox) {
                        nominativeBox.defaultBox = true;
                        this.saveNominativeBoxDefaultInDataBaseAndLocalStorage(nominativeBox);
                    }
                }
            });
    }

    saveNominativeBoxDefaultInDataBaseAndLocalStorage(nominativeBox: CepMailModel) {
        this.mailBoxServices.updateMailBox(nominativeBox).subscribe(
            () => {
                const user = this.userInfo;
                user.parametrage.defaultMailBox = nominativeBox;
                this.userInfo = user;
            },
            error => {
                console.error(error);
            }
        );
    }

    hasDefaultBox(): boolean {
        return this.userInfo.parametrage?.defaultMailBox != null;
    }

    getDefaultBoxMail(): CepMailModel {
        return this.userInfo.parametrage?.defaultMailBox;
    }
}
