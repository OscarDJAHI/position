import { Injectable } from '@angular/core';
import { CpnMasEchangeService } from 'src/app/messaging/message/services/cpn-mas-echange.service';
import { CpnConfig } from 'src/app/messaging/shared/models/cpn-config.model';

@Injectable({
    providedIn: 'root'
})
export class ConfigurationService {

    cpnConfigMap: CpnConfig;

    constructor(private cpnMasEchangeService: CpnMasEchangeService) { }

    getCpnConfig() {
        return this.cpnMasEchangeService.getCpnConfig();
    }

   
    hasJdrAccess(idJuridiction: string){
		return this.cpnConfigMap.codeSrjJuridictionsActive.indexOf(idJuridiction)>-1;		
	}


}
