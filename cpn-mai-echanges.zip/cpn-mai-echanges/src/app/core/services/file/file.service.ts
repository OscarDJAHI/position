import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { MatDialog } from '@angular/material';
import { HttpClient } from '@angular/common/http';
import { Arborescence } from '../../models/arborescence.model';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

declare var $: any;

@Injectable({
    providedIn: 'root'
})
export class FileService {

    private UrlToCallByFormat = {
        'download': {
            'rtf': environment.REST_URL_BPN_GET_FILE,
            'docx': environment.REST_URL_BPN_GET_FILE,
            'ods': environment.REST_URL_BPN_GET_FILE,
            'xls': environment.REST_URL_BPN_GET_FILE,
            'odt': environment.REST_URL_BPN_GET_FILE
        },
        'display': {
            'jpg': environment.REST_URL_BPN_VIEW_IMAGE,
            'pdf': environment.REST_URL_BPN_VIEW_DOC,
            'bmp': environment.REST_URL_BPN_VIEW_IMAGE
        }
    };

    constructor(private dialog: MatDialog, private http: HttpClient, private router: Router, private modalService: NgbModal) {

    }

    /**
     * download documents passes en parametre
     *    idsList liste des documents
     */
    public loadDownload(idsList: number[]): Observable<any> {
        return this.http.get(environment.REST_URL_DOWNLOAD + "?idsList=" + idsList, {responseType: 'blob'});
    }

    /**
     * download documents passes en parametre
     *    idsList liste des documents
     */
    public download(idsList: number[], typeBlob: string, nameDownload: string) {
        this.loadDownload(idsList).subscribe(respData => {
            let blob = new Blob([respData], {type: typeBlob});
            let url = window.URL.createObjectURL(blob);

            // create <a> tag dinamically
            let fileLink = document.createElement('a');
            fileLink.href = url;

            // it forces the name of the downloaded file
            fileLink.download = nameDownload;

            // triggers the click event
            document.body.appendChild(fileLink);
            fileLink.click();
            document.body.removeChild(fileLink);
        }, error => {
            console.log(error);
        });
    }

    /**
     * Ouvre le document correspondant
     *
     */
    openFile(node: Arborescence, content: any) {
        if (node.format == 'odt') {
            this.dialog.open(content, {width: '100%'});
        } else if (this.UrlToCallByFormat['download'].hasOwnProperty(node.format) && !this.router.url.includes('corbeille')) {
            let UrlToCall = this.UrlToCallByFormat['download'][node.format];
            window.open(UrlToCall + node.id);
        } else if (this.UrlToCallByFormat['display'].hasOwnProperty(node.format)) {
            let UrlToCall = this.UrlToCallByFormat['display'][node.format];
        }
    }
}
