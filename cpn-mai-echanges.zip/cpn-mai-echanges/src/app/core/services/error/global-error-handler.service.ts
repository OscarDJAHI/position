import { ErrorHandler, Injectable } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';

import { ErrorHandlerService } from './error-handler.service';

@Injectable({providedIn: 'root'})
export class GlobalErrorHandlerService implements ErrorHandler {

    constructor(private errorHandlerService: ErrorHandlerService) {
    }

    handleError(err) {
        // Gestion des erreurs HTTP
        if (err instanceof HttpErrorResponse || err.status) {
            const error = err as HttpErrorResponse;

            switch (error.status) {
                case 418:
                    break;
                case 401:
                    console.log('ERREUR 401');
                    this.errorHandlerService.redirectLogin();
                    break;
                case 403:
                    this.errorHandlerService.redirectForbidden();
                    break;
                default:
                    console.error(error);
                    break;
            }
        } else {
            console.error(err);
        }
    }
}
