import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class ErrorHandlerService {

    constructor() {
    }

    /**
     * Fonction permettant la redirection vers la passerelle en vue d'une connexion par le SSO en cas d'erreur 401
     */
    redirectLogin(): void {
        window.location.href = '/saml/login';
    }

    /**
     * Fonction permettant la redirection vers la passerelle en vue d'une déconnexion en cas d'erreur 403
     */
    redirectForbidden(): void {
        window.location.href = '/saml/logout';
    }
}
