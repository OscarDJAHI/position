import { TestBed } from '@angular/core/testing';

import { IndicatorLogService } from './indicator-log.service';

describe('IndicatorLogService', () => {
    beforeEach(() => TestBed.configureTestingModule({}));

    it('should be created', () => {
        const service: IndicatorLogService = TestBed.get(IndicatorLogService);
        expect(service).toBeTruthy();
    });
});
