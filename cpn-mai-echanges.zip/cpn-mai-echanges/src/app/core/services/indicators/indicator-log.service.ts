import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { environment } from 'src/environments/environment';
import { IndicatorId } from './indicator-id.enum';

@Injectable({
    providedIn: 'root'
})
export class IndicatorLogService {

    constructor(private http: HttpClient) {
    }

    log(indicatorId: string, nb: number = 1) {
        return this.http.post(
            environment.REST_URL_POST_INDICATEUR,
            {indic: indicatorId, nb: nb});
    }

    logCpn14(nb: number = 1) {
        return this.log(IndicatorId.CPN14, nb)
    }


}
