export const IndicatorId = {
    CPN06: "CPN06",
    CPN07: "CPN07",
    CPN08: "CPN08",
    CPN14: "CPN14",
}
