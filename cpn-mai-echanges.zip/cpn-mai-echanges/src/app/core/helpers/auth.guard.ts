import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { UserInfoModel } from 'src/app/core/models/user-info.model';
import { AuthentificationService } from 'src/app/core/services/authentification/authentification.service';


@Injectable({providedIn: 'root'})
export class AuthGuard implements CanActivate {
    constructor(
        private router: Router,
        private authenticationService: AuthentificationService,
    ) {
    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        const currentUser: UserInfoModel = this.authenticationService.userInfo;

        if (currentUser) {
            if (route.data.roles) {
                let isAuthorized: boolean = false;
                currentUser.roles.forEach(userRole => {
                    for (const currentRole of route.data.roles) {
                        if (userRole.includes(currentRole)) {
                            isAuthorized = true;
                        }
                    }
                });

                if (!isAuthorized) {
                    this.router.navigate(['']);
                    return false;
                }
            }

            return true;
        }

        this.router.navigate(['/saml/login'], {queryParams: {returnUrl: state.url}});
        return false;
    }
}
