import { Component, Input, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';

import { Subscription } from 'rxjs';
import { filter, map, take } from 'rxjs/operators';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

import { UserInfoModel } from 'src/app/core/models/user-info.model';
import { BoxType } from 'src/app/core/models/enums/box-type.enum';
import { AuthentificationService } from 'src/app/core/services/authentification/authentification.service';
import { CepMailModel, DataService } from 'src/app/messaging/shared/services/data.service';
import { AlertModalContent, MailboxAddComponent } from 'src/app/messaging/mailbox/components/add/mailbox-add.component';
import { MailboxDeleteComponent } from 'src/app/messaging/mailbox/components/delete/mailbox-delete.component';
import { SignatureComponent } from 'src/app/messaging/message/components/signature/signature.component';
import { MessageSearchService } from 'src/app/messaging/message/services/message-search.service';
import { MailboxManageDefaultComponent } from 'src/app/messaging/mailbox/components/manage-default/mailbox-manage-default.component';
import { AlertesModalService } from 'src/app/messaging/shared/services/alertes-modal.service';
import { MailboxService } from 'src/app/messaging/mailbox/services/mailbox.service';
import { UtilisateurService } from 'src/app/core/services/utilisateur/utilisateur.service';
import { ConfigurationService } from 'src/app/core/services/configuration/configuration.service';

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

    notifSubscription: Subscription;

    userPrenom: string;
    userNom: string;
    mail: string;
    juridiction: string;
    siteDescription: string;
    profile: string;
    userInitiales: string = '';
    isBpn = false;
    isCpn = false;
    isSps = false;
    searchBar = true;
    isBtnMyMailBoxesParamEnabled: boolean;

    dateTempsReel: Date;
    cpnVersion: string;
    rechercheActive: boolean;
    hasJdrAccess: boolean;
    minLengthSearch = 3;  //TODO à paramétrer ?

    @Input() headerLabelCPN_BPN: { ABBR_LABEL: '', DEF_LABEL: '' };

    cpnLabel = 'CPN';
    bpnLabel = 'BPN';
    spsLabel = 'SPS';

    countNotifNewMsg: number;

    env_hostName = window.location.origin;

    userInfo: UserInfoModel;
    mailList = [];
    moduleName: any;
    environnementDisplayMessage: string;

    constructor(
        public dataService: DataService,
        private authentificationService: AuthentificationService,
        private modalService: NgbModal,
        private router: Router,
        private searchService: MessageSearchService,
        private alertModalService: AlertesModalService,
        private userService: UtilisateurService,
        private mailBoxService: MailboxService,
        private configurationService: ConfigurationService
    ) {
    }

    ngOnInit() {
        this.headerLabelCPN_BPN = { ABBR_LABEL: '', DEF_LABEL: '' };
        this.countNotifNewMsg = 0;
        this.cpnVersion = this.configurationService.cpnConfigMap.version;
        this.environnementDisplayMessage = this.configurationService.cpnConfigMap.environnementDisplayMessage;
        this.rechercheActive = this.configurationService.cpnConfigMap.rechercheEnable;
        this.hasJdrAccess = this.configurationService.hasJdrAccess(this.dataService.newUserInfo.idJuridiction);
        this.router.events.pipe(
            filter(event => event instanceof NavigationEnd)
        ).subscribe((event: NavigationEnd) => {
            this.moduleName = event.url;
        });

        // cpn code snippet
        this.userInfo = this.dataService.newUserInfo;

        const that = this;
        this.authentificationService.getUser$().subscribe(user => {
            // cpn code snippet
            this.dataService.updateUserInfoState(user);

            if (user != null && user.prenom != null && user.prenom !== '') {
                that.userPrenom = user.prenom;
                that.userInitiales = user.prenom.charAt(0).toUpperCase();
            }
            if (user != null && user.nom != null && user.nom !== '') {
                that.userNom = user.nom;
                that.userInitiales += user.nom.charAt(0).toUpperCase();
            }
            if (user != null && user.idJuridiction != null && user.idJuridiction !== '') {
                that.juridiction = user.idJuridiction;
            }
            if (user != null && user.mail != null && user.mail !== '') {
                that.mail = user.mail;
            }
            if (user != null && user.siteDescription != null && user.siteDescription !== '') {
                that.siteDescription = user.siteDescription;
            }

            if (user != null && user.roles != null) {
                const profils: string[] = [];
                user.roles.forEach(role => {
                    if (role.indexOf('BPN:BPN') > -1 || role.indexOf('BPN:UTILISATEUR') > -1) {
                        that.isBpn = true;
                        this.dataService.updateBpnProfileState(that.isBpn);
                    }

                    if (role.indexOf('BPN:CPN') > -1) {
                        that.isCpn = true;
                        this.dataService.updateCpnProfileState(that.isCpn);
                    }
                    // ajout redirection sps
                    if (role.indexOf('BPN:SPS_UTILISATEUR') > -1) {
                        console.log(role);

                        that.isSps = true;
                        this.dataService.updateSpsProfileState(that.isSps);
                    }

                    if (role.endsWith('UTILISATEUR')) {
                        profils.push('utilisateur');
                    }

                    if (role.endsWith('TITULAIRE')) {
                        profils.push('titulaire');
                    }

                    if (role.endsWith('ADMINISTRATEUR')) {
                        profils.push('administrateur');
                    }

                    if (role.endsWith('STAGIAIRE')) {
                        profils.push('stagiaire');
                    }

                    if (role.endsWith('VACATAIRE')) {
                        profils.push('vacataire');
                    }
                });

                this.profile = profils.filter(function (elem, index, self) {
                    return index === self.indexOf(elem);
                }).join(', ');
            }
        });

        this.dataService.cpnSpsLoadEmitter.subscribe(
            data => {
                if (data.length === 0 && this.notifSubscription !== undefined) {
                    this.notifSubscription.unsubscribe();
                }
            });

        this.dataService.userCepMails$.subscribe(
            data => {
                if (data) {
                    this.mailList = data.map(d => d.email);
                }
            },
            error => {
                console.error(error);
            }
        );
    }

    signOut() {
        this.authentificationService.deconnexion();
    }

    openAddBoiteStructurelle() {
        const config = { size: 'None', centered: true, windowClass: 'cpn-add-boite-structurelle' };
        const modalRef = this.modalService.open(MailboxAddComponent, config);
        modalRef.componentInstance.name = 'World';
    }

    openDeleteBoiteStructurelle() {
        const config = { size: 'None', centered: true, windowClass: 'cpn-delete-boite-structurelle' };
        const modalRef = this.modalService.open(MailboxDeleteComponent, config);
        modalRef.componentInstance.name = 'World';
    }

    openManageSignature() {
        const config = { size: 'lg', centered: true, windowClass: 'cpn-manage-signature' };
        const modalRef = this.modalService.open(SignatureComponent, config);
        modalRef.componentInstance.name = 'Manage Signature';
    }

    openConsoleAdmin() {
        this.router.navigateByUrl('procedures/console');
    }

    checkMesMessageriesAvailabilityButton() {
        this.dataService.userCepMails$
            .pipe(take(1), map((data: CepMailModel[]) => {
                if (data) {
                    return data.filter((boxe: CepMailModel) => !boxe.nominative);
                }
                return data;
            }))
            .subscribe((data: CepMailModel[]) => {
                this.isBtnMyMailBoxesParamEnabled = data != null && data?.length > 0;
            });
    }

    openManageDefaultMailBoxModal(previousChoice: CepMailModel = undefined) {
        if (this.isBtnMyMailBoxesParamEnabled) {
            const config = { size: 'md', centered: true, windowClass: 'cpn-manage-signature' };
            const modalRef = this.modalService.open(MailboxManageDefaultComponent, config);
            modalRef.componentInstance.name = 'manage messagerie';
            modalRef.componentInstance.previousChoice = previousChoice;
            modalRef.result.then(
                (chosenBox: CepMailModel) => {
                    this.confirmChoiceDefaultMail(chosenBox);
                }, () => {
                    console.info("Pas de mail par defaut");
                });
        }
    }

    confirmChoiceDefaultMail(defaultMailSelected: CepMailModel) {
        const message: string = `<p>Vous &ecirc;tes sur le point de choisir la boite de reception :</p>
        <p>${defaultMailSelected.email}</p>
        <p>&Ecirc;tes-vous s&ucirc;r ?</p>`;
        const options: AlertModalContent = { title: "", message: message };
        const modal: NgbModalRef = this.alertModalService.openValidationModal(options);
        modal.result.then(
            () => {
                this.getUserMailBoxListAndUpdateDefaultOne(defaultMailSelected);
            },
            () => {
                this.openManageDefaultMailBoxModal(defaultMailSelected);
            });
    }

    getUserMailBoxListAndUpdateDefaultOne(defaultBoxMailChosen: CepMailModel) {
        this.dataService.userCepMails$
            .pipe(take(1), map((data: CepMailModel[]) => {
                data.forEach((el: CepMailModel) => {
                    el.defaultBox = el.email === defaultBoxMailChosen.email;
                });
                return data;
            }))
            .subscribe((data: CepMailModel[]) => {
                this.sendUpdatedBoxListToBackAndUpdateDefaultBoxMail(data);
            });
    }

    sendUpdatedBoxListToBackAndUpdateDefaultBoxMail(mailBoxes: CepMailModel[]) {
        this.mailBoxService.updateMailBoxes(mailBoxes).subscribe(
            (data: CepMailModel[]) => {
                this.userService.updateOrCreateUserParametersWithDefaultBox(data);
                this.dataService.updateUserCepMails(data);
            },
            error => {
                const options: AlertModalContent = { title: "Erreur", message: error };
                this.alertModalService.openErrorModal(options);
            }
        );
    }

    search(event: any) {
        if (this.rechercheActive) {
            const srchTerm = event.target.value;

            if (srchTerm && srchTerm.length >= this.minLengthSearch) {
                this.searchService.notifyHeaderSearchLaunched(srchTerm);
                this.searchService.searchMessages({
                    typeBox: BoxType.INBOX,
                    isNomitativeBox: 'false', // TODO à virer avec la nouvelle api
                    boxMails: this.buildMailList(),
                    term: srchTerm
                });
            }
        }
    }

    giveDate() {
        this.dateTempsReel = new Date();
    }

    private buildMailList() {
        if (!this.mailList.includes(this.userInfo.mail)) {
            this.mailList.push(this.userInfo.mail);
        }
        return this.mailList;
    }

    isEnvironnementDisplayMessageNotEmpty(): boolean {
        if (!this.environnementDisplayMessage) {
            return false;
        }

        return this.environnementDisplayMessage.trim() !== '';
    }
}
