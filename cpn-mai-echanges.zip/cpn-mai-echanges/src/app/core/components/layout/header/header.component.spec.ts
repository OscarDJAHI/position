import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { HeaderComponent } from './header.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { NgbModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AuthentificationService } from 'src/app/core/services/authentification/authentification.service';
import { CpnNotificationService } from 'src/app/messaging/shared/services/cpn-notification.service';
import { DataService } from 'src/app/messaging/shared/services/data.service';
import { CpnAlerteComponent } from 'src/app/messaging/shared/modals/alerte/cpn-alerte.component';

xdescribe('HeaderComponent', () => {
    let component: HeaderComponent;
    let fixture: ComponentFixture<HeaderComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [
                    HeaderComponent,
                    CpnAlerteComponent
                ],
                imports: [
                    RouterTestingModule,
                    HttpClientModule,
                    NgbModule
                ],
                providers: [
                    AuthentificationService,
                    NgbModal,
                    CpnNotificationService,
                    DataService
                ]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(HeaderComponent);
        component = fixture.debugElement.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
