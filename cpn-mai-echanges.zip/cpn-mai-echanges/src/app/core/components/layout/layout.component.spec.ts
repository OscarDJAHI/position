import { HttpClientModule } from '@angular/common/http';
import { TestBed, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { NgbModalConfig, NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { FooterComponent } from '../layout/footer/footer.component';
import { HeaderComponent } from '../layout/header/header.component';

import { CpnAlerteComponent } from '../../../messaging/shared/modals/alerte/cpn-alerte.component';
import { MessageWriteModalRestoreComponent } from '../../../messaging/message/components/write-modal-restore/message-write-modal-restore.component';
import { FormateDate } from '../../../messaging/shared/pipes/format-date.pipe';
import { ContactService } from '../../../messaging/contact/services/contact.service';
import { MailboxService } from '../../../messaging/mailbox/services/mailbox.service';
import { CpnMasEchangeService } from '../../../messaging/message/services/cpn-mas-echange.service';
import { CpnNotificationService } from '../../../messaging/shared/services/cpn-notification.service';
import { DataService } from '../../../messaging/shared/services/data.service';
import { DemandeArService } from '../../../messaging/shared/services/demande-ar.service';
import { StorageService } from '../../../messaging/shared/services/storage.service';
import { UtilsService } from '../../../messaging/shared/services/utils.service';
import { LayoutComponent } from './layout.component';
import { GoToTopComponent } from './buttons/go-to-top/go-to-top.component';

describe('AppComponent', () => {
    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            declarations: [
                LayoutComponent,
                HeaderComponent,
                MessageWriteModalRestoreComponent,
                GoToTopComponent,
                FooterComponent,
                CpnAlerteComponent,
                FormateDate
            ],
            imports: [
                RouterTestingModule,
                NgbModule,
                HttpClientModule,
            ],
            providers: [
                MailboxService,
                ContactService,
                CpnNotificationService,
                CpnMasEchangeService,
                DataService,
                UtilsService,
                NgbModalConfig,
                DemandeArService,
                StorageService,
            ]
        }).compileComponents();
    }));

    it('should create the app', () => {
        const fixture = TestBed.createComponent(LayoutComponent);
        const app = fixture.debugElement.componentInstance;
        expect(app).toBeTruthy();
    });

    it(`should have as title 'cpn-mai-echange'`, () => {
        const fixture = TestBed.createComponent(LayoutComponent);
        const app = fixture.debugElement.componentInstance;
        expect(app.title).toEqual('cpn-mai-echange');
    });
});
