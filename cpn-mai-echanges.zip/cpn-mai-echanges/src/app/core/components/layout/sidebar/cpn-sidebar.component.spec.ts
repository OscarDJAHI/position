import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { NgbModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderModule } from 'ngx-ui-loader';
import { SimplebarAngularModule } from 'simplebar-angular';
import { MaterialModule } from 'src/app/core/modules/material/material.module';
import { CpnNotificationService } from '../../services/cpn-notification.service';
import { DataService } from '../../services/data.service';
import { StorageService } from '../../services/storage.service';
import { CountNotReadMails } from '../count-not-read-mails/count-not-read-mails.component';
import { CpnSidebarComponent } from './cpn-sidebar.component';

xdescribe('CpnSidebarComponent', () => {
    let component: CpnSidebarComponent;
    let fixture: ComponentFixture<CpnSidebarComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [CpnSidebarComponent, CountNotReadMails],
                imports: [
                    MaterialModule,
                    NgxUiLoaderModule,
                    FormsModule,
                    NgbModule,
                    ReactiveFormsModule,
                    RouterTestingModule,
                    HttpClientModule,
                    SimplebarAngularModule
                ],
                providers: [
                    DataService,
                    CpnNotificationService,
                    StorageService,
                    NgbModal,
                ]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CpnSidebarComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
