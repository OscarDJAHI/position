import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { map } from 'rxjs/operators';

import { UserInfoModel } from 'src/app/core/models/user-info.model';
import { BoxType } from 'src/app/core/models/enums/box-type.enum';
import { CepMailModel, DataService } from 'src/app/messaging/shared/services/data.service';
import { StorageService } from 'src/app/messaging/shared/services/storage.service';
import { MessagesListService } from 'src/app/messaging/message/services/messages-list.service';
import { MessageWriteModalComponent } from 'src/app/messaging/message/components/write-modal/message-write-modal.component';
import { ContactSearchComponent } from 'src/app/messaging/contact/components/search/contact-search.component';
import { MessageListWrapper } from 'src/app/messaging/message/models/message-list-wrapper.model';
import { CpnNotificationService } from 'src/app/messaging/shared/services/cpn-notification.service';
import { UserAction } from 'src/app/core/models/user-action.model';
import { MessageParams } from 'src/app/messaging/message/models/message-params.model';
import { UtilisateurService } from 'src/app/core/services/utilisateur/utilisateur.service';
import { ConfigurationService } from 'src/app/core/services/configuration/configuration.service';
export interface MailboxModel {
    name: string;
    email: string;
    userId: string;
}

@Component({
    selector: 'app-cpn-sidebar',
    templateUrl: './cpn-sidebar.component.html',
    styleUrls: ['./cpn-sidebar.component.scss']
})
export class CpnSidebarComponent implements OnInit {

    scrollMaxHeight = false;
    toggleSubNav = { procedure: false, inbox: false, sent: false };

    mailboxes: MailboxModel[];
    userInfo: UserInfoModel;

    boxEmail: string;
    hasJdrAccess: boolean;

    boxTypeValue: string;
    boxTypeEnum = BoxType;

    userAction = UserAction;

    isNominativeBoxTHeDefaultOne: boolean = false;
    currentBoxMail: string;

    @Output() selectBoiteEvent = new EventEmitter();
    @Input() sidebarState: boolean;
    newProcedureNotificationsCount: number;

    constructor(
        public dataService: DataService,
        private storageService: StorageService,
        private modalService: NgbModal,
        private ngxUiLoaderService: NgxUiLoaderService,
        private messagesListService: MessagesListService,
        private notificationService: CpnNotificationService,
        private userService: UtilisateurService,
        private configurationService: ConfigurationService
    ) {
    }

    ngOnInit() {
        this.clickOutHoverNav();
        this.updateNewProcedureNotifications();
        this.userInfo = this.userService.userInfo;
        this.getMailboxes();
        this.boxTypeValue = BoxType.INBOX;

        this.dataService.listMessagesEmitter.subscribe(
            (data: MessageListWrapper) => {
                this.boxTypeValue = data.typeBox;
            });

        this.dataService.toggleSideBar.emit(false);
        this.hasJdrAccess = this.configurationService.hasJdrAccess(this.dataService.newUserInfo.idJuridiction);
    }

    toggleSideBarNav(currNavItem: string) {
        if (currNavItem === 'procedure') {
            this.dataService.toggleSideBar.emit(true);
        } else {
            this.dataService.toggleSideBar.emit(false);
        }
    }

    displayHoverNav(e: any) {

        this.hideHoverNav();

        const navLabel = e.target.getAttribute('id');
        const nav: HTMLElement = document.querySelector('#' + navLabel);
        const subNav: HTMLElement = document.querySelector('.hover-' + navLabel);
        const navPos = nav.getBoundingClientRect();
        if (subNav) {
            subNav.style.top = String(navPos.top - 120 + window.scrollY) + 'px';
            subNav.style.display = 'block';
        }
    }

    hideHoverNav() {
        let hoverNavs: NodeListOf<Element> = document.querySelectorAll('.hover-nav');
        hoverNavs.forEach((el: HTMLElement) => {
            el.style.display = "none";
        })
    }

    clickOutHoverNav() {
        window.addEventListener('click', (e: any) => {
            this.hideHoverNav();
        });
    }

    toggleCurrentSubNav(curr, nav1, nav2) {
        this.currentBoxMail = this.dataService.currentBoxEmail;
        this.toggleSubNav[nav1] = false;
        this.toggleSubNav[nav2] = false;
        this.toggleSubNav[curr] = !this.toggleSubNav[curr];
    }

    closeSubNavs(curr) {
        for (const iterator in this.toggleSubNav) {
            if (iterator !== curr) {
                this.toggleSubNav.inbox = false;
                this.toggleSubNav.procedure = false;
                this.toggleSubNav.sent = false;
            } else {
                return;
            }
        }
    }

    openWriteNewMailModal() {
        this.dataService.openTinyWindowRequest.emit(false);
        let writeNewMessageType = { newMsg: true, msgReponse: false };

        if (localStorage.getItem('writeNewMessageType') != null) {
            writeNewMessageType = JSON.parse(localStorage.getItem('writeNewMessageType'));
            if (!writeNewMessageType.newMsg) {
                this.storageService.destroyStoredMailObject();
            }

            writeNewMessageType = { newMsg: true, msgReponse: false };
        }

        const config = { size: 'xl', windowClass: 'cpn-write-new-mail-modal', centered: true };
        const modalRef = this.modalService.open(MessageWriteModalComponent, config);
        modalRef.componentInstance.name = 'WriteNewMailComponent';
        modalRef.componentInstance.writeNewMessageState = writeNewMessageType;

        localStorage.setItem('writeNewMessageType', JSON.stringify(writeNewMessageType));
    }

    openSearchContactModal() {
        const config = { size: 'lg', windowClass: 'cpn-recherche-contact-modal', centered: true };
        const modalRef = this.modalService.open(ContactSearchComponent, config);
        modalRef.componentInstance.name = 'RechercheContactComponent';
    }

    getNomitativeBoxParam(typeBox: string): MessageParams {
        return {
            typeBox,
            isNomitativeBox: 'true',
            boxMail: this.userInfo.mail,
            page: '1'
        };
    }

    getStructuralBoxParam(typeBox: string, mailBox: string): MessageParams {
        return {
            typeBox,
            isNomitativeBox: 'false',
            boxMail: mailBox,
            page: '1'
        };
    }

    getDefaultBoxParam(typeBox: string): MessageParams {
        let boxMail: string = this.userInfo.mail;
        let isNomitativeBox: string = 'true';
        const defaultMailBox: CepMailModel = this.userService.userInfo.parametrage?.defaultMailBox;

        if (defaultMailBox) {
            boxMail = defaultMailBox.email;
            isNomitativeBox = String(defaultMailBox.nominative);
        }

        return {
            typeBox,
            isNomitativeBox: isNomitativeBox,
            boxMail: boxMail,
            page: '1'
        }
    }

    setDeletedMessageParams(typeBox: string) {
        const mails: any[] = [];
        if (this.mailboxes) {
            this.mailboxes.forEach(m => {
                mails.push(m.email);
            });
        }

        mails.push(this.userInfo.mail);

        return {
            typeBox,
            isNomitativeBox: 'false',
            deleted: 'true',
            boxMail: mails.join(),
            page: '1'
        };
    }

    getDeletedMessages() {
        this.messagesListService.getDeletedMessages(this.setDeletedMessageParams('TRASH'));
    }

    highlightNavItem(event: any, currentParentNav: any) {
        document.querySelectorAll('.main-nav-wrapper a').forEach(el => {
            el.classList.remove('active');
        });
        this.boxTypeValue = currentParentNav;
        let target = event.target;
        if ('A' !== target.tagName) {
            target = target.parentElement;
        }
        target.classList.add('active');
    }

    private updateNewProcedureNotifications() {
        this.notificationService.newProcedureNotifications$.subscribe(
            res => {
                this.newProcedureNotificationsCount = res;
            },
            error => {
                console.error('Sorry! Something went wrong when trying to fetch new procedures notifications', error);
            }
        )
    }

    private getMailboxes() {
        this.startLoader();

        this.dataService.userCepMails$
            .pipe(map((mailBoxes: CepMailModel[]) => {
                if (mailBoxes) {
                    return mailBoxes.filter(boxe => !boxe.nominative);
                }
                return mailBoxes;
            }))
            .subscribe(
                (data: CepMailModel[]) => {
                    this.mailboxes = data;
                    if (this.mailboxes) {
                        this.scrollMaxHeight = this.mailboxes.length > 3;
                        this.stopLoader();
                    }
                },
                error => {
                    console.log('Error:', error);
                    this.stopLoader();
                }
            );
    }

    getMessages(params: MessageParams) {
        this.messagesListService.getMessages(params);
    }

    isActive(boxMail: string, boxType: string) {
        return boxMail == this.dataService.currentBoxEmail && boxType == this.boxTypeValue;
    }

    private startLoader() {
        this.ngxUiLoaderService.startLoader('mailboxes-inbox');
        this.ngxUiLoaderService.startLoader('mailboxes-sent');
    }

    private stopLoader() {
        this.ngxUiLoaderService.stopLoader('mailboxes-inbox');
        this.ngxUiLoaderService.stopLoader('mailboxes-sent');
    }
}
