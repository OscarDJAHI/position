import { Component, OnInit } from '@angular/core';

export interface LinkObject {
    label: string;
    src: string;
}

@Component({
    selector: 'app-footer',
    templateUrl: './footer.component.html',
    styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {

    public currentYear: number;
    public mainLinksList: LinkObject[] = [
        {label: 'contact', src: '/'},
        {label: 'lexique', src: '/'},
        {label: 'plan du site', src: '/'},
        {label: 'mentions légales', src: '/'}
    ];

    public exLinksList: LinkObject[] = [
        {label: 'gouvernement.fr', src: 'https://www.gouvernement.fr'},
        {label: 'legifrance.gouv.fr', src: 'https://www.legifrance.gouv.fr'},
        {label: 'service-public.fr', src: 'https://www.service-public.fr'},
        {label: 'france.fr', src: 'https://www.france.fr'},
        {label: 'data.gouv.fr', src: 'https://www.data.gouv.fr'}
    ];

    constructor() {
    }

    ngOnInit() {
        const currentDate: Date = new Date();
        this.currentYear = currentDate.getFullYear();
    }
}
