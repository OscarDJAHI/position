import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { BtnAddComponent } from './btn-add.component';

xdescribe('BtnAddComponent', () => {
    let component: BtnAddComponent;
    let fixture: ComponentFixture<BtnAddComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [BtnAddComponent]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BtnAddComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
