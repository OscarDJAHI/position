import { Component, Input, OnInit } from '@angular/core';

@Component({
    selector: 'btn-add',
    templateUrl: './btn-add.component.html',
    styleUrls: ['./btn-add.component.scss']
})
export class BtnAddComponent implements OnInit {

    @Input() label: String = 'Ajouter';
    @Input() size: String = 'md';
    @Input() isDisabled = false;
    @Input() hasIcon = true;

    constructor() {
    }

    ngOnInit() {
    }
}
