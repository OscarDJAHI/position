import { Component, Input, OnInit } from '@angular/core';

@Component({
    selector: 'btn-cancel',
    templateUrl: './btn-cancel.component.html',
    styleUrls: ['./btn-cancel.component.scss']
})
export class BtnCancelComponent implements OnInit {

    @Input() label: String = 'Ajouter';
    @Input() size: String = 'md';

    constructor() {
    }

    ngOnInit() {
    }

}
