import { Component, ElementRef, HostListener, OnInit, ViewChild } from '@angular/core';
import * as $ from 'jquery';

@Component({
    selector: 'btn-go-to-top',
    templateUrl: './go-to-top.component.html',
    styleUrls: ['./go-to-top.component.scss']
})
export class GoToTopComponent implements OnInit {

    public isVisible: boolean = false;
    @ViewChild('goToTop', {static: true}) element: ElementRef;
    private scrollHeightToShow = 300;

    constructor() {
    }

    @HostListener('window:scroll')
    handleScroll() {
        const windowScroll = window.pageYOffset;
        if (windowScroll >= this.scrollHeightToShow) {
            this.isVisible = true;
        } else {
            this.isVisible = false;
        }
    }

    ngOnInit() {
    }

    public scrollToTop(): void {
        $('html, body').animate({scrollTop: 0}, '300');
    }
}
