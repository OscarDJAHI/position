import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CpnSidebarComponent } from './sidebar/cpn-sidebar.component';
import { SharedModule } from 'src/app/messaging/shared/shared.module';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { BtnAddComponent } from './buttons/btn-add/btn-add.component';
import { BtnCancelComponent } from './buttons/btn-cancel/btn-cancel.component';
import { GoToTopComponent } from './buttons/go-to-top/go-to-top.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../../modules/material/material.module';
import { NgxUiLoaderModule } from 'ngx-ui-loader';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TransverseModule } from 'src/app/transverse/transverse.module';

const routes: Routes = [];

@NgModule({
    declarations: [
        CpnSidebarComponent,
        HeaderComponent,
        FooterComponent,
        BtnAddComponent,
        BtnCancelComponent,
        GoToTopComponent
    ],
    imports: [
        CommonModule,
        SharedModule,
        ReactiveFormsModule,
        FormsModule,
        MaterialModule,
        NgxUiLoaderModule,
        NgbModule,
        TransverseModule,
        RouterModule.forChild(routes)
    ],
    exports: [
        CpnSidebarComponent,
        HeaderComponent,
        FooterComponent,
        BtnAddComponent,
        BtnCancelComponent,
        GoToTopComponent,
        RouterModule
    ]
})
export class LayoutModule {
}
