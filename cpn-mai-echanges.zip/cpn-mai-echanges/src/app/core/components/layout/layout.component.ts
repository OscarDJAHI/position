import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router, RouterEvent } from '@angular/router';
import { filter } from 'rxjs/operators';
import { AuthentificationService } from '../../services/authentification/authentification.service';
import { DataService } from '../../../messaging/shared/services/data.service';
import { ConfigurationService } from '../../services/configuration/configuration.service';
import {AlertesModalService} from "../../../messaging/shared/services/alertes-modal.service";

@Component({
    selector: 'app-layout',
    templateUrl: './layout.component.html',
    styleUrls: ['./layout.component.scss']
})
export class LayoutComponent implements OnInit {
    title = 'cpn-mai-echanges';
    appCntx = '';

    cpnLabel = 'CPN';
    cpnDef = 'Communication Pénale Numérique';

    bpnLabel = 'BPN';
    bpnDef = 'Bureau Pénal Numérique';

    spsLabel = 'SPS';
    spsDef = 'Stockage Pénal Securisé';

    closeWindow = true;

    prtheaderLabelCPN_BPN = {ABBR_LABEL: this.bpnLabel, DEF_LABEL: this.bpnDef};

    isUserLogged = false;
    toggleSideBar: boolean = false;
    hideSideBar: boolean;

    public isBpn = false;
    public isCpn = false;
    public isSps = true;

    isCpnParamsLoaded = false;

    constructor(
        private authentificationService: AuthentificationService,
        private router: Router,
        private dataService: DataService,
        private configurationService: ConfigurationService,
        private alertModalService: AlertesModalService
    ) {
    }

    checkIfUserLogged() {
        this.authentificationService.getUser$().subscribe(user => {
            this.isUserLogged = !!user;
            this.dataService.newUserInfo = user;
        });
    }

    ngOnInit() {
        this.checkIfUserLogged();

        this.configurationService.getCpnConfig().subscribe(
            data => {
                this.isCpnParamsLoaded = true;
                this.configurationService.cpnConfigMap = data;
            }, error => {
                console.error(error);
                this.alertModalService.openErrorModal({
                    title: error.code,
                    message: 'Serveur indisponible'
                });
            });

        this.prtheaderLabelCPN_BPN = {ABBR_LABEL: this.bpnLabel, DEF_LABEL: this.bpnDef};

        const that = this;
        this.router.events.pipe(
            filter((event: RouterEvent) => event instanceof NavigationEnd)
        ).subscribe((reslt) => {
            this.authentificationService.getUser$().subscribe(user => {

                if (user !== null && user.roles !== null) {
                    // Customisation du titre du header si profil = BPN_STORE
                    if (user.roles.indexOf('BPN:BPN_STORE') != -1) {
                        this.prtheaderLabelCPN_BPN.DEF_LABEL = 'Un produit du Store PPN';
                        this.prtheaderLabelCPN_BPN.ABBR_LABEL = 'BPN STORE';
                    }
                    user.roles.forEach(role => {
                        if (role.indexOf('BPN:BPN') > -1 || role.indexOf('BPN:UTILISATEUR') > -1) {
                            that.isBpn = true;
                        }
                        if (role.indexOf('BPN:CPN') > -1) {
                            that.isCpn = true;
                            that.isSps = true;
                        }
                    });

                    this.appCntx = 'CPN';
                }
            });
        });

        this.dataService.cpnSpsLoadEmitter.subscribe(
            data => {
                switch (data) {
                    case 'cpn':
                        this.prtheaderLabelCPN_BPN = {ABBR_LABEL: this.cpnLabel, DEF_LABEL: this.cpnDef};
                        break;
                    case 'sps':
                        this.prtheaderLabelCPN_BPN = {ABBR_LABEL: this.spsLabel, DEF_LABEL: this.spsDef};
                        break;
                    default:
                        this.prtheaderLabelCPN_BPN = {ABBR_LABEL: this.bpnLabel, DEF_LABEL: this.bpnDef};
                }
            });

        this.dataService.openTinyWindowRequest.subscribe(
            data => {
                this.closeWindow = !data;
            }
        );

        this.dataService.toggleSideBar.subscribe(
            data => {
                this.toggleSideBar = data;
            }
        );

        this.dataService.hideSideBar.subscribe(
            (data) => {
                this.hideSideBar = data;
            }
        );
    }

}
