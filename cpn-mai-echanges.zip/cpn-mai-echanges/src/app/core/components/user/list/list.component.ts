import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UserInfoModel } from 'src/app/core/models/user-info.model';
import { getStyleColorOfValue } from 'src/app/core/fonctions/fonctions';

@Component({
    selector: 'app-user-list',
    templateUrl: './list.component.html',
    styleUrls: ['./list.component.scss']
})
export class UserListComponent implements OnInit {

    @Input() public users: UserInfoModel[] = [];
    @Output() public removeUserActionEmitter: EventEmitter<UserInfoModel> = new EventEmitter();

    constructor() {
    }

    public getStyleColorOfValue = (value: String) => getStyleColorOfValue(value);

    ngOnInit() {
    }

}
