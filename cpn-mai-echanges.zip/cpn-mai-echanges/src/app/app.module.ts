import { APP_BOOTSTRAP_LISTENER, ErrorHandler, NgModule } from "@angular/core";
import { DatePipe, DecimalPipe } from "@angular/common";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";

import { NgbActiveModal } from "@ng-bootstrap/ng-bootstrap";
import { NgxUiLoaderModule } from "ngx-ui-loader";

import { CoreModule } from "./core/core.module";
import { MessagingModule } from "./messaging/messaging.module";

import { GlobalErrorHandlerService } from "./core/services/error/global-error-handler.service";
import { AuthentificationService } from "./core/services/authentification/authentification.service";
import { initName } from "./core/fonctions/fonctions";
import { DataService } from "./messaging/shared/services/data.service";

import { AppRoutingModule } from "./app-routing.module";
import { LayoutComponent } from "./core/components/layout/layout.component";
import { TransverseModule } from "./transverse/transverse.module";

@NgModule({
    declarations: [LayoutComponent],
    imports: [
        AppRoutingModule,
        BrowserModule,
        BrowserAnimationsModule,
        CoreModule,
        MessagingModule,
        NgxUiLoaderModule,
        TransverseModule
    ],
    providers: [
        NgbActiveModal,
        {
            provide: ErrorHandler,
            useClass: GlobalErrorHandlerService
        },
        {
            provide: APP_BOOTSTRAP_LISTENER,
            useFactory: initName,
            deps: [AuthentificationService],
            multi: true
        },
        DatePipe,
        DataService,
        DecimalPipe
    ],
    entryComponents: [],
    bootstrap: [LayoutComponent]
})
export class AppModule {
}
