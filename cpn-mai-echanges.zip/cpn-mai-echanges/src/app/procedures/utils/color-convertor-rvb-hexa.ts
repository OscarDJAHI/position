export function rgbToHex(rvb: string) {
    if (rvb) {
        const colr = rvb.split(',');
        const r = Number(colr[0]);
        const g = Number(colr[1]);
        const b = Number(colr[2]);
        return "#" + componentToHex(r) + componentToHex(g) + componentToHex(b);
    }
}

function componentToHex(c: Number) {
    var hex = c.toString(16);
    return hex.length == 1 ? "0" + hex : hex;
}

export function hexToRgb(hex) {
    if (hex) {
        hex = hex.replace('#', '');

        var arrBuff = new ArrayBuffer(4);
        var vw = new DataView(arrBuff);
        vw.setUint32(0, parseInt(hex, 16), false);
        var arrByte = new Uint8Array(arrBuff);

        return arrByte[1] + "," + arrByte[2] + "," + arrByte[3];
    }
}
