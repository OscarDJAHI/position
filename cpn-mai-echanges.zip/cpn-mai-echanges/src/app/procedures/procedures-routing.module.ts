import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { JournalModule } from './journal/journal.module';
import { ConsoleModule } from './console/console.module';
import { MonitoringModule } from './monitoring/monitoring.module';


const routes: Routes = [
    {
        path: 'journal',
        loadChildren: () => import('./journal/journal.module').then(m => m.JournalModule)
    },
    {
        path: 'console',
        loadChildren: () => import('./console/console.module').then(m => m.ConsoleModule)
    },
    {
        path: 'monitoring',
        loadChildren: () => import('./monitoring/monitoring.module').then(m => m.MonitoringModule)
    }
];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
        JournalModule,
        ConsoleModule,
        MonitoringModule
    ],
    exports: [RouterModule]
})
export class ProceduresRoutingModule {
}
