import { Component, Injector, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import * as _ from 'lodash';
import { forkJoin } from 'rxjs';

import { DataService } from 'src/app/messaging/shared/services/data.service';
import {
    Couleur,
    LiaisonOrientationViewModel,
    OrientationMJ,
    OrientationSPP,
    ServiceMJ,
    SousServiceMJ
} from '../../models/console.model';
import { OrientationService } from '../../services/orientation.service';
import { CouleurService } from '../../services/couleur.service';
import { ServiceSousServiceMJService } from '../../services/serviceSousService-mj.service';
import { ConfirmationModalComponent } from '../confirmation-modal/confirmation-modal.component';
import { AlertModalContent } from '../../../../messaging/shared/models/alerte-modal-content.model';
import { AlertesModalService } from '../../../../messaging/shared/services/alertes-modal.service';

@Component({
    selector: 'app-orientation',
    templateUrl: './orientation.component.html',
    styleUrls: ['./orientation.component.scss']
})
export class OrientationComponent implements OnInit {

    liaisonsOrientationsVM: LiaisonOrientationViewModel[] = [];

    liaisonsOrientationForm: FormGroup = new FormGroup({});
    initFormsReady = false;

    orientationsFromDB: OrientationMJ[] = [];
    orientationsFromSPP: OrientationSPP[] = [];

    codeJuridiction = '';
    orderBoolean = false;

    servicesMJ: ServiceMJ[] = [];
    sousServicesMJ: SousServiceMJ[] = [];
    couleurs: Couleur[] = [];

    alertModalContent: AlertModalContent = {title: 'Liaison/Orientation', message: 'Enregistré avec succès!'};

    private dataService: DataService;
    private orientationService: OrientationService;
    private serviceSousServiceMJService: ServiceSousServiceMJService;
    private couleurService: CouleurService;
    private ngxService: NgxUiLoaderService;
    private activeModal: NgbActiveModal;
    private alertModalService: AlertesModalService;
    private modalService: NgbModal;

    constructor(private injector: Injector) {
        this.dataService = injector.get<DataService>(DataService);
        this.orientationService = injector.get<OrientationService>(OrientationService);
        this.serviceSousServiceMJService = injector.get<ServiceSousServiceMJService>(ServiceSousServiceMJService);
        this.couleurService = injector.get<CouleurService>(CouleurService);
        this.ngxService = injector.get<NgxUiLoaderService>(NgxUiLoaderService);
        this.activeModal = injector.get<NgbActiveModal>(NgbActiveModal);
        this.alertModalService = injector.get<AlertesModalService>(AlertesModalService);
        this.modalService = injector.get<NgbModal>(NgbModal);
    }

    ngOnInit() {
        this.codeJuridiction = String(this.dataService.newUserInfo.idJuridiction);
        this.initLiaisonsOrientatinData();
    }

    initForms() {
        const group = {};
        this.orientationsFromSPP.forEach((o, i) => {
            group[`service_${ o.libelleCourt }`] = new FormControl('');
            group[`sousService_${ o.libelleCourt }`] = new FormControl('');
            group[`couleur_${ o.libelleCourt }`] = new FormControl('');
        });
        this.liaisonsOrientationForm = new FormGroup(group);
        this.initFormsReady = true;
    }

    initOrientationMJ(): OrientationMJ {
        return {
            id: null,
            code: null,
            codeSrj: null,
            libelle: null,
            service: {id: null, libelle: null, codeSrj: null},
            sousService: {id: null, libelle: null, serviceId: null},
            couleur: {id: null, libelle: null, code: null, codeSrj: null},
            favori: false
        };
    }

    initLiaisonsOrientatinData() {
        this.customUiLoader();
        forkJoin(
            [
                this.orientationService.getOrientationsFromSpp(),
                this.orientationService.getOrientationsByCodeSrj(this.codeJuridiction),
                this.serviceSousServiceMJService.getServices(this.codeJuridiction),
                this.couleurService.getCouleursByCodeSrj(this.codeJuridiction)
            ]
        ).subscribe(
            ([orientationsSpp, orientationsCpn, mjServices, mjCouleurs]) => {
                this.orientationsFromSPP = orientationsSpp;
                this.orientationsFromDB = orientationsCpn;
                this.servicesMJ = mjServices;
                this.couleurs = mjCouleurs;

                this.mergeOrientations();
            },
            error => {
                this.ngxService.stopLoader('cpnLoader');
            },
            () => {
                this.ngxService.stopLoader('cpnLoader');
                this.initForms();
                this.defaultSeletedOption();
            });
    }

    mergeOrientations() {
        // init collection variable orientationsFromSPP
        this.orientationsFromSPP.forEach(ospp => {
            ospp.id = null;
            ospp.favori = false;
            ospp.service = {id: null, libelle: null};
            ospp.sousService = {id: null, serviceId: null, libelle: null};
            ospp.couleur = {id: null, libelle: null, code: null, codeSrj: null};
        });

        // merge orientationsFromDB in orientationsFromSPP
        this.orientationsFromDB.forEach(o => {
            if (this.orientationsFromSPP.find(ospp => ospp.libelleCourt === o.code)) {
                this.orientationsFromSPP.find(ospp => ospp.libelleCourt === o.code).id = o.id;
                this.orientationsFromSPP.find(ospp => ospp.libelleCourt === o.code).favori = o.favori;

                if (o.service) {
                    this.orientationsFromSPP.find(ospp => ospp.libelleCourt === o.code).service = o.service;
                    this.orientationsFromSPP.find(ospp => ospp.libelleCourt === o.code).sousService = o.sousService;
                }

                if (o.couleur) {
                    this.orientationsFromSPP.find(ospp => ospp.libelleCourt === o.code).couleur = o.couleur;
                }
            }
        });

        // init liaisonOrientationViewModel
        this.orientationsFromSPP.forEach(o => {
            this.liaisonsOrientationsVM.push({
                id: o.id,
                libelleCourt: o.libelleCourt,
                libelleLong: o.libelleLong,
                favori: o.favori,
                service: o.service,
                sousService: o.sousService,
                couleur: o.couleur,
                services: this.servicesMJ,
                sousServices: [],
                couleurs: [],
                btnValidation: false
            });
        });

        this.orientationsFromSPP.forEach(o => {
            if (this.liaisonsOrientationsVM.find(lo => lo.libelleCourt === o.libelleCourt)) {
                this.liaisonsOrientationsVM.find(lo => lo.libelleCourt === o.libelleCourt).id = o.id;
                this.liaisonsOrientationsVM.find(lo => lo.libelleCourt === o.libelleCourt).favori = o.favori;

                if (o.service) {
                    this.liaisonsOrientationsVM.find(lo => lo.libelleCourt === o.libelleCourt).service = o.service;
                    this.liaisonsOrientationsVM.find(lo => lo.libelleCourt === o.libelleCourt).sousService = o.sousService;

                    if (o.service.id) {
                        this.serviceSousServiceMJService.getSousServicesByService(o.service.id).subscribe(
                            data => {
                                this.liaisonsOrientationsVM.find(lo => lo.libelleCourt === o.libelleCourt).service.sousServices = data;
                            });
                    }
                }

                if (o.couleur) {
                    this.liaisonsOrientationsVM.find(lo => lo.libelleCourt === o.libelleCourt).couleur = o.couleur;
                }
            }
        });
    }

    defaultSeletedOption() {
        this.liaisonsOrientationsVM.forEach(o => {
            if (o.service && o.service.id) {
                this.liaisonsOrientationForm.get(`service_${ o.libelleCourt }`).setValue(o.service.id);

                if (o.sousService && o.sousService.id) {
                    this.liaisonsOrientationForm.get(`sousService_${ o.libelleCourt }`).setValue(o.sousService.id);
                }

                if (o.couleur && o.couleur.id) {
                    this.liaisonsOrientationForm.get(`couleur_${ o.libelleCourt }`).setValue(o.couleur.id);
                }

                o.btnValidation = false;
            } else {
                this.liaisonsOrientationForm.get(`sousService_${ o.libelleCourt }`).disable();
            }
        });
    }

    toggleFavori(orientationVM: LiaisonOrientationViewModel) {
        const orientation: OrientationMJ = {
            id: orientationVM.id,
            code: orientationVM.libelleCourt,
            libelle: orientationVM.libelleLong,
            favori: !orientationVM.favori,
            service: orientationVM.service,
            sousService: orientationVM.sousService,
            couleur: orientationVM.couleur,
            codeSrj: this.codeJuridiction,
        };

        if (orientation.id) {
            this.orientationService.updateOrientation(orientation).subscribe(
                (data: OrientationMJ) => {
                    orientationVM.favori = data.favori;
                },
                () => {
                    this.handleError();
                }
            );
        } else {
            orientation.service = null;
            orientation.sousService = null;
            orientation.couleur = null;

            this.orientationService.createOrientation(orientation).subscribe(
                (data: OrientationMJ) => {
                    orientationVM.id = data.id;
                    orientationVM.favori = data.favori;
                },
                () => {
                    this.handleError();
                }
            );
        }
    }

    sortToggleBy(libelle: string) {
        const order = this.orderBoolean ? ['asc', 'desc'] : ['desc', 'asc'];
        this.liaisonsOrientationsVM = _.orderBy(this.liaisonsOrientationsVM, [orientationSpp => orientationSpp[libelle].toLowerCase()], order);
    }

    isServiceChecked(orientation: LiaisonOrientationViewModel): boolean {
        const selectedServiceValue = this.liaisonsOrientationForm.get(`service_${ orientation.libelleCourt }`).value;
        return !(selectedServiceValue.length === 0 || selectedServiceValue === 'null');
    }

    checkLinkServiceSousServiceInput(orientation: LiaisonOrientationViewModel) {
        const selectedServiceValue = this.liaisonsOrientationForm.get(`service_${ orientation.libelleCourt }`).value;

        if (this.isServiceChecked(orientation)) {
            this.liaisonsOrientationForm.get(`sousService_${ orientation.libelleCourt }`).enable();
            this.loadSousServiceOnChangeService(orientation, selectedServiceValue);
            orientation.btnValidation = true;
        } else {
            this.liaisonsOrientationForm.get(`sousService_${ orientation.libelleCourt }`).disable();
            this.liaisonsOrientationForm.get(`sousService_${ orientation.libelleCourt }`).setValue('');
            this.liaisonsOrientationForm.get(`couleur_${ orientation.libelleCourt }`).setValue('');
            orientation.btnValidation = false;
        }
    }

    checkSousService(orientation: LiaisonOrientationViewModel) {
        orientation.btnValidation = this.isServiceChecked(orientation);
    }

    checkCouleur(orientation: LiaisonOrientationViewModel) {
        orientation.btnValidation = this.isServiceChecked(orientation);
    }

    loadSousServiceOnChangeService(orientation: LiaisonOrientationViewModel, serviceId: number) {
        this.serviceSousServiceMJService.getSousServicesByService(serviceId).subscribe(
            data => {
                orientation.service.sousServices = data;
                orientation.btnValidation = true;
            });
    }

    confirmationModal(orientationMJ: OrientationMJ, orientationVM: LiaisonOrientationViewModel) {
        const config = {size: 'default', centered: true, windowClass: 'cpn-modal-confirmation'};
        const modalRef = this.modalService.open(ConfirmationModalComponent, config);
        modalRef.componentInstance.modalBodyLabel = 'Souhaitez vous valider cette association ?';
        modalRef.componentInstance.modalTitle = 'Validation';

        modalRef.result.then((result) => {
            if (result === 'valid') {
                this.saveLiaisonOrientation(orientationMJ, orientationVM);
            }
        });
    }

    saveLiaisonOrientation(orientationMJ: OrientationMJ, orientationVM: LiaisonOrientationViewModel) {
        if (!orientationMJ.id) {
            this.orientationService.createOrientation(orientationMJ).subscribe(
                (data: OrientationMJ) => {
                    orientationVM.id = data.id;
                    this.handleSuccess();
                },
                () => {
                    this.handleError();
                }
            );
        } else {
            this.orientationService.updateOrientation(orientationMJ).subscribe(
                (data: OrientationMJ) => {
                    orientationVM.id = data.id;
                    this.handleSuccess();
                },
                () => {
                    this.handleError();
                }
            );
        }
    }

    submitLiaisonOrientation(orientation: LiaisonOrientationViewModel) {
        const selectedServiceValue = this.liaisonsOrientationForm.get(`service_${ orientation.libelleCourt }`).value;
        const selectedSousServiceValue = this.liaisonsOrientationForm.get(`sousService_${ orientation.libelleCourt }`).value;
        const selectedCouleurValue = this.liaisonsOrientationForm.get(`couleur_${ orientation.libelleCourt }`).value;

        const orientationMJ = this.initOrientationMJ();

        if (orientation.id) {
            orientationMJ.id = orientation.id;
        }

        orientationMJ.code = orientation.libelleCourt;
        orientationMJ.libelle = orientation.libelleLong;
        orientationMJ.codeSrj = this.codeJuridiction;
        orientationMJ.favori = orientation.favori;

        if (selectedServiceValue.length === 0 || selectedServiceValue === 'null') {
            orientationMJ.service = null;
        } else {
            orientationMJ.service.id = selectedServiceValue;
        }

        if (selectedSousServiceValue.length === 0 || selectedSousServiceValue === 'null') {
            orientationMJ.sousService = null;
        } else {
            orientationMJ.sousService.id = selectedSousServiceValue;
        }

        if (selectedCouleurValue.length === 0 || selectedCouleurValue === 'null') {
            orientationMJ.couleur = null;
        } else {
            orientationMJ.couleur.id = selectedCouleurValue;
        }

        this.confirmationModal(orientationMJ, orientation);
    }

    private customUiLoader() {
        this.ngxService.startLoader('cpnLoader');
        document.querySelector('.cpn-loader .ngx-overlay').classList.remove('ngx-position-absolute');
        document.querySelector('.cpn-loader .ngx-foreground-spinner')['style']['width'] = '224px';
    }

    private handleSuccess() {
        this.alertModalService.openSuccessModal(this.alertModalContent);
    }

    private handleError() {
        this.alertModalService.openGenericErrorModal();
    }
}
