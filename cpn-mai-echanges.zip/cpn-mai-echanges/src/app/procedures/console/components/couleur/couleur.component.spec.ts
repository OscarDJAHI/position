import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { CouleurComponent } from './couleur.component';

describe('CouleurComponent', () => {
    let component: CouleurComponent;
    let fixture: ComponentFixture<CouleurComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [CouleurComponent]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CouleurComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
