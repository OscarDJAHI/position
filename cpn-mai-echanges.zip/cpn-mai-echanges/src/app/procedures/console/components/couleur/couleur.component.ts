import { Component, OnInit } from '@angular/core';
import { CouleurService } from '../../services/couleur.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Couleur } from '../../models/console.model';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { DataService } from '../../../../messaging/shared/services/data.service';
import { BaseScrollTable } from '../../../../core/services/share/base-scroll-table';
import { CustomUiLoader } from '../../../../core/services/share/custom-ui-loader';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ConfirmationModalComponent } from '../confirmation-modal/confirmation-modal.component';
import { AlertesModalService } from '../../../../messaging/shared/services/alertes-modal.service';
import { AlertModalContent } from '../../../../messaging/shared/models/alerte-modal-content.model';

@Component({
    selector: 'app-couleur',
    templateUrl: './couleur.component.html',
    styleUrls: ['./couleur.component.scss']
})
export class CouleurComponent extends BaseScrollTable implements OnInit {

    customUiLoaderService: CustomUiLoader;
    libelleExist = false;
    enableAddButton = false;
    selectedColor: any;
    formColor: FormGroup;
    edge = 'edge';
    firefox = 'firefox';
    codeSrj: string;
    countButtonClicked = 0;
    colorToUpdate = null;
    defaultColor = '#000000';
    alertModalContent: AlertModalContent = {title: 'Couleur', message: 'Enregistré avec succès!'};

    constructor(
        public activeModal: NgbActiveModal,
        private alertModalService: AlertesModalService,
        private dataService: DataService,
        private colorService: CouleurService,
        private modalService: NgbModal,
        public ngxService: NgxUiLoaderService) {
        super(ngxService);
    }

    ngOnInit() {
        this.initForm();
        this.codeSrj = String(this.dataService.newUserInfo.idJuridiction);
        this.initScroll('.tbody-scroll');
        this.getColorsPageable();
    }

    initForm() {
        this.formColor = new FormGroup({
            libelle: new FormControl('', Validators.required)
        });
    }

    getColorsPageable() {
        this.customUiLoaderService.customUiLoader('cpnLoader');
        this.colorService.getColorsPageable(this.size, this.page, this.codeSrj).subscribe(
            (data) => {
                this.contentTableModelView = data;
            },
            (error) => {
                this.ngxService.stopLoader('cpnLoader');
            },
            () => {
                this.ngxService.stopLoader('cpnLoader');
            }
        );
    }

    onChangeLibelle() {
        this.libelleExist = false;
        const libelle = this.formColor.value.libelle.trim();
        this.enableAddButton = libelle.length > 0;
    }

    onScrollDown() {
        const scrollLogic = this.listTableWrapper.scrollTop + this.listTableWrapper.clientHeight >= this.listTableWrapper.scrollHeight;
        if (scrollLogic && this.contentTableModelView.content.length < this.contentTableModelView.totalElements) {
            this.contentTableModelView.number = this.contentTableModelView.number + 1;
            const callback = this.colorService.getColorsPageable(String(this.contentTableModelView.size), String(this.contentTableModelView.number), this.codeSrj);
            this.scroll(callback);
        }
    }

    initColorPalette() {
        document.getElementById('color').focus();
        const inputElement = document.getElementById('color') as HTMLInputElement;
        inputElement.value = this.defaultColor;
        document.getElementById('color').click();
    }

    openColorPalette() {
        this.libelleExist = false;
        const colorName = this.formColor.value.libelle.trim();
        this.colorService.isLibelleExist(colorName).subscribe(
            (data) => {
                if (data) {
                    this.libelleExist = true;
                } else {
                    this.initColorPalette();
                }
            },
            (error) => {
                this.handleError(error);
                this.libelleExist = false;
            }
        );
    }

    getBrowserName(): string {
        const agent = window.navigator.userAgent.toLowerCase();
        switch (true) {
            case agent.indexOf('edg') > -1:
                return this.edge;
            case agent.indexOf(this.firefox) > -1:
                return this.firefox;
        }
    }

    refreshTable() {
        this.page = '0';
        this.size = '10';
        this.getColorsPageable();
        this.formColor.reset();
    }

    closeColorPalette() {
        document.getElementById('color').style.display = 'none';
        document.getElementById('libelle').focus();
        document.getElementById('color').style.display = 'inline';
    }

    submitColor() {
        this.countButtonClicked = 0;
        this.libelleExist = false;
        if (this.selectedColor != null && this.formColor.value.libelle) {
            const color: Couleur = {
                libelle: this.formColor.value.libelle.trim(),
                code: this.selectedColor,
                codeSrj: this.codeSrj
            };

            this.colorService.create(color).subscribe(
                (data) => {
                    this.enableAddButton = false;
                    this.refreshTable();
                },
                (error) => {
                    this.handleError(error);
                }
            );
        }
    }

    onInputColor(event) {
        this.selectedColor = event.target.value;
        if (this.getBrowserName() === this.edge) {
            this.closeColorPalette();
            this.countButtonClicked++;

            if (this.countButtonClicked === 1) {
                this.submitColor();
            }
        }
    }

    onChangeColor(event) {
        this.selectedColor = event.target.value;
        if (this.getBrowserName() === this.firefox) {
            if (this.selectedColor.toUpperCase() !== this.defaultColor.toUpperCase()) {
                this.submitColor();
            }
        }
    }

    onUpdateColor(couleur: Couleur) {
        const config = {size: 'default', centered: true, windowClass: 'cpn-modal-confirmation'};
        const modalRef = this.modalService.open(ConfirmationModalComponent, config);
        modalRef.componentInstance.modalBodyLabel = 'Souhaitez vous modifier la couleur ?';
        modalRef.componentInstance.modalTitle = 'Validation';

        modalRef.result.then((result) => {
            if (result === 'valid') {
                if (this.colorToUpdate && this.colorToUpdate.code !== couleur.code) {
                    this.onValidateUpdate(this.colorToUpdate);
                }
            }
        });
    }

    onValidateUpdate(couleur: Couleur) {
        this.colorService.updateColor(couleur).subscribe(
            () => {
                this.colorToUpdate = null;
                this.handleSuccess();
            },
            (error) => {
                this.handleError(error);
            }
        );
    }

    onDeleteColor(couleur: Couleur) {
        if (!couleur.deletable) {
            return;
        }
        const config = {size: 'default', centered: true, windowClass: 'cpn-modal-confirmation'};
        const modalRef = this.modalService.open(ConfirmationModalComponent, config);
        modalRef.componentInstance.modalBodyLabel = 'Souhaitez vous supprimer cette couleur?';
        modalRef.componentInstance.modalTitle = 'Suppression';
        modalRef.componentInstance.alertModalContent = this.alertModalContent;
        modalRef.result.then((result) => {
            if (result === 'valid') {
                this.onValidateDelete(couleur);
            }
        });
    }

    onValidateDelete(couleur: Couleur) {
        this.colorService.deleteColorById(String(couleur.id)).subscribe(
            () => {
                this.handleSuccess();
            },
            (error) => {
                this.handleError(error);
            }
        );
    }

    createColorObject(couleur: Couleur): Couleur {
        return {
            id: couleur.id,
            libelle: couleur.libelle,
            code: couleur.code,
            codeSrj: couleur.codeSrj,
            dateCreation: couleur.dateCreation
        };
    }

    onChangeUpdate(event, couleur: Couleur) {
        this.colorToUpdate = this.createColorObject(couleur);
        this.colorToUpdate.code = event.target.value;
    }

    private handleSuccess() {
        this.refreshTable();
        this.alertModalService.openSuccessModal(this.alertModalContent);
    }

    private handleError(error: any) {
        this.alertModalService.openGenericErrorModal();
    }
}
