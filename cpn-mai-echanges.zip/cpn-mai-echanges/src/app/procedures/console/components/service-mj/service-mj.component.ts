import { Component, OnInit } from '@angular/core';
import { ServiceSousServiceMJService } from '../../services/serviceSousService-mj.service';
import { DataService } from 'src/app/messaging/shared/services/data.service';
import { ServiceMJ, ServiceSortType, SousServiceMJ } from '../../models/console.model';
import { BLANK_SELECT } from 'src/app/procedures/journal/constants/constants';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { BaseScrollTable } from '../../../../core/services/share/base-scroll-table';
import { CustomUiLoader } from '../../../../core/services/share/custom-ui-loader';
import { ConfirmationModalComponent } from '../confirmation-modal/confirmation-modal.component';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AlertModalContent } from '../../../../messaging/shared/models/alerte-modal-content.model';
import { AlertesModalService } from '../../../../messaging/shared/services/alertes-modal.service';

@Component({
    selector: 'app-service-mj',
    templateUrl: './service-mj.component.html',
    styleUrls: ['./service-mj.component.scss']
})
export class ServiceMJComponent extends BaseScrollTable implements OnInit {

    customUiLoaderService: CustomUiLoader;
    addForm: FormGroup;
    listServiceMJ: ServiceMJ[] = [];
    selectedSortType = ServiceSortType.SOUS_SERVICE_ASC;
    sortTypeEnum = ServiceSortType;
    codeSrj: string;
    alertModalContent: AlertModalContent = { title: 'Sous service', message: 'Enregistré avec succès!' };
    isSousServiceExists: boolean;

    constructor(private dataService: DataService,
        public activeModal: NgbActiveModal,
        private alertModalService: AlertesModalService,
        private serviceMJService: ServiceSousServiceMJService,
        private formBuilder: FormBuilder,
        private modalService: NgbModal,
        public ngxService: NgxUiLoaderService) {
        super(ngxService);
    }

    ngOnInit() {
        this.codeSrj = String(this.dataService.newUserInfo.idJuridiction);
        this.initFrom();
        this.initScroll('.tbody-scroll');
        this.loadServices();
        this.loadSousServices();
    }

    initFrom() {
        this.addForm = this.formBuilder.group({
            service: BLANK_SELECT,
            sousService: ''
        });
        this.addForm.get('sousService').disable();
    }

    loadServices() {
        this.serviceMJService.getServices(this.codeSrj).subscribe(
            data => {
                this.listServiceMJ = data;
            }
        );
    }

    loadSousServices() {
        this.customUiLoaderService.customUiLoader('cpnLoader');
        this.serviceMJService.getSousServicesByCodeSrjPageable(this.size, this.page, this.codeSrj, this.selectedSortType).subscribe(
            data => {
                this.contentTableModelView = data;
            },
            error => {
                this.ngxService.stopLoader('cpnLoader');
            },
            () => {
                this.ngxService.stopLoader('cpnLoader');
            }
        );
    }

    toggleFavori(sousSerivce: SousServiceMJ) {
        const sservice: SousServiceMJ = {
            id: sousSerivce.id,
            serviceId: sousSerivce.serviceId,
            favori: !sousSerivce.favori,
            libelle: sousSerivce.libelle,
            serviceLibelle: sousSerivce.serviceLibelle
        };

        this.serviceMJService.updateSousService(sservice).subscribe(
            (data) => {
                sousSerivce.favori = data.favori;
            },
            error => {
                this.handleError(error);
            }
        );
    }

    selectService(selectedService: string) {
        if (selectedService === BLANK_SELECT) {
            this.addForm.get('sousService').setValue('');
            this.addForm.get('sousService').disable();
        } else {
            this.addForm.get('sousService').enable();
        }
    }

    toggleServiceSort() {
        this.selectedSortType = this.selectedSortType === ServiceSortType.SERVICE_ASC ?
            ServiceSortType.SERVICE_DESC : ServiceSortType.SERVICE_ASC;
        this.loadSousServices();
    }

    toggleSousServiceSort() {
        this.selectedSortType = this.selectedSortType === ServiceSortType.SOUS_SERVICE_ASC ? ServiceSortType.SOUS_SERVICE_DESC : ServiceSortType.SOUS_SERVICE_ASC;
        this.loadSousServices();
    }

    onChangeSousServiceLibelle() {
        this.isSousServiceExists = false;
    }

    submitForm() {
        const sousService: SousServiceMJ = {
            libelle: this.addForm.get('sousService').value.trim(),
            serviceId: this.addForm.get('service').value
        };

        this.serviceMJService.isSousServiceExist(sousService.libelle, sousService.serviceId).subscribe(
            (response: boolean) => {
                this.isSousServiceExists = response;
                if (!response) {
                    this.serviceMJService.addSousService(sousService).subscribe(
                        () => {
                            // on passe au tri par date de création
                            this.selectedSortType = ServiceSortType.DATE;
                            this.loadSousServices();
                            this.addForm.get('service').setValue(BLANK_SELECT);
                            this.addForm.get('sousService').setValue('');
                            this.addForm.get('sousService').disable();
                        },
                        error => {
                            this.handleError(error);
                        }
                    );
                }
            }
        );
    }

    onScrollDown() {
        const scrollLogic = this.listTableWrapper.scrollTop + this.listTableWrapper.clientHeight >= this.listTableWrapper.scrollHeight;
        if (scrollLogic && this.contentTableModelView.content.length < this.contentTableModelView.totalElements) {
            this.contentTableModelView.number = this.contentTableModelView.number + 1;
            const callback = this.serviceMJService.getSousServicesByCodeSrjPageable(String(this.contentTableModelView.size), String(this.contentTableModelView.number), this.codeSrj, this.selectedSortType);
            this.scroll(callback);
        }
    }

    onDeleteSousService(sousService: SousServiceMJ) {
        if (!sousService.deletable) {
            return;
        }
        const config = { size: 'default', centered: true, windowClass: 'cpn-modal-confirmation' };
        const modalRef = this.modalService.open(ConfirmationModalComponent, config);
        modalRef.componentInstance.modalBodyLabel = 'Souhaitez vous supprimer le sous service ?';
        modalRef.componentInstance.modalTitle = 'Suppression';

        modalRef.result.then((result) => {
            if (result === 'valid') {
                this.onValidateDelete(sousService);
            }
        });
    }

    private handleError(error: any) {
        this.alertModalService.openGenericErrorModal();
    }

    private handleSuccess() {
        this.loadSousServices();
        this.alertModalService.openSuccessModal(this.alertModalContent);
    }

    private onValidateDelete(sousService) {
        this.serviceMJService.deleteSousService(String(sousService.id)).subscribe(
            () => {
                this.handleSuccess();
            },
            (error) => {
                this.handleError(error);
            }
        );
    }
}
