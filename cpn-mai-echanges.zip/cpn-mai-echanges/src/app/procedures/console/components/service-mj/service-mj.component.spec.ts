import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { ServiceMJComponent } from './service-mj.component';

describe('ServiceMJComponent', () => {
    let component: ServiceMJComponent;
    let fixture: ComponentFixture<ServiceMJComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [ServiceMJComponent]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ServiceMJComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
