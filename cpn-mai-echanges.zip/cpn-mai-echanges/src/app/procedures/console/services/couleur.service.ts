import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Couleur } from '../models/console.model';
import { ContentTableModelView } from '../../../core/models/model-view.model';

@Injectable({
    providedIn: 'root'
})
export class CouleurService {

    constructor(private http: HttpClient) {
    }

    create(color: Couleur): Observable<Couleur> {
        return this.http.post<Couleur>(environment.REST_URL_COLORS, color);
    }

    updateColor(color: Couleur): Observable<Couleur> {
        return this.http.put<Couleur>(environment.REST_URL_COLORS, color);
    }

    deleteColorById(id: string): Observable<any> {
        return this.http.delete(`${ environment.REST_URL_COLORS }/${ id }`);
    }

    getCouleursByCodeSrj(codeSrj: string): Observable<Couleur[]> {
        return this.http.get<Couleur[]>(`${ environment.REST_URL_GET_COLORS }/${ codeSrj }`);
    }

    getColorsPageable(size: string, page: string, codeSrj: string): Observable<ContentTableModelView> {
        const params = {size, page};
        return this.http.get<ContentTableModelView>(`${ environment.REST_URL_GET_COLORS }/${ codeSrj }/pageable`, {params});
    }

    isLibelleExist(libelle: string): Observable<any> {
        return this.http.get(`${ environment.REST_URL_IS_LIBELLE_COLOR }/${ libelle }`);
    }
}
