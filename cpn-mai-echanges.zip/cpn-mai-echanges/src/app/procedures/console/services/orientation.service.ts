import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { OrientationMJ, OrientationSPP } from '../models/console.model';

@Injectable({
    providedIn: 'root'
})
export class OrientationService {

    constructor(private http: HttpClient) {
    }

    getOrientationsByCodeSrj(codeSrj: string): Observable<OrientationMJ[]> {
        return this.http.get<OrientationMJ[]>(`${ environment.REST_URL_GET_ALL_ORIENTATIONS }/${ codeSrj }`);
    }

    getOrientationsFromSpp(): Observable<OrientationSPP[]> {
        return this.http.get<OrientationSPP[]>(`${ environment.REST_URL_GET_ALL_ORIENTATIONS_FROM_SPP }`);
    }

    createOrientation(orientationMJ: OrientationMJ): Observable<OrientationMJ> {
        return this.http.post<OrientationMJ>(`${ environment.REST_URL_CREATE_UPDATE_ORIENTATION }`, orientationMJ);
    }

    updateOrientation(orientationMJ: OrientationMJ): Observable<OrientationMJ> {
        return this.http.put<OrientationMJ>(`${ environment.REST_URL_CREATE_UPDATE_ORIENTATION }`, orientationMJ);
    }
}
