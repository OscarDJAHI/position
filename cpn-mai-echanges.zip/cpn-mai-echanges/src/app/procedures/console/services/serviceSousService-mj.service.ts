import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';

import { environment } from 'src/environments/environment';

import { ContentTableModelView } from '../../../core/models/model-view.model';

import { ServiceMJ, ServiceSortType, SousServiceMJ } from '../models/console.model';

@Injectable({
    providedIn: 'root'
})
export class ServiceSousServiceMJService {

    private servicesMJ: ServiceMJ[] = [];

    constructor(private http: HttpClient) {
    }

    getServices(codeSrj: String): Observable<ServiceMJ[]> {
        if (this.servicesMJ && this.servicesMJ.length) {
            return of(this.servicesMJ);
        }

        return this.http.get<ServiceMJ[]>(`${environment.REST_URL_GET_ALL_SERVICES}/${codeSrj}`)
            .pipe(
                tap((data) => {
                    this.servicesMJ = data;
                })
            );
    }

    getSousServicesByService(serviceId: number): Observable<SousServiceMJ[]> {
        return this.http.get<SousServiceMJ[]>(`${environment.REST_URL_GET_ALL_SOUS_SERVICES_BY_SERVICE}/${serviceId}`);
    }

    getSousServicesByCodeSrjPageable(size: string, page: string, codeSrj: String, sortType: ServiceSortType): Observable<ContentTableModelView> {
        return this.http.get<ContentTableModelView>(`${environment.REST_URL_GET_ALL_SOUS_SERVICES_BY_CODE_SRJ}/${codeSrj}/pageable`, {
            params: {
                size,
                page,
                sortType
            }
        });
    }

    addSousService(sousService: SousServiceMJ): Observable<any> {
        return this.http.post(environment.REST_URL_SOUS_SERVICES, sousService);
    }

    updateSousService(sousService: SousServiceMJ): Observable<any> {
        return this.http.put(`${environment.REST_URL_SOUS_SERVICES}`, sousService);
    }

    deleteSousService(id: string): Observable<any> {
        return this.http.delete(`${environment.REST_URL_SOUS_SERVICES}/${id}`);
    }

    isSousServiceExist(libelle: string, service_id: number): Observable<any> {
        return this.http.get(`${environment.REST_URL_SOUS_SERVICES}/label/${libelle}/service/${service_id}`);
    }
}
