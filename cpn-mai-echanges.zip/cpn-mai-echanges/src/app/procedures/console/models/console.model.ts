export interface LiaisonOrientationViewModel {
    id?: number;
    libelleCourt: string;
    libelleLong: string;
    service: ServiceMJ;
    sousService: SousServiceMJ;
    couleur: Couleur;
    services?: ServiceMJ[];
    sousServices?: SousServiceMJ[];
    couleurs?: Couleur[];
    btnValidation: boolean;
    favori: boolean;
}

export interface OrientationMJ {
    id?: number;
    code: string;
    libelle: string;
    favori: boolean;
    service: ServiceMJ;
    sousService: SousServiceMJ;
    couleur: Couleur;
    codeSrj: string;
}

export interface OrientationSPP {
    id?: number;
    favori?: boolean;
    deferrement: string;
    libelleCourt: string;
    libelleLong: string;
    miseEnCause: string;
    priorisationNumerique: string;
    texte: string;
    service?: ServiceMJ;
    sousService?: SousServiceMJ;
    couleur?: Couleur;
}

export interface ServiceMJ {
    id: number;
    libelle: string;
    selected?: boolean;
    codeSrj?: string;
    sousServices?: SousServiceMJ[];
}

export interface SousServiceMJ {
    id?: number;
    serviceId: number;
    serviceLibelle?: string;
    favori?: boolean;
    libelle: string;
    deletable?: boolean;
}

export interface Couleur {
    id?: number;
    libelle: string;
    code: string;
    codeSrj: string;
    dateCreation?: Date;
    deletable?: boolean;
}

export enum ServiceSortType {
    SERVICE_ASC = 'SERVICE_ASC',
    SERVICE_DESC = 'SERVICE_DESC',
    SOUS_SERVICE_ASC = 'SOUS_SERVICE_ASC',
    SOUS_SERVICE_DESC = 'SOUS_SERVICE_DESC',
    DATE = 'DATE'
}
