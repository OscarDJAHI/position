import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { ConsoleComponent } from './console.component';

const routes: Routes = [
    {
        path: 'console',
        component: ConsoleComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ConsoleRoutingModule {
}
