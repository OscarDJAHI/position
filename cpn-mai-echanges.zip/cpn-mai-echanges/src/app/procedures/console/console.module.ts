import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConsoleComponent } from './console.component';
import { ConsoleRoutingModule } from './console-routing.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ServiceMJComponent } from './components/service-mj/service-mj.component';
import { CouleurComponent } from './components/couleur/couleur.component';
import { OrientationComponent } from './components/orientation/orientation.component';
import { OrientationService } from './services/orientation.service';
import { ServiceSousServiceMJService } from './services/serviceSousService-mj.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CouleurService } from './services/couleur.service';
import { ConfirmationModalComponent } from './components/confirmation-modal/confirmation-modal.component';

@NgModule({
    declarations: [
        ConsoleComponent,
        ServiceMJComponent,
        CouleurComponent,
        OrientationComponent,
        ConfirmationModalComponent
    ],
    imports: [
        CommonModule,
        ConsoleRoutingModule,
        ReactiveFormsModule,
        NgbModule,
        FormsModule,
    ],
    entryComponents: [
        ConfirmationModalComponent
    ],
    providers: [
        CouleurService,
        ServiceSousServiceMJService,
        OrientationService
    ]
})
export class ConsoleModule {
}
