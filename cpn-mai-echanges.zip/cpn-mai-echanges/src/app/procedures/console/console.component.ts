import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/messaging/shared/services/data.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-console',
    templateUrl: './console.component.html',
    styleUrls: ['./console.component.scss']
})
export class ConsoleComponent implements OnInit {

    constructor(public dataService: DataService, private router: Router) {
        this.dataService.hideSideBar.emit(true);
    }

    ngOnInit() {
        this.dataService.cpnSpsLoadEmitter.emit('cpn');
    }

    navigateToMessage() {
        this.dataService.hideSideBar.emit(false);
        this.router.navigateByUrl('/messages');
    }

}
