import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProceduresRoutingModule } from './procedures-routing.module';

@NgModule({
    declarations: [],
    imports: [
        CommonModule,
        ProceduresRoutingModule
    ]
})
export class ProceduresModule {
}
