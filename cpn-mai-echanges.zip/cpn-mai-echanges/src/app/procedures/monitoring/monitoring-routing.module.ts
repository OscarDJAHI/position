import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { MonitoringComponent } from './monitoring.component';

const routes: Routes = [
    {
        path: 'monitoring',
        component: MonitoringComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class MonitoringRoutingModule {
}
