import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/messaging/shared/services/data.service';

@Component({
    selector: 'app-monitoring',
    templateUrl: './monitoring.component.html',
    styleUrls: ['./monitoring.component.scss']
})
export class MonitoringComponent implements OnInit {

    constructor(public dataService: DataService) {
        this.dataService.toggleSideBar.emit(true);
    }

    ngOnInit() {
        this.dataService.cpnSpsLoadEmitter.emit('cpn');
    }

}
