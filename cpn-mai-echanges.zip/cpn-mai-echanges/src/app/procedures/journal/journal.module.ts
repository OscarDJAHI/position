import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { JournalComponent } from './journal.component';
import { CalendrierModalComponent } from './components/calendrier-modal/calendrier-modal.component';
import { InfoModalComponent } from 'src/app/core/components/info-modal/info-modal.component';
import { DetailProcedureModalComponent } from './components/detail-procedure-modal/detail-procedure-modal.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { JournalService } from 'src/app/procedures/journal/services/journal.service';
import { JournalRoutingModule } from './journal-routing.module';
import { JdrBgColorDirective } from './directives/jdr-bg-color.directive';
import { EllipsisActiveDirective } from './directives/ellipsis-active.directive';
import { CommentaireModalComponent } from './components/commentaire-modal/commentaire-modal.component';
import { NgxUiLoaderModule } from 'ngx-ui-loader';

@NgModule({
    declarations: [
        JournalComponent,
        CalendrierModalComponent,
        InfoModalComponent,
        DetailProcedureModalComponent,
        EllipsisActiveDirective,
        JdrBgColorDirective,
        CommentaireModalComponent
    ],
    imports: [
        CommonModule,
        JournalRoutingModule,
        ReactiveFormsModule,
        FormsModule,
        NgbModule,
        NgxUiLoaderModule
    ],
    entryComponents: [
        CalendrierModalComponent,
        InfoModalComponent,
        DetailProcedureModalComponent
    ],
    providers: [
        JournalService,
    ]
})
export class JournalModule {
}
