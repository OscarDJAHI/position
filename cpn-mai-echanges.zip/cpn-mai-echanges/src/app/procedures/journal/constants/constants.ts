export const PROCEDURES_POLLING_INTERVAL = 100000;

export const PROCEDURE_STATE_LABEL = {
    TRAITE: 'Traité',
    A_TRAITER: 'À traiter',
    EN_COURS: 'En cours',
    ECHEC: 'Échec',
}

export const SCREEN_SIZE = {
    SM: 1280,
    MD: 1536,
    LG: 1920,
    XL: 2176,
}

export const COMMENT_LENGTH = {
    SM: 17,
    MD: 21,
    LG: 28,
};

export const BLANK_SELECT = '...';

export const DEFFEREMENT_LABEL = {
    O: 'oui',
    N: 'non',
}
