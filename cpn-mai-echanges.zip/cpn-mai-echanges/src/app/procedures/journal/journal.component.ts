import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

import { interval, Subscription } from 'rxjs';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as fileSaver from 'file-saver';

import { InfoModalComponent } from 'src/app/core/components/info-modal/info-modal.component';
import { BLANK_SELECT, PROCEDURE_STATE_LABEL, PROCEDURES_POLLING_INTERVAL } from './constants/constants';
import {
    Procedure,
    ProcedureEtatEnum,
    ProcedureStatusUpdated,
    ProcedureTypeEnum,
    SousServiceMJ
} from './models/journal.model';
import { CalendrierModalComponent } from './components/calendrier-modal/calendrier-modal.component';
import { DetailProcedureModalComponent } from './components/detail-procedure-modal/detail-procedure-modal.component';
import { SpsService } from 'src/app/core/services/sps/sps.service';
import { DataService } from 'src/app/messaging/shared/services/data.service';
import { JournalService } from 'src/app/procedures/journal/services/journal.service';
import { CustomUiLoader } from '../../core/services/share/custom-ui-loader';
import { BaseScrollTable } from '../../core/services/share/base-scroll-table';
import {AlertesModalService} from '../../messaging/shared/services/alertes-modal.service';
import { UtilsService } from '../../messaging/shared/services/utils.service';
import { CommentaireModalComponent } from './components/commentaire-modal/commentaire-modal.component';


@Component({
    selector: 'app-journal',
    templateUrl: './journal.component.html',
    styleUrls: ['./journal.component.scss']
})
export class JournalComponent extends BaseScrollTable implements OnInit, OnDestroy {

    INFO_PARQUET_SOURCE = 'InfoParquet';
    customUiLoaderService: CustomUiLoader;
    intervalSubscription: Subscription = new Subscription();
    intervalObservable$ = interval(PROCEDURES_POLLING_INTERVAL);
    searchProcedureForm: FormGroup;

    procedureEtatEnum = ProcedureEtatEnum;
    listSousServiceMj: SousServiceMJ[] = [];
    isCanlendarModal: boolean;
    dateDebut: string;
    dateFin: string;
    dateIconClass: string;
    selectedItemsList: Procedure[] = [];
    MAX_PROCEDURE_RECEPTION = 10;
    selectedProcedureId: number;

    constructor(
        public dataService: DataService,
        private cpnMasJournalService: JournalService,
        public ngxService: NgxUiLoaderService,
        private modalService: NgbModal,
        private spsService: SpsService,
        private alertModalService: AlertesModalService
    ) {
        super(ngxService);
    }

    ngOnInit() {
        this.dataService.toggleSideBar.emit(true);
        this.dataService.cpnSpsLoadEmitter.emit('cpn');
        this.dateIconClass = 'far fa-calendar-alt fa-spec2 text-gris';
        this.isCanlendarModal = false;
        this.initForms();
        this.initScroll('.tbody-scroll');
        this.loadServices();
        this.getProcedures();
        this.setProcedureModelView();
        window.onresize = () => {
            this.getProcedures();
        };
        this.poolingProcedureState();
    }

    setProcedureModelView() {
        this.dataService.procedureList$.subscribe(
            (data: Procedure[]) => {
                this.contentTableModelView.content = data;
            });
    }

    initForms() {
        this.searchProcedureForm = new FormGroup({
            service: new FormControl(''),
            sousService: new FormControl(''),
            unite: new FormControl(''),
            numberProcedure: new FormControl(''),
            orientation: new FormControl(''),
            multi: new FormControl(''),
            urgence: new FormControl(''),
            nomDossier: new FormControl(''),
            commentaire: new FormControl(''),
            dateDebut: new FormControl(''),
            dateFin: new FormControl(''),
            etat: new FormControl(this.procedureEtatEnum.A_TRAITER)
        });
        this.searchProcedureForm.get('sousService').disable();
    }

    resetProcedureTable() {
        this.searchProcedureForm.reset({ etat: this.procedureEtatEnum.A_TRAITER });
        this.initDateFilter();
        this.initSousServiceFilter();
        this.getProcedures();
    }

    getProcedures() {
        this.customUiLoaderService.customUiLoader('cpnLoader');
        this.searchProcedureForm.value.dateDebut = this.dateDebut;
        this.searchProcedureForm.value.dateFin = this.dateFin;
        this.cpnMasJournalService.getProcedures(this.size, this.page, this.searchProcedureForm.value).subscribe(
            data => {
                this.contentTableModelView = data;
                this.dataService.procedureList.next(this.contentTableModelView.content);
                this.openInfoModalIfNoProcedure();
            },
            error => {
                this.ngxService.stopLoader('cpnLoader');
            },
            () => {
                this.ngxService.stopLoader('cpnLoader');
            }
        );
    }

    openInfoModalIfNoProcedure() {
        if (this.contentTableModelView.content.length === 0) {
            const config = { centered: true, windowClass: 'cpn-info-modal' };
            const modal = this.modalService.open(InfoModalComponent, config);

            modal.componentInstance.message = 'Aucun résultat trouvé correspondant à votre recherche.';
            modal.result.then(
                result => {
                    if (this.isCanlendarModal) {
                        this.openCalendarModal();
                    }
                },
                error => console.log('Sorry ! Something went wrong xx', error)
            );
        }
    }

    getProcedureStateLabel(state) {
        return PROCEDURE_STATE_LABEL[state];
    }

    loadServices() {
        this.cpnMasJournalService.getServices(this.dataService.newUserInfo.idJuridiction).subscribe(
            data => {
                this.dataService.listServiceMJ = data;
            }
        );
    }

    onScrollDown() {
        const scrollLogic = this.listTableWrapper.scrollTop + this.listTableWrapper.clientHeight >= this.listTableWrapper.scrollHeight;
        if (scrollLogic && this.contentTableModelView.content.length < this.contentTableModelView.totalElements) {
            this.contentTableModelView.number = this.contentTableModelView.number + 1;
            const callback = this.cpnMasJournalService.getProcedures(String(this.contentTableModelView.size), String(this.contentTableModelView.number), this.searchProcedureForm.value);
            this.scroll(callback);
        }
    }

    poolingProcedureState() {
        this.intervalSubscription = this.intervalObservable$.subscribe(
            () => {
                const procedureIds = this.contentTableModelView.content.map(p => String(p.id));

                this.cpnMasJournalService.getProcedureStatusByIds(procedureIds).subscribe(
                    (data: ProcedureStatusUpdated[]) => {
                        data.forEach(
                            d => {
                                this.contentTableModelView.content.find(p => p.id === d.idProcedure).etat = d.etat;
                            });

                        this.dataService.procedureList.next(this.contentTableModelView.content);
                    });
            });
    }

    selectService(selectedService: string) {
        this.customUiLoaderService.customUiLoader('cpnLoader');
        if (selectedService !== BLANK_SELECT) {
            const selectedId = this.dataService.listServiceMJ.find(s => s.libelle === selectedService).id;
            this.cpnMasJournalService.getSousServicesByService(selectedId.toString()).subscribe(data => {
                this.listSousServiceMj = data;
                this.searchProcedureForm.get('sousService').enable();
            });
        } else {
            this.initSousServiceFilter();
        }
        // on réinitialise systématiquement la valeur du ss service après modification du service
        this.searchProcedureForm.get('sousService').setValue('');
        this.getProcedures();
    }

    isProcedureEchec(procedure: Procedure): boolean {
        return procedure.etat === ProcedureEtatEnum.ECHEC;
    }

    isProcedureATraiterAndManuel(procedure: Procedure): boolean {
        return procedure.etat === ProcedureEtatEnum.A_TRAITER && procedure.typeProcedure === ProcedureTypeEnum.MANUEL;
    }

    isActif(procedure: Procedure) {
        return !(this.isProcedureATraiterAndManuel(procedure) || !this.isProcedureEchec(procedure));
    }

    selectSousService() {
        this.customUiLoaderService.customUiLoader('cpnLoader');
        this.isCanlendarModal = false;
        this.getProcedures();
    }

    selectEtat() {
        this.isCanlendarModal = false;
        this.getProcedures();
    }

    putUnite() {
        this.isCanlendarModal = false;
        this.getProcedures();
    }

    putNumberProcedure() {
        this.isCanlendarModal = false;
        this.getProcedures();
    }

    putOrientation() {
        this.isCanlendarModal = false;
        this.getProcedures();
    }

    selectMulti() {
        this.isCanlendarModal = false;
        this.getProcedures();
    }

    selectUrgence() {
        this.isCanlendarModal = false;
        this.getProcedures();
    }

    putNomDossier() {
        this.isCanlendarModal = false;
        this.getProcedures();
    }

    putCommentaire() {
        this.isCanlendarModal = false;
        this.getProcedures();
    }

    openCalendarModal() {
        const config = { centered: true, windowClass: 'cpn-calendar-modal', size: 'default' };
        const modal = this.modalService.open(CalendrierModalComponent, config);

        modal.componentInstance.dateDebut = this.dateDebut;
        modal.componentInstance.dateFin = this.dateFin;
        modal.result.then(
            result => {
                this.dateDebut = result.dateDebut;
                this.dateFin = result.dateFin;
                this.dateIconClass = 'far fa-calendar-alt fa-spec2 text-blue';
                this.getProcedures();
            },
            error => {
                this.isCanlendarModal = false;
                this.initDateFilter();
                this.getProcedures();
            }
        );
    }

    detailProcedureModale(procedure: any) {
        this.customUiLoaderService.customUiLoader('cpnLoader');
        this.cpnMasJournalService.getProcedureById(String(procedure.id)).subscribe(
            data => {
                const config = { centered: true, windowClass: 'cpn-detail-procedure-modal', size: 'xl' };
                this.modalService.open(DetailProcedureModalComponent, config);
                this.dataService.procedure.next(data);
                this.ngxService.stopLoader('cpnLoader');
            });
    }

    receiveProcedure(procedure: Procedure) {
        if (this.isActif(procedure)) {
            return;
        }

        this.cpnMasJournalService.bookProcedure(Array.of(procedure.id)).subscribe(
            () => {
              procedure.etat = 'EN_COURS';
              this.spsService.openModalReceiptProcedure('CPN', Array.of(procedure));
            },
            error => {
              this.alertModalService.openErrorModal({
                title: "Traitement Procedure",
                message: UtilsService.toMessage(error)
              });
            }
          );

    }
    receiveProcedureParLot() {
            if (this.checkTooManyProcedures()) {
                this.openInfoModalIfTooManyProceduresReceptionLot();
            } else {
                this.cpnMasJournalService.bookProcedure(this.selectedItemsList.map(p => p.id)).subscribe(
                    data => {
                        if(data.alreadyBooked && data.alreadyBooked.length){
                            this.alertModalService.openErrorModal({
                                title: "Traitement Procedure",
                                message: "Les procedures suivantes sont en cours de traitement: " + data.alreadyBooked.join(",")
                              });

                            data.alreadyBooked.forEach(idProcedure=> {
                                let index = this.selectedItemsList.findIndex(p => p.id === idProcedure);
                                this.selectedItemsList.splice(index, 1);
                            });
                        }

                        let booked = data.booked;
                        if(data.booked && data.booked.length){
                            data.booked.forEach(idProcedure=> {
                                let index = this.selectedItemsList.findIndex(p => p.id === idProcedure);
                                this.selectedItemsList[index].etat = 'EN_COURS';
                            });
                        }
                        this.spsService.openModalReceiptProcedure('CPN', this.selectedItemsList);
                        this.resetCheckboxList();
                    },
                    error => {
                      this.alertModalService.openErrorModal({
                        title: "Traitement Procedure",
                        message: UtilsService.toMessage(error)
                      });
                    }
                  );
            }
        }


    private checkTooManyProcedures() {
        return this.selectedItemsList &&
            (this.selectedItemsList.length <= 1 || this.selectedItemsList.length > this.MAX_PROCEDURE_RECEPTION)
    }

    telechargementProcedure(procedureId: string) {
        this.ngxService.start();
        this.cpnMasJournalService.telechargementProcedure(procedureId).subscribe(response => {
            const contentDisposition = response.headers.get('Content-Disposition');
            const blob: Blob = new Blob([response.body], { type: 'text/json; charset=utf-8' });
            const regex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
            const matches = regex.exec(contentDisposition);
            const fileName = matches[1].replace(/['"]/g, '');
            fileSaver.saveAs(blob, fileName);
            this.ngxService.stop();
        });
    }


    changeCheckboxSelection(event: any, procedure: Procedure) {
        if (event.target.checked) {
            this.selectedItemsList.push(procedure);
        } else {
            const index = this.selectedItemsList.findIndex(p => p.id === procedure.id);
            this.selectedItemsList.splice(index, 1);
        }
    }

    isReceptionLotDisabled() {
        return this.selectedItemsList.length <= 1 || this.selectedItemsList.length > this.MAX_PROCEDURE_RECEPTION;
    }

    ngOnDestroy() {
        this.intervalSubscription.unsubscribe();
    }

    openCommentaryModal(procedure: Procedure) {
        //permet de forcer l'application de la directive appEllipsisActive après modification du commentaire
        this.selectedProcedureId = procedure.id;
        const config = { size: 'lg', centered: true };
        const modalRef = this.modalService.open(CommentaireModalComponent, config);
        modalRef.componentInstance.procedure = procedure;
        modalRef.result.then(
            () => {
                this.selectedProcedureId = -1;
            });
    }

    isProcedureInfoParquet(procedure: Procedure): boolean {
        return procedure.source === this.INFO_PARQUET_SOURCE;
    }

    private initDateFilter() {
        this.dateDebut = null;
        this.dateFin = null;
        this.dateIconClass = 'far fa-calendar-alt fa-spec2 text-gris';
    }

    private initSousServiceFilter() {
        this.listSousServiceMj = [];
        this.searchProcedureForm.get('sousService').disable();
    }

    private resetCheckboxList() {
        this.selectedItemsList = [];
        this.getProcedures();
    }

    private openInfoModalIfTooManyProceduresReceptionLot() {
        const config = { centered: true, windowClass: 'cpn-info-modal' };
        const modal = this.modalService.open(InfoModalComponent, config);

        modal.componentInstance.message = this.MAX_PROCEDURE_RECEPTION + ' procédures simultanées peuvent être sélectionnées au maximun. Veuillez revoir la sélection.';

    }

}
