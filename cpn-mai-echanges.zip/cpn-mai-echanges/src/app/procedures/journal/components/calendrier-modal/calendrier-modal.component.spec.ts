import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { CalendrierModalComponent } from './calendrier-modal.component';

describe('CalendrierModalComponent', () => {
    let component: CalendrierModalComponent;
    let fixture: ComponentFixture<CalendrierModalComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [CalendrierModalComponent]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CalendrierModalComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
