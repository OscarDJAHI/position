import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal, NgbDateAdapter, NgbDateParserFormatter, NgbDatepickerI18n } from '@ng-bootstrap/ng-bootstrap';
import {
    CustomAdapter,
    CustomDateParserFormatter,
    CustomDatepickerI18n,
    I18n
} from '../../../../messaging/shared/utils/CustomDateParserFormatter';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { onlyNumbers } from '../../../../messaging/shared/utils/onlyNumbersHelper'
import { maskedDate } from '../../../../messaging/shared/utils/maskHelper'

@Component({
    selector: 'app-calendrier-modal',
    templateUrl: './calendrier-modal.component.html',
    styleUrls: ['./calendrier-modal.component.scss'],
    providers: [
        { provide: NgbDateAdapter, useClass: CustomAdapter },
        { provide: NgbDateParserFormatter, useClass: CustomDateParserFormatter },
        { provide: NgbDatepickerI18n, useClass: CustomDatepickerI18n, },
        I18n
    ]

})
export class CalendrierModalComponent implements OnInit {

    formCalendar: FormGroup;
    dateMask = maskedDate;
    numberOnly = onlyNumbers;

    @Input() dateDebut: string;
    @Input() dateFin: string;

    constructor(
        public activeModal: NgbActiveModal,
        private formBuilder: FormBuilder
    ) {
    }

    static date(c: FormControl) {
        const dateRegEx = new RegExp(/^([0-2][0-9]|(3)[0-1])(\/)(((0)[0-9])|((1)[0-2]))(\/)\d{4}$/);
        return dateRegEx.test(c.value) ? null : { date: true }
    }

    static dateBeforeValidator(control: AbstractControl) {

        if (control.get('dateDebut').value && control.get('dateFin').value
            && (!control.get('dateDebut').errors || (control.get('dateDebut').errors && !control.get('dateDebut').errors.date))
            && (!control.get('dateFin').errors || (control.get('dateFin').errors && !control.get('dateFin').errors.date))) {
            let dateParts = control.get('dateDebut').value.split("/");
            const dateDebut = new Date(+dateParts[2], +dateParts[1] - 1, +dateParts[0]);
            dateParts = control.get('dateFin').value.split("/");
            const dateFin = new Date(+dateParts[2], +dateParts[1] - 1, +dateParts[0]);

            if (dateDebut > dateFin) {
                control.get('dateFin').setErrors({ DateFinBeforeDebut: true });
            } else {
                control.get('dateFin').setErrors({ DateFinBeforeDebut: false });
            }
        } else {
            let errors = control.get('dateFin').errors;
            if (errors) {
                errors.DateFinBeforeDebut = false;
            } else {
                errors = { DateFinBeforeDebut: false };
            }
            control.get('dateFin').setErrors(errors);
        }
    }

    static convertStringToDate(date: string) {
        let dateParts = date.split("/");
        return new Date(+dateParts[2], +dateParts[1] - 1, +dateParts[0]);
    }

    ngOnInit() {
        this.formCalendar = this.formBuilder.group({
            dateDebut: new FormControl(this.dateDebut, [Validators.compose([CalendrierModalComponent.date])]),
            dateFin: new FormControl(this.dateFin, [Validators.compose([CalendrierModalComponent.date])]),
        },
            {
                validator: CalendrierModalComponent.dateBeforeValidator
            });
    }

    submitForm() {
        this.activeModal.close(this.formCalendar.value);
    }

    isDateValid(controlDate: string) {
        return this.formCalendar.controls[controlDate].value &&
            this.formCalendar.controls[controlDate].dirty &&
            this.formCalendar.controls[controlDate].errors &&
            this.formCalendar.controls[controlDate].errors.date;
    }

    isFormValid() {
        let atLeastOneField = this.formCalendar.get('dateDebut').value || this.formCalendar.get('dateFin').value;
        let dateDebutValid = !this.formCalendar.get('dateDebut').value || (this.formCalendar.get('dateDebut').value && !this.formCalendar.get('dateDebut').hasError('date'));
        let dateFinValid = !this.formCalendar.get('dateFin').value || (this.formCalendar.get('dateFin').value && !this.formCalendar.get('dateFin').hasError('date')
            && !this.formCalendar.get('dateFin').hasError('DateFinBeforeDebut'));
        return atLeastOneField && dateDebutValid && dateFinValid;
    }
}
