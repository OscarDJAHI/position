import { Component, OnInit, Input } from '@angular/core';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Procedure } from '../../models/journal.model';
import { JournalService } from '../../services/journal.service';
import { AlertesModalService } from 'src/app/messaging/shared/services/alertes-modal.service';
import { AlertModalContent } from 'src/app/messaging/shared/models/alerte-modal-content.model';

@Component({
  selector: 'app-commentaire-modal',
  templateUrl: './commentaire-modal.component.html',
  styleUrls: ['./commentaire-modal.component.scss']
})
export class CommentaireModalComponent implements OnInit {

  MAX_COMMENTAIRE_CHAR_LENGTH = 500;
  MAX_LENGTH_ERROR_MSG = `Le commentaire est trop long. Veuillez ne pas dépasser ${this.MAX_COMMENTAIRE_CHAR_LENGTH} caractères.`;
  VALIDATION_MSG = 'Votre commentaire a bien été enregistré !'

  @Input()
  procedure: Procedure;

  commentaireForm: FormGroup;
  alertModalContent: AlertModalContent = {title: '', message: ''};

  constructor(private ngxService: NgxUiLoaderService,
              public activeModal: NgbActiveModal,
              private alertModalService: AlertesModalService,
              private journalService: JournalService) { }

  ngOnInit(): void {
    this.commentaireForm = new FormGroup({
        commentaireText: new FormControl(this.procedure.commentaire, Validators.maxLength(this.MAX_COMMENTAIRE_CHAR_LENGTH)),
    });
  }

  checkLength(): boolean {
      return this.commentaireForm.get("commentaireText").value.length > this.MAX_COMMENTAIRE_CHAR_LENGTH;
  }

  submitForm() {
    this.ngxService.startLoader('commentaire-loader');
    this.procedure.commentaire = this.commentaireForm.get("commentaireText").value;
    this.journalService.updateCommentary(this.procedure.id.toString(), this.procedure.commentaire).subscribe(
        () => {
            this.handleSuccess();
        },
        error => {
            this.handleError(error);
        }
    )
  }

  private handleSuccess() {
    this.ngxService.stopLoader('commentaire-loader');
    this.activeModal.close();

    this.alertModalContent.message = this.VALIDATION_MSG;
    this.alertModalService.openSuccessModal(this.alertModalContent);
}

  private handleError(error: any) {
    this.ngxService.stopLoader('commentaire-loader');

    this.activeModal.close();
    this.alertModalService.openGenericErrorModal();
}
}
