import { Component, OnInit } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DataService } from 'src/app/messaging/shared/services/data.service';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { Procedure, ProcedureFichier, ProcedureHistoEtat, ProcedureIssue } from '../../models/journal.model';
import { PROCEDURE_STATE_LABEL, DEFFEREMENT_LABEL } from '../../constants/constants';
import { JournalService } from '../../services/journal.service';
import { AttachmentDisplayComponent } from 'src/app/messaging/message/components/attachment-display/attachment-display.component';
import { InfoModalComponent } from 'src/app/core/components/info-modal/info-modal.component';

@Component({
    selector: 'app-detail-procedure-modal',
    templateUrl: './detail-procedure-modal.component.html',
    styleUrls: ['./detail-procedure-modal.component.scss']
})
export class DetailProcedureModalComponent implements OnInit {

    procedure: Procedure;
    procedureIssues: ProcedureIssue[] = [];
    procedureFichiers: ProcedureFichier[] = [];
    procedureHistoEtats: ProcedureHistoEtat[] = [];

    constructor(public activeModal: NgbActiveModal,
                public dataService: DataService,
                private ngxService: NgxUiLoaderService,
                private journalService: JournalService,
                private modalService: NgbModal,) {
    }

    ngOnInit() {
        this.getProcedure();
    }

    getProcedure() {
        this.dataService.procedure$.subscribe(
            data => {
                this.procedure = data;
                this.procedureIssues = this.orderProcedureIssuesByPriorite(this.procedure.procedureIssues);
                this.procedureFichiers = this.procedure.procedureFichiers;
                this.procedureHistoEtats = this.procedure.procedureHistoEtats;
                this.ngxService.stopLoader('searchLoader');
            },
            error => {
                this.ngxService.stopLoader('searchLoader');
            },
            () => {
                this.ngxService.stopLoader('searchLoader');
            });
    }
    orderProcedureIssuesByPriorite(procedureIssues: ProcedureIssue[]) {
        return procedureIssues.sort((a, b) => a.priorite.localeCompare(b.priorite));
    }

    getProcedureStateLabel(state) {
        return PROCEDURE_STATE_LABEL[state];
    }

    openPreview(fichier: ProcedureFichier ) {
        if (fichier.uri) {
            const options = { centered: true, size: 'xl', windowClass: 'cpn-preview-modal' };
            const urlPreview = this.journalService.getPreviewFileUrl(fichier.uri);
            const modal = this.modalService.open(AttachmentDisplayComponent, options);
            modal.componentInstance.data = urlPreview;
            modal.componentInstance.fileName = fichier.idPdf;
        } else {
            const config = { centered: true, windowClass: 'cpn-info-modal' };
            const modal = this.modalService.open(InfoModalComponent, config);

            modal.componentInstance.message = 'Contenu du fichier indisponible !';

        }
    }

    getDefferementLabel(code) {
        return DEFFEREMENT_LABEL[code];
    }
}
