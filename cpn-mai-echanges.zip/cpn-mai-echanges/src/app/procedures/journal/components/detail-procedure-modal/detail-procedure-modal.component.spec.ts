import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { DetailProcedureModalComponent } from './detail-procedure-modal.component';

describe('DetailProcedureModalComponent', () => {
    let component: DetailProcedureModalComponent;
    let fixture: ComponentFixture<DetailProcedureModalComponent>;

    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
                declarations: [DetailProcedureModalComponent]
            })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(DetailProcedureModalComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
