import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ServiceMJ, SousServiceMJ, StatusBooking, Procedure } from 'src/app/procedures/journal/models/journal.model';
import { tap } from 'rxjs/operators';
import { BLANK_SELECT } from 'src/app/procedures/journal/constants/constants';
import { DomSanitizer } from '@angular/platform-browser';

@Injectable()
export class JournalService {

    listServiceMJ: ServiceMJ[] = [];

    constructor(private http: HttpClient,
                private sanitizer: DomSanitizer) {
    }

    getProcedures(size: string, page: string, searchForm: any): Observable<any> {
        const params = { size, page };
        if (searchForm.service && searchForm.service != BLANK_SELECT) {
            params['service'] = searchForm.service;
        }
        if (searchForm.sousService && searchForm.sousService != BLANK_SELECT) {
            params['sousService'] = searchForm.sousService;
        }
        if (searchForm.unite) {
            params['unite'] = searchForm.unite;
        }
        if (searchForm.numberProcedure) {
            params['numeroProcedure'] = searchForm.numberProcedure;
        }
        if (searchForm.orientation) {
            params['orientation'] = searchForm.orientation;
        }
        if (searchForm.multi) {
            params['multi'] = searchForm.multi;
        }
        if (searchForm.urgence) {
            params['urgence'] = searchForm.urgence;
        }
        if (searchForm.nomDossier) {
            params['nomDossier'] = searchForm.nomDossier;
        }
        if (searchForm.commentaire) {
            params['commentaire'] = searchForm.commentaire;
        }
        if (searchForm.etat && searchForm.etat != BLANK_SELECT) {
            params['etat'] = searchForm.etat;
        }
        if (searchForm.dateDebut) {
            params['dateDebut'] = searchForm.dateDebut;
        }
        if (searchForm.dateFin) {
            params['dateFin'] = searchForm.dateFin;
        }

        return this.http.get(`${environment.REST_URL_GET_PROCEDURE}`, { params });
    }

    getProcedureStatusByIds(ids: string[]): Observable<any> {
        return this.http.get(`${environment.REST_URL_GET_PROCEDURE_STATUS_BY_IDS}`, { params: { idProcedures: ids.join() } });
    }

    getServices(codeSrj: String): Observable<ServiceMJ[]> {
        if (this.listServiceMJ && this.listServiceMJ.length) {
            return of(this.listServiceMJ);
        }

        return this.http.get<ServiceMJ[]>(`${environment.REST_URL_GET_ALL_SERVICES}/${codeSrj}`)
            .pipe(
                tap((data) => {
                    this.listServiceMJ = data;
                }));
    }

    getSousServicesByService(serviceId: String): Observable<SousServiceMJ[]> {
        return this.http.get<SousServiceMJ[]>(`${environment.REST_URL_GET_ALL_SOUS_SERVICES_BY_SERVICE}/${serviceId}`);
    }

    getProcedureById(id: string): Observable<any> {
        return this.http.get(`${environment.REST_URL_GET_PROCEDURE_BY_ID}/${id}`);
    }

    telechargementProcedure(id: string): Observable<HttpResponse<Blob>> {
        const url = environment.REST_URL_DOWNLOAD_PROCEDURE.replace('{id}', id);
        return this.http.get(url, { responseType: 'blob', observe: 'response' });
    }

    bookProcedure(ids: number[]):  Observable<StatusBooking> {
		const url = environment.REST_URL_BOOK_PROCEDURE;
		return this.http.put<StatusBooking>(url, {"ids_to_book": ids});
	}

    getFilesByProcedureId(id: number): Observable<any> {
        return this.http.get(`${environment.REST_URL_GET_FILES_BY_PROCEDURE_ID}/${id}`);
    }

    getPreviewFileUrl(uri: string) {
        return this.sanitizer.bypassSecurityTrustResourceUrl(`${environment.REST_URL_GET_PREVIEW_PROCEDURE_FILE}/${uri}`);
    }

    updateCommentary(id: string, text: string):  Observable<any> {
        const url = environment.REST_URL_PUT_PROCEDURE_COMMENTARY.replace('{id}', id);
		return this.http.put<any>(url, {text});
	}
}
