export interface Procedure {
    id: number;
    etat: string;
    numeroProcedure: string;
    codeSrj: string;
    libelleUnite: string;
    commentaire: string;
    dateCreation: string;
    nomDossier: string;
    multi: boolean;
    urgence: boolean;
    orientation: string;
    codeOrientation: string;
    service: string;
    sousService: string;
    couleur: string;
    typeProcedure: string;
    source: string;

    uri: string;
    version?: string;
    idSps?: string;
    codeUnite?: string;
    anneeProcedure?: string;
    numeroProcedureFormate?: string;
    refSource?: RefSourceDTO;
    procedureIssues?: ProcedureIssue[];
    procedureHistoEtats?: ProcedureHistoEtat[];
    procedureFichiers?: ProcedureFichier[];
    dateExtraction?: string;
    dateTransmission?: string;
    dateCloture?: string;
    codeInsee?: string;
    juridiction?: string;
    idj?: string;
}

export interface ProcedureHistoEtat {
    id: number;
    etat: string;
    dateEtat: string;
    uidUtilisateur: string;
    procedureId: string;
}

export interface ProcedureIssue {
    id: number;
    defferement: string;
    modePoursuite: string;
    priorite: string;
    procedureId: number;
    orientation: OrientationDTO;
    estPrioritaire: boolean;
}

export interface ProcedureFichier {
    id: number;
    idPdf: string;
    procedureId: number;
    uri: string;
}

export interface RefSourceDTO {
    id: number;
    libelle: string;
    codeSrj: string;
    libelleCourt: string;
}

export interface OrientationDTO {
    id: number;
    code: string;
    libelle: string;
    service: ServiceMJ;
    sousService: SousServiceMJ;
    couleur: any;
    codeSrj: string;
}

export interface ServiceMJ {
    id: number;
    libelle: string;
}

export interface SousServiceMJ {
    id: number;
    idService: number;
    libelle: string;
}

export enum ProcedureEtatEnum {
    TRAITE = 'TRAITE',
    A_TRAITER = 'A_TRAITER',
    EN_COURS = 'EN_COURS',
    ECHEC = 'ECHEC',
}

export enum ProcedureTypeEnum {
    MANUEL = 'MANUEL',
    AUTO = 'AUTO',
}

export interface ProcedureStatusUpdated {
    idProcedure: number;
    etat: string;
}

export interface StatusBooking {
    message: string;
    booked: number[];
    alreadyBooked: number[];
}
