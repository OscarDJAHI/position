import { Directive, ElementRef, OnInit } from '@angular/core';

@Directive({
    selector: '[appEllipsisActive]'
})
export class EllipsisActiveDirective implements OnInit {
    constructor(private el: ElementRef) {
    }

    ngOnInit(): void {
        setTimeout(() => {
            if (this.el.nativeElement.offsetWidth < this.el.nativeElement.scrollWidth) {
                const tooltipElt: HTMLElement = document.querySelector('.procedure-comment-tooltip');

                this.el.nativeElement.addEventListener('mouseenter', () => {
                    const cpnHeader: HTMLElement = document.querySelector('.cpn-header');
                    const cpnSideBarMini: HTMLElement = document.querySelector('.sidebar-mini');
                    const elementRec = this.el.nativeElement.getBoundingClientRect();
                    const tooltipMargin = 5;

                    tooltipElt.style.top = elementRec.top - cpnHeader.clientHeight + elementRec.height + tooltipMargin + window.scrollY + 'px';
                    tooltipElt.style.left = elementRec.left - cpnSideBarMini.clientWidth - 30 + window.scrollX + 'px';

                    tooltipElt.style.display = 'block';
                    tooltipElt.innerHTML = this.el.nativeElement.innerHTML;
                });

                this.el.nativeElement.addEventListener('mouseleave', () => {
                    tooltipElt.style.display = 'none';
                });

                this.el.nativeElement.addEventListener('dblclick', () => {
                    tooltipElt.style.display = 'none';
                });
            }
        }, 1000);
    }
}
