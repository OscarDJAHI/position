// Karma configuration file, see link for more information
// https://karma-runner.github.io/1.0/config/configuration-file.html

module.exports = function (config) {
  config.set({
    basePath: '',
    frameworks: ['jasmine', '@angular-devkit/build-angular'],
    plugins: [
      require('karma-jasmine'),
      require('karma-firefox-launcher'),
      require('karma-jasmine-html-reporter'),
      require('karma-coverage-istanbul-reporter'),
      require('@angular-devkit/build-angular/plugins/karma')
    ],
    client: {
      clearContext: false, // leave Jasmine Spec Runner output visible in browser
      jasmine: {
        random: false
      }
    },
    files: [
      { pattern: './node_modules/jquery/dist/jquery.min.js', watched: false },  
      { pattern: './node_modules/jstree/dist/jstree.min.js', watched: false },  
      { pattern: './src/test.ts', watched: false }
    ],
    coverageIstanbulReporter: {
      dir: require('path').join(__dirname, './coverage/bpn-mai'),
      reports: ['html', 'lcovonly', 'text-summary'],
      fixWebpackSourcePaths: false
    },
    reporters: ['progress', 'kjhtml'],
    port: 9876,
    colors: true,
    logLevel: config.LOG_INFO,
    autoWatch: true,
    browsers: ['Firefox'],
    singleRun: false,
    restartOnFileChange: true
  });
};
